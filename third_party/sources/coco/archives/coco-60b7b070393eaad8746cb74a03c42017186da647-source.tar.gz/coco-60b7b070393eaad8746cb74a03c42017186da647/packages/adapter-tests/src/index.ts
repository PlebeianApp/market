import { Amount, deriveKeysetId, type Token } from '@cashu/cashu-ts';
import { initializeCoco, type Manager } from '@cashu/coco-core';
import {
  type Mint,
  type Keyset,
  type CoreProof,
  type Repositories,
  type MeltOperation,
  type MintQuote,
  type MeltQuote,
  type QuoteIdentity,
  type MintQuoteRef,
  type MeltQuoteRef,
  type MintOperation,
  type PaymentRequestReceiveAttempt,
  type PaymentRequestReceiveOperation,
  type ReceiveOperation,
  type SendOperation,
  type AuthSession,
  type KeypairPurpose,
  type Keypair,
  type WalletAuthorityIdentity,
  DerivationIndexExhaustedError,
  QuoteIdentityConflictError,
  RepositoryTransactionConflictError,
  WalletAuthorityConflictError,
  WalletAuthorityNotAcquiredError,
  WalletAuthorityValidationError,
  getRepositoryFacadeMethods,
  isRepositoryMutation,
} from '@cashu/coco-core/adapter';

/** Creates one initialized, isolated repository root for a contract test. */
export type TransactionFactory<TRepositories extends Repositories = Repositories> = () => Promise<{
  repositories: TRepositories;
  dispose(): Promise<void>;
}>;

/** Creates two repository references backed by the same physical Wallet store. */
export type SharedTransactionFactory<TRepositories extends Repositories = Repositories> =
  () => Promise<{
    first: TRepositories;
    second: TRepositories;
    dispose(): Promise<void>;
  }>;

/** Configuration shared by repository adapter contract suites. */
export type ContractOptions<TRepositories extends Repositories = Repositories> = {
  /** Creates a fresh repository root for each contract case. */
  createRepositories: TransactionFactory<TRepositories>;
  /** Enables cross-root concurrency cases against one physical Wallet store. */
  createSharedRepositories?: SharedTransactionFactory<TRepositories>;
  /** Supplies independent roots when same-root ambient context cannot model root-operation probes. */
  createIsolationRepositories?: SharedTransactionFactory<TRepositories>;
  /** Keeps adapters with auto-closing transactions alive until the supplied release settles. */
  holdTransactionOpen?: (release: Promise<void>) => Promise<void>;
  /** Enables cases asserting that root operations cannot observe or join staged transaction work. */
  testConcurrentRootOperationIsolation?: boolean;
  /** Enables the case asserting writer ownership is acquired before callback entry. */
  testWriterOwnershipAtEntry?: boolean;
};

export type KeypairAllocationContractOptions<TRepositories extends Repositories = Repositories> = {
  createRepositories: TransactionFactory<TRepositories>;
  createSharedRepositories?: SharedTransactionFactory<TRepositories>;
};

export type RepositoryConstructionIntrinsicContractOptions<
  TRepositories extends Repositories = Repositories,
> = {
  constructRepositories(): {
    repositories: TRepositories;
    dispose(): Promise<void> | void;
  };
};

export type RepositoryInvocationIntrinsicContractOptions<
  TRepositories extends Repositories = Repositories,
> = {
  label?: string;
  constructRepositories():
    | {
        repositories: TRepositories;
        dispose(): Promise<void> | void;
      }
    | Promise<{
        repositories: TRepositories;
        dispose(): Promise<void> | void;
      }>;
};

const receiveContractMint = 'https://receive-id-contract.test';
const receiveContractKeys = {
  '1': '0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798',
  '2': '02c6047f9441ed7d6d3045406e95c07cd85c778e4b8cef3ca7abac09b95c709ee5',
};
const receiveContractKeysetId = deriveKeysetId(receiveContractKeys, { unit: 'sat' });

function receiveContractToken(
  secret = 'receive-contract-input',
  options: { mint?: string; unit?: string; amount?: number } = {},
): Token {
  const amount = options.amount ?? 1;
  return {
    mint: options.mint ?? receiveContractMint,
    unit: options.unit ?? 'sat',
    proofs: [
      {
        id: receiveContractKeysetId,
        amount: Amount.from(amount),
        secret,
        C: receiveContractKeys[amount === 2 ? '2' : '1']!,
      },
    ],
  };
}

async function seedReceiveContract(repositories: Repositories): Promise<void> {
  const now = Math.floor(Date.now() / 1000);
  await repositories.mintRepository.addNewMint({
    mintUrl: receiveContractMint,
    name: 'Receive ID Contract Mint',
    trusted: true,
    mintInfo: {
      name: 'Receive ID Contract Mint',
      version: '1.0.0',
      pubkey: '',
      contact: [],
      nuts: {
        '4': { methods: [], disabled: false },
        '5': { methods: [], disabled: false },
      },
    },
    createdAt: now,
    updatedAt: now,
  });
  await repositories.keysetRepository.addKeyset({
    mintUrl: receiveContractMint,
    id: receiveContractKeysetId,
    unit: 'sat',
    keypairs: receiveContractKeys,
    active: true,
    feePpk: 0,
  });
}

/** Public Receive PREPARE idempotency and atomic reservation contract. Five cases per adapter. */
export function runCallerOwnedReceiveOperationIdContract(
  options: {
    createRepositories: TransactionFactory;
    createIndependentRepositories: SharedTransactionFactory;
  },
  runner: ContractRunner,
): void {
  const { describe, it, expect } = runner;
  const makeManager = async (repositories: Repositories): Promise<Manager> => {
    return initializeCoco({
      repo: repositories,
      seedGetter: async () => new Uint8Array(64).fill(1),
      watchers: {
        mintOperationWatcher: { disabled: true },
        proofStateWatcher: { disabled: true },
        meltQuoteWatcher: { disabled: true },
      },
      processors: {
        mintOperationProcessor: { disabled: true },
        meltSettlementProcessor: { disabled: true },
      },
    });
  };

  describe('caller-owned Receive operation ID contract', () => {
    it('replays the exact operation sequentially, after restart, and after terminal rollback', async () => {
      const {
        first: repositories,
        second: restartRepositories,
        dispose,
      } = await options.createIndependentRepositories();
      let firstManager: Manager | undefined;
      let restarted: Manager | undefined;
      try {
        firstManager = await makeManager(repositories);
        await seedReceiveContract(repositories);
        const token = receiveContractToken('lifecycle-input');
        const first = await firstManager.ops.receive.prepare({
          token,
          operationId: 'receive-lifecycle-command',
        });
        const counter = await repositories.counterRepository.getCounter(
          receiveContractMint,
          receiveContractKeysetId,
        );
        expect(
          JSON.stringify(
            await firstManager.ops.receive.prepare({
              token,
              operationId: 'receive-lifecycle-command',
            }),
          ),
        ).toBe(JSON.stringify(first));

        restarted = await makeManager(restartRepositories);
        expect(
          JSON.stringify(
            await restarted.ops.receive.prepare({
              token,
              operationId: 'receive-lifecycle-command',
            }),
          ),
        ).toBe(JSON.stringify(first));
        await restarted.ops.receive.cancel(first.id, 'contract terminal replay');
        const terminal = await restarted.ops.receive.prepare({
          token,
          operationId: 'receive-lifecycle-command',
        });
        expect(terminal.state).toBe('rolled_back');
        expect(
          JSON.stringify(
            await restartRepositories.counterRepository.getCounter(
              receiveContractMint,
              receiveContractKeysetId,
            ),
          ),
        ).toBe(JSON.stringify(counter));
      } finally {
        await restarted?.dispose();
        if (firstManager) {
          // The restart root advanced durable authority, so the crashed root can no longer prove
          // exact release. Disposal must report that stale cleanup and preserve its attachment.
          await expectThrowsNamed(() => firstManager!.dispose(), 'AggregateError', expect);
        }
        await dispose();
      }
    });

    it('converges concurrent same-ID retries on one allocation', async () => {
      const { repositories, dispose } = await options.createRepositories();
      let manager: Manager | undefined;
      try {
        manager = await makeManager(repositories);
        await seedReceiveContract(repositories);
        const request = {
          token: receiveContractToken('concurrent-same-id'),
          operationId: 'receive-concurrent-command',
        };
        const [first, second] = await Promise.all([
          manager.ops.receive.prepare(request),
          manager.ops.receive.prepare(request),
        ]);
        expect(JSON.stringify(first)).toBe(JSON.stringify(second));
        expect(
          (await repositories.receiveOperationRepository.getByState('prepared')).filter(
            (operation) => operation.id === request.operationId,
          ),
        ).toHaveLength(1);
        expect(
          (
            await repositories.counterRepository.getCounter(
              receiveContractMint,
              receiveContractKeysetId,
            )
          )?.counter,
        ).toBe(1);
      } finally {
        await manager?.dispose();
        await dispose();
      }
    });

    it('rejects mint, unit, amount, and input-set conflicts without consuming another counter', async () => {
      const { repositories, dispose } = await options.createRepositories();
      let manager: Manager | undefined;
      try {
        manager = await makeManager(repositories);
        await seedReceiveContract(repositories);
        const operationId = 'receive-conflict-command';
        await manager.ops.receive.prepare({
          token: receiveContractToken('conflict-original'),
          operationId,
        });
        const before = await repositories.counterRepository.getCounter(
          receiveContractMint,
          receiveContractKeysetId,
        );
        const conflicts = [
          receiveContractToken('conflict-original', { mint: 'https://other-mint.test' }),
          receiveContractToken('conflict-original', { unit: 'usd' }),
          receiveContractToken('conflict-original', { amount: 2 }),
          receiveContractToken('conflict-other-input'),
        ];
        for (const token of conflicts) {
          await expectThrowsNamed(
            () => manager!.ops.receive.prepare({ token, operationId }),
            'ReceiveOperationConflictError',
            expect,
          );
        }
        expect(
          JSON.stringify(
            await repositories.counterRepository.getCounter(
              receiveContractMint,
              receiveContractKeysetId,
            ),
          ),
        ).toBe(JSON.stringify(before));
      } finally {
        await manager?.dispose();
        await dispose();
      }
    });

    it('rejects a cross-operation-class ID collision before creating a Receive row', async () => {
      const { repositories, dispose } = await options.createRepositories();
      let manager: Manager | undefined;
      try {
        manager = await makeManager(repositories);
        await seedReceiveContract(repositories);
        const operationId = 'receive-cross-class-command';
        await repositories.sendOperationRepository.create(
          createDummyPreparedSendOperation({ id: operationId }),
        );
        await expectThrowsNamed(
          () =>
            manager!.ops.receive.prepare({
              token: receiveContractToken('cross-class-input'),
              operationId,
            }),
          'OperationIdConflictError',
          expect,
        );
        expect(await repositories.receiveOperationRepository.getById(operationId)).toBe(null);
        expect(
          await repositories.counterRepository.getCounter(
            receiveContractMint,
            receiveContractKeysetId,
          ),
        ).toBe(null);
      } finally {
        await manager?.dispose();
        await dispose();
      }
    });

    it('atomically lets only one different ID reserve the same input proof set', async () => {
      const { repositories, dispose } = await options.createRepositories();
      let manager: Manager | undefined;
      try {
        manager = await makeManager(repositories);
        await seedReceiveContract(repositories);
        const token = receiveContractToken('competing-input');
        const outcomes = await Promise.allSettled([
          manager.ops.receive.prepare({ token, operationId: 'receive-competing-a' }),
          manager.ops.receive.prepare({ token, operationId: 'receive-competing-b' }),
        ]);
        expect(outcomes.filter((outcome) => outcome.status === 'fulfilled')).toHaveLength(1);
        expect(outcomes.filter((outcome) => outcome.status === 'rejected')).toHaveLength(1);
        expect(await repositories.receiveOperationRepository.getByState('prepared')).toHaveLength(
          1,
        );
        expect(
          (
            await repositories.counterRepository.getCounter(
              receiveContractMint,
              receiveContractKeysetId,
            )
          )?.counter,
        ).toBe(1);
      } finally {
        await manager?.dispose();
        await dispose();
      }
    });
  });
}

/** Storage-level, symmetric ownership contract for every monetary operation class. */
export function runOperationIdOwnershipContract(
  options: { createRepositories: TransactionFactory },
  runner: ContractRunner,
): void {
  const { describe, it, expect } = runner;
  const classes = [
    'send',
    'receive',
    'mint',
    'melt',
    'payment-request-receive',
    'payment-request-receive-attempt',
  ] as const;
  type Owner = (typeof classes)[number];

  const create = async (repositories: Repositories, owner: Owner, id: string): Promise<void> => {
    switch (owner) {
      case 'send':
        return repositories.sendOperationRepository.create(
          createDummyPreparedSendOperation({ id }),
        );
      case 'receive':
        return repositories.receiveOperationRepository.create({
          ...createDummyReceiveOperation(),
          id,
        });
      case 'mint':
        return repositories.mintOperationRepository.create(
          createDummyMintOperation({ id, quoteId: `quote-${id}` }),
        );
      case 'melt':
        return repositories.meltOperationRepository.create(
          createDummyMeltOperation({ id, quoteId: `quote-${id}` }),
        );
      case 'payment-request-receive':
        return repositories.paymentRequestReceiveOperationRepository.create(
          createDummyPaymentRequestReceiveOperation({ id, requestId: `request-${id}` }),
        );
      case 'payment-request-receive-attempt':
        return repositories.paymentRequestReceiveAttemptRepository.create(
          createDummyPaymentRequestReceiveAttempt({
            id,
            requestOperationId: `request-operation-${id}`,
            requestId: `request-${id}`,
            transportMessageId: `message-${id}`,
            payloadHash: `payload-${id}`,
          }),
        );
    }
  };

  const get = (repositories: Repositories, owner: Owner, id: string): Promise<unknown | null> => {
    switch (owner) {
      case 'send':
        return repositories.sendOperationRepository.getById(id);
      case 'receive':
        return repositories.receiveOperationRepository.getById(id);
      case 'mint':
        return repositories.mintOperationRepository.getById(id);
      case 'melt':
        return repositories.meltOperationRepository.getById(id);
      case 'payment-request-receive':
        return repositories.paymentRequestReceiveOperationRepository.getById(id);
      case 'payment-request-receive-attempt':
        return repositories.paymentRequestReceiveAttemptRepository.getById(id);
    }
  };

  describe('global operation-ID ownership contract', () => {
    for (let leftIndex = 0; leftIndex < classes.length; leftIndex++) {
      for (let rightIndex = leftIndex + 1; rightIndex < classes.length; rightIndex++) {
        const left = classes[leftIndex]!;
        const right = classes[rightIndex]!;
        it(`atomically resolves concurrent ${left} vs ${right} ownership`, async () => {
          const { repositories, dispose } = await options.createRepositories();
          const id = `ownership-${left}-${right}`;
          try {
            const outcomes = await Promise.allSettled([
              create(repositories, left, id),
              create(repositories, right, id),
            ]);
            expect(outcomes.filter((outcome) => outcome.status === 'fulfilled')).toHaveLength(1);
            const rejected = outcomes.find((outcome) => outcome.status === 'rejected');
            expect(rejected?.status).toBe('rejected');
            if (rejected?.status === 'rejected') {
              expect((rejected.reason as Error).name).toBe('OperationIdConflictError');
            }
            const rows = await Promise.all([
              get(repositories, left, id),
              get(repositories, right, id),
            ]);
            expect(rows.filter(Boolean)).toHaveLength(1);
          } finally {
            await dispose();
          }
        });
      }
    }

    it('does not reuse ownership after terminal-row deletion', async () => {
      const { repositories, dispose } = await options.createRepositories();
      const id = 'ownership-never-reused';
      try {
        await create(repositories, 'receive', id);
        await repositories.receiveOperationRepository.delete(id);
        await expectThrowsNamed(
          () => create(repositories, 'receive', id),
          'OperationIdConflictError',
          expect,
        );
        await expectThrowsNamed(
          () => create(repositories, 'send', id),
          'OperationIdConflictError',
          expect,
        );
        expect(await repositories.sendOperationRepository.getById(id)).toBe(null);
      } finally {
        await dispose();
      }
    });
  });
}

/**
 * Exercise the durable capability fence at the common monetary transaction gateway.
 *
 * The delayed-response case deliberately pauses outside the database transaction, immediately
 * before applying a remote result. This models the point at which another runtime may take over;
 * once a database transaction begins, the authority row participates in the same writer lock.
 */
export function runWalletAuthorityContract(
  options: { createSharedRepositories: SharedTransactionFactory },
  runner: ContractRunner,
): void {
  const { describe, it, expect } = runner;

  describe('durable Wallet authority contract', () => {
    const repositoryNames = [
      'mintRepository',
      'keyRingRepository',
      'counterRepository',
      'keysetRepository',
      'proofRepository',
      'mintQuoteRepository',
      'legacyMintQuoteRepository',
      'meltQuoteRepository',
      'historyRepository',
      'sendOperationRepository',
      'meltOperationRepository',
      'authSessionRepository',
      'mintOperationRepository',
      'receiveOperationRepository',
      'paymentRequestReceiveOperationRepository',
      'paymentRequestReceiveAttemptRepository',
    ] as const;
    const mutations = repositoryNames.flatMap((repository) =>
      getRepositoryFacadeMethods(repository)
        .filter((method) => isRepositoryMutation(repository, method))
        .map((method) => ({ repository, method })),
    );

    it('atomically attaches one Manager session to the exact repository root', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      try {
        const claimDescriptor = Object.getOwnPropertyDescriptor(first, 'claimSessionAttachment');
        const releaseDescriptor = Object.getOwnPropertyDescriptor(
          first,
          'releaseSessionAttachment',
        );
        expect(claimDescriptor?.writable).toBe(false);
        expect(claimDescriptor?.configurable).toBe(false);
        expect(releaseDescriptor?.writable).toBe(false);
        expect(releaseDescriptor?.configurable).toBe(false);

        const claim = first.claimSessionAttachment;
        const release = first.releaseSessionAttachment;
        const token = claim();
        const transparent = new Proxy(first, {});
        const boundClaim = first.claimSessionAttachment.bind(null);
        const boundRelease = first.releaseSessionAttachment.bind(null);

        expectSyncThrows(() => first.claimSessionAttachment(), expect);
        expectSyncThrows(() => transparent.claimSessionAttachment(), expect);
        expectSyncThrows(() => boundClaim(), expect);
        expect(release(Object.freeze({}))).toBe(false);
        expectSyncThrows(() => first.claimSessionAttachment(), expect);
        expect(boundRelease(token)).toBe(true);

        const successor = transparent.claimSessionAttachment();
        expect(release(token)).toBe(false);
        expectSyncThrows(() => claim(), expect);
        expect(transparent.releaseSessionAttachment(successor)).toBe(true);

        // A peer root over the same durable store owns an independent attachment slot. Durable
        // generation takeover, rather than attachment sharing, coordinates the two roots.
        const firstToken = claim();
        const peerToken = second.claimSessionAttachment();
        expect(firstToken === peerToken).toBe(false);
        expect(release(firstToken)).toBe(true);
        expect(second.releaseSessionAttachment(peerToken)).toBe(true);
      } finally {
        await dispose();
      }
    });

    async function invokeMutation(
      repositories: Repositories,
      mutation: (typeof mutations)[number],
    ): Promise<unknown> {
      const callable = repositories[mutation.repository][
        mutation.method as keyof (typeof repositories)[typeof mutation.repository]
      ] as (...args: unknown[]) => unknown;
      return Promise.resolve(callable());
    }

    it('exposes frozen null-prototype repository facades with no reflective target path', async () => {
      const { first, dispose } = await options.createSharedRepositories();
      try {
        const ownNames = Object.getOwnPropertyNames(first);
        const prototypeNames = Object.getOwnPropertyNames(Object.getPrototypeOf(first));
        for (const name of ['db', 'database', 'repositories', 'rootScope']) {
          expect(ownNames.includes(name)).toBe(false);
          expect((first as unknown as Record<string, unknown>)[name]).toBe(undefined);
        }
        for (const name of [
          'createRepositoryScope',
          'wrapRootRepository',
          'assertAuthority',
          'runExclusive',
        ]) {
          expect(prototypeNames.includes(name)).toBe(false);
        }
        for (const repository of repositoryNames) {
          const facade = first[repository] as object;
          expect(Object.getPrototypeOf(facade)).toBe(null);
          expect(Object.isFrozen(facade)).toBe(true);
          expect(Object.getOwnPropertySymbols(facade).length).toBe(0);
          expectSyncThrows(
            () => Object.setPrototypeOf(facade, { create: () => undefined }),
            expect,
          );
          expectSyncThrows(
            () => Object.defineProperty(facade, 'hostile', { get: () => undefined }),
            expect,
          );
        }
      } finally {
        await dispose();
      }
    });

    it('rejects every facade mutator when unacquired, stale, captured, bound, or released', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      try {
        for (const mutation of mutations) {
          await expectThrowsNamed(
            () => invokeMutation(first, mutation),
            WalletAuthorityNotAcquiredError.name,
            expect,
          );
        }
        await first.acquireAuthority({ namespace: 'wallet', ownerId: 'runtime-a' });
        const captured = mutations.map((mutation) => ({
          mutation,
          callable: (
            first[mutation.repository][
              mutation.method as keyof (typeof first)[typeof mutation.repository]
            ] as (...args: unknown[]) => unknown
          ).bind(first[mutation.repository]),
        }));
        await second.acquireAuthority({ namespace: 'wallet', ownerId: 'runtime-b' });
        for (const mutation of mutations) {
          await expectThrowsNamed(
            () => invokeMutation(first, mutation),
            WalletAuthorityConflictError.name,
            expect,
          );
        }
        for (const { callable } of captured) {
          await expectThrowsNamed(
            () => Promise.resolve().then(() => callable()),
            WalletAuthorityConflictError.name,
            expect,
          );
        }
        expect(await second.counterRepository.getCounter('https://mint.test', 'keyset-id')).toBe(
          null,
        );
        expect(await second.releaseAuthority()).toBe(true);
        for (const mutation of mutations) {
          await expectThrowsNamed(
            () => invokeMutation(second, mutation),
            WalletAuthorityConflictError.name,
            expect,
          );
        }
      } finally {
        await dispose();
      }
    });

    it('revokes transaction facade functions after callback completion', async () => {
      const { first, dispose } = await options.createSharedRepositories();
      try {
        await first.acquireAuthority({ namespace: 'wallet', ownerId: 'runtime-a' });
        let captured: Repositories['counterRepository'] | undefined;
        await first.withTransaction(async (scope) => {
          captured = scope.counterRepository;
          await captured.setCounter('https://mint.test', 'keyset-id', 1);
          expect(Object.getPrototypeOf(captured)).toBe(null);
          expect(Object.isFrozen(captured)).toBe(true);
        });
        await expectThrowsNamed(
          () => captured!.setCounter('https://mint.test', 'keyset-id', 2),
          'WalletAuthorityLifecycleError',
          expect,
        );
        expect(
          (await first.counterRepository.getCounter('https://mint.test', 'keyset-id'))?.counter,
        ).toBe(1);
      } finally {
        await dispose();
      }
    });

    it('rejects incomplete or non-canonical authority identities', async () => {
      const { first, dispose } = await options.createSharedRepositories();
      const invalidIdentities = [
        null,
        {},
        { namespace: '', ownerId: 'runtime-a' },
        { namespace: ' wallet', ownerId: 'runtime-a' },
        { namespace: 'wallet', ownerId: '' },
        { namespace: 'wallet', ownerId: 'runtime-a ' },
      ] as unknown as WalletAuthorityIdentity[];
      try {
        for (const identity of invalidIdentities) {
          await expectThrowsNamed(
            () => first.acquireAuthority(identity),
            WalletAuthorityValidationError.name,
            expect,
          );
        }
      } finally {
        await dispose();
      }
    });

    it('rejects an unfenced runtime before and after another runtime acquires authority', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      try {
        await expectThrowsNamed(
          () => second.counterRepository.setCounter('https://mint.test', 'keyset-id', 1),
          WalletAuthorityNotAcquiredError.name,
          expect,
        );
        await first.acquireAuthority({ namespace: 'wallet', ownerId: 'runtime-a' });
        await expectThrowsNamed(
          () => second.counterRepository.setCounter('https://mint.test', 'keyset-id', 1),
          WalletAuthorityNotAcquiredError.name,
          expect,
        );
        expect(await second.counterRepository.getCounter('https://mint.test', 'keyset-id')).toBe(
          null,
        );
      } finally {
        await dispose();
      }
    });

    it('fences a delayed remote response before any monetary mutation and lets the new owner reconcile once', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      const responseArrived = createDeferred();
      try {
        const firstAuthority = await first.acquireAuthority({
          namespace: 'wallet',
          ownerId: 'runtime-a',
        });
        const executing = {
          ...createDummyPreparedSendOperation({ id: 'delayed-request', revision: 0 }),
          state: 'executing' as const,
        };
        await first.withTransaction(async (scope) => {
          await scope.sendOperationRepository.create(executing);
          await scope.counterRepository.setCounter(executing.mintUrl, 'keyset-id', 1);
        });

        let staleCallbackEntered = false;
        const staleApply = responseArrived.promise.then(() =>
          first.withTransaction(async (scope) => {
            staleCallbackEntered = true;
            await scope.counterRepository.setCounter(executing.mintUrl, 'keyset-id', 2);
            await scope.proofRepository.saveProofs(executing.mintUrl, [
              createDummyProof({ secret: 'stale-response-proof', C: 'C-stale-response' }),
            ]);
            await scope.keyRingRepository.setPersistedKeyPair(derivedKeypair(0, 'p2pk'));
            await scope.sendOperationRepository.update({ ...executing, state: 'pending' });
          }),
        );

        const secondAuthority = await second.acquireAuthority({
          namespace: 'wallet',
          ownerId: 'runtime-b',
        });
        expect(secondAuthority.generation).toBe(firstAuthority.generation + 1);
        responseArrived.resolve();
        await expectThrowsNamed(() => staleApply, WalletAuthorityConflictError.name, expect);

        expect(staleCallbackEntered).toBe(false);
        expect(
          (await second.counterRepository.getCounter(executing.mintUrl, 'keyset-id'))?.counter,
        ).toBe(1);
        expect(
          await second.proofRepository.getProofBySecret(executing.mintUrl, 'stale-response-proof'),
        ).toBe(null);
        expect(
          await second.keyRingRepository.getPersistedKeyPair(
            derivedKeypair(0, 'p2pk').publicKeyHex,
            'p2pk',
          ),
        ).toBe(null);
        expect((await second.sendOperationRepository.getById(executing.id))?.state).toBe(
          'executing',
        );

        let recoveryApplications = 0;
        await second.withTransaction(async (scope) => {
          const durable = await scope.sendOperationRepository.getById(executing.id);
          if (!durable || durable.state !== 'executing') return;
          recoveryApplications++;
          await scope.counterRepository.setCounter(executing.mintUrl, 'keyset-id', 2);
          await scope.proofRepository.saveProofs(executing.mintUrl, [
            createDummyProof({ secret: 'recovered-response-proof', C: 'C-recovered-response' }),
          ]);
          const transitioned = await scope.sendOperationRepository.transition({
            operationId: durable.id,
            expectedState: 'executing',
            expectedRevision: durable.revision ?? 0,
            next: { ...durable, state: 'pending' },
          });
          if (!transitioned) throw new Error('exact delayed response lost its durable identity');
        });

        expect(recoveryApplications).toBe(1);
        expect((await second.sendOperationRepository.getById(executing.id))?.state).toBe('pending');
        expect(
          await second.proofRepository.getProofBySecret(
            executing.mintUrl,
            'recovered-response-proof',
          ),
        ).toBeDefined();
      } finally {
        responseArrived.resolve();
        await dispose();
      }
    });

    it('uses generations to reject an ABA return by the same owner ID', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      try {
        const original = await first.acquireAuthority({
          namespace: 'wallet',
          ownerId: 'runtime-a',
        });
        const returned = await second.acquireAuthority({
          namespace: 'wallet',
          ownerId: 'runtime-a',
        });
        expect(returned.ownerId).toBe(original.ownerId);
        expect(returned.generation).toBe(original.generation + 1);
        await expectThrowsNamed(
          () => first.counterRepository.setCounter('https://mint.test', 'keyset-id', 1),
          WalletAuthorityConflictError.name,
          expect,
        );
      } finally {
        await dispose();
      }
    });

    it('does not let a stale release clear the current authority', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      try {
        await first.acquireAuthority({ namespace: 'wallet', ownerId: 'runtime-a' });
        await second.acquireAuthority({ namespace: 'wallet', ownerId: 'runtime-b' });
        expect(await first.releaseAuthority()).toBe(false);
        await second.counterRepository.setCounter('https://mint.test', 'keyset-id', 1);
        expect(
          (await second.counterRepository.getCounter('https://mint.test', 'keyset-id'))?.counter,
        ).toBe(1);
      } finally {
        await dispose();
      }
    });

    it('binds one physical Wallet store to one stable namespace', async () => {
      const { first, second, dispose } = await options.createSharedRepositories();
      try {
        await first.acquireAuthority({ namespace: 'wallet-a', ownerId: 'runtime-a' });
        await expectThrowsNamed(
          () => second.acquireAuthority({ namespace: 'wallet-b', ownerId: 'runtime-b' }),
          WalletAuthorityValidationError.name,
          expect,
        );
      } finally {
        await dispose();
      }
    });
  });
}

/**
 * Prove repository roots, facades, and transaction scopes use descriptor intrinsics captured
 * before supported post-import code can replace the mutable globals.
 */
export function runRepositoryConstructionIntrinsicContract(
  options: RepositoryConstructionIntrinsicContractOptions,
  runner: ContractRunner,
): void {
  const { describe, it, expect } = runner;
  const repositoryNames = [
    'mintRepository',
    'keyRingRepository',
    'counterRepository',
    'keysetRepository',
    'proofRepository',
    'mintQuoteRepository',
    'legacyMintQuoteRepository',
    'meltQuoteRepository',
    'historyRepository',
    'sendOperationRepository',
    'meltOperationRepository',
    'authSessionRepository',
    'mintOperationRepository',
    'receiveOperationRepository',
    'paymentRequestReceiveOperationRepository',
    'paymentRequestReceiveAttemptRepository',
  ] as const;
  const nativeDefineProperty = Object.defineProperty;
  const nativeDefineProperties = Object.defineProperties;
  const nativeReflectDefineProperty = Reflect.defineProperty;

  const weakenDescriptor = (descriptor: PropertyDescriptor): void => {
    descriptor.configurable = true;
    if ('value' in descriptor) descriptor.writable = true;
  };

  const installPoison = (): (() => void) => {
    Object.defineProperties = ((target: object, descriptors: PropertyDescriptorMap) => {
      for (const descriptor of Object.values(descriptors)) weakenDescriptor(descriptor);
      return nativeDefineProperties(target, descriptors);
    }) as typeof Object.defineProperties;
    Object.defineProperty = ((
      target: object,
      property: PropertyKey,
      descriptor: PropertyDescriptor,
    ) => {
      weakenDescriptor(descriptor);
      return nativeDefineProperty(target, property, descriptor);
    }) as typeof Object.defineProperty;
    Reflect.defineProperty = ((
      target: object,
      property: PropertyKey,
      descriptor: PropertyDescriptor,
    ) => {
      weakenDescriptor(descriptor);
      return nativeReflectDefineProperty(target, property, descriptor);
    }) as typeof Reflect.defineProperty;
    return () => {
      Object.defineProperties = nativeDefineProperties;
      Object.defineProperty = nativeDefineProperty;
      Reflect.defineProperty = nativeReflectDefineProperty;
    };
  };

  const assertImmutableFacade = (facade: object): void => {
    expect(Object.getPrototypeOf(facade)).toBe(null);
    expect(Object.isFrozen(facade)).toBe(true);
    for (const method of Object.getOwnPropertyNames(facade)) {
      const descriptor = Object.getOwnPropertyDescriptor(facade, method);
      expect(descriptor?.configurable).toBe(false);
      expect(descriptor?.writable).toBe(false);
      expectSyncThrows(
        () => nativeDefineProperty(facade, method, { value: () => undefined }),
        expect,
      );
    }
  };

  describe('post-import repository construction intrinsic fence', () => {
    it('keeps root, facade, and transaction-scope descriptors immutable under poisoning', async () => {
      let constructed: ReturnType<typeof options.constructRepositories> | undefined;
      const restoreConstructionIntrinsics = installPoison();
      try {
        constructed = options.constructRepositories();
      } finally {
        restoreConstructionIntrinsics();
      }
      if (!constructed) throw new Error('Repository construction did not complete');
      const { repositories, dispose } = constructed;
      try {
        for (const attachment of ['claimSessionAttachment', 'releaseSessionAttachment']) {
          const descriptor = Object.getOwnPropertyDescriptor(repositories, attachment);
          expect(descriptor?.configurable).toBe(false);
          expect(descriptor?.writable).toBe(false);
          expectSyncThrows(
            () => nativeDefineProperty(repositories, attachment, { value: () => undefined }),
            expect,
          );
        }
        for (const repository of repositoryNames) {
          const descriptor = Object.getOwnPropertyDescriptor(repositories, repository);
          expect(descriptor?.configurable).toBe(false);
          expect(descriptor?.writable).toBe(false);
          assertImmutableFacade(repositories[repository]);
        }

        await repositories.init();
        await repositories.acquireAuthority({
          namespace: 'descriptor-intrinsic-contract',
          ownerId: 'contract-root',
        });
        const restoreTransactionIntrinsics = installPoison();
        try {
          await repositories.withTransaction(async (scope) => {
            for (const repository of repositoryNames) {
              const descriptor = Object.getOwnPropertyDescriptor(scope, repository);
              expect(descriptor?.configurable).toBe(false);
              expect(descriptor?.writable).toBe(false);
              assertImmutableFacade(scope[repository]);
            }
          });
        } finally {
          restoreTransactionIntrinsics();
        }
        expect(await repositories.releaseAuthority()).toBe(true);
      } finally {
        await dispose();
      }
    });
  });
}

/** Prove repository dispatch never consults post-import mutable invocation intrinsics. */
export function runRepositoryInvocationIntrinsicContract(
  options: RepositoryInvocationIntrinsicContractOptions,
  runner: ContractRunner,
): void {
  const { describe, it, expect } = runner;
  const repositoryNames = [
    'mintRepository',
    'keyRingRepository',
    'counterRepository',
    'keysetRepository',
    'proofRepository',
    'mintQuoteRepository',
    'legacyMintQuoteRepository',
    'meltQuoteRepository',
    'historyRepository',
    'sendOperationRepository',
    'meltOperationRepository',
    'authSessionRepository',
    'mintOperationRepository',
    'receiveOperationRepository',
    'paymentRequestReceiveOperationRepository',
    'paymentRequestReceiveAttemptRepository',
  ] as const;
  const trackedMethods = ['getCounter', 'getProofBySecret', 'getById'] as const;
  const nativeApplyMethod = Function.prototype.apply;
  const nativeBind = Function.prototype.bind;
  const nativeCall = Function.prototype.call;
  const nativeCreate = Object.create;
  const nativeDefineProperties = Object.defineProperties;
  const nativeDefineProperty = Object.defineProperty;
  const nativeFreeze = Object.freeze;
  const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
  const nativeGetPrototypeOf = Object.getPrototypeOf;
  const nativeKeys = Object.keys;
  const nativeReflectApply = Reflect.apply;
  const nativeReflectDefineProperty = Reflect.defineProperty;
  const nativeReflectOwnKeys = Reflect.ownKeys;

  const isTrackedProperty = (property: PropertyKey): boolean => {
    for (let index = 0; index < trackedMethods.length; index += 1) {
      if (property === trackedMethods[index]) return true;
    }
    return false;
  };

  const isRawRepository = (value: unknown): value is object => {
    if (typeof value !== 'object' || value === null) return false;
    if (nativeGetPrototypeOf(value) === null) return false;
    let owner: object | null = value;
    while (owner !== null) {
      for (let index = 0; index < trackedMethods.length; index += 1) {
        const descriptor = nativeGetOwnPropertyDescriptor(owner, trackedMethods[index]!);
        if (descriptor && 'value' in descriptor && typeof descriptor.value === 'function') {
          return true;
        }
      }
      owner = nativeGetPrototypeOf(owner);
    }
    return false;
  };

  describe(`post-import repository invocation intrinsic fence${options.label ? ` (${options.label})` : ''}`, () => {
    it('keeps raw roots and transaction implementations outside poisoned call paths', async () => {
      const capturedRaw: object[] = [];
      let substitutedMethodCalls = 0;

      const capture = (value: unknown): void => {
        if (isRawRepository(value)) capturedRaw[capturedRaw.length] = value;
        if (typeof value !== 'object' || value === null) return;
        for (let index = 0; index < repositoryNames.length; index += 1) {
          const descriptor = nativeGetOwnPropertyDescriptor(value, repositoryNames[index]!);
          if (descriptor && 'value' in descriptor && isRawRepository(descriptor.value)) {
            capturedRaw[capturedRaw.length] = descriptor.value;
          }
        }
      };

      const weaken = (descriptor: PropertyDescriptor): void => {
        descriptor.configurable = true;
        if ('value' in descriptor) descriptor.writable = true;
      };

      const installPoison = (): (() => void) => {
        Object.getOwnPropertyDescriptor = ((owner: object, property: PropertyKey) => {
          capture(owner);
          const descriptor = nativeGetOwnPropertyDescriptor(owner, property);
          if (
            isTrackedProperty(property) &&
            descriptor &&
            'value' in descriptor &&
            typeof descriptor.value === 'function' &&
            nativeGetPrototypeOf(owner) !== null
          ) {
            return {
              configurable: true,
              enumerable: descriptor.enumerable,
              writable: true,
              value: function substitutedRepositoryMethod(this: unknown) {
                substitutedMethodCalls += 1;
                capture(this);
                return Promise.resolve(null);
              },
            };
          }
          return descriptor;
        }) as typeof Object.getOwnPropertyDescriptor;
        Object.getPrototypeOf = ((value: object) => {
          capture(value);
          return nativeGetPrototypeOf(value);
        }) as typeof Object.getPrototypeOf;
        Object.keys = ((value: object) => {
          capture(value);
          return nativeKeys(value);
        }) as typeof Object.keys;
        Object.create = ((prototype: object | null, properties?: PropertyDescriptorMap) => {
          capture(prototype);
          return properties === undefined
            ? nativeCreate(prototype)
            : nativeCreate(prototype, properties);
        }) as typeof Object.create;
        Object.freeze = (<T extends Function | object>(value: T): Readonly<T> => {
          capture(value);
          return nativeFreeze(value);
        }) as typeof Object.freeze;
        Object.defineProperty = ((
          target: object,
          property: PropertyKey,
          descriptor: PropertyDescriptor,
        ) => {
          capture(target);
          weaken(descriptor);
          return nativeDefineProperty(target, property, descriptor);
        }) as typeof Object.defineProperty;
        Object.defineProperties = ((target: object, descriptors: PropertyDescriptorMap) => {
          capture(target);
          const names = nativeKeys(descriptors);
          for (let index = 0; index < names.length; index += 1) {
            const descriptor = nativeGetOwnPropertyDescriptor(descriptors, names[index]!)?.value;
            if (descriptor) weaken(descriptor as PropertyDescriptor);
          }
          return nativeDefineProperties(target, descriptors);
        }) as typeof Object.defineProperties;
        Reflect.defineProperty = ((
          target: object,
          property: PropertyKey,
          descriptor: PropertyDescriptor,
        ) => {
          capture(target);
          weaken(descriptor);
          return nativeReflectDefineProperty(target, property, descriptor);
        }) as typeof Reflect.defineProperty;
        Reflect.ownKeys = ((target: object) => {
          capture(target);
          return nativeReflectOwnKeys(target);
        }) as typeof Reflect.ownKeys;
        Reflect.apply = ((target: Function, receiver: unknown, args: ArrayLike<unknown>) => {
          capture(receiver);
          for (let index = 0; index < args.length; index += 1) capture(args[index]);
          return nativeReflectApply(target, receiver, args);
        }) as typeof Reflect.apply;
        Function.prototype.call = function poisonedCall(
          this: Function,
          receiver: unknown,
          ...args: unknown[]
        ) {
          capture(receiver);
          for (let index = 0; index < args.length; index += 1) capture(args[index]);
          return nativeReflectApply(nativeCall, this, [receiver, ...args]);
        } as typeof Function.prototype.call;
        Function.prototype.apply = function poisonedApply(
          this: Function,
          receiver: unknown,
          args?: ArrayLike<unknown> | null,
        ) {
          capture(receiver);
          if (args) {
            for (let index = 0; index < args.length; index += 1) capture(args[index]);
          }
          return nativeReflectApply(nativeApplyMethod, this, [receiver, args]);
        } as typeof Function.prototype.apply;
        Function.prototype.bind = function poisonedBind(
          this: Function,
          receiver: unknown,
          ...args: unknown[]
        ) {
          capture(receiver);
          for (let index = 0; index < args.length; index += 1) capture(args[index]);
          return nativeReflectApply(nativeBind, this, [receiver, ...args]);
        } as typeof Function.prototype.bind;

        return () => {
          Function.prototype.bind = nativeBind;
          Function.prototype.apply = nativeApplyMethod;
          Function.prototype.call = nativeCall;
          Reflect.apply = nativeReflectApply;
          Reflect.ownKeys = nativeReflectOwnKeys;
          Reflect.defineProperty = nativeReflectDefineProperty;
          Object.defineProperties = nativeDefineProperties;
          Object.defineProperty = nativeDefineProperty;
          Object.freeze = nativeFreeze;
          Object.create = nativeCreate;
          Object.keys = nativeKeys;
          Object.getPrototypeOf = nativeGetPrototypeOf;
          Object.getOwnPropertyDescriptor = nativeGetOwnPropertyDescriptor;
        };
      };

      let constructed: Awaited<ReturnType<typeof options.constructRepositories>> | undefined;
      let capturedTransactionCounter: Repositories['counterRepository'] | undefined;
      const restore = installPoison();
      try {
        constructed = await options.constructRepositories();
        await constructed.repositories.init();
        await constructed.repositories.acquireAuthority({
          namespace: `repository-invocation-intrinsic-${options.label ?? 'adapter'}`,
          ownerId: 'round-eleven',
        });
        await constructed.repositories.counterRepository.getCounter('https://mint.test', 'keyset');
        await constructed.repositories.proofRepository.getProofBySecret(
          'https://mint.test',
          'missing-proof',
        );
        await constructed.repositories.sendOperationRepository.getById('missing-operation');
        await constructed.repositories.withTransaction(async (scope) => {
          capturedTransactionCounter = scope.counterRepository;
          await scope.counterRepository.setCounter('https://mint.test', 'keyset', 1);
          await scope.proofRepository.getProofBySecret('https://mint.test', 'missing-proof');
          await scope.sendOperationRepository.getById('missing-operation');
        });
      } finally {
        restore();
      }

      if (!constructed) throw new Error('Repository construction did not complete');
      const { repositories, dispose } = constructed;
      try {
        expect(capturedRaw).toHaveLength(0);
        expect(substitutedMethodCalls).toBe(0);
        const capturedCounterSet = repositories.counterRepository.setCounter;
        const capturedProofSave = repositories.proofRepository.saveProofs;
        const capturedOperationCreate = repositories.sendOperationRepository.create;
        expect(await repositories.releaseAuthority()).toBe(true);
        await expectThrows(
          () => repositories.counterRepository.setCounter('https://mint.test', 'keyset', 99),
          expect,
        );
        await expectThrows(() => capturedCounterSet('https://mint.test', 'keyset', 99), expect);
        await expectThrows(() => capturedProofSave('https://mint.test', []), expect);
        await expectThrows(() => capturedOperationCreate({} as SendOperation), expect);
        await expectThrows(
          () => capturedTransactionCounter!.setCounter('https://mint.test', 'keyset', 99),
          expect,
        );
        expect(
          (await repositories.counterRepository.getCounter('https://mint.test', 'keyset'))?.counter,
        ).toBe(1);
        expect(
          await repositories.proofRepository.getProofBySecret('https://mint.test', 'missing-proof'),
        ).toBe(null);
        expect(await repositories.sendOperationRepository.getById('missing-operation')).toBe(null);
      } finally {
        await dispose();
      }
    });
  });
}

function sortedIndexes(indexes: number[]): number[] {
  return [...indexes].sort((left, right) => left - right);
}

function expectExactIndexRange(
  indexes: number[],
  start: number,
  count: number,
  expect: Expectation,
): void {
  const expected = Array.from({ length: count }, (_, offset) => start + offset);
  expect(indexes.length).toBe(count);
  expect(new Set(indexes).size).toBe(count);
  expect(JSON.stringify(sortedIndexes(indexes))).toBe(JSON.stringify(expected));
}

function derivedKeypair(derivationIndex: number, purpose: KeypairPurpose) {
  const prefix = purpose === 'p2pk' ? '02' : '03';
  return {
    publicKeyHex: prefix + derivationIndex.toString(16).padStart(64, '0'),
    secretKey: new Uint8Array(32).fill((derivationIndex % 254) + 1),
    derivationIndex,
    purpose,
  } as const;
}

/** Exercise the key-allocation transaction on an initialized adapter without starting a Manager. */
export async function allocateKeypairForTest(
  repositories: Repositories,
  purpose: KeypairPurpose,
): Promise<Keypair> {
  return repositories.withTransaction(async ({ keyRingRepository }) => {
    const lastAllocatedIndex = await keyRingRepository.getLastAllocatedIndex(purpose);
    const highestStoredIndex = await keyRingRepository.getHighestStoredDerivationIndex(purpose);
    const previousIndex = Math.max(lastAllocatedIndex ?? -1, highestStoredIndex ?? -1);
    if (previousIndex >= 0x7fffffff) throw new DerivationIndexExhaustedError(purpose);
    const keypair = derivedKeypair(previousIndex + 1, purpose);
    await keyRingRepository.setPersistedKeyPair(keypair);
    await keyRingRepository.setLastAllocatedIndex(purpose, keypair.derivationIndex);
    return keypair;
  });
}

export function runKeypairAllocationContract(
  options: KeypairAllocationContractOptions,
  runner: ContractRunner,
): void {
  const { describe, it, expect } = runner;

  describe('keypair allocation contract', () => {
    it('starts each purpose at zero and advances independently', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const p2pk = await Promise.all([
          allocateKeypairForTest(repositories, 'p2pk'),
          allocateKeypairForTest(repositories, 'p2pk'),
          allocateKeypairForTest(repositories, 'p2pk'),
        ]);
        const quote = await Promise.all([
          allocateKeypairForTest(repositories, 'nut20_mint_quote'),
          allocateKeypairForTest(repositories, 'nut20_mint_quote'),
          allocateKeypairForTest(repositories, 'nut20_mint_quote'),
        ]);

        expectExactIndexRange(
          p2pk.map((key) => key.derivationIndex!),
          0,
          3,
          expect,
        );
        expectExactIndexRange(
          quote.map((key) => key.derivationIndex!),
          0,
          3,
          expect,
        );
      } finally {
        await dispose();
      }
    });

    it('continues above existing persisted keypairs', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.keyRingRepository.setPersistedKeyPair(derivedKeypair(7, 'p2pk'));
        const next = await allocateKeypairForTest(repositories, 'p2pk');
        expect(next.derivationIndex).toBe(8);
      } finally {
        await dispose();
      }
    });

    it('allocates one exact sequence under one-root concurrency', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const indexes = await Promise.all(
          Array.from({ length: 50 }, () =>
            allocateKeypairForTest(repositories, 'nut20_mint_quote'),
          ),
        );
        expectExactIndexRange(
          indexes.map((key) => key.derivationIndex!),
          0,
          50,
          expect,
        );
      } finally {
        await dispose();
      }
    });

    it('rolls back an unexposed index but does not recycle a deleted committed key', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await expectThrowsNamed(
          () =>
            repositories.withTransaction(async (scope) => {
              await scope.keyRingRepository.setPersistedKeyPair(derivedKeypair(0, 'p2pk'));
              await scope.keyRingRepository.setLastAllocatedIndex('p2pk', 0);
              throw new Error('allocation aborted');
            }),
          Error.name,
          expect,
        );
        const keypair = await allocateKeypairForTest(repositories, 'p2pk');
        expect(keypair.derivationIndex).toBe(0);
        await repositories.keyRingRepository.deletePersistedKeyPair(keypair.publicKeyHex, 'p2pk');
        expect((await allocateKeypairForTest(repositories, 'p2pk')).derivationIndex).toBe(1);
      } finally {
        await dispose();
      }
    });

    it('fails explicitly without advancing beyond the maximum child index', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.keyRingRepository.setPersistedKeyPair(
          derivedKeypair(0x7fffffff, 'nut20_mint_quote'),
        );
        await expectThrowsNamed(
          () => allocateKeypairForTest(repositories, 'nut20_mint_quote'),
          DerivationIndexExhaustedError.name,
          expect,
        );
        await expectThrowsNamed(
          () => allocateKeypairForTest(repositories, 'nut20_mint_quote'),
          DerivationIndexExhaustedError.name,
          expect,
        );
      } finally {
        await dispose();
      }
    });

    if (options.createSharedRepositories) {
      it('coordinates shared callers over one physical store', async () => {
        const { first, second, dispose } = await options.createSharedRepositories!();
        try {
          const indexes = await Promise.all([
            ...Array.from({ length: 50 }, () => allocateKeypairForTest(first, 'nut20_mint_quote')),
            ...Array.from({ length: 50 }, () => allocateKeypairForTest(second, 'nut20_mint_quote')),
          ]);
          expectExactIndexRange(
            indexes.map((key) => key.derivationIndex!),
            0,
            100,
            expect,
          );

          const p2pk = await Promise.all([
            allocateKeypairForTest(first, 'p2pk'),
            allocateKeypairForTest(second, 'p2pk'),
          ]);
          expectExactIndexRange(
            p2pk.map((key) => key.derivationIndex!),
            0,
            2,
            expect,
          );
        } finally {
          await dispose();
        }
      });
    }
  });
}

export async function runRepositoryTransactionContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('repository transactions contract', () => {
    it('commits all repositories together', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        let committed = false;
        let committedPublicKey = '';
        await repositories.withTransaction(async (tx) => {
          await tx.mintRepository.addOrUpdateMint(createDummyMint());
          await tx.keysetRepository.addKeyset(createDummyKeyset());
          await tx.proofRepository.saveProofs('https://mint.test', [createDummyProof()]);
          await tx.meltOperationRepository.create(createDummyMeltOperation());
          await tx.counterRepository.setCounter('https://mint.test', 'keyset-id', 7);
          const keypair = derivedKeypair(0, 'p2pk');
          await tx.keyRingRepository.setPersistedKeyPair(keypair);
          await tx.keyRingRepository.setLastAllocatedIndex('p2pk', 0);
          committedPublicKey = keypair.publicKeyHex;
          committed = true;
        });

        expect(committed).toBe(true);
        const stored = await repositories.proofRepository.getAllReadyProofs();
        expect(stored.length).toBeGreaterThan(0);
        const operation = await repositories.meltOperationRepository.getById('melt-op');
        expect(operation).toBeDefined();
        expect(operation?.methodData.amountSats?.toString()).toBe('1');
        const counter = await repositories.counterRepository.getCounter(
          'https://mint.test',
          'keyset-id',
        );
        expect(counter?.counter).toBe(7);
        const keypair = await repositories.keyRingRepository.getPersistedKeyPair(
          committedPublicKey,
          'p2pk',
        );
        expect(keypair).toBeDefined();
        await repositories.keyRingRepository.deletePersistedKeyPair(committedPublicKey, 'p2pk');
        const nextKeypair = await allocateKeypairForTest(repositories, 'p2pk');
        expect(nextKeypair.derivationIndex).toBe(1);
      } finally {
        await dispose();
      }
    });

    it('rolls back commits on error', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await expectThrows(async () => {
          await repositories.withTransaction(async (tx) => {
            await tx.mintRepository.addOrUpdateMint(createDummyMint());
            await tx.keysetRepository.addKeyset(createDummyKeyset());
            await tx.proofRepository.saveProofs('https://mint.test', [createDummyProof()]);
            await tx.meltOperationRepository.create(createDummyMeltOperation());
            await tx.counterRepository.setCounter('https://mint.test', 'keyset-id', 7);
            await tx.keyRingRepository.setPersistedKeyPair(derivedKeypair(0, 'p2pk'));
            await tx.keyRingRepository.setLastAllocatedIndex('p2pk', 0);
            throw new Error('boom');
          });
        }, expect);

        const mints = await repositories.mintRepository.getAllMints();
        expect(mints.length).toBe(0);
        const keysets =
          await repositories.keysetRepository.getKeysetsByMintUrl('https://mint.test');
        expect(keysets.length).toBe(0);
        const proofs = await repositories.proofRepository.getAllReadyProofs();
        expect(proofs.length).toBe(0);
        const operation = await repositories.meltOperationRepository.getById('melt-op');
        expect(operation).toBe(null);
        const counter = await repositories.counterRepository.getCounter(
          'https://mint.test',
          'keyset-id',
        );
        expect(counter).toBe(null);
        const keypairs = await repositories.keyRingRepository.getAllPersistedKeyPairs('p2pk');
        expect(keypairs).toHaveLength(0);
        const reallocated = await allocateKeypairForTest(repositories, 'p2pk');
        expect(reallocated.derivationIndex).toBe(0);
      } finally {
        await dispose();
      }
    });

    it('preserves callback failures as non-conflict errors', async () => {
      const { repositories, dispose } = await options.createRepositories();
      const invariantError = new Error('database is locked by a domain invariant');
      try {
        let thrown: unknown;
        try {
          await repositories.withTransaction(async () => {
            throw invariantError;
          });
        } catch (error) {
          thrown = error;
        }

        expect(thrown).toBe(invariantError);
        expect(thrown instanceof RepositoryTransactionConflictError).toBe(false);
      } finally {
        await dispose();
      }
    });

    if (options.testConcurrentRootOperationIsolation) {
      it('does not expose writes from an active transaction that rolls back', async () => {
        const { transactionRepositories, rootRepositories, dispose } =
          await createIsolationRepositories(options);
        const transactionEntered = createDeferred();
        const releaseTransaction = createDeferred();
        try {
          const stagedMint = {
            ...createDummyMint(),
            mintUrl: 'https://staged-mint.test',
          };
          const transactionOutcomePromise = settle(
            transactionRepositories.withTransaction(async (tx) => {
              await tx.mintRepository.addOrUpdateMint(stagedMint);
              transactionEntered.resolve();
              await (options.holdTransactionOpen?.(releaseTransaction.promise) ??
                releaseTransaction.promise);
              throw new Error('rollback staged mint');
            }),
          );
          await transactionEntered.promise;

          const rootReadPromise = rootRepositories.mintRepository.getAllMints();
          releaseTransaction.resolve();
          const [transactionOutcome, observedMints] = await Promise.all([
            transactionOutcomePromise,
            rootReadPromise,
          ]);
          expect(transactionOutcome.status).toBe('rejected');
          expect(observedMints.some((mint) => mint.mintUrl === stagedMint.mintUrl)).toBe(false);

          const storedMints = await rootRepositories.mintRepository.getAllMints();
          expect(storedMints.some((mint) => mint.mintUrl === stagedMint.mintUrl)).toBe(false);
        } finally {
          releaseTransaction.resolve();
          await dispose();
        }
      });

      it('does not include concurrent root repository writes in active transactions', async () => {
        const { transactionRepositories, rootRepositories, dispose } =
          await createIsolationRepositories(options);
        try {
          const transactionEntered = createDeferred();
          const releaseTransaction = createDeferred();
          const mintInTransaction = {
            ...createDummyMint(),
            mintUrl: 'https://mint-in-transaction.test',
          };
          const outsideMint = {
            ...createDummyMint(),
            mintUrl: 'https://outside-mint.test',
          };

          const transactionOutcomePromise = settle(
            transactionRepositories.withTransaction(async (tx) => {
              await tx.mintRepository.addOrUpdateMint(mintInTransaction);
              transactionEntered.resolve();
              await (options.holdTransactionOpen?.(releaseTransaction.promise) ??
                releaseTransaction.promise);
              throw new Error('rollback transaction');
            }),
          );

          await transactionEntered.promise;

          const outsideWritePromise = rootRepositories.mintRepository.addOrUpdateMint(outsideMint);

          releaseTransaction.resolve();
          const [transactionOutcome] = await Promise.all([
            transactionOutcomePromise,
            outsideWritePromise,
          ]);
          expect(transactionOutcome.status).toBe('rejected');

          const mints = await rootRepositories.mintRepository.getAllMints();
          expect(mints).toHaveLength(1);
          expect(mints[0]?.mintUrl).toBe(outsideMint.mintUrl);
        } finally {
          await dispose();
        }
      });

      it('does not clobber concurrent root writes when a transaction commits', async () => {
        const { transactionRepositories, rootRepositories, dispose } =
          await createIsolationRepositories(options);
        const transactionEntered = createDeferred();
        const releaseTransaction = createDeferred();
        try {
          const mintInTransaction = {
            ...createDummyMint(),
            mintUrl: 'https://committed-transaction-mint.test',
          };
          const outsideMint = {
            ...createDummyMint(),
            mintUrl: 'https://outside-committed-transaction.test',
          };

          const transactionPromise = transactionRepositories.withTransaction(async (tx) => {
            await tx.mintRepository.addOrUpdateMint(mintInTransaction);
            transactionEntered.resolve();
            await (options.holdTransactionOpen?.(releaseTransaction.promise) ??
              releaseTransaction.promise);
          });
          await transactionEntered.promise;

          const outsideWritePromise = rootRepositories.mintRepository.addOrUpdateMint(outsideMint);
          releaseTransaction.resolve();
          await Promise.all([transactionPromise, outsideWritePromise]);

          const mints = await rootRepositories.mintRepository.getAllMints();
          expect(mints).toHaveLength(2);
          expect(mints.some((mint) => mint.mintUrl === mintInTransaction.mintUrl)).toBe(true);
          expect(mints.some((mint) => mint.mintUrl === outsideMint.mintUrl)).toBe(true);
        } finally {
          releaseTransaction.resolve();
          await dispose();
        }
      });
    }

    if (options.createSharedRepositories) {
      it('serializes or reports typed conflicts for concurrent Wallet writers', async () => {
        const { first, second, dispose } = await options.createSharedRepositories!();
        try {
          const mintUrl = 'https://transaction-contention.test';
          const keysetId = 'contention-keyset';
          await first.counterRepository.setCounter(mintUrl, keysetId, 0);

          const increment = (repositories: Repositories) =>
            settle(
              repositories.withTransaction(async (tx) => {
                const current = await tx.counterRepository.getCounter(mintUrl, keysetId);
                await tx.counterRepository.setCounter(
                  mintUrl,
                  keysetId,
                  (current?.counter ?? 0) + 1,
                );
              }),
            );

          const outcomes = await Promise.all([increment(first), increment(second)]);
          const fulfilledCount = outcomes.filter(
            (outcome) => outcome.status === 'fulfilled',
          ).length;
          expect(fulfilledCount > 0).toBe(true);
          for (const outcome of outcomes) {
            if (outcome.status === 'rejected') {
              expect(outcome.reason instanceof RepositoryTransactionConflictError).toBe(true);
            }
          }

          const counter = await first.counterRepository.getCounter(mintUrl, keysetId);
          expect(counter?.counter).toBe(fulfilledCount);
        } finally {
          await dispose();
        }
      });
    }

    if (options.createSharedRepositories && options.testWriterOwnershipAtEntry) {
      it('acquires write ownership before entering a conflicting callback', async () => {
        const { first, second, dispose } = await options.createSharedRepositories!();
        const releaseFirst = createDeferred();
        try {
          const firstEntered = createDeferred();
          const firstMint = {
            ...createDummyMint(),
            mintUrl: 'https://first-writer.test',
          };
          const secondMint = {
            ...createDummyMint(),
            mintUrl: 'https://second-writer.test',
          };
          let firstWriterHeld = true;

          const firstOutcomePromise = settle(
            first.withTransaction(async (tx) => {
              await tx.mintRepository.addOrUpdateMint(firstMint);
              firstEntered.resolve();
              await releaseFirst.promise;
              firstWriterHeld = false;
            }),
          );
          await firstEntered.promise;

          const secondEntered = createDeferred();
          let secondEnteredWhileFirstHeld = false;
          const secondOutcomePromise = settle(
            second.withTransaction(async (tx) => {
              secondEnteredWhileFirstHeld = firstWriterHeld;
              secondEntered.resolve();
              await tx.mintRepository.addOrUpdateMint(secondMint);
            }),
          );

          const acquisitionOutcome = await Promise.race([
            secondEntered.promise.then(() => 'callback-entered' as const),
            secondOutcomePromise.then(() => 'transaction-settled' as const),
            new Promise<'pending'>((resolve) => setTimeout(() => resolve('pending'), 0)),
          ]);
          expect(acquisitionOutcome === 'callback-entered').toBe(false);

          releaseFirst.resolve();
          const [firstOutcome, secondOutcome] = await Promise.all([
            firstOutcomePromise,
            secondOutcomePromise,
          ]);
          expect(secondEnteredWhileFirstHeld).toBe(false);
          expect(firstOutcome.status).toBe('fulfilled');
          if (secondOutcome.status === 'rejected') {
            expect(secondOutcome.reason instanceof RepositoryTransactionConflictError).toBe(true);
            expect(
              secondOutcome.reason instanceof RepositoryTransactionConflictError
                ? secondOutcome.reason.transient
                : false,
            ).toBe(true);
          }

          const mints = await first.mintRepository.getAllMints();
          expect(mints.some((mint) => mint.mintUrl === firstMint.mintUrl)).toBe(true);
          expect(mints.some((mint) => mint.mintUrl === secondMint.mintUrl)).toBe(
            secondOutcome.status === 'fulfilled',
          );
        } finally {
          releaseFirst.resolve();
          await dispose();
        }
      });
    }
  });
}

export type ContractRunner = {
  describe(name: string, fn: () => void): void;
  it(name: string, fn: () => Promise<void> | void): void;
  expect: Expectation;
};

async function createIsolationRepositories(options: ContractOptions): Promise<{
  transactionRepositories: Repositories;
  rootRepositories: Repositories;
  dispose(): Promise<void>;
}> {
  if (options.createIsolationRepositories) {
    const { first, second, dispose } = await options.createIsolationRepositories();
    return { transactionRepositories: first, rootRepositories: second, dispose };
  }

  const { repositories, dispose } = await options.createRepositories();
  return {
    transactionRepositories: repositories,
    rootRepositories: repositories,
    dispose,
  };
}

type Expectation = {
  (value: unknown): ExpectApi;
};

type ExpectApi = {
  toBe(value: unknown): void;
  toHaveLength(len: number): void;
  toBeGreaterThan(value: number): void;
  toBeDefined(): void;
};

async function expectThrows(fn: () => Promise<unknown>, expect: Expectation) {
  let didThrow = false;
  try {
    await fn();
  } catch (error) {
    didThrow = true;
  }
  expect(didThrow).toBe(true);
}

function expectSyncThrows(fn: () => unknown, expect: Expectation): void {
  let didThrow = false;
  try {
    fn();
  } catch {
    didThrow = true;
  }
  expect(didThrow).toBe(true);
}

async function expectThrowsError(
  fn: () => Promise<unknown>,
  errorClass: Function,
  expect: Expectation,
) {
  let thrown: unknown;
  try {
    await fn();
  } catch (error) {
    thrown = error;
  }
  expect(thrown instanceof errorClass).toBe(true);
}

async function expectThrowsNamed(
  fn: () => Promise<unknown>,
  errorName: string,
  expect: Expectation,
) {
  let thrown: unknown;
  try {
    await fn();
  } catch (error) {
    thrown = error;
  }
  expect(thrown instanceof Error ? thrown.name : undefined).toBe(errorName);
}

function createDeferred<T = void>() {
  let resolve!: (value: T) => void;
  let reject!: (reason?: unknown) => void;
  const promise = new Promise<T>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject } as const;
}

function settle<T>(promise: Promise<T>) {
  return promise.then(
    (value) => ({ status: 'fulfilled' as const, value }),
    (reason: unknown) => ({ status: 'rejected' as const, reason }),
  );
}

export function createDummyMint(): Mint {
  return {
    mintUrl: 'https://mint.test',
    name: 'Test Mint',
    mintInfo: {
      name: 'Test Mint',
      pubkey: 'pubkey',
      version: '1.0',
      contact: {},
      nuts: {},
    } as Mint['mintInfo'],
    trusted: true,
    createdAt: 0,
    updatedAt: 0,
  };
}

export function createDummyKeyset(): Keyset {
  return {
    mintUrl: 'https://mint.test',
    id: 'keyset-id',
    unit: 'sat',
    keypairs: {},
    active: true,
    feePpk: 0,
    updatedAt: 0,
  };
}

export function createDummyProof(overrides?: Partial<CoreProof>): CoreProof {
  return {
    id: 'proof-id',
    amount: Amount.from(1),
    secret: 'secret',
    C: 'C',
    mintUrl: 'https://mint.test',
    unit: 'sat',
    state: 'ready',
    ...overrides,
  } satisfies CoreProof;
}

type InitMeltOperation = Extract<MeltOperation, { state: 'init' }>;

export function createDummyMeltOperation(
  overrides?: Partial<InitMeltOperation>,
): InitMeltOperation {
  return {
    id: 'melt-op',
    state: 'init',
    mintUrl: 'https://mint.test',
    unit: 'sat',
    method: 'bolt11',
    methodData: { invoice: 'lnbc1test', amountSats: Amount.from(1) },
    quoteId: 'melt-quote-id',
    createdAt: 0,
    updatedAt: 0,
    ...overrides,
  } satisfies MeltOperation;
}

type PreparedSendOperation = Extract<SendOperation, { state: 'prepared' }>;

function createDummyPreparedSendOperation(
  overrides?: Partial<PreparedSendOperation>,
): PreparedSendOperation {
  return {
    id: 'send-op',
    state: 'prepared',
    mintUrl: 'https://mint.test',
    amount: Amount.from(3),
    unit: 'sat',
    method: 'default',
    methodData: {},
    createdAt: 0,
    updatedAt: 0,
    needsSwap: false,
    fee: Amount.zero(),
    inputAmount: Amount.from(3),
    inputProofSecrets: ['send-secret-1'],
    ...overrides,
  } satisfies PreparedSendOperation;
}

function createDummySendOperationsByState(unit: string): SendOperation[] {
  const prepared = createDummyPreparedSendOperation({ id: 'send-prepared', unit });
  const token = {
    mint: prepared.mintUrl,
    unit,
    proofs: [{ id: 'keyset-id', amount: Amount.from(3), secret: 'token-secret', C: 'C-token' }],
  };
  return [
    {
      id: 'send-init',
      state: 'init',
      mintUrl: prepared.mintUrl,
      amount: prepared.amount,
      unit,
      method: 'default',
      methodData: {},
      createdAt: 0,
      updatedAt: 0,
    },
    prepared,
    { ...prepared, id: 'send-executing', state: 'executing' },
    { ...prepared, id: 'send-pending', state: 'pending', token },
    { ...prepared, id: 'send-finalized', state: 'finalized', token },
    { ...prepared, id: 'send-rolling-back', state: 'rolling_back', token },
    { ...prepared, id: 'send-rolled-back', state: 'rolled_back', token },
  ] satisfies SendOperation[];
}

type PendingMintOperation = Extract<MintOperation, { state: 'pending' }>;

export function createDummyMintQuote(
  overrides?: Partial<MintQuote<'bolt11'>>,
): MintQuote<'bolt11'> {
  return {
    mintUrl: 'https://mint.test',
    method: 'bolt11',
    quoteId: 'quote-id',
    quote: 'quote-id',
    state: 'UNPAID',
    request: 'lnbc1test',
    amount: Amount.from(3),
    unit: 'sat',
    expiry: 1_730_000_000,
    reusable: false,
    amountPaid: Amount.zero(),
    amountIssued: Amount.zero(),
    remoteUpdatedAt: null,
    quoteData: {
      amount: Amount.from(3),
    },
    createdAt: 0,
    updatedAt: 0,
    ...overrides,
  } satisfies MintQuote<'bolt11'>;
}

export function createDummyMeltQuote(
  overrides?: Partial<MeltQuote<'bolt11'>>,
): MeltQuote<'bolt11'> {
  return {
    mintUrl: 'https://mint.test',
    method: 'bolt11',
    quoteId: 'melt-quote-id',
    quote: 'melt-quote-id',
    state: 'UNPAID',
    request: 'lnbc1test',
    amount: Amount.from(3),
    unit: 'sat',
    fee_reserve: Amount.from(1),
    expiry: 1_730_000_000,
    payment_preimage: null,
    createdAt: 0,
    updatedAt: 0,
    ...overrides,
  } satisfies MeltQuote<'bolt11'>;
}

export function createDummyMintOperation(
  overrides?: Partial<PendingMintOperation>,
): PendingMintOperation {
  return {
    id: 'mint-op',
    state: 'pending',
    mintUrl: 'https://mint.test',
    quoteId: 'quote-id',
    method: 'bolt11',
    methodData: {},
    createdAt: 0,
    updatedAt: 0,
    amount: Amount.from(3),
    unit: 'sat',
    request: 'lnbc1test',
    expiry: 1_730_000_000,
    outputData: { keep: [], send: [] },
    ...overrides,
  } satisfies PendingMintOperation;
}

type InitMintOperation = Extract<MintOperation, { state: 'init' }>;

export function createDummyInitMintOperation(
  overrides?: Partial<InitMintOperation>,
): InitMintOperation {
  return {
    id: 'mint-op-init',
    state: 'init',
    mintUrl: 'https://mint.test',
    quoteId: 'mint-quote-id',
    method: 'bolt11',
    methodData: {},
    createdAt: 0,
    updatedAt: 0,
    amount: Amount.from(3),
    unit: 'sat',
    ...overrides,
  } satisfies InitMintOperation;
}

export function createDummyReceiveOperation(): ReceiveOperation {
  return {
    id: 'receive-op',
    state: 'init',
    mintUrl: 'https://mint.test',
    unit: 'sat',
    amount: Amount.from(3),
    inputProofs: [
      { id: 'keyset-id', amount: Amount.from(1), secret: 'receive-secret-1', C: 'C1' },
      { id: 'keyset-id', amount: Amount.from(2), secret: 'receive-secret-2', C: 'C2' },
    ],
    createdAt: 0,
    updatedAt: 0,
  } satisfies ReceiveOperation;
}

export function createDummyPaymentRequestReceiveOperation(
  overrides?: Partial<PaymentRequestReceiveOperation>,
): PaymentRequestReceiveOperation {
  return {
    id: 'payment-request-receive-op',
    requestId: 'request-id',
    encodedRequest: 'CREQB1TEST',
    state: 'active',
    transport: 'inband',
    amount: Amount.from(100),
    unit: 'sat',
    mints: ['https://mint.test'],
    singleUse: true,
    createdAt: 0,
    updatedAt: 0,
    ...overrides,
  };
}

export function createDummyPaymentRequestReceiveAttempt(
  overrides?: Partial<PaymentRequestReceiveAttempt>,
): PaymentRequestReceiveAttempt {
  return {
    id: 'payment-request-receive-attempt',
    requestOperationId: 'payment-request-receive-op',
    requestId: 'request-id',
    transport: 'inband',
    transportMessageId: 'message-id',
    payloadHash: 'payload-hash',
    mintUrl: 'https://mint.test',
    unit: 'sat',
    grossAmount: Amount.from(100),
    state: 'received',
    createdAt: 0,
    updatedAt: 0,
    ...overrides,
  };
}

export function createDummyAuthSession(overrides?: Partial<AuthSession>): AuthSession {
  return {
    mintUrl: 'https://mint.test',
    accessToken: 'access-token-123',
    expiresAt: Math.floor(Date.now() / 1000) + 3600,
    ...overrides,
  };
}

export async function runMintQuoteRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('MintQuoteRepository contract', () => {
    it('applies legacy BOLT11 state updates monotonically', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMintQuote({
          state: 'UNPAID',
          amountPaid: Amount.zero(),
          amountIssued: Amount.zero(),
          remoteUpdatedAt: null,
          updatedAt: 10,
        });
        await repositories.mintQuoteRepository.upsertMintQuote(quote);

        await repositories.mintQuoteRepository.setMintQuoteState(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
          'PAID',
          20,
        );
        await repositories.mintQuoteRepository.setMintQuoteState(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
          'UNPAID',
          30,
        );

        const paid = await repositories.mintQuoteRepository.getMintQuote(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
        );
        expect(paid?.method).toBe('bolt11');
        if (paid?.method !== 'bolt11') throw new Error('Expected BOLT11 quote');
        expect(paid.state).toBe('PAID');
        expect(paid.amountPaid.equals(quote.amount)).toBe(true);
        expect(paid.amountIssued.isZero()).toBe(true);
        expect(paid.remoteUpdatedAt).toBe(null);
        expect(paid.updatedAt).toBe(30);

        await repositories.mintQuoteRepository.setMintQuoteState(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
          'ISSUED',
          40,
        );

        const issued = await repositories.mintQuoteRepository.getMintQuote(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
        );
        expect(issued?.method).toBe('bolt11');
        if (issued?.method !== 'bolt11') throw new Error('Expected BOLT11 quote');
        expect(issued.state).toBe('ISSUED');
        expect(issued.amountPaid.equals(quote.amount)).toBe(true);
        expect(issued.amountIssued.equals(quote.amount)).toBe(true);
        expect(issued.remoteUpdatedAt).toBe(null);
        expect(issued.updatedAt).toBe(40);
      } finally {
        await dispose();
      }
    });

    it('keeps canonical BOLT11 accounting authoritative over legacy state updates', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMintQuote({
          state: 'UNPAID',
          amountPaid: Amount.from(3),
          amountIssued: Amount.zero(),
          remoteUpdatedAt: 10,
        });
        await repositories.mintQuoteRepository.upsertMintQuote(quote);
        await repositories.mintQuoteRepository.setMintQuoteState(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
          'UNPAID',
          20,
        );

        const stored = await repositories.mintQuoteRepository.getMintQuote(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
        );

        expect(stored?.method).toBe('bolt11');
        if (stored?.method !== 'bolt11') throw new Error('Expected BOLT11 quote');
        expect(stored.state).toBe('PAID');
        expect(stored.amountPaid.equals(Amount.from(3))).toBe(true);
        expect(stored.amountIssued.isZero()).toBe(true);
        expect(stored.remoteUpdatedAt).toBe(10);
      } finally {
        await dispose();
      }
    });

    it('keeps concurrent legacy state updates from overwriting canonical accounting', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        for (let i = 0; i < 10; i++) {
          const quote = createDummyMintQuote({
            quoteId: `concurrent-accounting-${i}`,
            quote: `concurrent-accounting-${i}`,
            state: 'UNPAID',
            amountPaid: Amount.zero(),
            amountIssued: Amount.zero(),
            remoteUpdatedAt: null,
          });
          const canonical = {
            ...quote,
            state: 'PAID' as const,
            amountPaid: Amount.from(3),
            amountIssued: Amount.zero(),
            remoteUpdatedAt: 10,
            updatedAt: 10,
          };
          await repositories.mintQuoteRepository.upsertMintQuote(quote);

          await Promise.all([
            repositories.mintQuoteRepository.setMintQuoteState(
              quote.mintUrl,
              quote.method,
              quote.quoteId,
              'ISSUED',
              20,
            ),
            repositories.mintQuoteRepository.upsertMintQuote(canonical),
          ]);

          const stored = await repositories.mintQuoteRepository.getMintQuote(
            quote.mintUrl,
            quote.method,
            quote.quoteId,
          );

          expect(stored?.method).toBe('bolt11');
          if (stored?.method !== 'bolt11') throw new Error('Expected BOLT11 quote');
          expect(stored.state).toBe('PAID');
          expect(stored.amountPaid.equals(Amount.from(3))).toBe(true);
          expect(stored.amountIssued.isZero()).toBe(true);
          expect(stored.remoteUpdatedAt).toBe(10);
        }
      } finally {
        await dispose();
      }
    });

    it('selects pending BOLT11 quotes from accounting instead of stored state', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const pending = createDummyMintQuote({
          quoteId: 'accounting-pending',
          quote: 'accounting-pending',
          state: 'ISSUED',
          amountPaid: Amount.from(3),
          amountIssued: Amount.zero(),
        });
        const issued = createDummyMintQuote({
          quoteId: 'accounting-issued',
          quote: 'accounting-issued',
          state: 'UNPAID',
          amountPaid: Amount.from(3),
          amountIssued: Amount.from(3),
        });
        await repositories.mintQuoteRepository.upsertMintQuote(pending);
        await repositories.mintQuoteRepository.upsertMintQuote(issued);

        const storedPending = await repositories.mintQuoteRepository.getPendingMintQuotes('bolt11');
        const pendingIds = storedPending.map((quote) => quote.quoteId);

        expect(pendingIds.includes('accounting-pending')).toBe(true);
        expect(pendingIds.includes('accounting-issued')).toBe(false);
      } finally {
        await dispose();
      }
    });
  });
}

export async function runMintOperationRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('MintOperationRepository contract', () => {
    it('round-trips init mint operation quote ids', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyInitMintOperation({ quoteId: 'init-mint-quote' });
        await repositories.mintOperationRepository.create(operation);

        const stored = await repositories.mintOperationRepository.getById(operation.id);

        expect(stored).toBeDefined();
        expect(stored!.state).toBe('init');
        expect(stored!.quoteId).toBe('init-mint-quote');
      } finally {
        await dispose();
      }
    });

    it('preserves null quote expiries for pending operations', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyMintOperation({ expiry: null });
        await repositories.mintOperationRepository.create(operation);

        const stored = await repositories.mintOperationRepository.getById(operation.id);
        const pending = await repositories.mintOperationRepository.getPending();

        expect(stored).toBeDefined();
        expect(pending).toHaveLength(1);
        if (!stored || stored.state !== 'pending' || pending[0]?.state !== 'pending') {
          throw new Error('Expected pending mint operations');
        }
        expect(stored.expiry).toBe(null);
        expect(pending[0].expiry).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('returns only pending and executing work from getPending', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const pending = createDummyMintOperation({
          id: 'mint-op-pending',
          quoteId: 'quote-pending',
          createdAt: 1_000,
        });
        const executing = {
          ...createDummyMintOperation({
            id: 'mint-op-executing',
            quoteId: 'quote-executing',
            createdAt: 2_000,
          }),
          state: 'executing',
        } satisfies MintOperation;
        const finalized = {
          ...createDummyMintOperation({
            id: 'mint-op-finalized',
            quoteId: 'quote-finalized',
            createdAt: 3_000,
          }),
          state: 'finalized',
        } satisfies MintOperation;

        await repositories.mintOperationRepository.create(pending);
        await repositories.mintOperationRepository.create(executing);
        await repositories.mintOperationRepository.create(finalized);

        const inFlight = await repositories.mintOperationRepository.getPending();

        expect(inFlight).toHaveLength(2);
        expect(
          inFlight
            .map((operation) => operation.state)
            .sort()
            .join(','),
        ).toBe('executing,pending');
        expect(
          inFlight
            .map((operation) => operation.id)
            .sort()
            .join(','),
        ).toBe('mint-op-executing,mint-op-pending');
      } finally {
        await dispose();
      }
    });

    it('returns sibling mint operations by full quote identity in deterministic order', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const first = createDummyMintOperation({
          id: 'mint-op-a',
          quoteId: 'shared-quote',
          createdAt: 2_000,
        });
        const second = createDummyMintOperation({
          id: 'mint-op-b',
          quoteId: 'shared-quote',
          createdAt: 1_000,
        });
        const otherMethod = createDummyMintOperation({
          id: 'mint-op-other',
          quoteId: 'shared-quote',
          method: 'bolt11',
          mintUrl: 'https://other-mint.test',
        });

        await repositories.mintOperationRepository.create(first);
        await repositories.mintOperationRepository.create(second);
        await repositories.mintOperationRepository.create(otherMethod);

        const stored = await repositories.mintOperationRepository.getByQuoteId(
          'https://mint.test',
          'bolt11',
          'shared-quote',
        );

        expect(stored).toHaveLength(2);
        expect(stored[0]?.id).toBe('mint-op-b');
        expect(stored[1]?.id).toBe('mint-op-a');
      } finally {
        await dispose();
      }
    });

    it('persists canonical mint quotes by full quote identity', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMintQuote({
          mintUrl: 'https://mint.test/',
          quoteId: 'canonical-quote',
          quote: 'canonical-quote',
          state: 'UNPAID',
          amountPaid: Amount.from(3),
          remoteUpdatedAt: 10,
        });
        await repositories.mintQuoteRepository.upsertMintQuote(quote);
        await repositories.mintQuoteRepository.setMintQuoteState(
          'https://mint.test',
          'bolt11',
          'canonical-quote',
          'UNPAID',
          20,
        );

        const stored = await repositories.mintQuoteRepository.getMintQuote(
          'https://mint.test',
          'bolt11',
          'canonical-quote',
        );

        expect(stored).toBeDefined();
        expect(stored!.mintUrl).toBe('https://mint.test');
        expect(stored!.method).toBe('bolt11');
        expect(stored!.quoteId).toBe('canonical-quote');
        expect(stored!.reusable).toBe(false);
        if (stored!.method !== 'bolt11') {
          throw new Error(`Expected bolt11 quote, got ${stored!.method}`);
        }
        expect(stored!.state).toBe('PAID');
        expect(stored!.quoteData.amount.equals(Amount.from(3))).toBe(true);
        expect(stored!.amountPaid.equals(Amount.from(3))).toBe(true);
        expect(stored!.amountIssued.equals(Amount.zero())).toBe(true);
        expect(stored!.remoteUpdatedAt).toBe(10);
      } finally {
        await dispose();
      }
    });

    it('looks up canonical mint quotes by identity without method', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMintQuote({
          mintUrl: 'https://mint.test/',
          quoteId: 'identity-mint-quote',
          quote: 'identity-mint-quote',
        });
        const ref: MintQuoteRef = quote;
        const identity: QuoteIdentity = ref;
        await repositories.mintQuoteRepository.upsertMintQuote(quote);

        const stored = await repositories.mintQuoteRepository.getMintQuoteById(identity);
        const absent = await repositories.mintQuoteRepository.getMintQuoteById({
          mintUrl: 'https://mint.test',
          quoteId: 'missing-mint-quote',
        });

        expect(stored).toBeDefined();
        expect(stored!.method).toBe('bolt11');
        expect(stored!.quoteId).toBe('identity-mint-quote');
        expect(absent).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('rejects same-mint mint quote identity collisions across methods', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMintQuote({
          mintUrl: 'https://mint.test/',
          quoteId: 'colliding-mint-quote',
          quote: 'colliding-mint-quote',
        });
        const collidingQuote: MintQuote<'bolt12'> = {
          mintUrl: 'https://mint.test',
          method: 'bolt12',
          quoteId: 'colliding-mint-quote',
          quote: 'colliding-mint-quote',
          request: 'lno1collision',
          unit: 'sat',
          expiry: 1_730_000_000,
          pubkey: '02'.padEnd(66, '4'),
          reusable: true,
          amountPaid: Amount.zero(),
          amountIssued: Amount.zero(),
          remoteUpdatedAt: 20,
          quoteData: {
            pubkey: '02'.padEnd(66, '4'),
          },
          createdAt: 0,
          updatedAt: 0,
        };

        await repositories.mintQuoteRepository.upsertMintQuote(quote);
        await expectThrowsError(
          () => repositories.mintQuoteRepository.upsertMintQuote(collidingQuote),
          QuoteIdentityConflictError,
          expect,
        );

        const exact = await repositories.mintQuoteRepository.getMintQuote(
          'https://mint.test',
          'bolt11',
          'colliding-mint-quote',
        );
        const missingSibling = await repositories.mintQuoteRepository.getMintQuote(
          'https://mint.test',
          'bolt12',
          'colliding-mint-quote',
        );
        expect(exact).toBeDefined();
        expect(missingSibling).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('keeps mint and melt quote identity namespaces separate', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.mintQuoteRepository.upsertMintQuote(
          createDummyMintQuote({
            quoteId: 'shared-cross-kind-quote',
            quote: 'shared-cross-kind-quote',
          }),
        );
        await repositories.meltQuoteRepository.upsertMeltQuote(
          createDummyMeltQuote({
            quoteId: 'shared-cross-kind-quote',
            quote: 'shared-cross-kind-quote',
          }),
        );

        const mintQuote = await repositories.mintQuoteRepository.getMintQuoteById({
          mintUrl: 'https://mint.test',
          quoteId: 'shared-cross-kind-quote',
        });
        const meltQuote = await repositories.meltQuoteRepository.getMeltQuoteById({
          mintUrl: 'https://mint.test',
          quoteId: 'shared-cross-kind-quote',
        });

        expect(mintQuote).toBeDefined();
        expect(meltQuote).toBeDefined();
        expect(mintQuote!.quoteId).toBe(meltQuote!.quoteId);
      } finally {
        await dispose();
      }
    });

    it('persists reusable onchain mint quote data', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.mintQuoteRepository.upsertMintQuote({
          mintUrl: 'https://mint.test/',
          method: 'onchain',
          quoteId: 'onchain-quote',
          quote: 'onchain-quote',
          request: 'bc1qdeposit',
          unit: 'sat',
          expiry: 1_730_000_000,
          pubkey: '02'.padEnd(66, '1'),
          reusable: true,
          amountPaid: Amount.from(21),
          amountIssued: Amount.from(8),
          remoteUpdatedAt: 20,
          quoteData: {
            pubkey: '02'.padEnd(66, '1'),
          },
          createdAt: 0,
          updatedAt: 0,
        });

        const stored = await repositories.mintQuoteRepository.getMintQuote(
          'https://mint.test',
          'onchain',
          'onchain-quote',
        );

        expect(stored).toBeDefined();
        if (!stored) {
          throw new Error('Expected onchain quote to be stored');
        }
        expect(stored.method).toBe('onchain');
        if (stored.method !== 'onchain') {
          throw new Error(`Expected onchain quote, got ${stored.method}`);
        }
        expect(stored.reusable).toBe(true);
        expect(stored.quoteData.pubkey).toBe('02'.padEnd(66, '1'));
        expect(stored.amountPaid.equals(Amount.from(21))).toBe(true);
        expect(stored.amountIssued.equals(Amount.from(8))).toBe(true);
      } finally {
        await dispose();
      }
    });

    it('persists reusable BOLT12 mint quote data', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.mintQuoteRepository.upsertMintQuote({
          mintUrl: 'https://mint.test/',
          method: 'bolt12',
          quoteId: 'bolt12-quote',
          quote: 'bolt12-quote',
          request: 'lno1offer',
          amount: Amount.from(12),
          unit: 'sat',
          expiry: 1_730_000_000,
          pubkey: '02'.padEnd(66, '2'),
          reusable: true,
          amountPaid: Amount.from(21),
          amountIssued: Amount.from(8),
          remoteUpdatedAt: 20,
          quoteData: {
            pubkey: '02'.padEnd(66, '2'),
            amount: Amount.from(12),
          },
          createdAt: 0,
          updatedAt: 0,
        });
        await repositories.mintQuoteRepository.upsertMintQuote({
          mintUrl: 'https://mint.test/',
          method: 'bolt12',
          quoteId: 'bolt12-amountless-quote',
          quote: 'bolt12-amountless-quote',
          request: 'lno1amountless',
          unit: 'sat',
          expiry: 1_730_000_000,
          pubkey: '02'.padEnd(66, '3'),
          reusable: true,
          amountPaid: Amount.from(5),
          amountIssued: Amount.zero(),
          remoteUpdatedAt: null,
          quoteData: {
            pubkey: '02'.padEnd(66, '3'),
          },
          createdAt: 0,
          updatedAt: 0,
        });

        const stored = await repositories.mintQuoteRepository.getMintQuote(
          'https://mint.test',
          'bolt12',
          'bolt12-quote',
        );
        const amountless = await repositories.mintQuoteRepository.getMintQuote(
          'https://mint.test',
          'bolt12',
          'bolt12-amountless-quote',
        );

        expect(stored).toBeDefined();
        if (!stored) {
          throw new Error('Expected BOLT12 quote to be stored');
        }
        expect(stored.method).toBe('bolt12');
        if (stored.method !== 'bolt12') {
          throw new Error(`Expected BOLT12 quote, got ${stored.method}`);
        }
        expect(stored.reusable).toBe(true);
        expect(stored.amount?.equals(Amount.from(12))).toBe(true);
        expect(stored.quoteData.pubkey).toBe('02'.padEnd(66, '2'));
        expect(stored.quoteData.amount?.equals(Amount.from(12))).toBe(true);
        expect(stored.amountPaid.equals(Amount.from(21))).toBe(true);
        expect(stored.amountIssued.equals(Amount.from(8))).toBe(true);

        expect(amountless).toBeDefined();
        if (!amountless) {
          throw new Error('Expected amountless BOLT12 quote to be stored');
        }
        expect(amountless.method).toBe('bolt12');
        if (amountless.method !== 'bolt12') {
          throw new Error(`Expected amountless BOLT12 quote, got ${amountless.method}`);
        }
        expect(amountless.reusable).toBe(true);
        expect(amountless.amount).toBe(undefined);
        expect(amountless.quoteData.amount).toBe(undefined);
        expect(amountless.quoteData.pubkey).toBe('02'.padEnd(66, '3'));
        expect(amountless.amountPaid.equals(Amount.from(5))).toBe(true);
        expect(amountless.amountIssued.equals(Amount.from(0))).toBe(true);
      } finally {
        await dispose();
      }
    });
  });
}

export async function runMeltQuoteRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('MeltQuoteRepository contract', () => {
    it('persists canonical melt quotes by full quote identity', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMeltQuote({
          mintUrl: 'https://mint.test/',
          quoteId: 'canonical-melt-quote',
          quote: 'canonical-melt-quote',
          state: 'PENDING',
          lastObservedRemoteState: 'PENDING',
          lastObservedRemoteStateAt: 20,
        });

        const persisted = await repositories.meltQuoteRepository.upsertMeltQuote(quote);

        const stored = await repositories.meltQuoteRepository.getMeltQuote(
          'https://mint.test',
          'bolt11',
          'canonical-melt-quote',
        );

        expect(persisted.mintUrl).toBe(stored?.mintUrl);
        expect(persisted.quote).toBe(stored?.quote);
        expect(persisted.createdAt).toBe(stored?.createdAt);
        expect(persisted.updatedAt).toBe(stored?.updatedAt);
        expect(persisted.amount.equals(stored!.amount)).toBe(true);
        expect(stored).toBeDefined();
        expect(stored!.mintUrl).toBe('https://mint.test');
        expect(stored!.method).toBe('bolt11');
        expect(stored!.quoteId).toBe('canonical-melt-quote');
        expect(stored!.state).toBe('PENDING');
        expect(stored!.lastObservedRemoteState).toBe('PENDING');
        expect(stored!.lastObservedRemoteStateAt).toBe(20);
      } finally {
        await dispose();
      }
    });

    it('rehydrates cached melt change signature amounts', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMeltQuote({
          quoteId: 'paid-melt-with-change',
          quote: 'paid-melt-with-change',
          state: 'PAID',
          change: [
            {
              id: 'keyset-1',
              amount: Amount.from(2),
              C_: '02'.padEnd(66, '1'),
            },
          ],
        });

        await repositories.meltQuoteRepository.upsertMeltQuote(quote);
        const stored = await repositories.meltQuoteRepository.getMeltQuote(
          quote.mintUrl,
          quote.method,
          quote.quoteId,
        );

        expect(stored?.change).toHaveLength(1);
        expect(stored?.change?.[0]?.amount.equals(Amount.from(2))).toBe(true);
      } finally {
        await dispose();
      }
    });

    it('looks up canonical melt quotes by identity without method', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMeltQuote({
          mintUrl: 'https://mint.test/',
          quoteId: 'identity-melt-quote',
          quote: 'identity-melt-quote',
        });
        const ref: MeltQuoteRef = quote;
        const identity: QuoteIdentity = ref;
        await repositories.meltQuoteRepository.upsertMeltQuote(quote);

        const stored = await repositories.meltQuoteRepository.getMeltQuoteById(identity);
        const absent = await repositories.meltQuoteRepository.getMeltQuoteById({
          mintUrl: 'https://mint.test',
          quoteId: 'missing-melt-quote',
        });

        expect(stored).toBeDefined();
        expect(stored!.method).toBe('bolt11');
        expect(stored!.quoteId).toBe('identity-melt-quote');
        expect(absent).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('rejects same-mint melt quote identity collisions across methods', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote = createDummyMeltQuote({
          mintUrl: 'https://mint.test/',
          quoteId: 'colliding-melt-quote',
          quote: 'colliding-melt-quote',
        });
        const collidingQuote = {
          ...createDummyMeltQuote({
            mintUrl: 'https://mint.test',
            quoteId: 'colliding-melt-quote',
            quote: 'colliding-melt-quote',
            request: 'lno1collision',
          }),
          method: 'bolt12' as const,
        } satisfies MeltQuote<'bolt12'>;

        await repositories.meltQuoteRepository.upsertMeltQuote(quote);
        await expectThrowsError(
          () => repositories.meltQuoteRepository.upsertMeltQuote(collidingQuote),
          QuoteIdentityConflictError,
          expect,
        );

        const exact = await repositories.meltQuoteRepository.getMeltQuote(
          'https://mint.test',
          'bolt11',
          'colliding-melt-quote',
        );
        const missingSibling = await repositories.meltQuoteRepository.getMeltQuote(
          'https://mint.test',
          'bolt12',
          'colliding-melt-quote',
        );
        expect(exact).toBeDefined();
        expect(missingSibling).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('lists only active melt quotes, optionally scoped by method', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.meltQuoteRepository.upsertMeltQuote(
          createDummyMeltQuote({ quoteId: 'unpaid', quote: 'unpaid', state: 'UNPAID' }),
        );
        await repositories.meltQuoteRepository.upsertMeltQuote(
          createDummyMeltQuote({ quoteId: 'pending', quote: 'pending', state: 'PENDING' }),
        );
        await repositories.meltQuoteRepository.upsertMeltQuote(
          createDummyMeltQuote({ quoteId: 'paid', quote: 'paid', state: 'PAID' }),
        );

        const pending = await repositories.meltQuoteRepository.getPendingMeltQuotes('bolt11');

        expect(pending).toHaveLength(2);
        expect(pending.some((quote) => quote.quoteId === 'paid')).toBe(false);
      } finally {
        await dispose();
      }
    });

    it('persists onchain melt quote fee options and outpoint', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const quote: MeltQuote<'onchain'> = {
          mintUrl: 'https://mint.test/',
          method: 'onchain',
          quoteId: 'onchain-melt-quote',
          quote: 'onchain-melt-quote',
          state: 'PENDING',
          request: 'bc1ptest',
          amount: Amount.from(21),
          unit: 'sat',
          fee_options: [
            {
              fee_index: 7,
              fee_reserve: Amount.from(2),
              estimated_blocks: 3,
            },
          ],
          outpoint: 'txid:0',
          expiry: 1_730_000_000,
          createdAt: 0,
          updatedAt: 0,
        };

        await repositories.meltQuoteRepository.upsertMeltQuote(quote);

        const stored = await repositories.meltQuoteRepository.getMeltQuote(
          'https://mint.test',
          'onchain',
          'onchain-melt-quote',
        );

        expect(stored?.method).toBe('onchain');
        if (stored?.method !== 'onchain') {
          throw new Error('Expected onchain melt quote');
        }
        expect(stored.fee_options).toHaveLength(1);
        expect(stored.fee_options[0]!.fee_index).toBe(7);
        expect(stored.fee_options[0]!.fee_reserve.equals(Amount.from(2))).toBe(true);
        expect(stored.fee_options[0]!.estimated_blocks).toBe(3);
        expect(stored.outpoint).toBe('txid:0');
      } finally {
        await dispose();
      }
    });
  });
}

export async function runReceiveOperationRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('ReceiveOperationRepository contract', () => {
    it('conditionally advances Receive state with monotonic revisions and unchanged request data', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = {
          ...createDummyReceiveOperation(),
          state: 'prepared' as const,
          fee: Amount.from(1),
          outputData: { keep: [], send: [] },
        };
        const repository = repositories.receiveOperationRepository;
        await repository.create(operation);
        expect((await repository.getById(operation.id))?.revision).toBe(0);
        const executing = {
          ...operation,
          state: 'executing' as const,
          revision: 99,
          updatedAt: 2000,
        };
        expect(
          await repository.transition({
            operationId: operation.id,
            expectedState: 'prepared',
            expectedRevision: 1,
            next: executing,
          }),
        ).toBe(false);
        expect(
          await repository.transition({
            operationId: operation.id,
            expectedState: 'prepared',
            expectedRevision: 0,
            next: executing,
          }),
        ).toBe(true);
        expect(
          await repository.transition({
            operationId: operation.id,
            expectedState: 'prepared',
            expectedRevision: 0,
            next: executing,
          }),
        ).toBe(false);
        const stored = await repository.getById(operation.id);
        expect(stored?.revision).toBe(1);
        expect(JSON.stringify(stored?.inputProofs)).toBe(JSON.stringify(operation.inputProofs));
        expect(stored?.state).toBe('executing');
        await expectThrows(
          () =>
            repository.transition({
              operationId: operation.id,
              expectedState: 'executing',
              expectedRevision: 1,
              next: { ...executing, id: 'different' },
            }),
          expect,
        );
        expect((await repository.getById(operation.id))?.revision).toBe(1);
      } finally {
        await dispose();
      }
    });

    it('isolates nested Receive request data on every write and read', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = {
          ...createDummyReceiveOperation(),
          state: 'prepared' as const,
          fee: Amount.from(1),
          outputData: { keep: [], send: [] },
          source: {
            type: 'payment-request' as const,
            requestOperationId: 'parent',
            attemptId: 'attempt',
            transport: 'inband' as const,
          },
        };
        operation.inputProofs[0]!.dleq = { e: 'e', s: 's', r: 'r' };
        const repository = repositories.receiveOperationRepository;
        await repository.create(operation);
        operation.inputProofs[0]!.secret = 'changed';
        operation.inputProofs[0]!.dleq!.e = 'changed';
        operation.source.requestOperationId = 'changed';
        const reads = [
          (await repository.getById(operation.id))!,
          (await repository.getByState('prepared'))[0]!,
          (await repository.getByMintUrl(operation.mintUrl))[0]!,
          (await repository.getByPaymentRequestAttemptId('attempt'))!,
        ];
        for (const snapshot of reads) {
          expect(snapshot.inputProofs[0]!.secret).toBe('receive-secret-1');
          expect(snapshot.inputProofs[0]!.dleq!.e).toBe('e');
          snapshot.inputProofs[0]!.dleq!.e = 'changed again';
        }
        expect((await repository.getById(operation.id))!.inputProofs[0]!.dleq!.e).toBe('e');
        const next = {
          ...reads[0]!,
          state: 'executing' as const,
          fee: Amount.from(1),
          outputData: { keep: [], send: [] },
        };
        await repository.transition({
          operationId: operation.id,
          expectedState: 'prepared',
          expectedRevision: 0,
          next,
        });
        next.inputProofs[0]!.secret = 'changed after transition';
        const pending = (await repository.getPending())[0]!;
        expect(pending.inputProofs[0]!.secret).toBe('receive-secret-1');
        pending.inputProofs[0]!.secret = 'changed pending snapshot';
        expect((await repository.getById(operation.id))!.inputProofs[0]!.secret).toBe(
          'receive-secret-1',
        );
      } finally {
        await dispose();
      }
    });

    it('rolls back a Receive transition with its counter allocation', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyReceiveOperation();
        await repositories.receiveOperationRepository.create(operation);
        await expectThrows(
          () =>
            repositories.withTransaction(async (scope) => {
              await scope.counterRepository.setCounter(operation.mintUrl, 'receive-keyset', 3);
              await scope.receiveOperationRepository.transition({
                operationId: operation.id,
                expectedState: 'init',
                expectedRevision: 0,
                next: {
                  ...operation,
                  state: 'prepared',
                  fee: Amount.from(1),
                  outputData: { keep: [], send: [] },
                },
              });
              throw new Error('abort Receive transaction');
            }),
          expect,
        );
        expect((await repositories.receiveOperationRepository.getById(operation.id))?.state).toBe(
          'init',
        );
        expect(
          (await repositories.receiveOperationRepository.getById(operation.id))?.revision,
        ).toBe(0);
        expect(
          await repositories.counterRepository.getCounter(operation.mintUrl, 'receive-keyset'),
        ).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('rehydrates persisted input proof amounts', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyReceiveOperation();
        await repositories.receiveOperationRepository.create(operation);

        const stored = await repositories.receiveOperationRepository.getById(operation.id);

        expect(stored).toBeDefined();
        expect(stored!.inputProofs).toHaveLength(2);
        expect(stored!.inputProofs[0]!.amount.equals(Amount.from(1))).toBe(true);
        expect(stored!.inputProofs[1]!.amount.equals(Amount.from(2))).toBe(true);
      } finally {
        await dispose();
      }
    });

    it('creates prepared operations with serialized fees', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = {
          ...createDummyReceiveOperation(),
          id: 'receive-op-prepared',
          state: 'prepared',
          fee: Amount.from(1),
          outputData: { keep: [], send: [] },
        } satisfies ReceiveOperation;
        await repositories.receiveOperationRepository.create(operation);

        const stored = await repositories.receiveOperationRepository.getById(operation.id);

        expect(stored).toBeDefined();
        expect(stored!.state).toBe('prepared');
        if (stored!.state === 'prepared') {
          expect(stored!.fee.equals(Amount.from(1))).toBe(true);
        }
      } finally {
        await dispose();
      }
    });

    it('round-trips optional receive operation source metadata', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyReceiveOperation();
        operation.source = {
          type: 'payment-request',
          requestOperationId: 'request-op',
          attemptId: 'attempt-id',
          transport: 'inband',
        };
        await repositories.receiveOperationRepository.create(operation);

        const stored = await repositories.receiveOperationRepository.getById(operation.id);
        const byAttempt =
          await repositories.receiveOperationRepository.getByPaymentRequestAttemptId('attempt-id');

        expect(stored).toBeDefined();
        expect(byAttempt?.id).toBe(operation.id);
        expect(stored!.source?.type).toBe('payment-request');
        if (stored!.source?.type === 'payment-request') {
          expect(stored!.source.requestOperationId).toBe('request-op');
          expect(stored!.source.attemptId).toBe('attempt-id');
        }
      } finally {
        await dispose();
      }
    });
  });
}

export async function runPaymentRequestReceiveRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('PaymentRequestReceiveRepository contract', () => {
    it('round-trips active operations and attempts', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyPaymentRequestReceiveOperation();
        const attempt = createDummyPaymentRequestReceiveAttempt();

        await repositories.paymentRequestReceiveOperationRepository.create(operation);
        await repositories.paymentRequestReceiveAttemptRepository.create(attempt);

        const active =
          await repositories.paymentRequestReceiveOperationRepository.getActiveByRequestId(
            'request-id',
          );
        const attempts =
          await repositories.paymentRequestReceiveAttemptRepository.getByRequestOperationId(
            operation.id,
          );
        const byPayload =
          await repositories.paymentRequestReceiveAttemptRepository.getByPayloadHash(
            operation.id,
            attempt.payloadHash,
          );

        expect(active).toHaveLength(1);
        expect(attempts).toHaveLength(1);
        expect(byPayload).toBeDefined();
        expect(active[0]!.amount.equals(Amount.from(100))).toBe(true);
        expect(attempts[0]!.grossAmount.equals(Amount.from(100))).toBe(true);
      } finally {
        await dispose();
      }
    });

    it('enforces idempotency by request operation and payload hash', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.paymentRequestReceiveAttemptRepository.create(
          createDummyPaymentRequestReceiveAttempt(),
        );

        let duplicateRejected = false;
        try {
          await repositories.paymentRequestReceiveAttemptRepository.create(
            createDummyPaymentRequestReceiveAttempt({ id: 'duplicate-attempt' }),
          );
        } catch {
          duplicateRejected = true;
        }

        expect(duplicateRejected).toBe(true);
      } finally {
        await dispose();
      }
    });

    it('enforces idempotency by transport message id', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.paymentRequestReceiveAttemptRepository.create(
          createDummyPaymentRequestReceiveAttempt(),
        );

        let duplicateRejected = false;
        try {
          await repositories.paymentRequestReceiveAttemptRepository.create(
            createDummyPaymentRequestReceiveAttempt({
              id: 'duplicate-message-attempt',
              payloadHash: 'different-payload-hash',
            }),
          );
        } catch {
          duplicateRejected = true;
        }

        expect(duplicateRejected).toBe(true);
      } finally {
        await dispose();
      }
    });

    it('looks up attempts by transport message id and child receive id', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const attempt = createDummyPaymentRequestReceiveAttempt({
          receiveOperationId: 'receive-op-id',
        });
        await repositories.paymentRequestReceiveAttemptRepository.create(attempt);

        const byMessage =
          await repositories.paymentRequestReceiveAttemptRepository.getByTransportMessageId(
            'message-id',
          );
        const byReceive =
          await repositories.paymentRequestReceiveAttemptRepository.getByReceiveOperationId(
            'receive-op-id',
          );

        expect(byMessage).toBeDefined();
        expect(byReceive).toBeDefined();
        expect(byMessage!.id).toBe(attempt.id);
        expect(byReceive!.id).toBe(attempt.id);
      } finally {
        await dispose();
      }
    });

    it('prefers finalized attempts for request id and payload hash lookups', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.paymentRequestReceiveAttemptRepository.create(
          createDummyPaymentRequestReceiveAttempt({
            id: 'rejected-attempt',
            requestOperationId: 'old-operation',
            transportMessageId: undefined,
            state: 'rejected',
            error: 'below requested amount',
          }),
        );
        await repositories.paymentRequestReceiveAttemptRepository.create(
          createDummyPaymentRequestReceiveAttempt({
            id: 'finalized-attempt',
            requestOperationId: 'new-operation',
            transportMessageId: undefined,
            state: 'finalized',
          }),
        );

        const byRequestPayload =
          await repositories.paymentRequestReceiveAttemptRepository.getByRequestIdAndPayloadHash(
            'request-id',
            'payload-hash',
          );

        expect(byRequestPayload?.id).toBe('finalized-attempt');
      } finally {
        await dispose();
      }
    });
  });
}

export async function runSendOperationRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('SendOperationRepository contract', () => {
    it('round-trips custom-unit send operations in every state', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operations = createDummySendOperationsByState('usd');
        for (const operation of operations) {
          await repositories.sendOperationRepository.create(operation);
        }

        for (const operation of operations) {
          const stored = await repositories.sendOperationRepository.getById(operation.id);
          expect(stored).toBeDefined();
          expect(stored!.unit).toBe('usd');
        }

        const pending = await repositories.sendOperationRepository.getByState('pending');
        expect(pending).toHaveLength(1);
        expect(pending[0]!.unit).toBe('usd');

        const inFlight = await repositories.sendOperationRepository.getPending();
        expect(inFlight).toHaveLength(3);
        for (const operation of inFlight) {
          expect(operation.unit).toBe('usd');
        }
      } finally {
        await dispose();
      }
    });

    it('round-trips legacy P2PK send operation method data', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const publicKey = `02${'11'.repeat(32)}`;
        const operation = createDummyPreparedSendOperation({
          id: 'send-p2pk-legacy',
          method: 'p2pk',
          methodData: { pubkey: publicKey },
        });

        await repositories.sendOperationRepository.create(operation);

        const stored = await repositories.sendOperationRepository.getById(operation.id);
        expect(stored).toBeDefined();
        expect(stored!.method).toBe('p2pk');
        expect(JSON.stringify(stored!.methodData)).toBe(JSON.stringify({ pubkey: publicKey }));
      } finally {
        await dispose();
      }
    });

    it('round-trips structured P2PK send operation method data', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const primaryKey = `02${'22'.repeat(32)}`;
        const secondKey = `03${'33'.repeat(32)}`;
        const refundKey = `02${'44'.repeat(32)}`;
        const methodData = {
          options: {
            pubkey: [primaryKey, secondKey],
            requiredSignatures: 2,
            locktime: 1_730_000_000,
            refundKeys: [refundKey],
            requiredRefundSignatures: 1,
            sigFlag: 'SIG_ALL',
            additionalTags: [['memo', 'payment-request']],
          },
        };
        const operation = createDummyPreparedSendOperation({
          id: 'send-p2pk-structured',
          method: 'p2pk',
          methodData: methodData as unknown as PreparedSendOperation['methodData'],
        });

        await repositories.sendOperationRepository.create(operation);

        const stored = await repositories.sendOperationRepository.getById(operation.id);
        expect(stored).toBeDefined();
        expect(stored!.method).toBe('p2pk');
        expect(JSON.stringify(stored!.methodData)).toBe(JSON.stringify(methodData));
      } finally {
        await dispose();
      }
    });

    it('keeps nested Send request data independent of caller-owned objects', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyPreparedSendOperation({ id: 'immutable-send-request' });
        const original = JSON.stringify(operation);
        await repositories.sendOperationRepository.create(operation);
        operation.inputProofSecrets.push('caller-mutation');
        const read = await repositories.sendOperationRepository.getById(operation.id);
        if (!read || read.state !== 'prepared') throw new Error('Missing prepared Send');
        expect(read.inputProofSecrets.includes('caller-mutation')).toBe(false);
        read.inputProofSecrets.push('query-mutation');
        const stored = await repositories.sendOperationRepository.getById(operation.id);
        expect(
          JSON.stringify(stored && 'inputProofSecrets' in stored ? stored.inputProofSecrets : []),
        ).toBe(JSON.stringify(JSON.parse(original).inputProofSecrets));
      } finally {
        await dispose();
      }
    });

    it('preserves the separate reclaim output plan through create, update, and transition', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const original = createDummyPreparedSendOperation({ id: 'send-reclaim-plan' });
        const reclaimData = {
          version: 1 as const,
          operationId: original.id,
          mintUrl: original.mintUrl,
          unit: original.unit,
          inputProofSecrets: ['reclaim-input'],
          inputOwnership: 'used' as const,
          outputData: { keep: [], send: [] },
          spendingPath: 'refund' as const,
          conditionFingerprint: 'condition-fingerprint',
          refundPublicKeyX: '11'.repeat(32),
          allocation: { keysetId: 'keyset-id', counterStart: 0, counterEnd: 0 },
          planCommitment: 'commitment',
        };
        const operation: SendOperation = { ...original, state: 'rolling_back', reclaimData };
        await repositories.sendOperationRepository.create(operation);
        let stored = await repositories.sendOperationRepository.getById(operation.id);
        expect(JSON.stringify(stored!.reclaimData)).toBe(JSON.stringify(reclaimData));
        expect(
          JSON.stringify(stored && 'outputData' in stored ? stored.outputData : undefined),
        ).toBe(JSON.stringify(original.outputData));
        await repositories.sendOperationRepository.update({ ...operation, error: 'interrupted' });
        stored = await repositories.sendOperationRepository.getById(operation.id);
        expect(JSON.stringify(stored!.reclaimData)).toBe(JSON.stringify(reclaimData));
        expect(
          await repositories.sendOperationRepository.transition({
            operationId: operation.id,
            expectedState: 'rolling_back',
            expectedRevision: stored!.revision ?? 0,
            next: { ...operation, state: 'rolled_back' },
          }),
        ).toBe(true);
        stored = await repositories.sendOperationRepository.getById(operation.id);
        expect(JSON.stringify(stored!.reclaimData)).toBe(JSON.stringify(reclaimData));
      } finally {
        await dispose();
      }
    });

    it('normalizes legacy revisions and allows only one conditional transition winner', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const prepared = createDummyPreparedSendOperation({
          id: 'send-cas',
          revision: undefined,
        });
        await repositories.sendOperationRepository.create(prepared);

        const legacy = await repositories.sendOperationRepository.getById(prepared.id);
        expect(legacy?.revision).toBe(0);

        const next = {
          ...prepared,
          state: 'executing',
          updatedAt: 1234,
          executionMemo: 'persisted before transport',
        } as SendOperation;
        const winners = await Promise.all([
          repositories.sendOperationRepository.transition({
            operationId: prepared.id,
            expectedState: 'prepared',
            expectedRevision: 0,
            next,
          }),
          repositories.sendOperationRepository.transition({
            operationId: prepared.id,
            expectedState: 'prepared',
            expectedRevision: 0,
            next,
          }),
        ]);
        expect(winners.filter(Boolean)).toHaveLength(1);

        const stored = await repositories.sendOperationRepository.getById(prepared.id);
        expect(stored?.state).toBe('executing');
        expect(stored?.revision).toBe(1);
        expect(stored?.updatedAt).toBe(1000);
        expect(stored?.executionMemo).toBe('persisted before transport');
      } finally {
        await dispose();
      }
    });
  });
}

export async function runMeltOperationRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('MeltOperationRepository contract', () => {
    it('round-trips custom-unit init melt operations', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const operation = createDummyMeltOperation({
          quoteId: 'init-melt-quote',
          unit: 'usd',
        });
        await repositories.meltOperationRepository.create(operation);

        const stored = await repositories.meltOperationRepository.getById(operation.id);

        expect(stored).toBeDefined();
        expect(stored!.state).toBe('init');
        expect(stored!.quoteId).toBe('init-melt-quote');
        expect(stored!.unit).toBe('usd');
      } finally {
        await dispose();
      }
    });

    it('rejects duplicate quote-bound melt operations', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.meltOperationRepository.create(
          createDummyMeltOperation({ id: 'melt-op-1', quoteId: 'shared-melt-quote' }),
        );

        await expectThrows(
          () =>
            repositories.meltOperationRepository.create(
              createDummyMeltOperation({ id: 'melt-op-2', quoteId: 'shared-melt-quote' }),
            ),
          expect,
        );
      } finally {
        await dispose();
      }
    });

    it('rejects updates that would duplicate a melt quote binding', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.meltOperationRepository.create(
          createDummyMeltOperation({ id: 'melt-op-1', quoteId: 'shared-melt-quote' }),
        );
        await repositories.meltOperationRepository.create(
          createDummyMeltOperation({ id: 'melt-op-2', quoteId: 'other-melt-quote' }),
        );

        await expectThrows(
          () =>
            repositories.meltOperationRepository.update(
              createDummyMeltOperation({ id: 'melt-op-2', quoteId: 'shared-melt-quote' }),
            ),
          expect,
        );
      } finally {
        await dispose();
      }
    });
  });
}

export async function runAuthSessionRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('AuthSessionRepository contract', () => {
    it('saveSession + getSession round-trip', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const repo = repositories.authSessionRepository;
        const session = createDummyAuthSession();
        await repo.saveSession(session);
        const result = await repo.getSession(session.mintUrl);
        expect(result).toBeDefined();
        expect(result!.mintUrl).toBe(session.mintUrl);
        expect(result!.accessToken).toBe(session.accessToken);
        expect(result!.expiresAt).toBe(session.expiresAt);
      } finally {
        await dispose();
      }
    });

    it('getSession returns null for unknown mintUrl', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const result = await repositories.authSessionRepository.getSession('https://unknown.test');
        expect(result).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('saveSession upserts on same mintUrl', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const repo = repositories.authSessionRepository;
        const session = createDummyAuthSession();
        await repo.saveSession(session);

        const updated = { ...session, accessToken: 'new-token-456' };
        await repo.saveSession(updated);

        const result = await repo.getSession(session.mintUrl);
        expect(result).toBeDefined();
        expect(result!.accessToken).toBe('new-token-456');

        const all = await repo.getAllSessions();
        expect(all).toHaveLength(1);
      } finally {
        await dispose();
      }
    });

    it('deleteSession removes session', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const repo = repositories.authSessionRepository;
        const session = createDummyAuthSession();
        await repo.saveSession(session);
        await repo.deleteSession(session.mintUrl);
        const result = await repo.getSession(session.mintUrl);
        expect(result).toBe(null);
      } finally {
        await dispose();
      }
    });

    it('getAllSessions returns all stored sessions', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const repo = repositories.authSessionRepository;
        await repo.saveSession(createDummyAuthSession({ mintUrl: 'https://mint-a.test' }));
        await repo.saveSession(createDummyAuthSession({ mintUrl: 'https://mint-b.test' }));
        await repo.saveSession(createDummyAuthSession({ mintUrl: 'https://mint-c.test' }));

        const all = await repo.getAllSessions();
        expect(all).toHaveLength(3);
      } finally {
        await dispose();
      }
    });

    it('persists optional fields (refreshToken, scope, batPool)', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const repo = repositories.authSessionRepository;
        const session = createDummyAuthSession({
          refreshToken: 'refresh-xyz',
          scope: 'read write',
          batPool: [
            { id: 'proof-1', amount: Amount.from(1), secret: 's1', C: 'C1' },
            { id: 'proof-2', amount: Amount.from(2), secret: 's2', C: 'C2' },
          ] as AuthSession['batPool'],
        });
        await repo.saveSession(session);

        const result = await repo.getSession(session.mintUrl);
        expect(result).toBeDefined();
        expect(result!.refreshToken).toBe('refresh-xyz');
        expect(result!.scope).toBe('read write');
        expect(result!.batPool).toBeDefined();
        expect(result!.batPool!).toHaveLength(2);
        expect(result!.batPool![0]!.amount.equals(Amount.from(1))).toBe(true);
        expect(result!.batPool![1]!.amount.equals(Amount.from(2))).toBe(true);
      } finally {
        await dispose();
      }
    });
  });
}

export async function runProofRepositoryContract(
  options: ContractOptions,
  runner: ContractRunner,
): Promise<void> {
  const { describe, it, expect } = runner;

  describe('ProofRepository contract', () => {
    it('preserves request material across metadata mutations and caller-owned snapshots', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const proof = {
          ...createDummyProof(),
          dleq: { e: 'e', s: 's', r: 'r' },
          witness: '{"signatures":["signature"]}',
        };
        const material = (value: CoreProof) =>
          JSON.stringify({
            id: value.id,
            amount: value.amount,
            secret: value.secret,
            C: value.C,
            dleq: value.dleq,
            witness: value.witness,
          });
        const expected = material(proof);
        await repositories.proofRepository.saveProofs(proof.mintUrl, [proof]);
        proof.dleq.e = 'caller-mutation';
        const queried = await repositories.proofRepository.getProofBySecret(
          proof.mintUrl,
          proof.secret,
        );
        expect(material(queried!)).toBe(expected);
        queried!.dleq!.s = 'query-mutation';
        await repositories.proofRepository.reserveProofs(
          proof.mintUrl,
          [proof.secret],
          'request-owner',
        );
        await repositories.proofRepository.setProofState(proof.mintUrl, [proof.secret], 'inflight');
        await repositories.proofRepository.setCreatedByOperation(
          proof.mintUrl,
          [proof.secret],
          'creator',
        );
        await repositories.proofRepository.setProofState(proof.mintUrl, [proof.secret], 'spent');
        await repositories.proofRepository.releaseProofs(proof.mintUrl, [proof.secret]);
        const stored = await repositories.proofRepository.getProofBySecret(
          proof.mintUrl,
          proof.secret,
        );
        expect(material(stored!)).toBe(expected);
      } finally {
        await dispose();
      }
    });

    it('returns matches for a mint', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.proofRepository.saveProofs('https://mint.test', [
          createDummyProof({ secret: 'secret-1' }),
          createDummyProof({ secret: 'secret-2', C: 'C2' }),
        ]);

        const proofs = await repositories.proofRepository.getProofsBySecrets('https://mint.test', [
          'secret-1',
          'secret-2',
        ]);

        expect(proofs).toHaveLength(2);
      } finally {
        await dispose();
      }
    });

    it('ignores missing secrets', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.proofRepository.saveProofs('https://mint.test', [
          createDummyProof({ secret: 'secret-1' }),
        ]);

        const proofs = await repositories.proofRepository.getProofsBySecrets('https://mint.test', [
          'secret-1',
          'missing-secret',
        ]);

        expect(proofs).toHaveLength(1);
      } finally {
        await dispose();
      }
    });

    it('does not return proofs from another mint', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.proofRepository.saveProofs('https://mint.test', [
          createDummyProof({ secret: 'shared-secret' }),
        ]);
        await repositories.proofRepository.saveProofs('https://other-mint.test', [
          createDummyProof({ mintUrl: 'https://other-mint.test', secret: 'shared-secret' }),
        ]);

        const proofs = await repositories.proofRepository.getProofsBySecrets('https://mint.test', [
          'shared-secret',
        ]);

        expect(proofs).toHaveLength(1);
        expect(proofs[0]?.mintUrl).toBe('https://mint.test');
      } finally {
        await dispose();
      }
    });

    it('does not duplicate returned proofs for repeated secrets', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.proofRepository.saveProofs('https://mint.test', [
          createDummyProof({ secret: 'secret-1' }),
        ]);

        const proofs = await repositories.proofRepository.getProofsBySecrets('https://mint.test', [
          'secret-1',
          'secret-1',
          'secret-1',
        ]);

        expect(proofs).toHaveLength(1);
      } finally {
        await dispose();
      }
    });

    it('returns large secret batches without hitting adapter query limits', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const secrets = Array.from({ length: 1100 }, (_, index) => `secret-${index}`);
        await repositories.proofRepository.saveProofs(
          'https://mint.test',
          secrets.map((secret, index) =>
            createDummyProof({
              secret,
              C: `C-${index}`,
            }),
          ),
        );

        const proofs = await repositories.proofRepository.getProofsBySecrets(
          'https://mint.test',
          secrets,
        );

        expect(proofs).toHaveLength(secrets.length);
        expect(new Set(proofs.map((proof) => proof.secret)).size).toBe(secrets.length);
      } finally {
        await dispose();
      }
    });

    it('round-trips proof units and filters ready proofs by unit', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        await repositories.proofRepository.saveProofs('https://mint.test', [
          createDummyProof({ secret: 'sat-secret', C: 'C-sat', unit: 'sat' }),
          createDummyProof({ secret: 'usd-secret', C: 'C-usd', unit: 'USD' }),
        ]);

        const satProofs = await repositories.proofRepository.getReadyProofs('https://mint.test', {
          unit: 'sat',
        });
        const usdProofs = await repositories.proofRepository.getAvailableProofs(
          'https://mint.test',
          { unit: 'usd' },
        );
        const allUsd = await repositories.proofRepository.getAllReadyProofs({ units: ['usd'] });

        expect(satProofs).toHaveLength(1);
        expect(usdProofs).toHaveLength(1);
        expect(allUsd).toHaveLength(1);
        expect(usdProofs[0]?.unit).toBe('usd');
      } finally {
        await dispose();
      }
    });

    it('rejects proofs without a unit', async () => {
      const { repositories, dispose } = await options.createRepositories();
      try {
        const proof = createDummyProof({ secret: 'missing-unit' }) as unknown as Omit<
          CoreProof,
          'unit'
        >;
        delete (proof as { unit?: string }).unit;

        await expectThrows(
          () => repositories.proofRepository.saveProofs('https://mint.test', [proof as CoreProof]),
          expect,
        );
      } finally {
        await dispose();
      }
    });
  });
}

export { runIntegrationTests } from './integration.ts';
export type { IntegrationTestRunner, IntegrationTestOptions } from './integration.ts';
// Migration tests temporarily disabled - architecture being reconsidered
// export { runMigrationTests } from './migrations.ts';
// export type { MigrationTestRunner, MigrationTestOptions } from './migrations.ts';
export { createFakeInvoice } from 'fake-bolt11';
export type { FakeInvoiceOptions } from 'fake-bolt11';
