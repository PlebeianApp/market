# Plugins

Coco's plugin system allows you to extend the wallet's functionality by hooking into its lifecycle and registering custom APIs.

Plugin authors should import plugin lifecycle types, extension augmentation
types, service keys, and plugin errors from `@cashu/coco-core/plugin`.
Applications still import `initializeCoco` and manager-facing symbols from the
package root.

## Basic Plugin Structure

A plugin is an object that implements the `Plugin` interface:

```ts
import type { Plugin } from '@cashu/coco-core/plugin';

const myPlugin: Plugin<['eventBus', 'logger']> = {
  name: 'my-plugin',
  required: ['eventBus', 'logger'],
  onInit(ctx) {
    // Called when the plugin system initializes
    ctx.services.logger.info('Plugin initialized!');

    // Subscribe to events
    const unsubscribe = ctx.services.eventBus.on('proofs:saved', (payload) => {
      ctx.services.logger.info('Proofs saved', payload);
    });

    // Return cleanup function (optional)
    return unsubscribe;
  },
  onReady(ctx) {
    // Called after all plugins have been initialized
    ctx.services.logger.info('Plugin ready!');
  },
  onDispose() {
    // Called when the manager is disposed
  },
};
```

## Registering Plugins

Pass plugins to `initializeCoco()` via the `plugins` config option:

```ts
import { initializeCoco } from '@cashu/coco-core';

const manager = await initializeCoco({
  repo,
  seedGetter,
  plugins: [myPlugin],
});
```

Or register them at runtime using `manager.use()`:

```ts
manager.use(myPlugin);
```

## Available Services

Plugins can request supported service capabilities by declaring them in the `required` array. The following service keys are available:

These service keys are the supported plugin service surface. Plugins should import
`ServiceKey`, `ServiceMap`, `Plugin`, `PluginContext`, and `PluginExtensions` from
`@cashu/coco-core/plugin` instead of the package root. `PluginHost` is runtime
implementation wiring and is not needed to author extensions.

| Service                        | Description                                 |
| ------------------------------ | ------------------------------------------- |
| `mintService`                  | Manage mints (add, update, trust/untrust)   |
| `proofService`                 | Manage proofs (save, delete, query)         |
| `keyRingService`               | P2PK key management                         |
| `walletRestoreService`         | Restore/sweep with caller-supplied material |
| `counterService`               | Keyset counter management                   |
| `tokenService`                 | Token decoding and encoding helpers         |
| `historyService`               | Transaction history                         |
| `sendOperationService`         | Send operation lifecycle                    |
| `receiveOperationService`      | Receive operation lifecycle                 |
| `meltOperationService`         | Melt operation lifecycle                    |
| `mintOperationService`         | Mint operation lifecycle                    |
| `quotes`                       | Canonical quote create/import/lookup API    |
| `paymentRequestService`        | Payment request helpers                     |
| `paymentRequestReceiveService` | Payment request receive operation lifecycle |
| `subscriptions`                | Lifecycle-fenced subscription capability    |
| `eventBus`                     | Subscribe to Core events                    |
| `logger`                       | Logging interface                           |

Each supported key resolves to a dedicated plugin capability, not the corresponding internal Coco
service. Capability objects, the selected `ctx.services` map, and the plugin context are frozen
null-prototype objects. Their methods are an explicit allowlist of immutable wrappers, so adding a
method or dependency to an internal service does not add plugin authority. A fresh facade is created
for each plugin hook; concrete-instance identity, reflective dependency fields, event publication,
repository roots, transaction runners, transports, and other implementation objects are not part of
the plugin contract.

Capability return values and callback payloads are detached or sanitized before they cross the
boundary. Explicit adapters reconstruct supported domain values, including `PaymentRequest`,
`Response`, `Amount`, `OutputData`, dates, buffers, arrays, and plain records. Unsupported class
instances are rejected; Core-owned objects are never frozen or returned in place. Errors do not
retain internal `cause` graphs. This is intentionally incompatible with
plugins that used reflection, concrete `instanceof` checks, method replacement, or undocumented
service fields. Use only the operations declared by the exported capability interface.

The plugin boundary never exposes the Wallet Seed or a low-level wallet object that contains it.
This is true even for trusted, first-party plugins: `seedService` and `walletService` are not valid
service keys, and a plugin that requests an unavailable key is rejected before its lifecycle hook
runs. `walletRestoreService` accepts only caller-supplied restore inputs and never returns Coco's
configured wallet. P2PK/NUT-20 key material and proof secrets returned by their explicit capability
methods remain intentional sensitive domain outputs; they are not the master Wallet Seed.

Plugins that sync externally created mint quotes can request `quotes` and use
the same canonical quote API available on the manager:

```ts
import type { Plugin } from '@cashu/coco-core/plugin';

const externalQuotePlugin: Plugin<['quotes']> = {
  name: 'external-quote-plugin',
  required: ['quotes'],
  onReady: async ({ services }) => {
    await services.quotes.mint.import({
      mintUrl,
      method: 'bolt11',
      quote,
    });
  },
};
```

## Plugin Extensions

Plugins can register custom APIs that become accessible via `manager.ext`. This allows plugins to expose their own public interface to consumers.

### Registering an Extension

Use `ctx.registerExtension(key, api)` in your plugin's `onInit` or `onReady` hook:

```ts
import type { Plugin, PluginEventBus } from '@cashu/coco-core/plugin';

class MyPluginApi {
  constructor(private eventBus: PluginEventBus) {}

  onSubscriptionsResumed(handler: () => void): () => void {
    return this.eventBus.on('subscriptions:resumed', handler);
  }

  async fetchData() {
    // Custom plugin logic
    return { data: 'example' };
  }
}

const myPlugin: Plugin<['eventBus']> = {
  name: 'my-plugin',
  required: ['eventBus'],
  onInit(ctx) {
    const api = new MyPluginApi(ctx.services.eventBus);
    ctx.registerExtension('myPlugin', api);
  },
};
```

The `registerExtension` function is hook-scoped. Call it before that specific `onInit` or `onReady`
hook settles; a retained registrar rejects afterward, including during and after disposal.
Keys must be primitive strings containing 1–128 UTF-16 code units. Coco rejects objects, proxies,
boxed strings, symbols, and empty/oversized keys without invoking conversion hooks. `__proto__`,
`prototype`, `constructor`, and unusual Unicode are valid ordinary keys in the null-prototype
namespace, and the first owner cannot be overwritten.

### Using Extensions

After initialization, access the extension via `manager.ext`:

```ts
const manager = await initializeCoco({
  repo,
  seedGetter,
  plugins: [myPlugin],
});

// Access the plugin's API
const unsubscribe = manager.ext.myPlugin.onSubscriptionsResumed(() => {});
const result = await manager.ext.myPlugin.fetchData();
```

### TypeScript Support

For full TypeScript autocomplete and type safety, plugin authors should augment the `PluginExtensions` interface using module augmentation:

```ts
// my-plugin/index.ts
import type { Plugin, PluginEventBus, PluginExtensions } from '@cashu/coco-core/plugin';

// Define your API class
export class MyPluginApi {
  constructor(private eventBus: PluginEventBus) {}
  onSubscriptionsResumed(handler: () => void): () => void {
    return this.eventBus.on('subscriptions:resumed', handler);
  }
  async fetchData(): Promise<{ data: string }> {
    /* ... */
  }
}

// Augment PluginExtensions for type safety
declare module '@cashu/coco-core/plugin' {
  interface PluginExtensions {
    myPlugin: MyPluginApi;
  }
}

// Export the plugin
export const myPlugin: Plugin<['eventBus']> = {
  name: 'my-plugin',
  required: ['eventBus'],
  onInit(ctx) {
    ctx.registerExtension('myPlugin', new MyPluginApi(ctx.services.eventBus));
  },
};
```

When consumers import your plugin, they automatically get full type support:

```ts
import { initializeCoco } from '@cashu/coco-core';
import { myPlugin } from 'my-plugin'; // Type augmentation is included

const manager = await initializeCoco({
  plugins: [myPlugin],
  // ...
});

// Full autocomplete and type checking!
manager.ext.myPlugin.doSomething();
const result = await manager.ext.myPlugin.fetchData();
//    ^? Promise<{ data: string }>
```

### Extension Conflicts

Each extension key must be unique. If two plugins attempt to register the same key, an `ExtensionRegistrationError` will be thrown during initialization:

```ts
// This will throw an error
const pluginA: Plugin<['logger']> = {
  name: 'plugin-a',
  required: ['logger'],
  onInit(ctx) {
    ctx.registerExtension('shared', { from: 'A' });
  },
};

const pluginB: Plugin<['logger']> = {
  name: 'plugin-b',
  required: ['logger'],
  onInit(ctx) {
    ctx.registerExtension('shared', { from: 'B' }); // Throws!
  },
};
```

## Lifecycle Hooks

### `onInit(ctx)`

Called when the plugin system initializes. This is where you should:

- Set up event listeners
- Register extensions
- Initialize plugin state

The context provides access to requested services and the `registerExtension` method.

`eventBus` is subscribe-only (`on`, `once`, and `off`). Plugins cannot publish Core events. An
extension can expose objects the plugin created or legitimately received, but extension registration
does not grant access to additional Coco capabilities.

Capability authority is active only after factory-controlled recovery and is revoked synchronously
when `manager.dispose()` begins. Retained capability calls reject after revocation. Cleanup-only
unsubscribe/off handles are idempotent no-ops after revocation so disposal cannot strand resources,
and they cannot recreate transport or background work.

Native promises, foreign promises, and custom thenables remain accounted until settlement. Coco
captures its promise and timer operations before hooks run, so changing `Promise.resolve`, promise
prototype methods, or timers cannot bypass accounting. Disposal stops transports and callback
producers before the bounded drain. `lifecycle.disposeTimeoutMs` defaults to 5000ms; when it expires,
Coco still attempts all eligible cleanup and releases durable Wallet Authority before reporting an
aggregate timeout failure.

Return a cleanup function to be called during disposal (optional).

### `onReady(ctx)`

Called after all plugins have completed their `onInit` phase. Use this for:

- Logic that depends on other plugins being initialized
- Registering extensions that depend on other extensions

Return a cleanup function to be called during disposal (optional).

### `onDispose()`

Called when `manager.dispose()` is invoked. Use this for:

- Cleaning up resources
- Closing connections
- Flushing data

## Plugin Initialization Order

When using `initializeCoco()`:

1. Storage is opened and Wallet authority is acquired
2. Legacy reconciliation and all durable operation recovery completes
3. The private quiescence barrier is marked complete
4. Plugin initialization begins:
   - All plugins' `onInit` hooks run in registration order
   - All plugins' `onReady` hooks run in registration order
5. Watchers and processors are enabled
6. Manager is returned, fully initialized

This ensures that `manager.ext` contains all registered extensions before the manager is returned to the caller.

## Direct Manager Instantiation

Direct `Manager` construction is intentionally not a Wallet boot path. A directly constructed
Manager remains permanently quiescent: plugin hooks, subscriptions, watchers, and processors
cannot be activated. Use `initializeCoco()` for every running Wallet:

```ts
const manager = await initializeCoco({ repo: repositories, seedGetter, plugins: [myPlugin] });
```

## Error Handling

- Errors in `onInit` and `onReady` are logged but do not prevent other plugins from initializing
- `ExtensionRegistrationError` (duplicate keys) will propagate and fail initialization
- An unavailable requested service fails initialization before the plugin hook or disposal hook runs
- Disposal attempts every eligible hook and cleanup, then reports aggregate failures
- A disposal deadline failure leaves the Manager permanently revoked and is reported only after
  best-effort resource cleanup and durable authority release
