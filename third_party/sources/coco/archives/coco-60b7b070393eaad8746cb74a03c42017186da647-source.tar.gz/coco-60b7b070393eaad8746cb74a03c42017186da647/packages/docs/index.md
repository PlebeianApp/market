---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: 'Coco'
  text: 'A Cashu toolkit in TypeScript'
  tagline: Build Cashu applications with ease
  image:
    src: './coco.png'
    alt: 'Coco Logo'
  actions:
    - theme: brand
      text: Get Started
      link: /starting/start-here
    - theme: alt
      text: Github
      link: https://github.com/cashubtc/coco

features:
  - title: Platform agnostic
    details: Coco works in the browser, NodeJS or React Native
  - title: Batteries Included
    details: Coco brings everything you need to build a Cashu wallet. Without the complexity
  - title: Lifecycle APIs
    details: Use `manager.ops.send`, `manager.ops.receive`, and `manager.ops.melt` for recoverable operation workflows
---
