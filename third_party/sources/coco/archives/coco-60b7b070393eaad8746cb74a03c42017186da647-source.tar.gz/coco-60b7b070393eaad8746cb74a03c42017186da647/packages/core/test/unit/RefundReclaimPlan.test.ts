import { describe, expect, it } from 'bun:test';
import {
  commitRefundReclaimPlan,
  parseCommittedRefundReclaimPlan,
  serializeCommittedRefundReclaimPlan,
  verifyCommittedRefundReclaimPlan,
  type CommittedRefundReclaimPlan,
  type RefundReclaimPlan,
} from '../../operations/send/RefundReclaimPlan.ts';

const seed = new Uint8Array(32).fill(7);

function committedPlan(): CommittedRefundReclaimPlan {
  const plan: RefundReclaimPlan = {
    version: 1,
    operationId: 'refund-shape-test',
    mintUrl: 'https://mint.test',
    unit: 'sat',
    inputProofSecrets: ['proof-a', 'proof-b'],
    inputOwnership: 'created',
    spendingPath: 'refund',
    conditionFingerprint: 'ab'.repeat(32),
    refundPublicKeyX: 'cd'.repeat(32),
    outputData: {
      keep: [
        {
          blindedMessage: { amount: '3', id: 'keyset-1', B_: '02abcd' },
          blindingFactor: '12',
          secret: '736563726574',
        },
      ],
      send: [],
    },
    allocation: { keysetId: 'keyset-1', counterStart: 4, counterEnd: 5 },
  };
  return { ...plan, planCommitment: commitRefundReclaimPlan(plan, seed) };
}

describe('strict refund reclaim plan authentication', () => {
  it('is key-order independent while authenticating the complete exact shape', () => {
    const original = committedPlan();
    const reordered = Object.fromEntries(
      Object.entries(original).reverse(),
    ) as unknown as CommittedRefundReclaimPlan;
    reordered.outputData = Object.fromEntries(
      Object.entries(reordered.outputData).reverse(),
    ) as unknown as CommittedRefundReclaimPlan['outputData'];
    reordered.outputData.keep[0] = Object.fromEntries(
      Object.entries(reordered.outputData.keep[0]!).reverse(),
    ) as CommittedRefundReclaimPlan['outputData']['keep'][number];

    expect(verifyCommittedRefundReclaimPlan(reordered, seed)).toBe(reordered);
    expect(serializeCommittedRefundReclaimPlan(reordered)).toBe(
      serializeCommittedRefundReclaimPlan(original),
    );
  });

  const extensionCases: ReadonlyArray<readonly [string, (plan: any) => void]> = [
    ['plan', (plan) => (plan.extension = true)],
    ['allocation', (plan) => (plan.allocation.extension = true)],
    ['output data', (plan) => (plan.outputData.extension = true)],
    ['output', (plan) => (plan.outputData.keep[0].extension = true)],
    ['blinded message', (plan) => (plan.outputData.keep[0].blindedMessage.extension = true)],
    ['input array', (plan) => (plan.inputProofSecrets.extension = true)],
    ['output array', (plan) => (plan.outputData.keep.extension = true)],
  ];

  for (const [name, extend] of extensionCases) {
    it(`rejects an unexpected ${name} field under the old commitment`, () => {
      const plan: any = structuredClone(committedPlan());
      extend(plan);
      expect(() => verifyCommittedRefundReclaimPlan(plan, seed)).toThrow();
    });
  }

  it('rejects symbols, non-enumerable fields, custom prototypes, accessors, holes, and undefined', () => {
    const symbolPlan: any = committedPlan();
    symbolPlan[Symbol('extension')] = true;
    expect(() => parseCommittedRefundReclaimPlan(symbolPlan)).toThrow();

    const hiddenPlan: any = committedPlan();
    Object.defineProperty(hiddenPlan.outputData.keep[0], 'hidden', { value: true });
    expect(() => parseCommittedRefundReclaimPlan(hiddenPlan)).toThrow();

    const prototypePlan: any = committedPlan();
    Object.setPrototypeOf(prototypePlan.allocation, { polluted: true });
    expect(() => parseCommittedRefundReclaimPlan(prototypePlan)).toThrow();

    let getterRuns = 0;
    const accessorPlan: any = committedPlan();
    Object.defineProperty(accessorPlan, 'unit', {
      enumerable: true,
      get() {
        getterRuns++;
        return 'sat';
      },
    });
    expect(() => parseCommittedRefundReclaimPlan(accessorPlan)).toThrow();
    expect(getterRuns).toBe(0);

    const holePlan: any = committedPlan();
    delete holePlan.inputProofSecrets[0];
    expect(() => parseCommittedRefundReclaimPlan(holePlan)).toThrow();

    const undefinedPlan: any = committedPlan();
    undefinedPlan.unit = undefined;
    expect(() => parseCommittedRefundReclaimPlan(undefinedPlan)).toThrow();

    const missingPlan: any = committedPlan();
    delete missingPlan.unit;
    expect(() => parseCommittedRefundReclaimPlan(missingPlan)).toThrow();
  });
});
