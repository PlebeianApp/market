import { describe, expect, test } from 'bun:test';
import { PaymentRequest } from '@cashu/cashu-ts';

const CORE_ROOT = '/home/maximoto/dev/coco-market-prod-2026-09-21/packages/core';
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

async function probe(label: string, modulePath: string): Promise<void> {
  const core: any = await import(modulePath);
  const mint = `https://round7-prototype-${label}.invalid`;
  const encoded = new PaymentRequest([], `prototype-${label}`, 3n, 'sat', [
    mint,
  ]).toEncodedRequest();
  const originalMap = Array.prototype.map;
  let logged: any;
  let returned: any;
  let capturedOriginal: unknown;
  let mapCalls = 0;
  const logger = {
    error() {},
    warn() {},
    debug() {},
    info(_message: string, ...meta: unknown[]) {
      for (const item of meta as any[])
        if (item?.decodedPaymentRequest) logged = item.decodedPaymentRequest;
    },
    child() {
      return this;
    },
  };

  const manager = await core.initializeCoco({
    repo: new core.MemoryRepositories(),
    seedGetter: async () => new Uint8Array(64),
    logger,
    plugins: [
      {
        name: `prototype-detachment-${label}`,
        required: ['paymentRequestService'],
        async onInit({ services }: any) {
          Array.prototype.map = function (...args: unknown[]) {
            if (this.length === 1 && this[0] === mint) {
              mapCalls += 1;
              capturedOriginal = this;
            }
            return Reflect.apply(originalMap, this, args);
          };
          try {
            const resolved = await services.paymentRequestService.parse(encoded);
            returned = resolved.paymentRequest;
          } finally {
            Array.prototype.map = originalMap;
          }
        },
      },
    ],
    ...disabledRuntime,
  });

  try {
    expect(mapCalls).toBe(0);
    expect(capturedOriginal).toBeUndefined();
    expect(returned).not.toBe(logged);
    expect(returned.mints).not.toBe(logged.mints);
    expect(returned.amount).not.toBe(logged.amount);
    expect(returned.toEncodedRequest()).toBe(encoded);
    returned.mints.push('https://plugin-only.invalid');
    expect(logged.mints).toEqual([mint]);
    expect(Object.isFrozen(logged)).toBe(false);
    expect(Object.isFrozen(logged.mints)).toBe(false);
  } finally {
    Array.prototype.map = originalMap;
    await manager.dispose();
  }
}

for (const [label, modulePath] of [
  ['source', `${CORE_ROOT}/index.ts`],
  ['dist', `${CORE_ROOT}/dist/index.js`],
] as const) {
  describe(`round-seven prototype-safe return detachment (${label})`, () => {
    test('never dispatches the Core PaymentRequest through patched Array prototypes', () =>
      probe(label, modulePath));
  });
}
