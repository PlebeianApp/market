import { describe, expect, test } from 'bun:test';

const CORE_ROOT = '/home/maximoto/dev/coco-market-prod-2026-09-21/packages/core';
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

async function probe(label: string, modulePath: string): Promise<void> {
  const core: any = await import(modulePath);
  const originalResolve = Promise.resolve;
  const originalThen = Promise.prototype.then;
  const originalFinally = Promise.prototype.finally;
  let release!: () => void;
  let callbackStarted = false;
  let callbackSettled = false;
  const work = new Promise<void>((resolve) => {
    release = resolve;
  }).finally(() => {
    callbackSettled = true;
  });
  const foreignThenable = Object.create(null, {
    then: { enumerable: true, value: work.then.bind(work) },
  });
  const manager = await core.initializeCoco({
    repo: new core.MemoryRepositories(),
    seedGetter: async () => new Uint8Array(64),
    lifecycle: { disposeTimeoutMs: 500 },
    plugins: [
      {
        name: `foreign-thenable-${label}`,
        required: ['eventBus'],
        onInit({ services }: any) {
          services.eventBus.on('subscriptions:paused', () => {
            callbackStarted = true;
            Promise.resolve = (() => {
              throw new Error('patched Promise.resolve');
            }) as typeof Promise.resolve;
            Promise.prototype.then = (() => {
              throw new Error('patched Promise.then');
            }) as typeof Promise.prototype.then;
            Promise.prototype.finally = (() => {
              throw new Error('patched Promise.finally');
            }) as typeof Promise.prototype.finally;
            return foreignThenable;
          });
        },
      },
    ],
    ...disabledRuntime,
  });

  try {
    await manager.pauseSubscriptions();
  } finally {
    Promise.resolve = originalResolve;
    Promise.prototype.then = originalThen;
    Promise.prototype.finally = originalFinally;
  }
  expect(callbackStarted).toBe(true);
  let disposeReturned = false;
  const disposing = manager.dispose().then(() => {
    disposeReturned = true;
  });
  await Promise.resolve();
  await new Promise((resolve) => setTimeout(resolve, 0));
  expect(callbackSettled).toBe(false);
  expect(disposeReturned).toBe(false);
  release();
  await work;
  await disposing;
  expect(disposeReturned).toBe(true);
}

for (const [label, modulePath] of [
  ['source', `${CORE_ROOT}/index.ts`],
  ['dist', `${CORE_ROOT}/dist/index.js`],
] as const) {
  describe(`round-seven thenable accounting (${label})`, () => {
    test('tracks foreign thenables through patched Promise methods until settlement', () =>
      probe(label, modulePath));
  });
}
