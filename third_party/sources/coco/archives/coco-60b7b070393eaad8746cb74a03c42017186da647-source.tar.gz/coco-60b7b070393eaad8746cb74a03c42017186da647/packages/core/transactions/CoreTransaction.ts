import { OutputData, type OutputDataCreator } from '@cashu/cashu-ts';
import type { Repositories, RepositoryTransactionScope } from '@core/repositories';
import { RepositoryTransactionConflictError } from '@core/repositories';
import {
  RepositoryMintMetadataCommands,
  type ScopedMintMetadataCommands,
} from './scoped/mints/ScopedMintMetadataCommands.ts';
import {
  RepositoryProofCommands,
  type ScopedProofCommands,
} from './scoped/proofs/ScopedProofCommands.ts';
import {
  RepositoryOutputCommands,
  type ScopedOutputCommands,
} from './scoped/outputs/ScopedOutputCommands.ts';
import {
  RepositorySendCommands,
  type ScopedSendCommands,
} from './scoped/send/ScopedSendCommands.ts';
import {
  RepositoryKeypairCommands,
  type ScopedKeypairCommands,
} from './scoped/keypairs/ScopedKeypairCommands.ts';
import { TransactionLifetime } from './scoped/TransactionLifetime.ts';
import {
  RepositoryReceiveCommands,
  type ScopedReceiveCommands,
} from './scoped/receive/ScopedReceiveCommands.ts';

/**
 * Scoped commands sharing one adapter transaction attempt. Await mutations sequentially unless
 * their independence is established; lifetime tracking does not serialize conflicting work.
 */
export interface CoreTransaction {
  readonly mintMetadata: ScopedMintMetadataCommands;
  readonly keypairs: ScopedKeypairCommands;
  readonly proofs: ScopedProofCommands;
  readonly outputs: ScopedOutputCommands;
  readonly sends: ScopedSendCommands;
  readonly receives: ScopedReceiveCommands;
}

export interface CoreTransactionRunner {
  run<T>(work: (transaction: CoreTransaction) => Promise<T>): Promise<T>;
}

const MAX_TRANSACTION_ATTEMPTS = 3;

/** Internal adapter-backed transaction runner owned by the composition root. */
export class RepositoryCoreTransactionRunner implements CoreTransactionRunner {
  readonly #repositories: Repositories;
  readonly #outputDataCreator: OutputDataCreator;

  constructor(repositories: Repositories, outputDataCreator: OutputDataCreator = OutputData) {
    this.#repositories = repositories;
    this.#outputDataCreator = outputDataCreator;
  }

  async run<T>(work: (transaction: CoreTransaction) => Promise<T>): Promise<T> {
    for (let attempt = 1; ; attempt++) {
      try {
        return await this.#repositories.withTransaction((repositories) => {
          const lifetime = new TransactionLifetime();
          return lifetime.run(() =>
            work(lifetime.bind(this.#createTransaction(lifetime.bind(repositories)))),
          );
        });
      } catch (error) {
        if (
          !(error instanceof RepositoryTransactionConflictError) ||
          attempt >= MAX_TRANSACTION_ATTEMPTS
        ) {
          throw error;
        }
        // Yield outside the failed transaction so competing writers can finish before retrying.
        await new Promise((resolve) => setTimeout(resolve, attempt * 5));
      }
    }
  }

  #createTransaction(repositories: RepositoryTransactionScope): CoreTransaction {
    const mintMetadata = new RepositoryMintMetadataCommands(
      repositories.mintRepository,
      repositories.keysetRepository,
    );
    const proofs = new RepositoryProofCommands(
      repositories.proofRepository,
      repositories.keysetRepository,
    );
    const outputs = new RepositoryOutputCommands(
      repositories.counterRepository,
      repositories.keysetRepository,
      this.#outputDataCreator,
    );
    return {
      mintMetadata,
      keypairs: new RepositoryKeypairCommands(repositories.keyRingRepository),
      proofs,
      outputs,
      sends: new RepositorySendCommands(
        repositories.sendOperationRepository,
        [
          { type: 'melt', repository: repositories.meltOperationRepository },
          { type: 'mint', repository: repositories.mintOperationRepository },
          { type: 'receive', repository: repositories.receiveOperationRepository },
          {
            type: 'payment-request-receive',
            repository: repositories.paymentRequestReceiveOperationRepository,
          },
          {
            type: 'payment-request-receive-attempt',
            repository: repositories.paymentRequestReceiveAttemptRepository,
          },
        ],
        proofs,
        outputs,
        mintMetadata,
      ),
      receives: new RepositoryReceiveCommands(
        repositories.receiveOperationRepository,
        [
          { type: 'send', repository: repositories.sendOperationRepository },
          { type: 'melt', repository: repositories.meltOperationRepository },
          { type: 'mint', repository: repositories.mintOperationRepository },
          {
            type: 'payment-request-receive',
            repository: repositories.paymentRequestReceiveOperationRepository,
          },
          {
            type: 'payment-request-receive-attempt',
            repository: repositories.paymentRequestReceiveAttemptRepository,
          },
        ],
        proofs,
        outputs,
        mintMetadata,
      ),
    };
  }
}
