import type { Mint } from '../../models/Mint';
import type { MintRepository } from '..';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapDelete,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryMintRepository implements MintRepository {
  private mints: Map<string, Mint> = createMemoryMap();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryMintRepository): void {
    this.mints = cloneMemoryRepositoryStateValue(source.mints);
  }

  async isTrustedMint(mintUrl: string): Promise<boolean> {
    const mint = memoryMapGet(this.mints, mintUrl);
    return mint?.trusted ?? false;
  }

  async getMintByUrl(mintUrl: string): Promise<Mint> {
    const mint = memoryMapGet(this.mints, mintUrl);
    if (!mint) {
      throw new Error(`Mint not found: ${mintUrl}`);
    }
    return cloneMemoryValue(mint);
  }

  async findMintByUrl(mintUrl: string): Promise<Mint | null> {
    const mint = memoryMapGet(this.mints, mintUrl);
    return mint ? cloneMemoryValue(mint) : null;
  }

  async getAllMints(): Promise<Mint[]> {
    const mints = memoryMapValues(this.mints);
    for (let index = 0; index < mints.length; index += 1) {
      mints[index] = cloneMemoryValue(mints[index]!);
    }
    return mints;
  }

  async getAllTrustedMints(): Promise<Mint[]> {
    const result: Mint[] = [];
    const mints = memoryMapValues(this.mints);
    for (let index = 0; index < mints.length; index += 1) {
      const mint = mints[index]!;
      if (mint.trusted) memoryArrayPush(result, cloneMemoryValue(mint));
    }
    return result;
  }

  async addNewMint(mint: Mint): Promise<void> {
    memoryMapSet(this.mints, mint.mintUrl, cloneMemoryValue(mint));
  }

  async addOrUpdateMint(mint: Mint): Promise<void> {
    memoryMapSet(this.mints, mint.mintUrl, cloneMemoryValue(mint));
  }

  async updateMint(mint: Mint): Promise<void> {
    memoryMapSet(this.mints, mint.mintUrl, cloneMemoryValue(mint));
  }

  async setMintTrusted(mintUrl: string, trusted: boolean): Promise<void> {
    const mint = memoryMapGet(this.mints, mintUrl);
    if (mint) {
      memoryMapSet(this.mints, mintUrl, { ...mint, trusted });
    }
  }

  async deleteMint(mintUrl: string): Promise<void> {
    memoryMapDelete(this.mints, mintUrl);
  }
}
