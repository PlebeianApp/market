import {
  Amount,
  OutputData,
  createBlindSignature,
  createNewMintKeys,
  hashToCurve,
  pointFromHex,
  serializeMintKeys,
  sumProofs,
  type MintKeys,
  type Proof,
} from '@cashu/cashu-ts';
import { describe, expect, it, mock, spyOn } from 'bun:test';
import { CashuSendRemote } from '../../infra/handlers/send/CashuSendRemote.ts';
import { observeOutputProofs } from '../../infra/ProofRestore.ts';
import { validateProofStateResponse } from '../../operations/send/SendRemote.ts';
import type { MintRequestFn } from '../../infra/MintRequestProvider.ts';
import type { MintMetadata } from '../../mints/MintMetadata.ts';
import { ProofValidationError } from '../../models/Error.ts';
import { getProofStateInputsFromSerializedOutputs, serializeOutputData } from '../../utils.ts';
import { testMintInfo } from '../fixtures/MintMetadata.ts';

const mintUrl = 'https://mint.test';
const unit = 'sat';
const seed = new Uint8Array(64).fill(1);
const keyset = createNewMintKeys(8, new Uint8Array(32).fill(2));
const keys: MintKeys = { id: keyset.keysetId, unit, keys: serializeMintKeys(keyset.pubKeys) };
const metadata: MintMetadata = {
  mint: {
    mintUrl,
    name: 'Test Mint',
    trusted: true,
    mintInfo: testMintInfo,
    createdAt: 1,
    updatedAt: 1,
  },
  keysets: [
    { mintUrl, id: keys.id, unit, keypairs: keys.keys, active: true, feePpk: 0, updatedAt: 1 },
  ],
};

function inputProof(secret = 'synthetic-input', amount = 16): Proof {
  const signature = createBlindSignature(
    hashToCurve(new TextEncoder().encode(secret)),
    keyset.privKeys[String(amount)]!,
    keys.id,
  );
  return { id: keys.id, secret, amount: Amount.from(amount), C: signature.C_.toHex(true) };
}

type WireOutput = { id: string; amount: number; B_: string };
function sign(outputs: WireOutput[], signingKeyset = keyset) {
  return outputs.map((output) => {
    const signature = createBlindSignature(
      pointFromHex(output.B_),
      signingKeyset.privKeys[String(output.amount)]!,
      output.id,
    );
    return { id: output.id, amount: output.amount, C_: signature.C_.toHex(true) };
  });
}

function environment(signingKeyset = keyset) {
  const calls: Array<{ endpoint: string; body?: Record<string, unknown> }> = [];
  const request: MintRequestFn = async <T>({
    endpoint,
    requestBody,
  }: Parameters<MintRequestFn>[0]): Promise<T> => {
    calls.push({ endpoint, body: requestBody });
    if (endpoint.endsWith('/swap'))
      return { signatures: sign(requestBody!.outputs as WireOutput[], signingKeyset) } as T;
    if (endpoint.endsWith('/restore'))
      return {
        outputs: requestBody!.outputs,
        signatures: sign(requestBody!.outputs as WireOutput[], signingKeyset),
      } as T;
    if (endpoint.endsWith('/checkstate'))
      return {
        states: (requestBody!.Ys as string[]).map((Y) => ({
          Y,
          state: 'UNSPENT',
          witness: null,
        })),
      } as T;
    throw new Error(`Unexpected endpoint: ${endpoint}`);
  };
  const mint = {
    getAuthProvider: () => undefined,
    fetchMintInfo: mock(async () => testMintInfo),
    fetchKeysets: mock(async () => ({
      keysets: [{ id: keys.id, unit, active: true, input_fee_ppk: 0 }],
    })),
    fetchKeysForId: mock(async () => keys.keys),
  };
  return { remote: new CashuSendRemote(mint, { getRequestFn: () => request }), calls, mint };
}

function restoreStatesWithFirstWitness(
  Ys: string[],
  witness: unknown,
  includeWitness = true,
): unknown[] {
  return Ys.map((Y, index) => {
    const state = { Y, state: 'UNSPENT', witness: null };
    if (index !== 0) return state;
    if (includeWitness) return { ...state, witness };
    const { witness: _witness, ...withoutWitness } = state;
    return withoutWitness;
  });
}

async function observeRestoreStates(stateResponse: (Ys: string[]) => unknown) {
  const keep = OutputData.createDeterministicData(Amount.from(3), seed, 0, keys);
  const outputData = serializeOutputData({ keep, send: [] });
  const wire = keep.map((output) => ({
    id: output.blindedMessage.id,
    amount: output.blindedMessage.amount.toNumber(),
    B_: output.blindedMessage.B_,
  }));
  return observeOutputProofs(
    {
      mint: {
        restore: async () => ({
          outputs: wire.map((output) => ({ ...output, amount: Amount.from(output.amount) })),
          signatures: sign(wire).map((signature) => ({
            ...signature,
            amount: Amount.from(signature.amount),
          })),
        }),
        check: async ({ Ys }: { Ys: string[] }) => ({ states: stateResponse(Ys) }),
      },
    } as never,
    metadata.keysets,
    unit,
    outputData,
  );
}

describe('CashuSendRemote', () => {
  it('distinguishes recovery Restore none, partial, malformed, unmatched, and output states', async () => {
    const keep = OutputData.createDeterministicData(Amount.from(3), seed, 0, keys);
    const outputData = serializeOutputData({ keep, send: [] });
    const wire = keep.map((output) => ({
      id: output.blindedMessage.id,
      amount: output.blindedMessage.amount.toNumber(),
      B_: output.blindedMessage.B_,
    }));
    const rawOutputs = wire.map((output) => ({ ...output, amount: Amount.from(output.amount) }));
    const rawSignatures = sign(wire).map((signature) => ({
      ...signature,
      amount: Amount.from(signature.amount),
    }));
    const keysets = metadata.keysets;
    const observe = (
      restore: () => unknown,
      stateResponse: unknown | ((Ys: string[]) => unknown) = (Ys: string[]) =>
        Ys.map((Y) => ({ Y, state: 'UNSPENT', witness: null })),
    ) =>
      observeOutputProofs(
        {
          mint: {
            restore,
            check: async ({ Ys }: { Ys: string[] }) => ({
              states: typeof stateResponse === 'function' ? stateResponse(Ys) : stateResponse,
            }),
          },
        } as never,
        keysets,
        unit,
        outputData,
      );

    await expect(observe(() => ({ outputs: [], signatures: [] }))).resolves.toEqual({
      status: 'none',
    });
    await expect(
      observe(() => ({ outputs: rawOutputs.slice(0, 1), signatures: rawSignatures.slice(0, 1) })),
    ).resolves.toMatchObject({ status: 'partial', missingOutputs: keep.length - 1 });
    await expect(
      observe(() => ({ outputs: rawOutputs, signatures: rawSignatures.slice(0, -1) })),
    ).resolves.toMatchObject({ status: 'inconclusive', reason: 'malformed' });
    await expect(
      observe(() => ({
        outputs: [{ ...rawOutputs[0]!, B_: `02${'11'.repeat(32)}` }],
        signatures: rawSignatures.slice(0, 1),
      })),
    ).resolves.toMatchObject({ status: 'inconclusive', reason: 'unmatched' });
    await expect(
      observe(
        () => ({ outputs: rawOutputs, signatures: rawSignatures }),
        (Ys: string[]) => Ys.map((Y: string) => ({ Y, state: 'PENDING', witness: null })),
      ),
    ).resolves.toMatchObject({
      status: 'complete',
      outputs: expect.arrayContaining([
        expect.objectContaining({ state: expect.objectContaining({ state: 'PENDING' }) }),
      ]),
    });
    await expect(
      observe(() => {
        throw new Error('offline');
      }),
    ).resolves.toMatchObject({ status: 'inconclusive', reason: 'unavailable' });
  });

  it.each([
    [
      'Y1 wrong Y',
      (Ys: string[]) => [
        { Y: `02${'11'.repeat(32)}`, state: 'UNSPENT', witness: null },
        ...Ys.slice(1).map((Y) => ({ Y, state: 'UNSPENT', witness: null })),
      ],
      'inconclusive',
    ],
    [
      'Y2 duplicate Y',
      (Ys: string[]) => Ys.map(() => ({ Y: Ys[0], state: 'UNSPENT', witness: null })),
      'inconclusive',
    ],
    [
      'Y3 missing Y',
      (Ys: string[]) => Ys.slice(0, -1).map((Y) => ({ Y, state: 'UNSPENT', witness: null })),
      'inconclusive',
    ],
    [
      'Y4 extra Y',
      (Ys: string[]) => [
        ...Ys.map((Y) => ({ Y, state: 'UNSPENT', witness: null })),
        { Y: `03${'22'.repeat(32)}`, state: 'UNSPENT', witness: null },
      ],
      'inconclusive',
    ],
    [
      'Y5 reordered valid Ys',
      (Ys: string[]) => Ys.toReversed().map((Y) => ({ Y, state: 'UNSPENT', witness: null })),
      'complete',
    ],
    [
      'Y6 invalid state enum',
      (Ys: string[]) =>
        Ys.map((Y, index) => ({
          Y,
          state: index === 0 ? 'UNKNOWN' : 'UNSPENT',
          witness: null,
        })),
      'inconclusive',
    ],
    ['Y7 null response', () => null, 'inconclusive'],
    ['Y8 non-array object response', () => ({ state: 'UNSPENT' }), 'inconclusive'],
    [
      'Y9 malformed item',
      (Ys: string[]) =>
        Ys.map((Y, index) =>
          index === 0 ? { Y, witness: null } : { Y, state: 'UNSPENT', witness: null },
        ),
      'inconclusive',
    ],
    [
      'Y10 valid exact set all UNSPENT',
      (Ys: string[]) => Ys.map((Y) => ({ Y, state: 'UNSPENT', witness: null })),
      'complete',
    ],
  ] as const)('Restore state validation: %s', async (_name, stateResponse, status) => {
    const keep = OutputData.createDeterministicData(Amount.from(3), seed, 0, keys);
    const outputData = serializeOutputData({ keep, send: [] });
    const wire = keep.map((output) => ({
      id: output.blindedMessage.id,
      amount: output.blindedMessage.amount.toNumber(),
      B_: output.blindedMessage.B_,
    }));
    const result = await observeOutputProofs(
      {
        mint: {
          restore: async () => ({
            outputs: wire.map((output) => ({ ...output, amount: Amount.from(output.amount) })),
            signatures: sign(wire).map((signature) => ({
              ...signature,
              amount: Amount.from(signature.amount),
            })),
          }),
          check: async ({ Ys }: { Ys: string[] }) => ({ states: stateResponse(Ys) }),
        },
      } as never,
      metadata.keysets,
      unit,
      outputData,
    );
    expect(result.status).toBe(status);
  });

  it.each([
    ['W1 missing witness', null, false, false],
    ['W2 witness undefined', undefined, true, false],
    ['W3 witness object', {}, true, false],
    ['W4 witness array', [], true, false],
    ['W5 witness number', 7, true, false],
    ['W6 witness boolean', true, true, false],
    ['W7 empty witness string', '', true, true],
    ['W8 serialized witness string', JSON.stringify({ signatures: ['signature'] }), true, true],
    ['W9 null witness', null, true, true],
  ] as const)(
    'Restore witness validation: %s',
    async (_name, witness, includeWitness, shouldComplete) => {
      const result = await observeRestoreStates((Ys) =>
        restoreStatesWithFirstWitness(Ys, witness, includeWitness),
      );

      if (!shouldComplete) {
        expect(result).toEqual({
          status: 'inconclusive',
          reason: 'malformed',
          outputs: [],
        });
        return;
      }
      expect(result.status).toBe('complete');
      if (result.status === 'complete') {
        expect(result.outputs[0]!.state.witness).toBe(witness as string | null);
      }
    },
  );

  it('rejects duplicate expected proof identities before accepting NUT-07 evidence', () => {
    const proof = inputProof('duplicate-secret', 1);
    const Y = hashToCurve(new TextEncoder().encode(proof.secret)).toHex(true);
    expect(
      validateProofStateResponse(
        [proof, proof],
        [
          { Y, state: 'UNSPENT', witness: null },
          { Y, state: 'UNSPENT', witness: null },
        ],
      ),
    ).toEqual({ status: 'inconclusive', reason: 'duplicate' });
  });

  it.each(['default', 'p2pk'] as const)(
    'replays the identical %s swap request after losing a cached response',
    async (method) => {
      const inputs = [inputProof('input-a', 2), inputProof('input-b', 2)];
      const keep = OutputData.createDeterministicData(Amount.from(1), seed, 0, keys);
      const send =
        method === 'default'
          ? OutputData.createDeterministicData(Amount.from(3), seed, 1, keys)
          : OutputData.createP2PKData(
              { kind: 'P2PK', data: keys.keys['1']! },
              Amount.from(3),
              keys,
            );
      const swapRequest = {
        mintUrl,
        unit,
        amount: Amount.from(3),
        inputProofs: inputs,
        outputData: serializeOutputData({ keep, send }),
      };
      const bodies: string[] = [];
      const cache = new Map<string, { signatures: ReturnType<typeof sign> }>();
      const request: MintRequestFn = async <T>({
        endpoint,
        requestBody,
      }: Parameters<MintRequestFn>[0]): Promise<T> => {
        expect(endpoint).toBe(`${mintUrl}/v1/swap`);
        const body = JSON.stringify(requestBody);
        bodies.push(body);
        const cached = cache.get(body);
        if (cached) return cached as T;
        if (cache.size > 0) throw new Error('Inputs already spent; cached response missed');
        cache.set(body, { signatures: sign(requestBody!.outputs as WireOutput[]) });
        throw new Error('Swap response lost');
      };
      const remote = new CashuSendRemote(
        { getAuthProvider: () => undefined },
        { getRequestFn: () => request },
      );
      const random = spyOn(Math, 'random').mockReturnValue(0);
      try {
        await expect(remote.open(metadata, unit).swap(swapRequest)).rejects.toThrow(
          'Swap response lost',
        );
        random.mockReturnValue(0.999);
        const result = await remote.open(metadata, unit).swap(swapRequest);
        expect(bodies).toHaveLength(2);
        expect(bodies[1]).toBe(bodies[0]);
        expect(JSON.parse(bodies[0]!).inputs.map((proof: Proof) => proof.secret)).toEqual(
          inputs.map((proof) => proof.secret),
        );
        expect(sumProofs(result.send).toString()).toBe('3');
        expect(sumProofs(result.keep).toString()).toBe('1');
      } finally {
        random.mockRestore();
      }
    },
  );

  it.each(['swap', 'reclaim'] as const)(
    'unblinds %s with the persisted output keyset when another active keyset is cheaper',
    async (operation) => {
      const original = createNewMintKeys(8, new Uint8Array(32).fill(3), {
        input_fee_ppk: 1000,
      });
      const originalKeys: MintKeys = {
        id: original.keysetId,
        unit,
        keys: serializeMintKeys(original.pubKeys),
      };
      const keep = OutputData.createDeterministicData(
        Amount.from(operation === 'swap' ? 8 : 16),
        seed,
        0,
        originalKeys,
      );
      const send =
        operation === 'swap'
          ? OutputData.createDeterministicData(Amount.from(8), seed, keep.length, originalKeys)
          : [];
      const outputData = serializeOutputData({ keep, send });
      const { remote, calls } = environment(original);
      const session = remote.open(
        {
          ...metadata,
          keysets: [
            ...metadata.keysets,
            {
              mintUrl,
              id: originalKeys.id,
              unit,
              keypairs: originalKeys.keys,
              active: true,
              feePpk: 1000,
              updatedAt: 1,
            },
          ],
        },
        unit,
      );
      // Inputs belong to the cheaper keyset. Only the output plan determines unblinding keys.
      const result =
        operation === 'swap'
          ? await session.swap({
              mintUrl,
              unit,
              amount: Amount.from(8),
              inputProofs: [inputProof()],
              outputData,
            })
          : { keep: await session.reclaim([inputProof()], outputData), send: [] };
      expect(calls).toHaveLength(1);
      expect(sumProofs([...result.keep, ...result.send]).toString()).toBe('16');
      for (const proof of [...result.keep, ...result.send]) {
        const expected = createBlindSignature(
          hashToCurve(new TextEncoder().encode(proof.secret)),
          original.privKeys[proof.amount.toString()]!,
          originalKeys.id,
        );
        expect(proof.id).toBe(originalKeys.id);
        expect(proof.C).toBe(expected.C_.toHex(true));
      }
      expect((calls[0]!.body!.outputs as WireOutput[]).map((output) => output.B_).sort()).toEqual(
        [...keep, ...send].map((output) => output.blindedMessage.B_).sort(),
      );
    },
  );

  it.each(['swap', 'reclaim'] as const)(
    'rejects invalid %s output keysets before contacting the mint',
    async (operation) => {
      const outputs = serializeOutputData({
        keep: OutputData.createDeterministicData(Amount.from(8), seed, 0, keys),
        send: OutputData.createDeterministicData(Amount.from(8), seed, 1, keys),
      });
      const missing = {
        ...outputs.keep[0]!,
        blindedMessage: { ...outputs.keep[0]!.blindedMessage, id: '' },
      };
      const different = {
        ...outputs.send[0]!,
        blindedMessage: { ...outputs.send[0]!.blindedMessage, id: 'different-keyset' },
      };
      const mixed =
        operation === 'swap'
          ? { keep: outputs.keep, send: [different] }
          : { keep: [...outputs.keep, different], send: [] };
      for (const outputData of [{ keep: [], send: [] }, { keep: [missing], send: [] }, mixed]) {
        const { remote, calls } = environment();
        const session = remote.open(metadata, unit);
        await expect(
          (async () =>
            operation === 'swap'
              ? session.swap({
                  mintUrl,
                  unit,
                  amount: Amount.from(8),
                  inputProofs: [inputProof()],
                  outputData,
                })
              : session.reclaim([inputProof()], outputData))(),
        ).rejects.toBeInstanceOf(ProofValidationError);
        expect(calls).toHaveLength(0);
      }
    },
  );

  it.each(['default', 'p2pk'] as const)(
    'submits fixed %s outputs and unblinds without seed access or additional metadata calls',
    async (method) => {
      const { remote, calls } = environment();
      const keep = OutputData.createDeterministicData(Amount.from(8), seed, 0, keys);
      const send =
        method === 'default'
          ? OutputData.createDeterministicData(Amount.from(8), seed, 1, keys)
          : OutputData.createP2PKData(
              { kind: 'P2PK', data: keys.keys['1']! },
              Amount.from(8),
              keys,
            );
      const outputData = serializeOutputData({ keep, send });
      const session = remote.open(metadata, unit);
      const result = await session.swap({
        mintUrl,
        unit,
        amount: Amount.from(8),
        inputProofs: [inputProof()],
        outputData,
      });
      expect(sumProofs(result.keep).toString()).toBe('8');
      expect(sumProofs(result.send).toString()).toBe('8');
      expect(result.send[0]!.secret).toBe(new TextDecoder().decode(send[0]!.secret));
      expect(calls).toHaveLength(1);
      expect(calls[0]!.endpoint).toBe(`${mintUrl}/v1/swap`);
      expect((calls[0]!.body!.outputs as WireOutput[]).map((output) => output.B_).sort()).toEqual(
        [...keep, ...send].map((output) => output.blindedMessage.B_).sort(),
      );
      const states = await session.checkProofStates(result.send);
      expect(states.map((state) => state.state)).toEqual(['UNSPENT']);
    },
  );

  it('checks a saved P2PK allocation without proof signatures or amounts', async () => {
    const { remote, calls } = environment();
    const send = OutputData.createP2PKData(
      { kind: 'P2PK', data: keys.keys['1']! },
      Amount.from(8),
      keys,
    );
    const inputs = getProofStateInputsFromSerializedOutputs(
      serializeOutputData({ keep: [], send }).send,
    );

    const states = await remote.open(metadata, unit).checkProofStates(inputs);

    expect(inputs).toEqual([{ id: keys.id, secret: new TextDecoder().decode(send[0]!.secret) }]);
    expect(states.map((state) => state.state)).toEqual(['UNSPENT']);
    expect(calls).toHaveLength(1);
    expect(calls[0]!.endpoint).toBe(`${mintUrl}/v1/checkstate`);
    expect(calls[0]!.body!.Ys).toEqual(states.map((state) => state.Y));
  });

  it('restores and reclaims only the supplied output plan', async () => {
    const { remote, calls } = environment();
    const keep = OutputData.createDeterministicData(Amount.from(16), seed, 0, keys);
    const outputData = serializeOutputData({ keep, send: [] });
    const session = remote.open(metadata, unit);
    const reclaimed = await session.reclaim([inputProof()], outputData);
    const restored = await session.restoreOutputs(outputData);
    expect(restored).toEqual(reclaimed);
    expect(sumProofs(restored).toString()).toBe('16');
    expect(calls.map((call) => call.endpoint)).toEqual([
      `${mintUrl}/v1/swap`,
      `${mintUrl}/v1/restore`,
      `${mintUrl}/v1/checkstate`,
    ]);
  });
});
