import type { HistoryProjectionRepository, MintQuoteRepository } from '..';
import type {
  HistoryEntry,
  HistoryType,
  LegacyHistoryEntry,
  LegacyHistoryRowInput,
  ReceiveHistoryEntry,
  SendHistoryEntry,
} from '@core/models/History';
import {
  compareHistoryEntries,
  parseHistoryEntryId,
  projectLegacyHistoryRow,
  projectMeltOperation,
  projectMintOperation,
  projectReceiveOperation,
  projectSendOperation,
} from '@core/models/History';
import { getMintQuoteRemoteState } from '@core/models/MintQuote';
import type { MintOperation } from '@core/operations/mint';
import type { MemoryMeltOperationRepository } from './MemoryMeltOperationRepository';
import type { MemoryMintOperationRepository } from './MemoryMintOperationRepository';
import type { MemoryReceiveOperationRepository } from './MemoryReceiveOperationRepository';
import {
  createMemorySet,
  memoryArrayPush,
  memoryArraySlice,
  memoryArraySort,
  memorySetAdd,
  memorySetHas,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';
import type { MemorySendOperationRepository } from './MemorySendOperationRepository';

type OperationRepositories = {
  sendOperationRepository?: MemorySendOperationRepository;
  meltOperationRepository?: MemoryMeltOperationRepository;
  mintOperationRepository?: MemoryMintOperationRepository;
  mintQuoteRepository?: MintQuoteRepository;
  receiveOperationRepository?: MemoryReceiveOperationRepository;
};

export class MemoryHistoryRepository implements HistoryProjectionRepository {
  private legacyEntries: LegacyHistoryEntry[] = [];

  constructor(private readonly operationRepositories: OperationRepositories = {}) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryHistoryRepository): void {
    this.legacyEntries = cloneMemoryRepositoryStateValue(source.legacyEntries);
  }

  async getPaginatedHistoryEntries(limit: number, offset: number): Promise<HistoryEntry[]> {
    const entries = await this.getProjectedEntries();
    return memoryArraySlice(entries, offset, offset + limit);
  }

  async getHistoryEntryById(id: string): Promise<HistoryEntry | null> {
    const parsed = parseHistoryEntryId(id);
    if (!parsed) return null;

    if (parsed.source === 'legacy') {
      const entries = await this.getProjectedEntries();
      for (let index = 0; index < entries.length; index += 1) {
        const entry = entries[index]!;
        if (entry.id === id && entry.source === 'legacy') return cloneMemoryValue(entry);
      }
      return null;
    }

    return this.projectOperationById(parsed.type, parsed.operationId);
  }

  async addLegacyHistoryEntry(history: LegacyHistoryRowInput): Promise<LegacyHistoryEntry> {
    const entry = cloneMemoryValue(projectLegacyHistoryRow(history));
    memoryArrayPush(this.legacyEntries, entry);
    return cloneMemoryValue(entry);
  }

  async getSendHistoryEntry(
    mintUrl: string,
    operationId: string,
  ): Promise<SendHistoryEntry | null> {
    const operation =
      await this.operationRepositories.sendOperationRepository?.getById(operationId);
    if (!operation || operation.mintUrl !== mintUrl) return null;
    return projectSendOperation(operation);
  }

  async getReceiveHistoryEntry(
    mintUrl: string,
    operationId: string,
  ): Promise<ReceiveHistoryEntry | null> {
    const operation =
      await this.operationRepositories.receiveOperationRepository?.getById(operationId);
    if (!operation || operation.mintUrl !== mintUrl) return null;
    return projectReceiveOperation(operation);
  }

  private async getProjectedEntries(): Promise<HistoryEntry[]> {
    const operationEntries = await this.getOperationEntries();
    const dedupedLegacyEntries = this.dedupeLegacyEntries(operationEntries);

    const entries: HistoryEntry[] = [];
    for (let index = 0; index < operationEntries.length; index += 1) {
      memoryArrayPush(entries, operationEntries[index]!);
    }
    for (let index = 0; index < dedupedLegacyEntries.length; index += 1) {
      memoryArrayPush(entries, dedupedLegacyEntries[index]!);
    }
    return memoryArraySort(entries, compareHistoryEntries);
  }

  private async getOperationEntries(): Promise<HistoryEntry[]> {
    const entries: HistoryEntry[] = [];

    const sendOperations = await this.operationRepositories.sendOperationRepository?.getAll();
    for (let index = 0; index < (sendOperations?.length ?? 0); index += 1) {
      const operation = sendOperations![index]!;
      const entry = projectSendOperation(operation);
      if (entry) memoryArrayPush(entries, entry);
    }

    const meltOperations = await this.operationRepositories.meltOperationRepository?.getAll();
    for (let index = 0; index < (meltOperations?.length ?? 0); index += 1) {
      const operation = meltOperations![index]!;
      const entry = projectMeltOperation(operation);
      if (entry) memoryArrayPush(entries, entry);
    }

    const mintOperations = await this.operationRepositories.mintOperationRepository?.getAll();
    for (let index = 0; index < (mintOperations?.length ?? 0); index += 1) {
      const operation = mintOperations![index]!;
      const entry = await this.projectMintOperation(operation);
      if (entry) memoryArrayPush(entries, entry);
    }

    const receiveOperations = await this.operationRepositories.receiveOperationRepository?.getAll();
    for (let index = 0; index < (receiveOperations?.length ?? 0); index += 1) {
      const operation = receiveOperations![index]!;
      const entry = projectReceiveOperation(operation);
      if (entry) memoryArrayPush(entries, entry);
    }

    return entries;
  }

  private async projectOperationById(
    type: HistoryType,
    operationId: string,
  ): Promise<HistoryEntry | null> {
    switch (type) {
      case 'send': {
        const operation =
          await this.operationRepositories.sendOperationRepository?.getById(operationId);
        return operation ? projectSendOperation(operation) : null;
      }
      case 'melt': {
        const operation =
          await this.operationRepositories.meltOperationRepository?.getById(operationId);
        return operation ? projectMeltOperation(operation) : null;
      }
      case 'mint': {
        const operation =
          await this.operationRepositories.mintOperationRepository?.getById(operationId);
        return operation ? this.projectMintOperation(operation) : null;
      }
      case 'receive': {
        const operation =
          await this.operationRepositories.receiveOperationRepository?.getById(operationId);
        return operation ? projectReceiveOperation(operation) : null;
      }
    }
  }

  private async projectMintOperation(operation: MintOperation): Promise<HistoryEntry | null> {
    const entry = projectMintOperation(operation);
    if (!entry) return null;

    const quote = await this.operationRepositories.mintQuoteRepository?.getMintQuote(
      operation.mintUrl,
      operation.method,
      operation.quoteId,
    );
    const remoteState = quote ? getMintQuoteRemoteState(quote) : undefined;

    return remoteState ? { ...entry, remoteState } : entry;
  }

  private dedupeLegacyEntries(operationEntries: HistoryEntry[]): LegacyHistoryEntry[] {
    const operationKeys = createMemorySet<string>();
    const quoteKeys = createMemorySet<string>();

    for (let index = 0; index < operationEntries.length; index += 1) {
      const entry = operationEntries[index]!;
      if (entry.source !== 'operation') continue;
      memorySetAdd(operationKeys, this.operationKey(entry.type, entry.operationId));
      if ((entry.type === 'mint' || entry.type === 'melt') && entry.quoteId) {
        memorySetAdd(quoteKeys, this.quoteKey(entry.type, entry.mintUrl, entry.quoteId));
      }
    }

    const entries: LegacyHistoryEntry[] = [];
    for (let index = 0; index < this.legacyEntries.length; index += 1) {
      const entry = this.legacyEntries[index]!;
      if (
        entry.operationId &&
        memorySetHas(operationKeys, this.operationKey(entry.type, entry.operationId))
      ) {
        continue;
      }

      if (
        (entry.type === 'mint' || entry.type === 'melt') &&
        entry.quoteId &&
        memorySetHas(quoteKeys, this.quoteKey(entry.type, entry.mintUrl, entry.quoteId))
      ) {
        continue;
      }

      memoryArrayPush(entries, cloneMemoryValue(entry));
    }
    return entries;
  }

  private operationKey(type: HistoryType, operationId: string): string {
    return `${type}:${operationId}`;
  }

  private quoteKey(type: 'mint' | 'melt', mintUrl: string, quoteId: string): string {
    return `${type}:${mintUrl}:${quoteId}`;
  }
}
