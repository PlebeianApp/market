import type {
  Amount,
  OutputDataLike,
  PaymentRequest,
  PaymentRequestPayload,
  Proof,
  Token,
  Wallet,
} from '@cashu/cashu-ts';
import type { UnitAmount, UnitAmountLike } from '../amounts.ts';
import type {
  BalanceBreakdown,
  BalanceQuery,
  BalanceSnapshot,
  BalancesBreakdownByMint,
  BalancesByMint,
  BalancesByMintAndUnit,
  BalancesByUnit,
  CoreProof,
  MintInfo,
} from '../types.ts';
import type { Mint } from '../models/Mint.ts';
import type { Keyset } from '../models/Keyset.ts';
import type { Counter } from '../models/Counter.ts';
import type { Keypair } from '../models/Keypair.ts';
import type { HistoryEntry } from '../models/History.ts';
import type {
  CheckPaymentMethodCapabilityInput,
  ListPaymentMethodCapabilitiesInput,
  MethodUnitCapability,
  PaymentMethodCapability,
  PaymentMethodCapabilityCheck,
  TopLevelNutCapability,
} from '../services/MintService.ts';
import type {
  PreparedPaymentRequest,
  PaymentRequestExecutionResult,
  ResolvedPaymentRequest,
} from '../services/PaymentRequestService.ts';
import type {
  CreatePaymentRequestReceiveInput,
  PaymentRequestReceiveClaimResult,
} from '../services/PaymentRequestReceiveService.ts';
import type {
  PaymentRequestReceiveOperation,
  PaymentRequestReceiveSource,
  PaymentRequestReceiveState,
} from '../operations/paymentRequestReceive/PaymentRequestReceiveOperation.ts';
import type { PaymentRequestReceiveTransportHandler } from '../infra/handlers/paymentRequestReceive/index.ts';
import type { ExecuteSendOptions } from '../operations/send/SendOperationService.ts';
import type {
  CreateSendOperationOptions,
  InitSendOperation,
  PendingSendOperation,
  PreparedSendOperation,
  SendOperation,
} from '../operations/send/SendOperation.ts';
import type {
  CallerOwnedInitReceiveOperation,
  FinalizedReceiveOperation,
  InitReceiveOperation,
  PreparedReceiveOperation,
  ReceiveOperation,
  ReceiveOperationSource,
} from '../operations/receive/ReceiveOperation.ts';
import type {
  FinalizedMeltOperation,
  InitMeltOperation,
  MeltOperation,
  PendingMeltOperation,
  PreparedMeltOperation,
} from '../operations/melt/MeltOperation.ts';
import type { MeltMethod, MeltMethodInputData } from '../operations/melt/MeltMethodHandler.ts';
import type { FinalizeResult } from '../operations/melt/MeltMethodHandler.ts';
import type { MintOperation, PendingMintOperation } from '../operations/mint/MintOperation.ts';
import type {
  MintMethod,
  MintMethodQuoteImportSnapshot,
  PendingMintCheckResult,
} from '../operations/mint/MintMethodHandler.ts';
import type { ClaimMintQuoteOptions } from '../operations/mint/MintOperationService.ts';
import type { MintQuoteClaimabilityAssessment } from '../models/MintQuoteClaimability.ts';
import type { MeltQuote } from '../models/MeltQuote.ts';
import type { MintQuote } from '../models/MintQuote.ts';
import type { MeltQuoteRef, MintQuoteRef, QuoteIdentity } from '../models/QuoteIdentity.ts';
import type { CoreEvents } from '../events/types.ts';
import type { SubscriptionKind } from '../infra/SubscriptionProtocol.ts';

export type PluginDefaultSupportedMintQuoteMethod = 'bolt11' | 'onchain' | 'bolt12';
export type PluginDefaultSupportedMeltMethod = 'bolt11' | 'bolt12' | 'onchain';

export type PluginCreateMintQuoteInput =
  | {
      mintUrl: string;
      method: 'bolt11';
      amount: UnitAmountLike;
      unit?: string;
      locked?: boolean;
    }
  | { mintUrl: string; method: 'onchain'; unit?: string }
  | {
      mintUrl: string;
      method: 'bolt12';
      unit?: string;
      amount?: UnitAmountLike;
      description?: string;
    };

export type PluginImportMintQuoteInput = {
  mintUrl: string;
  quote: MintMethodQuoteImportSnapshot<'bolt11'>;
  method: 'bolt11';
};

export type PluginListPendingMintQuotesInput = {
  method?: PluginDefaultSupportedMintQuoteMethod;
};

export type PluginCreateMeltQuoteInput<
  TSupported extends PluginDefaultSupportedMeltMethod = PluginDefaultSupportedMeltMethod,
> = {
  [M in TSupported]: {
    mintUrl: string;
    method: M;
    methodData: MeltMethodInputData<M>;
    unit?: string;
  };
}[TSupported];

export type PluginListPendingMeltQuotesInput = {
  method?: PluginDefaultSupportedMeltMethod;
};

/** Explicit plugin capability for mint metadata and trust management. */
export interface PluginMintCapability {
  addMintByUrl(
    mintUrl: string,
    options?: { trusted?: boolean },
  ): Promise<{ mint: Mint; keysets: Keyset[] }>;
  updateMintData(mintUrl: string): Promise<{ mint: Mint; keysets: Keyset[] }>;
  isTrustedMint(mintUrl: string): Promise<boolean>;
  refreshAndCommitIfStale(mintUrl: string): Promise<{ mint: Mint; keysets: Keyset[] }>;
  ensureUpdatedMint(mintUrl: string): Promise<{ mint: Mint; keysets: Keyset[] }>;
  deleteMint(mintUrl: string): Promise<void>;
  getMintInfo(mintUrl: string): Promise<MintInfo>;
  supportsNut(mintUrl: string, nut: TopLevelNutCapability): Promise<boolean>;
  supportsNut29MintQuoteCheck(mintUrl: string, method: string): Promise<boolean>;
  getNut29MintQuoteCheckLimit(mintUrl: string, method: string): Promise<number>;
  assertNutSupported(mintUrl: string, nut: TopLevelNutCapability, scope?: string): Promise<void>;
  checkPaymentMethodCapability(
    input: CheckPaymentMethodCapabilityInput,
  ): Promise<PaymentMethodCapabilityCheck>;
  getMintMethodUnitCapability(
    mintUrl: string,
    nut: 4 | 5,
    method: string,
    unit: string,
  ): Promise<MethodUnitCapability>;
  listPaymentMethodCapabilities(
    input: ListPaymentMethodCapabilitiesInput,
  ): Promise<PaymentMethodCapability[]>;
  assertMethodUnitSupported(
    mintUrl: string,
    nut: 4 | 5,
    method: string,
    amountOrUnit: UnitAmount | string,
  ): Promise<void>;
  getAllMints(): Promise<Mint[]>;
  getAllTrustedMints(): Promise<Mint[]>;
  trustMint(mintUrl: string): Promise<void>;
  untrustMint(mintUrl: string): Promise<void>;
}

/** Explicit plugin capability for proof/output management. Proof secrets are intentional output. */
export interface PluginProofCapability {
  calculateSendAmountWithFees(mintUrl: string, intent: UnitAmount): Promise<Amount>;
  createOutputsAndIncrementCounters(
    mintUrl: string,
    amount: { keep: UnitAmount; send: UnitAmount },
    options?: { includeFees?: boolean },
  ): Promise<{
    keep: OutputDataLike[];
    send: OutputDataLike[];
    sendAmount: Amount;
    keepAmount: Amount;
  }>;
  saveProofs(mintUrl: string, proofs: CoreProof[]): Promise<void>;
  getReadyProofs(mintUrl: string, filter?: { unit?: string }): Promise<CoreProof[]>;
  getAllReadyProofs(filter?: { unit?: string }): Promise<CoreProof[]>;
  getBalance(mintUrl: string): Promise<Amount>;
  getSpendableBalance(mintUrl: string): Promise<Amount>;
  getBalanceBreakdown(mintUrl: string): Promise<BalanceBreakdown>;
  getBalances(): Promise<Record<string, Amount>>;
  getSpendableBalances(): Promise<Record<string, Amount>>;
  getBalancesByMint(scope?: BalanceQuery): Promise<BalancesByMint>;
  getBalancesByMintAndUnit(scope?: BalanceQuery): Promise<BalancesByMintAndUnit>;
  getBalanceTotal(scope?: BalanceQuery): Promise<BalanceSnapshot>;
  getBalancesByUnit(scope?: BalanceQuery): Promise<BalancesByUnit>;
  getBalanceTotalByUnit(scope?: BalanceQuery): Promise<BalancesByUnit>;
  getBalancesBreakdown(): Promise<BalancesBreakdownByMint>;
  getTrustedBalances(): Promise<Record<string, Amount>>;
  getTrustedSpendableBalances(): Promise<Record<string, Amount>>;
  getTrustedBalancesBreakdown(): Promise<BalancesBreakdownByMint>;
  setProofState(
    mintUrl: string,
    secrets: string[],
    state: 'inflight' | 'ready' | 'spent',
  ): Promise<void>;
  reserveProofs(
    mintUrl: string,
    secrets: string[],
    operationId: string,
    options?: { unit?: string },
  ): Promise<UnitAmount>;
  releaseProofs(mintUrl: string, secrets: string[]): Promise<void>;
  restoreProofsToReady(mintUrl: string, secrets: string[]): Promise<void>;
  deleteProofs(mintUrl: string, secrets: string[]): Promise<void>;
  wipeProofsByKeysetId(mintUrl: string, keysetId: string): Promise<void>;
  selectProofsToSend(mintUrl: string, intent: UnitAmount, includeFees?: boolean): Promise<Proof[]>;
  getProofsByKeysetId(
    mintUrl: string,
    keysetId: string,
    filter?: { unit?: string },
  ): Promise<CoreProof[]>;
  hasProofsForKeyset(mintUrl: string, keysetId: string): Promise<boolean>;
  prepareProofsForReceiving(proofs: Proof[]): Promise<Proof[]>;
  createBlankOutputs(mintUrl: string, intent: UnitAmount): Promise<OutputDataLike[]>;
}

/** Explicit P2PK/NUT-20 key capability. Derived private keys are intentional sensitive outputs. */
export interface PluginKeyRingCapability {
  generateNewKeyPair(): Promise<{ publicKeyHex: string }>;
  generateNewKeyPair(options: { dumpSecretKey: true }): Promise<Keypair>;
  generateNewKeyPair(options: { dumpSecretKey: false }): Promise<{ publicKeyHex: string }>;
  generateMintQuoteKeyPair(): Promise<Keypair>;
  addKeyPair(secretKey: Uint8Array): Promise<Keypair>;
  removeKeyPair(publicKey: string): Promise<void>;
  getKeyPair(publicKey: string): Promise<Keypair | null>;
  getMintQuoteKeyPair(publicKey: string): Promise<Keypair | null>;
  getLatestKeyPair(): Promise<Keypair | null>;
  getAllKeyPairs(): Promise<Keypair[]>;
  signProof(proof: Proof, publicKey: string): Promise<Proof>;
}

/** Restore/sweep operations only. This capability never returns Coco's configured Wallet. */
export interface PluginWalletRestoreCapability {
  sweepKeyset(
    mintUrl: string,
    keysetId: string,
    bip39seed: Uint8Array,
    unit?: string,
  ): Promise<void>;
  restoreKeyset(mintUrl: string, wallet: Wallet, keysetId: string, unit?: string): Promise<void>;
}

export interface PluginCounterCapability {
  getCounter(mintUrl: string, keysetId: string): Promise<Counter>;
  incrementCounter(mintUrl: string, keysetId: string, n: number): Promise<Counter>;
  overwriteCounter(mintUrl: string, keysetId: string, counter: number): Promise<Counter>;
}

export interface PluginTokenCapability {
  decodeToken(token: Token | string, mintUrl: string, expectedUnit?: string): Promise<Token>;
}

export interface PluginHistoryCapability {
  getPaginatedHistory(offset?: number, limit?: number): Promise<HistoryEntry[]>;
  getHistoryEntryById(id: string): Promise<HistoryEntry | null>;
  getOperationIdFromHistoryEntry(historyId: string): Promise<string>;
}

export interface PluginSendOperationCapability {
  init(
    mintUrl: string,
    amount: UnitAmount,
    options?: CreateSendOperationOptions,
  ): Promise<InitSendOperation>;
  prepare(operation: InitSendOperation): Promise<PreparedSendOperation>;
  execute(
    operation: PreparedSendOperation,
    options?: ExecuteSendOptions,
  ): Promise<{ operation: PendingSendOperation; token: Token }>;
  send(mintUrl: string, amount: UnitAmount): Promise<Token>;
  finalize(operationId: string): Promise<void>;
  rollback(operationId: string, reason?: string): Promise<void>;
  reclaim(operationId: string, options: { spendingPath: 'refund' }): Promise<SendOperation>;
  getOperation(operationId: string): Promise<SendOperation | null>;
  getPendingOperations(): Promise<SendOperation[]>;
  getPreparedOperations(): Promise<PreparedSendOperation[]>;
}

export interface PluginReceiveOperationCapability {
  prepareCallerOwned(
    token: Token | string,
    operationId: string,
    source?: ReceiveOperationSource,
  ): Promise<ReceiveOperation>;
  init(
    token: Token | string,
    source?: ReceiveOperationSource,
    operationId?: string,
  ): Promise<InitReceiveOperation>;
  prepare(
    draft: CallerOwnedInitReceiveOperation | InitReceiveOperation,
  ): Promise<ReceiveOperation | PreparedReceiveOperation>;
  receive(token: Token | string): Promise<void>;
  execute(operationOrId: ReceiveOperation | string): Promise<FinalizedReceiveOperation>;
  finalize(operationId: string): Promise<void>;
  rollback(operationId: string, reason?: string): Promise<void>;
  getOperation(operationId: string): Promise<ReceiveOperation | null>;
  getPendingOperations(): Promise<ReceiveOperation[]>;
  getPreparedOperations(): Promise<PreparedReceiveOperation[]>;
}

export interface PluginMeltOperationCapability {
  init(
    mintUrl: string,
    method: MeltMethod,
    methodData: MeltMethodInputData,
    unit?: string,
    options?: { quoteId?: string },
  ): Promise<InitMeltOperation>;
  prepareExistingQuote(
    quoteRef: MeltQuoteRef,
    options?: { feeIndex?: number },
  ): Promise<PreparedMeltOperation>;
  prepare(operationId: string): Promise<PreparedMeltOperation>;
  execute(operationId: string): Promise<PendingMeltOperation | FinalizedMeltOperation>;
  finalize(operationId: string, options?: { canonicalQuote?: MeltQuote }): Promise<FinalizeResult>;
  rollback(
    operationId: string,
    reason?: string,
    options?: { canonicalQuote?: MeltQuote },
  ): Promise<void>;
  getOperation(operationId: string): Promise<MeltOperation | null>;
  getOperationByQuote(
    mintUrl: string,
    quoteId: string,
    method?: MeltMethod,
  ): Promise<MeltOperation | null>;
  getOperationByQuoteIdentity(identity: QuoteIdentity): Promise<MeltOperation | null>;
  listOperationsByQuote(mintUrl: string, quoteId: string): Promise<MeltOperation[]>;
  getPendingOperations(): Promise<MeltOperation[]>;
  getPreparedOperations(): Promise<PreparedMeltOperation[]>;
}

export interface PluginMintOperationCapability {
  prepare(quoteRef: MintQuoteRef, requestedAmount: Amount): Promise<PendingMintOperation>;
  execute(operationId: string): Promise<MintOperation>;
  finalize(operationId: string): Promise<MintOperation>;
  getOperation(operationId: string): Promise<MintOperation | null>;
  getOperationByQuote(
    mintUrl: string,
    method: MintMethod,
    quoteId: string,
  ): Promise<MintOperation | null>;
  getOperationsForQuote(
    mintUrl: string,
    method: MintMethod,
    quoteId: string,
  ): Promise<MintOperation[]>;
  listOperationsByQuote(mintUrl: string, quoteId: string): Promise<MintOperation[]>;
  claimMintQuote(
    mintUrl: string,
    method: MintMethod,
    quoteId: string,
    options?: ClaimMintQuoteOptions,
  ): Promise<MintOperation[]>;
  claimPendingMintQuotes(options?: ClaimMintQuoteOptions): Promise<MintOperation[]>;
  getMintQuoteClaimability(
    mintUrl: string,
    method: MintMethod,
    quoteId: string,
    options?: { requestedAmount?: Amount; targetOperationId?: string },
  ): Promise<MintQuoteClaimabilityAssessment | undefined>;
  getInFlightOperations(): Promise<MintOperation[]>;
  getPendingOperations(): Promise<PendingMintOperation[]>;
  observePendingOperation(operationId: string): Promise<PendingMintCheckResult>;
  checkPendingOperation(operationId: string): Promise<PendingMintCheckResult>;
}

export interface PluginMintQuoteCapability {
  create(input: PluginCreateMintQuoteInput): Promise<MintQuote>;
  get(input: QuoteIdentity): Promise<MintQuote | null>;
  import(input: PluginImportMintQuoteInput): Promise<MintQuote>;
  listPending(input?: PluginListPendingMintQuotesInput): Promise<MintQuote[]>;
  refresh(input: QuoteIdentity): Promise<MintQuote>;
}

export interface PluginMeltQuoteCapability {
  create<M extends PluginDefaultSupportedMeltMethod>(
    input: PluginCreateMeltQuoteInput<M>,
  ): Promise<MeltQuote<M>>;
  get(input: QuoteIdentity): Promise<MeltQuote | null>;
  listPending(input?: PluginListPendingMeltQuotesInput): Promise<MeltQuote[]>;
  refresh(input: QuoteIdentity): Promise<MeltQuote>;
}

export interface PluginQuoteCapability {
  readonly mint: PluginMintQuoteCapability;
  readonly melt: PluginMeltQuoteCapability;
}

export interface PluginPaymentRequestCapability {
  parse(paymentRequest: string): Promise<ResolvedPaymentRequest>;
  prepare(
    request: ResolvedPaymentRequest,
    options: { mintUrl: string; amount?: UnitAmount },
  ): Promise<PreparedPaymentRequest>;
  execute(transaction: PreparedPaymentRequest): Promise<PaymentRequestExecutionResult>;
}

export interface PluginPaymentRequestReceiveCapability {
  registerTransportHandler(handler: PaymentRequestReceiveTransportHandler): () => void;
  create(input: CreatePaymentRequestReceiveInput): Promise<PaymentRequestReceiveOperation>;
  cancel(operationId: string, reason?: string): Promise<PaymentRequestReceiveOperation>;
  get(operationId: string): Promise<PaymentRequestReceiveOperation | null>;
  list(filter?: { state?: PaymentRequestReceiveState }): Promise<PaymentRequestReceiveOperation[]>;
  claimPayload(
    operationOrId: PaymentRequestReceiveOperation | string,
    payloadInput: PaymentRequestPayload | string,
    source?: PaymentRequestReceiveSource,
  ): Promise<PaymentRequestReceiveClaimResult>;
  ingestPayload(
    payloadInput: PaymentRequestPayload | string,
    source?: PaymentRequestReceiveSource,
  ): Promise<PaymentRequestReceiveClaimResult>;
}

export interface PluginSubscriptionCapability {
  subscribe<TPayload = unknown>(
    mintUrl: string,
    kind: SubscriptionKind,
    filters: string[],
    onNotification?: (payload: TPayload) => void | Promise<void>,
  ): Promise<Readonly<{ subId: string; unsubscribe: () => Promise<void> }>>;
  unsubscribe(mintUrl: string, subId: string): Promise<void>;
  pause(): void;
  resume(): void;
  getDiagnostics(): Readonly<{
    subscriptions: ReadonlyArray<
      Readonly<{
        subId: string;
        mintUrl: string;
        kind: SubscriptionKind;
        filters: readonly string[];
      }>
    >;
    activeMintCount: number;
    transportCount: number;
    paused: boolean;
  }>;
}

export type PluginEventHandler<Payload> = (payload: Payload) => void | Promise<void>;

/** Subscribe-only event capability. Event publication remains owned by Core. */
export interface PluginEventCapability {
  on<E extends keyof CoreEvents>(event: E, handler: PluginEventHandler<CoreEvents[E]>): () => void;
  once<E extends keyof CoreEvents>(
    event: E,
    handler: PluginEventHandler<CoreEvents[E]>,
  ): () => void;
  off<E extends keyof CoreEvents>(event: E, handler: PluginEventHandler<CoreEvents[E]>): void;
}

export interface PluginLoggerCapability {
  error(message: string, ...meta: unknown[]): void;
  warn(message: string, ...meta: unknown[]): void;
  info(message: string, ...meta: unknown[]): void;
  debug(message: string, ...meta: unknown[]): void;
}

// Keep the Cashu PaymentRequest type reachable for capability consumers without exposing a Coco
// implementation class. It is intentionally a domain value returned by parse().
export type PluginPaymentRequestValue = PaymentRequest;
