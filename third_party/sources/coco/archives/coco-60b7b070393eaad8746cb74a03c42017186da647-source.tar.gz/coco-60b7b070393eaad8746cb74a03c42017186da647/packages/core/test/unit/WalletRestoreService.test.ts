import {
  Amount,
  deriveKeysetId,
  OutputData,
  Wallet,
  type OutputDataLike,
  type Proof,
  type ProofState,
} from '@cashu/cashu-ts';
import { describe, it, beforeEach, afterEach, expect, mock } from 'bun:test';
import { WalletRestoreService } from '../../services/WalletRestoreService';
import type { ProofService } from '../../services/ProofService';
import type { CounterService } from '../../services/CounterService';
import type { WalletService } from '../../services/WalletService';
import type { MintRequestProvider } from '../../infra/MintRequestProvider';
import type { Logger } from '../../logging/Logger';
import { makeOutputDataCreator } from '../fixtures/OutputDataCreator.ts';

describe('WalletRestoreService', () => {
  const originalWalletMethods = {
    loadMint: Wallet.prototype.loadMint,
    batchRestore: Wallet.prototype.batchRestore,
    checkProofsStates: Wallet.prototype.checkProofsStates,
    getFeesForProofs: Wallet.prototype.getFeesForProofs,
  };

  afterEach(() => {
    Object.assign(Wallet.prototype, originalWalletMethods);
  });

  const mintUrl = 'https://mint.test';
  const keysetId = 'keyset-1';
  const bip39seed = new Uint8Array(64).fill(7);

  let proofService: ProofService;
  let counterService: CounterService;
  let walletService: WalletService;
  let requestProvider: MintRequestProvider;
  let logger: Logger;
  let service: WalletRestoreService;

  const makeProof = (amount: number, secret: string): Proof =>
    ({
      amount: Amount.from(amount),
      C: `C_${secret}`,
      id: keysetId,
      secret,
    }) as unknown as Proof;

  beforeEach(() => {
    // Mock ProofService
    proofService = {
      getProofsByKeysetId: mock(() => Promise.resolve([])),
      createOutputsAndIncrementCounters: mock(() =>
        Promise.resolve({
          keep: [],
          send: [{ amount: Amount.from(100), counter: 1, id: keysetId }],
        }),
      ),
      saveProofs: mock(() => Promise.resolve()),
    } as unknown as ProofService;

    // Mock CounterService
    counterService = {
      overwriteCounter: mock(() => Promise.resolve()),
    } as unknown as CounterService;

    // Mock WalletService
    walletService = {
      getWalletWithActiveKeysetId: mock(() =>
        Promise.resolve({
          wallet: {
            send: mock(() =>
              Promise.resolve({
                send: [makeProof(100, 'send-proof')],
                keep: [],
              }),
            ),
          },
        }),
      ),
    } as unknown as WalletService;

    // Mock Logger
    logger = {
      debug: mock(() => {}),
      info: mock(() => {}),
      warn: mock(() => {}),
      error: mock(() => {}),
    } as Logger;

    // Mock MintRequestProvider
    requestProvider = {
      getRequestFn: mock(() => undefined),
    } as unknown as MintRequestProvider;

    // Prevent actual network calls when a new Wallet is created inside sweepKeyset
    // by stubbing loadMint on the Wallet prototype.
    (Wallet.prototype as any).loadMint = mock(() => Promise.resolve());

    service = new WalletRestoreService(
      proofService,
      counterService,
      walletService,
      requestProvider,
      logger,
    );
  });

  describe('sweepKeyset', () => {
    it('uses the supplied creator for the sweep-specific Wallet Instance', async () => {
      const keypairs = {
        '1': '0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798',
      };
      const sweepKeysetId = deriveKeysetId(keypairs, { unit: 'sat' });
      const output = {
        blindedMessage: {
          amount: Amount.zero(),
          id: sweepKeysetId,
          B_: 'custom-sweep-restore-output',
        },
        blindingFactor: 17n,
        secret: new Uint8Array([7, 8, 9]),
        toProof: mock(() => {
          throw new Error('not used when the mint returns no signatures');
        }),
      } satisfies OutputDataLike;
      const createDeterministicData = mock(() => [output]);
      const creator = makeOutputDataCreator({ createDeterministicData });

      Wallet.prototype.loadMint = mock(async function (this: Wallet) {
        this.loadMintFromCache(
          {
            name: 'Sweep Mint',
            version: '1.0.0',
            pubkey: 'test-pubkey',
            contact: [],
            nuts: {
              '4': { methods: [], disabled: false },
              '5': { methods: [], disabled: false },
            },
          } as any,
          {
            mintUrl,
            keysets: [
              {
                id: sweepKeysetId,
                unit: 'sat',
                active: true,
                input_fee_ppk: 0,
                keys: keypairs,
              },
            ],
          },
        );
      });
      const restoreRequest = mock(async () => ({ outputs: [], signatures: [] }));
      Wallet.prototype.batchRestore = mock(async function (this: Wallet, config) {
        this.mint.restore = restoreRequest;
        const restored = await this.restore(config?.counter ?? 0, 1, {
          keysetId: config?.keysetId,
        });
        return {
          proofs: restored.proofs,
          lastCounterWithSignature: restored.lastCounterWithSignature,
        };
      });
      service = new WalletRestoreService(
        proofService,
        counterService,
        walletService,
        requestProvider,
        logger,
        creator,
      );
      const originalCreateDeterministicData = OutputData.createDeterministicData;
      OutputData.createDeterministicData = () => {
        throw new Error('built-in deterministic creation must not be used');
      };

      try {
        await service.sweepKeyset(mintUrl, sweepKeysetId, bip39seed);
      } finally {
        OutputData.createDeterministicData = originalCreateDeterministicData;
      }

      expect(createDeterministicData).toHaveBeenCalledWith(
        0,
        bip39seed,
        0,
        expect.objectContaining({ id: sweepKeysetId }),
        [0],
      );
      expect(restoreRequest).toHaveBeenCalledWith({ outputs: [output.blindedMessage] });
    });

    it('should successfully sweep a keyset with ready proofs', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(50, 'proof2')];

      // Mock Wallet methods
      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' } as ProofState, { state: 'UNSPENT' } as ProofState]),
      );
      const mockGetFeesForProofs = mock(() => Amount.from(1));

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;
      Wallet.prototype.getFeesForProofs = mockGetFeesForProofs;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      expect(mockBatchRestore).toHaveBeenCalledTimes(1);
      expect(mockCheckProofsStates).toHaveBeenCalledTimes(1);
      expect(proofService.createOutputsAndIncrementCounters).toHaveBeenCalledWith(mintUrl, {
        keep: { amount: Amount.zero(), unit: 'sat' },
        send: { amount: Amount.from(99), unit: 'sat' }, // 50 + 50 - 1 fee
      });
      expect(proofService.saveProofs).toHaveBeenCalledTimes(1);
      expect(logger.info).toHaveBeenCalledWith('Keyset sweep completed', {
        mintUrl,
        keysetId,
        readyProofs: 2,
        spentProofs: 0,
        sweptAmount: Amount.from(100),
        fee: Amount.from(1),
      });
    });

    it('should sweep with a unit-scoped wallet and persist swept proofs with that unit', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(50, 'proof2')];

      Wallet.prototype.batchRestore = mock(() => Promise.resolve({ proofs }));
      Wallet.prototype.checkProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' } as ProofState, { state: 'UNSPENT' } as ProofState]),
      );
      Wallet.prototype.getFeesForProofs = mock(() => Amount.from(1));

      await service.sweepKeyset(mintUrl, keysetId, bip39seed, 'USD');

      expect(walletService.getWalletWithActiveKeysetId).toHaveBeenCalledWith(mintUrl, 'usd');
      expect(proofService.createOutputsAndIncrementCounters).toHaveBeenCalledWith(mintUrl, {
        keep: { amount: Amount.zero(), unit: 'usd' },
        send: { amount: Amount.from(99), unit: 'usd' },
      });

      const savedProofsCall = (proofService.saveProofs as any).mock.calls[0];
      expect(savedProofsCall[0]).toBe(mintUrl);
      expect(savedProofsCall[1].map((proof: { unit: string }) => proof.unit)).toEqual(['usd']);
    });

    it('should return early when no proofs are found', async () => {
      const mockBatchRestore = mock(() => Promise.resolve({ proofs: [] }));
      Wallet.prototype.batchRestore = mockBatchRestore;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      expect(mockBatchRestore).toHaveBeenCalledTimes(1);
      expect(logger.warn).toHaveBeenCalledWith('No proofs to sweep', { mintUrl, keysetId });
      expect(proofService.saveProofs).not.toHaveBeenCalled();
    });

    it('should return early when all proofs are spent', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(50, 'proof2')];

      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() =>
        Promise.resolve([{ state: 'SPENT' } as ProofState, { state: 'SPENT' } as ProofState]),
      );

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      expect(logger.warn).toHaveBeenCalledWith('No ready proofs to sweep, all spent', {
        mintUrl,
        keysetId,
        spentCount: 2,
      });
      expect(proofService.saveProofs).not.toHaveBeenCalled();
    });

    it('should handle mixed spent and ready proofs', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(50, 'proof2'), makeProof(25, 'proof3')];

      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() =>
        Promise.resolve([
          { state: 'SPENT' } as ProofState,
          { state: 'UNSPENT' } as ProofState,
          { state: 'UNSPENT' } as ProofState,
        ]),
      );
      const mockGetFeesForProofs = mock(() => Amount.from(1));

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;
      Wallet.prototype.getFeesForProofs = mockGetFeesForProofs;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      expect(logger.debug).toHaveBeenCalledWith('Checked proof states', {
        mintUrl,
        keysetId,
        ready: 2,
        spent: 1,
      });
      expect(proofService.createOutputsAndIncrementCounters).toHaveBeenCalledWith(mintUrl, {
        keep: { amount: Amount.zero(), unit: 'sat' },
        send: { amount: Amount.from(74), unit: 'sat' }, // 50 + 25 - 1 fee
      });
      expect(proofService.saveProofs).toHaveBeenCalledTimes(1);
      expect(logger.info).toHaveBeenCalledWith('Keyset sweep completed', {
        mintUrl,
        keysetId,
        readyProofs: 2,
        spentProofs: 1,
        sweptAmount: Amount.from(75),
        fee: Amount.from(1),
      });
    });

    it('should throw when state check returns malformed data', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(50, 'proof2')];

      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' } as ProofState]),
      ); // Wrong length

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;

      expect(service.sweepKeyset(mintUrl, keysetId, bip39seed)).rejects.toThrow(
        'Malformed state check',
      );
      expect(logger.error).toHaveBeenCalledWith('Malformed state check', {
        mintUrl,
        keysetId,
        statesLength: 1,
        proofsLength: 2,
      });
    });

    it('should throw when state check returns non-array', async () => {
      const proofs = [makeProof(50, 'proof1')];

      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() => Promise.resolve(null as unknown as ProofState[]));

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;

      expect(service.sweepKeyset(mintUrl, keysetId, bip39seed)).rejects.toThrow(
        'Malformed state check',
      );
    });

    it('should return early when sweep total is negative', async () => {
      const proofs = [makeProof(5, 'proof1')];

      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' } as ProofState]),
      );
      // Mock a negative fee to create a negative total (edge case scenario)
      const mockGetFeesForProofs = mock(() => Amount.from(10));

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;
      Wallet.prototype.getFeesForProofs = mockGetFeesForProofs;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      expect(logger.warn).toHaveBeenCalledWith('Sweep amount is less than fee', {
        mintUrl,
        keysetId,
        amount: Amount.from(5),
        fee: Amount.from(10),
      });
      expect(proofService.saveProofs).not.toHaveBeenCalled();
    });

    it('should log debug messages at key stages', async () => {
      const proofs = [makeProof(50, 'proof1')];

      const mockBatchRestore = mock(() => Promise.resolve({ proofs }));
      const mockCheckProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' } as ProofState]),
      );
      const mockGetFeesForProofs = mock(() => Amount.from(1));

      Wallet.prototype.batchRestore = mockBatchRestore;
      Wallet.prototype.checkProofsStates = mockCheckProofsStates;
      Wallet.prototype.getFeesForProofs = mockGetFeesForProofs;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      expect(logger.debug).toHaveBeenCalledWith('Sweeping keyset', { mintUrl, keysetId });
      expect(logger.debug).toHaveBeenCalledWith('Proofs found for sweep', {
        mintUrl,
        keysetId,
        count: 1,
      });
      expect(logger.debug).toHaveBeenCalledWith('Sweep calculation', {
        mintUrl,
        keysetId,
        amount: Amount.from(50),
        fee: Amount.from(1),
        total: Amount.from(49),
      });
    });
  });

  describe('restoreKeyset', () => {
    let mockWallet: any;

    beforeEach(() => {
      mockWallet = {
        batchRestore: mock(() =>
          Promise.resolve({
            proofs: [makeProof(50, 'proof1')],
            lastCounterWithSignature: 10,
          }),
        ),
        checkProofsStates: mock(() => Promise.resolve([{ state: 'UNSPENT' }])),
      };
    });

    it('should successfully restore a keyset', async () => {
      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(mockWallet.batchRestore).toHaveBeenCalledWith({
        gapLimit: 300,
        batchSize: 100,
        counter: 0,
        keysetId,
        filterSpent: false,
      });
      expect(mockWallet.checkProofsStates).toHaveBeenCalledTimes(1);
      expect(counterService.overwriteCounter).toHaveBeenCalledWith(mintUrl, keysetId, 11);
      expect(proofService.saveProofs).toHaveBeenCalledTimes(1);
      expect(logger.info).toHaveBeenCalledWith('Saved restored proofs for keyset', {
        mintUrl,
        keysetId,
        total: 1,
      });
    });

    it('should persist restored proofs with the requested unit', async () => {
      await service.restoreKeyset(mintUrl, mockWallet, keysetId, 'USD');

      const savedProofsCall = (proofService.saveProofs as any).mock.calls[0];
      expect(savedProofsCall[0]).toBe(mintUrl);
      expect(savedProofsCall[1]).toHaveLength(1);
      expect(savedProofsCall[1][0].unit).toBe('usd');
    });

    it('should return early when no proofs are restored', async () => {
      mockWallet.batchRestore = mock(() =>
        Promise.resolve({ proofs: [], lastCounterWithSignature: 0 }),
      );

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(logger.warn).toHaveBeenCalledWith('No proofs to restore', { mintUrl, keysetId });
      expect(counterService.overwriteCounter).not.toHaveBeenCalled();
      expect(proofService.saveProofs).not.toHaveBeenCalled();
    });

    it('should throw when restored proofs are fewer than existing proofs', async () => {
      const existingProofs = [
        { id: keysetId, amount: Amount.from(50) },
        { id: keysetId, amount: Amount.from(25) },
        { id: keysetId, amount: Amount.from(10) },
      ];
      proofService.getProofsByKeysetId = mock(() => Promise.resolve(existingProofs as any));

      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs: [makeProof(50, 'proof1')],
          lastCounterWithSignature: 10,
        }),
      );

      expect(service.restoreKeyset(mintUrl, mockWallet, keysetId)).rejects.toThrow(
        'Restored less proofs than expected.',
      );
      expect(logger.warn).toHaveBeenCalledWith('Restored fewer proofs than previously stored', {
        mintUrl,
        keysetId,
        previous: 3,
        restored: 1,
      });
    });

    it('should handle malformed state check', async () => {
      mockWallet.checkProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' }, { state: 'SPENT' }]),
      ); // Wrong length

      expect(service.restoreKeyset(mintUrl, mockWallet, keysetId)).rejects.toThrow(
        'Malformed state check',
      );
      expect(logger.error).toHaveBeenCalledWith('Malformed state check', {
        mintUrl,
        keysetId,
        statesLength: 2,
        proofsLength: 1,
      });
    });

    it('should handle non-array state check response', async () => {
      mockWallet.checkProofsStates = mock(() => Promise.resolve(null));

      expect(service.restoreKeyset(mintUrl, mockWallet, keysetId)).rejects.toThrow(
        'Malformed state check',
      );
    });

    it('should throw when proof is missing during state check', async () => {
      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs: [makeProof(50, 'proof1')],
          lastCounterWithSignature: 10,
        }),
      );
      // Create a sparse array-like object that has a missing proof
      mockWallet.checkProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' }, { state: 'SPENT' }]),
      );

      // This will pass the length check but fail during iteration
      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs: [makeProof(50, 'proof1'), undefined as any, makeProof(25, 'proof3')],
          lastCounterWithSignature: 10,
        }),
      );
      mockWallet.checkProofsStates = mock(() =>
        Promise.resolve([{ state: 'UNSPENT' }, { state: 'SPENT' }, { state: 'UNSPENT' }]),
      );

      expect(service.restoreKeyset(mintUrl, mockWallet, keysetId)).rejects.toThrow(
        'Proof not found',
      );
      expect(logger.error).toHaveBeenCalledWith('Proof not found', { mintUrl, keysetId, index: 1 });
    });

    it('should correctly separate spent and ready proofs', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(25, 'proof2'), makeProof(10, 'proof3')];

      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs,
          lastCounterWithSignature: 20,
        }),
      );
      mockWallet.checkProofsStates = mock(() =>
        Promise.resolve([{ state: 'SPENT' }, { state: 'UNSPENT' }, { state: 'SPENT' }]),
      );

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(logger.debug).toHaveBeenCalledWith('Checked proof states', {
        mintUrl,
        keysetId,
        ready: 1,
        spent: 2,
      });
      expect(logger.info).toHaveBeenCalledWith('Saved restored proofs for keyset', {
        mintUrl,
        keysetId,
        total: 3,
      });
    });

    it('should set counter to 0 when lastCounterWithSignature is null', async () => {
      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs: [makeProof(50, 'proof1')],
          lastCounterWithSignature: null,
        }),
      );

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(counterService.overwriteCounter).toHaveBeenCalledWith(mintUrl, keysetId, 0);
    });

    it('should set counter to 0 when lastCounterWithSignature is 0', async () => {
      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs: [makeProof(50, 'proof1')],
          lastCounterWithSignature: 0,
        }),
      );

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(counterService.overwriteCounter).toHaveBeenCalledWith(mintUrl, keysetId, 0);
    });

    it('should increment counter when lastCounterWithSignature is positive', async () => {
      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs: [makeProof(50, 'proof1')],
          lastCounterWithSignature: 99,
        }),
      );

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(counterService.overwriteCounter).toHaveBeenCalledWith(mintUrl, keysetId, 100);
      expect(logger.debug).toHaveBeenCalledWith('Requested counter overwrite for keyset', {
        mintUrl,
        keysetId,
        counter: 100,
      });
    });

    it('should log all key stages during restore', async () => {
      const existingProofs = [{ id: keysetId, amount: Amount.from(25) }];
      proofService.getProofsByKeysetId = mock(() => Promise.resolve(existingProofs as any));

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      expect(logger.debug).toHaveBeenCalledWith('Restoring keyset', { mintUrl, keysetId });
      expect(logger.debug).toHaveBeenCalledWith('Existing proofs before restore', {
        mintUrl,
        keysetId,
        count: 1,
      });
      expect(logger.info).toHaveBeenCalledWith('Batch restore result', {
        mintUrl,
        keysetId,
        restored: 1,
        lastCounterWithSignature: 10,
      });
    });

    it('should save only ready proofs, not spent ones', async () => {
      const proofs = [makeProof(50, 'proof1'), makeProof(25, 'proof2')];

      mockWallet.batchRestore = mock(() =>
        Promise.resolve({
          proofs,
          lastCounterWithSignature: 5,
        }),
      );
      mockWallet.checkProofsStates = mock(() =>
        Promise.resolve([{ state: 'SPENT' }, { state: 'UNSPENT' }]),
      );

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      // Verify saveProofs was called with only ready proofs
      expect(proofService.saveProofs).toHaveBeenCalledTimes(1);
      const savedProofsCall = (proofService.saveProofs as any).mock.calls[0];
      expect(savedProofsCall[0]).toBe(mintUrl);
      // The second argument should be mapped proofs, we just check it was called
      expect(savedProofsCall[1]).toBeDefined();
    });
  });

  describe('integration between sweepKeyset and restoreKeyset', () => {
    it('should use the same batch restore parameters', async () => {
      const mockBatchRestore1 = mock(() => Promise.resolve({ proofs: [] }));
      Wallet.prototype.batchRestore = mockBatchRestore1;

      await service.sweepKeyset(mintUrl, keysetId, bip39seed);

      const mockWallet = {
        batchRestore: mock(() => Promise.resolve({ proofs: [], lastCounterWithSignature: 0 })),
        checkProofsStates: mock(() => Promise.resolve([])),
      } as unknown as Wallet;

      await service.restoreKeyset(mintUrl, mockWallet, keysetId);

      // Both should use the same batch size, gap limit, and start counter
      expect(mockBatchRestore1).toHaveBeenCalledWith({
        gapLimit: 300,
        batchSize: 100,
        counter: 0,
        keysetId,
        filterSpent: false,
      });
      expect(mockWallet.batchRestore).toHaveBeenCalledWith({
        gapLimit: 300,
        batchSize: 100,
        counter: 0,
        keysetId,
        filterSpent: false,
      });
    });
  });
});
