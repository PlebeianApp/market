import { QuoteIdentityConflictError } from '@core/models/Error';
import type { MeltQuote } from '@core/models/MeltQuote';
import type { QuoteIdentity } from '@core/models/QuoteIdentity';
import type { MeltQuoteRepository } from '..';
import { normalizeMintUrl } from '../../utils';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryMeltQuoteRepository implements MeltQuoteRepository {
  private quotes = createMemoryMap<string, MeltQuote>();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryMeltQuoteRepository): void {
    this.quotes = cloneMemoryRepositoryStateValue(source.quotes);
  }

  private makeKey(mintUrl: string, method: string, quoteId: string): string {
    return `${normalizeMintUrl(mintUrl)}::${method}::${quoteId}`;
  }

  async getMeltQuoteById(identity: QuoteIdentity): Promise<MeltQuote | null> {
    const normalizedMintUrl = normalizeMintUrl(identity.mintUrl);
    const matches: MeltQuote[] = [];
    const quotes = memoryMapValues(this.quotes);
    for (let index = 0; index < quotes.length; index += 1) {
      const quote = quotes[index]!;
      if (quote.mintUrl === normalizedMintUrl && quote.quoteId === identity.quoteId) {
        memoryArrayPush(matches, quote);
      }
    }
    if (matches.length > 1) {
      const methods: string[] = [];
      for (let index = 0; index < matches.length; index += 1) {
        memoryArrayPush(methods, matches[index]!.method);
      }
      throw new QuoteIdentityConflictError('melt', normalizedMintUrl, identity.quoteId, methods);
    }
    return matches[0] ? cloneMemoryValue(matches[0]) : null;
  }

  async getMeltQuote(mintUrl: string, method: string, quoteId: string): Promise<MeltQuote | null> {
    const quote = memoryMapGet(this.quotes, this.makeKey(mintUrl, method, quoteId));
    return quote ? cloneMemoryValue(quote) : null;
  }

  async upsertMeltQuote(quote: MeltQuote): Promise<MeltQuote> {
    const normalizedMintUrl = normalizeMintUrl(quote.mintUrl);
    const now = Date.now();
    const identityOwner = await this.getMeltQuoteById({
      mintUrl: normalizedMintUrl,
      quoteId: quote.quoteId,
    });
    if (identityOwner && identityOwner.method !== quote.method) {
      throw new QuoteIdentityConflictError(
        'melt',
        normalizedMintUrl,
        quote.quoteId,
        [identityOwner.method, quote.method],
        `Melt quote ${quote.quoteId} at ${normalizedMintUrl} already exists for method ${identityOwner.method}`,
      );
    }
    const existing = await this.getMeltQuote(normalizedMintUrl, quote.method, quote.quoteId);
    const persisted = {
      ...quote,
      mintUrl: normalizedMintUrl,
      quote: quote.quoteId,
      createdAt: existing?.createdAt ?? quote.createdAt,
      updatedAt: now,
    };
    memoryMapSet(
      this.quotes,
      this.makeKey(normalizedMintUrl, quote.method, quote.quoteId),
      cloneMemoryValue(persisted),
    );
    return cloneMemoryValue(persisted);
  }

  async getPendingMeltQuotes(method?: string): Promise<MeltQuote[]> {
    const result: MeltQuote[] = [];
    const quotes = memoryMapValues(this.quotes);
    for (let index = 0; index < quotes.length; index += 1) {
      const quote = quotes[index]!;
      if (method && quote.method !== method) continue;
      if (quote.state !== 'PAID') memoryArrayPush(result, cloneMemoryValue(quote));
    }
    return result;
  }
}
