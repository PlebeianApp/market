import { OutputData, type OutputDataCreator } from '@cashu/cashu-ts';
import { mock } from 'bun:test';
import { EventBus } from '../../events/EventBus.ts';
import type { CoreEvents } from '../../events/types.ts';
import { DefaultSendHandler } from '../../infra/handlers/send/DefaultSendHandler.ts';
import { P2pkSendHandler } from '../../infra/handlers/send/P2pkSendHandler.ts';
import { SendHandlerProvider } from '../../infra/handlers/send/SendHandlerProvider.ts';
import { SendOperationService } from '../../operations/send/SendOperationService.ts';
import type { RepositoryTransactionScope } from '../../repositories/index.ts';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import { RepositoryTransactionConflictError } from '../../repositories/RepositoryTransactionError.ts';
import { RepositoryCoreTransactionRunner } from '../../transactions/CoreTransaction.ts';
import { CoreSendTransactions } from '../../transactions/send/SendTransactions.ts';
import { testMintInfo, testMintKeypairs, testMintKeysetId } from './MintMetadata.ts';
import {
  createMintMetadataRemoteDouble,
  createMintServiceForMetadata,
} from './MintMetadataRefresh.ts';
import { createSendRemoteDouble } from './SendRemote.ts';
import { StoredMintQueries } from '../../mints/MintMetadata.ts';
import { KeypairP2pkSigner } from '../../keypairs/P2pkSigner.ts';
import { activateTestMemoryRepositories } from './TestMemoryRepositories.ts';
import type { SendRemote } from '../../operations/send/SendRemote.ts';
import { makeOutputDataCreator } from './OutputDataCreator.ts';

class ObservedMemoryRepositories extends MemoryRepositories {
  transactionCount = 0;
  transactionOpen = false;
  transactionConflictsRemaining = 0;

  override withTransaction<T>(work: (scope: RepositoryTransactionScope) => Promise<T>): Promise<T> {
    this.transactionCount++;
    return super.withTransaction(async (scope) => {
      this.transactionOpen = true;
      try {
        const result = await work(scope);
        if (this.transactionConflictsRemaining > 0) {
          this.transactionConflictsRemaining--;
          throw new RepositoryTransactionConflictError('Injected transaction conflict');
        }
        return result;
      } finally {
        this.transactionOpen = false;
      }
    });
  }
}

/** Real Send persistence and orchestration, with in-memory remote effects. */
export async function createSendEnvironment(units = ['sat']) {
  const mintUrl = 'https://mint.test';
  const repositories = await activateTestMemoryRepositories(new ObservedMemoryRepositories());
  await repositories.mintRepository.addNewMint({
    mintUrl,
    name: 'Test',
    trusted: true,
    mintInfo: testMintInfo,
    createdAt: 1,
    updatedAt: Math.floor(Date.now() / 1000),
  });
  for (const unit of units) {
    await repositories.keysetRepository.addKeyset({
      mintUrl,
      id: testMintKeysetId(unit),
      unit,
      keypairs: testMintKeypairs,
      active: true,
      feePpk: 0,
    });
  }
  repositories.transactionCount = 0;
  const seedSource = new Uint8Array(64).fill(1);
  const deterministicSeedBuffers: Uint8Array[] = [];
  const transactionOutputDataCreator = makeOutputDataCreator({
    createDeterministicData: (amount, seed, counter, keys) => {
      deterministicSeedBuffers.push(seed);
      return OutputData.createDeterministicData(amount, seed, counter, keys);
    },
  });
  const transactions = new CoreSendTransactions(
    new RepositoryCoreTransactionRunner(repositories, transactionOutputDataCreator),
  );
  const eventBus = new EventBus<CoreEvents>();
  const remote = createSendRemoteDouble();
  const metadataRemote = createMintMetadataRemoteDouble();
  const seedLoadTransactionStates: boolean[] = [];
  const returnedSeedBuffers: Uint8Array[] = [];
  const loadSeed = mock(async () => {
    seedLoadTransactionStates.push(repositories.transactionOpen);
    await Promise.resolve();
    seedLoadTransactionStates.push(repositories.transactionOpen);
    const returned = seedSource.slice();
    returnedSeedBuffers.push(returned);
    return returned;
  });
  const logger = {
    debug: mock(() => {}),
    info: mock(() => {}),
    warn: mock(() => {}),
    error: mock(() => {}),
  };
  const mintMetadataQueries = new StoredMintQueries(
    repositories.mintRepository,
    repositories.keysetRepository,
  );
  const p2pkSigner = new KeypairP2pkSigner(repositories.keyRingRepository);

  const buildService = (
    overrides: {
      eventBus?: EventBus<CoreEvents>;
      outputDataCreator?: OutputDataCreator;
      remote?: SendRemote;
    } = {},
  ) => {
    const { remote: remoteOverride = remote, ...serviceOverrides } = overrides;
    return new SendOperationService({
      operationQueries: repositories.sendOperationRepository,
      proofQueries: repositories.proofRepository,
      transactions,
      mintQueries: repositories.mintRepository,
      mintMetadataQueries,
      mintMetadataRefresh: createMintServiceForMetadata(
        repositories,
        metadataRemote,
        overrides.eventBus ?? eventBus,
      ),
      remote: remoteOverride,
      loadSeed,
      eventBus,
      handlerProvider: new SendHandlerProvider({
        default: new DefaultSendHandler(),
        p2pk: new P2pkSendHandler(p2pkSigner),
      }),
      logger,
      ...serviceOverrides,
    });
  };

  return {
    repositories,
    transactions,
    eventBus,
    remote,
    metadataRemote,
    seedSource,
    returnedSeedBuffers,
    deterministicSeedBuffers,
    seedLoadTransactionStates,
    loadSeed,
    logger,
    buildService,
    service: buildService(),
  };
}
