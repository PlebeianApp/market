import { WalletAuthorityLifecycleError } from '../models/Error.ts';
import { createSafePromise, rejectSafely, resolveSafely, thenSafely } from './SafeAsync.ts';

export interface CapabilityLifecycleGate {
  assertActive(): void;
  beginOperation(): () => void;
  isActive(): boolean;
}

export interface CapabilityLifecycleAuthority extends CapabilityLifecycleGate {
  activate(): void;
  revoke(): Promise<void>;
}

export interface LifecycleOperationCalls {
  asyncCall<T>(work: () => T | PromiseLike<T>): Promise<T>;
  syncCall<T>(work: () => T): T;
  callback<T>(work: () => T | PromiseLike<T>): Promise<T>;
}

class ManagerCapabilityLifecycle implements CapabilityLifecycleAuthority {
  #state: 'inactive' | 'active' | 'revoked' = 'inactive';
  #activeOperations = 0;
  readonly #drainWaiters = new Set<() => void>();

  activate(): void {
    if (this.#state !== 'inactive') {
      throw new WalletAuthorityLifecycleError('Invalid plugin capability activation lifecycle');
    }
    this.#state = 'active';
  }

  assertActive(): void {
    if (this.#state !== 'active') {
      throw new WalletAuthorityLifecycleError(
        this.#state === 'revoked'
          ? 'Manager capability authority has been revoked'
          : 'Manager capability authority is not active',
      );
    }
  }

  beginOperation(): () => void {
    this.assertActive();
    this.#activeOperations += 1;
    let completed = false;
    return () => {
      if (completed) return;
      completed = true;
      this.#activeOperations -= 1;
      if (this.#activeOperations !== 0) return;
      for (const resolve of this.#drainWaiters) resolve();
      this.#drainWaiters.clear();
    };
  }

  isActive(): boolean {
    return this.#state === 'active';
  }

  revoke(): Promise<void> {
    this.#state = 'revoked';
    if (this.#activeOperations === 0) return resolveSafely(undefined);
    return createSafePromise((resolve) => this.#drainWaiters.add(resolve));
  }
}

/** @internal Created only by Manager and never exported from a package entry point. */
export function createCapabilityLifecycleAuthority(): CapabilityLifecycleAuthority {
  return new ManagerCapabilityLifecycle();
}

/**
 * Build lifecycle-accounted calls around one private Manager authority. Promise assimilation and
 * handler attachment use intrinsics captured before plugins can mutate the realm.
 */
export function createLifecycleOperationCalls(
  lifecycle: CapabilityLifecycleGate,
): LifecycleOperationCalls {
  const asyncCall = <T>(work: () => T | PromiseLike<T>): Promise<T> => {
    let complete: () => void;
    try {
      complete = lifecycle.beginOperation();
    } catch (error) {
      return rejectSafely(error);
    }
    let result: T | PromiseLike<T>;
    try {
      result = work();
    } catch (error) {
      complete();
      return rejectSafely(error);
    }

    let pending: Promise<T>;
    try {
      pending = resolveSafely(result);
    } catch (error) {
      complete();
      return rejectSafely(error);
    }
    return thenSafely(
      pending,
      (value) => {
        try {
          lifecycle.assertActive();
          return value;
        } finally {
          complete();
        }
      },
      (error) => {
        complete();
        throw error;
      },
    );
  };

  return {
    asyncCall,
    syncCall<T>(work: () => T): T {
      const complete = lifecycle.beginOperation();
      try {
        const value = work();
        lifecycle.assertActive();
        return value;
      } finally {
        complete();
      }
    },
    callback: asyncCall,
  };
}
