import { describe, it, beforeEach, afterEach, expect, mock } from 'bun:test';
import { PluginHost } from '../../plugins/PluginHost.ts';
import { DuplicatePluginRegistrationError } from '../../plugins/types.ts';
import type { Plugin } from '../../plugins/types.ts';
import {
  createCapabilityLifecycleAuthority,
  type CapabilityLifecycleAuthority,
} from '../../plugins/CapabilityLifecycle.ts';

describe('PluginHost', () => {
  let host: PluginHost;
  let services: any;
  let capabilityValues: any;
  let originalConsoleError: typeof console.error;
  let errorCalls: any[][];
  let lifecycle: CapabilityLifecycleAuthority;

  beforeEach(() => {
    lifecycle = createCapabilityLifecycleAuthority();
    lifecycle.activate();
    host = new PluginHost(lifecycle);
    capabilityValues = {
      mintService: { s: 'mint' },
      proofService: { s: 'proof' },
      walletRestoreService: { s: 'walletRestore' },
      counterService: { s: 'counter' },
      historyService: { s: 'history' },
      subscriptions: { s: 'subs' },
      eventBus: { s: 'bus' },
      logger: { s: 'logger' },
    };
    services = Object.fromEntries(
      Object.entries(capabilityValues).map(([key, value]) => [key, () => value]),
    );
    originalConsoleError = console.error;
    errorCalls = [];
    // eslint-disable-next-line no-console
    console.error = (...args: any[]) => {
      errorCalls.push(args);
    };
  });

  afterEach(() => {
    // eslint-disable-next-line no-console
    console.error = originalConsoleError;
  });

  it('calls onInit with only declared services', async () => {
    const seen: any[] = [];
    const plugin: Plugin<['eventBus', 'logger']> = {
      name: 'subset',
      required: ['eventBus', 'logger'],
      onInit: (context) => {
        const s = context.services;
        seen.push(Object.keys(s).sort());
        expect(s.eventBus).toBe(capabilityValues.eventBus);
        expect(s.logger).toBe(capabilityValues.logger);
        expect(Object.getPrototypeOf(s)).toBeNull();
        expect(Object.isFrozen(s)).toBe(true);
        expect(Object.getPrototypeOf(context)).toBeNull();
        expect(Object.isFrozen(context)).toBe(true);
        expect(Object.getPrototypeOf(context.registerExtension)).toBeNull();
        expect(Object.isFrozen(context.registerExtension)).toBe(true);
      },
    };
    host.use(plugin);
    await host.init(services);
    expect(seen.length).toBe(1);
    expect(seen[0]).toEqual(['eventBus', 'logger']);
  });

  it('calls onReady after init', async () => {
    const order: string[] = [];
    const plugin: Plugin<['logger']> = {
      name: 'order',
      required: ['logger'],
      onInit: () => {
        order.push('init');
      },
      onReady: () => {
        order.push('ready');
      },
    };
    host.use(plugin);
    await host.init(services);
    await host.ready();
    expect(order).toEqual(['init', 'ready']);
  });

  it('does not rerun hooks when init and ready are called repeatedly', async () => {
    const calls = { init: 0, ready: 0 };
    const plugin: Plugin<['logger']> = {
      name: 'idempotent',
      required: ['logger'],
      onInit: () => {
        calls.init += 1;
      },
      onReady: () => {
        calls.ready += 1;
      },
    };

    host.use(plugin);
    await host.init(services);
    await host.init(services);
    await host.ready();
    await host.ready();

    expect(calls).toEqual({ init: 1, ready: 1 });
  });

  it('rejects duplicate plugin instance registration', async () => {
    const calls = { init: 0, ready: 0, dispose: 0 };
    const plugin: Plugin<['logger']> = {
      name: 'duplicate',
      required: ['logger'],
      onInit: () => {
        calls.init += 1;
      },
      onReady: () => {
        calls.ready += 1;
      },
      onDispose: () => {
        calls.dispose += 1;
      },
    };

    host.use(plugin);

    expect(() => host.use(plugin)).toThrow(DuplicatePluginRegistrationError);
    expect(() => host.use(plugin)).toThrow('Plugin "duplicate" is already registered');

    await host.init(services);
    await host.ready();
    await host.dispose();

    expect(calls).toEqual({ init: 1, ready: 1, dispose: 1 });
  });

  it('does not dispose or clean up a plugin whose initialization never began', async () => {
    const onInit = mock(() => mock(() => {}));
    const onReady = mock(() => {});
    const onDispose = mock(() => {});
    host.use({
      name: 'registered-only',
      required: [] as const,
      onInit,
      onReady,
      onDispose,
    });

    await host.dispose();

    expect(onInit).not.toHaveBeenCalled();
    expect(onReady).not.toHaveBeenCalled();
    expect(onDispose).not.toHaveBeenCalled();
  });

  it('rejects an unavailable service before any plugin lifecycle hook becomes eligible', async () => {
    const onInit = mock(() => {});
    const onReady = mock(() => {});
    const onDispose = mock(() => {});
    host.use({
      name: 'raw-seed-request',
      required: ['seedService'],
      onInit,
      onReady,
      onDispose,
    } as unknown as Plugin);

    await expect(host.init(services)).rejects.toThrow(
      'requested unavailable service "seedService"',
    );
    await host.dispose();

    expect(onInit).not.toHaveBeenCalled();
    expect(onReady).not.toHaveBeenCalled();
    expect(onDispose).not.toHaveBeenCalled();
  });

  it('coalesces concurrent init and ready calls', async () => {
    const calls = { init: 0, ready: 0 };
    const plugin: Plugin<['logger']> = {
      name: 'concurrent',
      required: ['logger'],
      onInit: async () => {
        calls.init += 1;
        await Promise.resolve();
      },
      onReady: async () => {
        calls.ready += 1;
        await Promise.resolve();
      },
    };

    host.use(plugin);
    await Promise.all([host.init(services), host.init(services)]);
    await Promise.all([host.ready(), host.ready()]);

    expect(calls).toEqual({ init: 1, ready: 1 });
  });

  it('supports only return-style cleanup from onInit', async () => {
    const flags = { cleaned: 0 };
    const plugin: Plugin<['logger']> = {
      name: 'cleanup',
      required: ['logger'],
      onInit: () => () => {
        flags.cleaned += 1;
      },
    };
    host.use(plugin);
    await host.init(services);
    await host.dispose();
    expect(flags.cleaned).toBe(1);
  });

  it('onInit returned cleanup runs on dispose', async () => {
    const flags = { cleaned: 0 };
    const plugin: Plugin<['logger']> = {
      name: 'return-cleanup',
      required: ['logger'],
      onInit: () => {
        return () => {
          flags.cleaned += 1;
        };
      },
    };
    host.use(plugin);
    await host.init(services);
    await host.dispose();
    expect(flags.cleaned).toBe(1);
  });

  it('onReady returned cleanup runs on dispose', async () => {
    const flags = { cleaned: 0 };
    const plugin: Plugin<['logger']> = {
      name: 'ready-cleanup',
      required: ['logger'],
      onReady: () => {
        return () => {
          flags.cleaned += 1;
        };
      },
    };
    host.use(plugin);
    await host.init(services);
    await host.ready();
    await host.dispose();
    expect(flags.cleaned).toBe(1);
  });

  it('late registration after init+ready runs both hooks', async () => {
    const order: string[] = [];
    let resolveReady!: () => void;
    const readyPromise = new Promise<void>((resolve) => {
      resolveReady = resolve;
    });

    await host.init(services);
    await host.ready();
    const plugin: Plugin<['logger']> = {
      name: 'late',
      required: ['logger'],
      onInit: async () => {
        order.push('init');
        await Promise.resolve();
      },
      onReady: () => {
        order.push('ready');
        resolveReady();
      },
    };

    host.use(plugin);
    await readyPromise;

    expect(order).toEqual(['init', 'ready']);
  });

  it('waits for runtime plugin lifecycle before draining cleanups during disposal', async () => {
    const calls: string[] = [];
    let resolveInit!: () => void;
    let markInitStarted: () => void = () => {};
    const initStarted = new Promise<void>((resolve) => {
      markInitStarted = resolve;
    });
    const initGate = new Promise<void>((resolve) => {
      resolveInit = resolve;
    });

    await host.init(services);
    await host.ready();

    const plugin: Plugin<['logger']> = {
      name: 'runtime-async-cleanup',
      required: ['logger'],
      onInit: async () => {
        markInitStarted();
        await initGate;
        return () => {
          calls.push('init-cleanup');
        };
      },
      onReady: () => {
        calls.push('ready');
        return () => {
          calls.push('ready-cleanup');
        };
      },
      onDispose: () => {
        calls.push('dispose');
      },
    };

    host.use(plugin);
    await initStarted;

    const disposePromise = host.dispose();
    resolveInit();
    await disposePromise;

    expect(calls).toContain('ready');
    expect(calls).toContain('dispose');
    expect(calls).toContain('init-cleanup');
    expect(calls).toContain('ready-cleanup');
  });

  it('rejects runtime plugin registration once disposal starts', async () => {
    await host.init(services);
    await host.ready();

    const disposePromise = host.dispose();

    expect(() =>
      host.use({
        name: 'too-late',
        required: [] as const,
      }),
    ).toThrow('Cannot register plugin after disposal has started');

    await disposePromise;
  });

  it('calls onDispose and continues running all cleanups', async () => {
    const calls: string[] = [];
    const pluginA: Plugin<['logger']> = {
      name: 'A',
      required: ['logger'],
      onInit: () => {
        return () => {
          void calls.push('cleanupA1');
        };
      },
      onDispose: () => {
        calls.push('disposeA');
      },
    };
    const pluginB: Plugin<['logger']> = {
      name: 'B',
      required: ['logger'],
      onInit: () => {
        return () => {
          calls.push('cleanupB1');
        };
      },
      onDispose: () => {
        calls.push('disposeB');
      },
    };
    host.use(pluginA);
    host.use(pluginB);
    await host.init(services);
    await host.dispose();
    // onDispose for each plugin, plus all cleanups (order of cleanups is not specified)
    expect(calls.includes('disposeA')).toBe(true);
    expect(calls.includes('disposeB')).toBe(true);
    expect(calls.includes('cleanupA1')).toBe(true);
    expect(calls.includes('cleanupB1')).toBe(true);
  });

  it('logs hook errors and surfaces disposal failures', async () => {
    const plugin: Plugin<['logger']> = {
      name: 'errors',
      required: ['logger'],
      onInit: () => {
        throw new Error('init failed');
      },
      onReady: () => {
        throw new Error('ready failed');
      },
      onDispose: () => {
        throw new Error('dispose failed');
      },
    };
    host.use(plugin);
    await host.init(services);
    await host.ready();
    await expect(host.dispose()).rejects.toBeInstanceOf(AggregateError);
    // Expect at least one error log per failing phase
    const joined = errorCalls.map((args) => String(args[0] ?? '')).join('\n');
    expect(joined.includes('Plugin init error')).toBe(true);
    expect(joined.includes('Plugin ready error')).toBe(true);
    expect(joined.includes('Plugin dispose error')).toBe(true);
  });

  it('runs every plugin cleanup before rejecting disposal failures', async () => {
    const calls: string[] = [];
    const disposeError = new Error('dispose failed');
    const cleanupError = new Error('cleanup failed');
    host.use({
      name: 'failing-dispose',
      required: [],
      onDispose: () => {
        calls.push('dispose');
        throw disposeError;
      },
    });
    host.use({
      name: 'failing-cleanup',
      required: [],
      onInit: () => () => {
        calls.push('cleanup');
        throw cleanupError;
      },
    });
    await host.init(services);

    try {
      await host.dispose();
      throw new Error('expected plugin disposal to fail');
    } catch (error) {
      expect(error).toBeInstanceOf(AggregateError);
      expect((error as AggregateError).errors).toEqual([disposeError, cleanupError]);
    }
    expect(calls).toEqual(['dispose', 'cleanup']);
  });

  it('registerExtension stores extension and is retrievable', async () => {
    const api = { foo: 'bar' };
    const plugin: Plugin<['logger']> = {
      name: 'ext-test',
      required: ['logger'],
      onInit: (ctx) => {
        ctx.registerExtension('myExt', api);
      },
    };
    host.use(plugin);
    await host.init(services);
    expect(host.getExtensions()).toEqual({ myExt: api });
  });

  it('registerExtension throws when key already exists', async () => {
    const pluginA: Plugin<['logger']> = {
      name: 'A',
      required: ['logger'],
      onInit: (ctx) => {
        ctx.registerExtension('conflict', { from: 'A' });
      },
    };
    const pluginB: Plugin<['logger']> = {
      name: 'B',
      required: ['logger'],
      onInit: (ctx) => {
        ctx.registerExtension('conflict', { from: 'B' });
      },
    };
    host.use(pluginA);
    host.use(pluginB);
    await expect(host.init(services)).rejects.toThrow(
      'Plugin "B" attempted to register extension "conflict", but it is already registered',
    );
  });

  it('multiple plugins can register different extensions', async () => {
    const pluginA: Plugin<['logger']> = {
      name: 'A',
      required: ['logger'],
      onInit: (ctx) => {
        ctx.registerExtension('extA', { a: 1 });
      },
    };
    const pluginB: Plugin<['logger']> = {
      name: 'B',
      required: ['logger'],
      onInit: (ctx) => {
        ctx.registerExtension('extB', { b: 2 });
      },
    };
    host.use(pluginA);
    host.use(pluginB);
    await host.init(services);
    expect(host.getExtensions()).toEqual({
      extA: { a: 1 },
      extB: { b: 2 },
    });
  });

  it('extension registered in onReady is available', async () => {
    const plugin: Plugin<['logger']> = {
      name: 'ready-ext',
      required: ['logger'],
      onReady: (ctx) => {
        ctx.registerExtension('readyExt', { ready: true });
      },
    };
    host.use(plugin);
    await host.init(services);
    await host.ready();
    expect(host.getExtensions()).toEqual({ readyExt: { ready: true } });
  });
});
