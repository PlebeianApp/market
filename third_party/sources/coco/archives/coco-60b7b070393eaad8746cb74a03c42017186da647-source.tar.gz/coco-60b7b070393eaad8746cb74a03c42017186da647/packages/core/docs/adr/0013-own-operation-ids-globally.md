---
status: accepted
---

# Own operation IDs globally for their full lifecycle

Every durable monetary command ID has one global owner class: Send, Receive, Mint, Melt, Payment
Request Receive, or Payment Request Receive Attempt. Each adapter stores the claim in a unique
ownership registry. Repository creation claims the ID in the same transaction as its operation row,
so a concurrent loser leaves no operation row and cannot commit counter allocation, proof
reservation, or any other Wallet mutation.

Claims are never deleted or reassigned. Terminal completion and explicit row cleanup do not make an
ID reusable, even by the same operation class. Idempotent behavior belongs in the lifecycle
coordinator: it loads an existing row, compares the canonical intent, and returns or advances that
exact operation instead of attempting a second creation.

SQL and IndexedDB schema migrations backfill all existing operation tables in a fixed class order
and stable ID order. A historical collision violates the registry's unique key, rolls the migration
back, and requires operator repair; choosing a winner would risk attributing remote money movement
to the wrong command. Memory repositories share an equivalent registry across peers and transaction
snapshots.

This replaces pairwise preflight checks as the correctness boundary. Read-only preflight can still
provide clearer diagnostics, but only the transactional storage claim decides ownership. Adapter
contracts exercise all pairwise races and deletion reuse. ADR-0011 still owns transaction scope and
ADR-0012 still owns the authority capability enclosing the claim.

[Transaction Design](../../../../TRANSACTION_DESIGN.md) is the authoritative implementation
contract.
