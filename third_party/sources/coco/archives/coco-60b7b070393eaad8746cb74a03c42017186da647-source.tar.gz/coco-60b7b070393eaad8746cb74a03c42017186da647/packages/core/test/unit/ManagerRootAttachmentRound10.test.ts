import { describe, expect, test } from 'bun:test';
import { cloneMemoryValue } from '../../repositories/memory/MemoryRepositoryTransaction.ts';

const CORE_ROOT = new URL('../..', import.meta.url).pathname.replace(/\/$/, '');
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

function withDescriptorPoison<T>(construct: () => T): T {
  const nativeDefineProperty = Object.defineProperty;
  const nativeDefineProperties = Object.defineProperties;
  const nativeReflectDefineProperty = Reflect.defineProperty;
  const weaken = (descriptor: PropertyDescriptor): void => {
    descriptor.configurable = true;
    if ('value' in descriptor) descriptor.writable = true;
  };
  Object.defineProperties = ((target: object, descriptors: PropertyDescriptorMap) => {
    for (const descriptor of Object.values(descriptors)) weaken(descriptor);
    return nativeDefineProperties(target, descriptors);
  }) as typeof Object.defineProperties;
  Object.defineProperty = ((
    target: object,
    property: PropertyKey,
    descriptor: PropertyDescriptor,
  ) => {
    weaken(descriptor);
    return nativeDefineProperty(target, property, descriptor);
  }) as typeof Object.defineProperty;
  Reflect.defineProperty = ((
    target: object,
    property: PropertyKey,
    descriptor: PropertyDescriptor,
  ) => {
    weaken(descriptor);
    return nativeReflectDefineProperty(target, property, descriptor);
  }) as typeof Reflect.defineProperty;
  try {
    return construct();
  } finally {
    Object.defineProperties = nativeDefineProperties;
    Object.defineProperty = nativeDefineProperty;
    Reflect.defineProperty = nativeReflectDefineProperty;
  }
}

describe('post-import descriptor intrinsic poisoning', () => {
  test('admits one source/dist Manager and preserves immutable Memory boundaries', async () => {
    const source: any = await import(`${CORE_ROOT}/index.ts?round10-poison-source`);
    const dist: any = await import(`${CORE_ROOT}/dist/index.js?round10-poison-dist`);
    const duplicateDist: any = await import(
      `${CORE_ROOT}/dist/index.js?round10-poison-dist-duplicate`
    );
    const root = withDescriptorPoison(() => new source.MemoryRepositories());
    const nativeDefineProperty = Object.defineProperty;
    for (const property of [
      'claimSessionAttachment',
      'releaseSessionAttachment',
      'counterRepository',
    ]) {
      expect(Object.getOwnPropertyDescriptor(root, property)).toMatchObject({
        configurable: false,
        writable: false,
      });
      expect(() => nativeDefineProperty(root, property, { value: () => undefined })).toThrow();
    }
    expect(Object.getPrototypeOf(root.counterRepository)).toBe(null);
    expect(Object.isFrozen(root.counterRepository)).toBe(true);
    expect(Object.getOwnPropertyDescriptor(root.counterRepository, 'setCounter')).toMatchObject({
      configurable: false,
      writable: false,
    });

    let initCalls = 0;
    const originalInit = root.init.bind(root);
    root.init = async () => {
      initCalls += 1;
      return originalInit();
    };
    const pluginRuns: string[] = [];
    const config = (label: string) => ({
      repo: root,
      seedGetter: async () => new Uint8Array(64).fill(0x10),
      authority: { namespace: 'round10-descriptor-poison', ownerId: 'shared-owner' },
      plugins: [
        {
          name: `round10-descriptor-poison-${label}`,
          onInit: () => {
            pluginRuns.push(label);
          },
        },
      ],
      ...disabledRuntime,
    });
    const outcomes = await Promise.allSettled([
      source.initializeCoco(config('source')),
      dist.initializeCoco(config('dist')),
      duplicateDist.initializeCoco(config('duplicate-dist')),
    ]);
    const winners = outcomes.filter(
      (outcome): outcome is PromiseFulfilledResult<any> => outcome.status === 'fulfilled',
    );
    const losers = outcomes.filter(
      (outcome): outcome is PromiseRejectedResult => outcome.status === 'rejected',
    );
    expect(winners).toHaveLength(1);
    expect(losers).toHaveLength(2);
    expect(losers.every(({ reason }) => String(reason).includes('already attached'))).toBe(true);
    expect(initCalls).toBe(1);
    expect(pluginRuns).toHaveLength(1);
    expect(root.getAuthority()?.generation).toBe(1);
    await winners[0]!.value.dispose();
  });

  test('normalizes inert data descriptors through the captured intrinsic', () => {
    const source = Object.create(null) as Record<string, unknown>;
    Object.defineProperty(source, 'locked', {
      configurable: false,
      enumerable: true,
      writable: false,
      value: { nested: true },
    });
    const clone = withDescriptorPoison(() => cloneMemoryValue(source));
    expect(clone).not.toBe(source);
    expect(clone.locked).not.toBe(source.locked);
    expect(Object.getPrototypeOf(clone)).toBeNull();
    expect(Object.getOwnPropertyDescriptor(clone, 'locked')).toMatchObject({
      configurable: true,
      enumerable: true,
      writable: true,
    });
  });

  test('keeps the emitted Memory root immutable and single-attached', async () => {
    const source: any = await import(`${CORE_ROOT}/index.ts?round10-emitted-peer`);
    const dist: any = await import(`${CORE_ROOT}/dist/index.js?round10-emitted-root`);
    const root = withDescriptorPoison(() => new dist.MemoryRepositories());
    for (const property of [
      'claimSessionAttachment',
      'releaseSessionAttachment',
      'counterRepository',
    ]) {
      expect(Object.getOwnPropertyDescriptor(root, property)).toMatchObject({
        configurable: false,
        writable: false,
      });
    }
    const config = {
      repo: root,
      seedGetter: async () => new Uint8Array(64).fill(0x11),
      authority: { namespace: 'round10-emitted-poison', ownerId: 'shared-owner' },
      ...disabledRuntime,
    };
    const outcomes = await Promise.allSettled([
      dist.initializeCoco(config),
      source.initializeCoco(config),
    ]);
    const winners = outcomes.filter(
      (outcome): outcome is PromiseFulfilledResult<any> => outcome.status === 'fulfilled',
    );
    expect(winners).toHaveLength(1);
    expect(outcomes.filter((outcome) => outcome.status === 'rejected')).toHaveLength(1);
    expect(root.getAuthority()?.generation).toBe(1);
    await winners[0]!.value.dispose();
  });
});
