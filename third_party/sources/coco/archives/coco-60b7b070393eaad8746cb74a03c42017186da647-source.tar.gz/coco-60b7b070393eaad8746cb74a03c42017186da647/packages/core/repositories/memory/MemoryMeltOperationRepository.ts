import type { MeltOperationRepository } from '..';
import type { MeltOperation, MeltOperationState } from '../../operations/melt/MeltOperation';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapDelete,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';
import { MemoryOperationIdOwnership } from '../OperationIdOwnership.ts';

const getOperationQuoteId = (operation: MeltOperation): string | undefined =>
  'quoteId' in operation && operation.quoteId ? operation.quoteId : undefined;

export class MemoryMeltOperationRepository implements MeltOperationRepository {
  private operations = createMemoryMap<string, MeltOperation>();

  constructor(private readonly operationIds = new MemoryOperationIdOwnership()) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryMeltOperationRepository): void {
    this.operations = cloneMemoryRepositoryStateValue(source.operations);
    this.operationIds.copyFrom(source.operationIds);
  }

  async create(operation: MeltOperation): Promise<void> {
    if (memoryMapHas(this.operations, operation.id)) {
      throw new Error(`MeltOperation with id ${operation.id} already exists`);
    }
    this.operationIds.claim(operation.id, 'melt');
    this.assertNoDuplicateQuoteOperation(operation);
    memoryMapSet(this.operations, operation.id, cloneMemoryValue(operation));
  }

  async update(operation: MeltOperation): Promise<void> {
    if (!memoryMapHas(this.operations, operation.id)) {
      throw new Error(`MeltOperation with id ${operation.id} not found`);
    }
    this.assertNoDuplicateQuoteOperation(operation);
    memoryMapSet(
      this.operations,
      operation.id,
      cloneMemoryValue({ ...operation, updatedAt: Date.now() }),
    );
  }

  async getById(id: string): Promise<MeltOperation | null> {
    const operation = memoryMapGet(this.operations, id);
    return operation ? cloneMemoryValue(operation) : null;
  }

  async getByState(state: MeltOperationState): Promise<MeltOperation[]> {
    const results: MeltOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (operation.state === state) {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getPending(): Promise<MeltOperation[]> {
    const results: MeltOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (operation.state === 'executing' || operation.state === 'pending') {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getByMintUrl(mintUrl: string): Promise<MeltOperation[]> {
    const results: MeltOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (operation.mintUrl === mintUrl) {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getByQuoteId(mintUrl: string, quoteId: string): Promise<MeltOperation[]> {
    const results: MeltOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (
        operation.mintUrl === mintUrl &&
        'quoteId' in operation &&
        operation.quoteId === quoteId
      ) {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getAll(): Promise<MeltOperation[]> {
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      operations[index] = cloneMemoryValue(operations[index]!);
    }
    return operations;
  }

  async delete(id: string): Promise<void> {
    memoryMapDelete(this.operations, id);
  }

  private assertNoDuplicateQuoteOperation(operation: MeltOperation): void {
    const quoteId = getOperationQuoteId(operation);
    if (!quoteId) return;

    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const existing = operations[index]!;
      if (
        existing.id !== operation.id &&
        existing.mintUrl === operation.mintUrl &&
        getOperationQuoteId(existing) === quoteId
      ) {
        throw new Error(
          `MeltOperation already exists for mint ${operation.mintUrl} and quote ${quoteId}`,
        );
      }
    }
  }
}
