import { QuoteIdentityConflictError } from '@core/models/Error';
import {
  applyBolt11MintQuoteStateFallback,
  deriveBolt11MintQuoteState,
  isMintQuotePending,
  isStatefulMintQuote,
  type MintQuote,
} from '@core/models/MintQuote';
import type { QuoteIdentity } from '@core/models/QuoteIdentity';
import type { MintMethodRemoteState } from '@core/operations/mint/MintMethodHandler';
import type { MintQuoteRepository } from '..';
import { normalizeMintUrl } from '../../utils';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryMintQuoteRepository implements MintQuoteRepository {
  private quotes = createMemoryMap<string, MintQuote>();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryMintQuoteRepository): void {
    this.quotes = cloneMemoryRepositoryStateValue(source.quotes);
  }

  private makeKey(mintUrl: string, method: string, quoteId: string): string {
    return `${normalizeMintUrl(mintUrl)}::${method}::${quoteId}`;
  }

  async getMintQuoteById(identity: QuoteIdentity): Promise<MintQuote | null> {
    const normalizedMintUrl = normalizeMintUrl(identity.mintUrl);
    const matches: MintQuote[] = [];
    const quotes = memoryMapValues(this.quotes);
    for (let index = 0; index < quotes.length; index += 1) {
      const quote = quotes[index]!;
      if (quote.mintUrl === normalizedMintUrl && quote.quoteId === identity.quoteId) {
        memoryArrayPush(matches, quote);
      }
    }
    if (matches.length > 1) {
      const methods: string[] = [];
      for (let index = 0; index < matches.length; index += 1) {
        memoryArrayPush(methods, matches[index]!.method);
      }
      throw new QuoteIdentityConflictError('mint', normalizedMintUrl, identity.quoteId, methods);
    }
    return matches[0] ? cloneMemoryValue(matches[0]) : null;
  }

  async getMintQuote(mintUrl: string, method: string, quoteId: string): Promise<MintQuote | null> {
    const key = this.makeKey(mintUrl, method, quoteId);
    const quote = memoryMapGet(this.quotes, key);
    return quote ? cloneMemoryValue(quote) : null;
  }

  async upsertMintQuote(quote: MintQuote): Promise<void> {
    const normalizedMintUrl = normalizeMintUrl(quote.mintUrl);
    const now = Date.now();
    const identityOwner = await this.getMintQuoteById({
      mintUrl: normalizedMintUrl,
      quoteId: quote.quoteId,
    });
    if (identityOwner && identityOwner.method !== quote.method) {
      throw new QuoteIdentityConflictError(
        'mint',
        normalizedMintUrl,
        quote.quoteId,
        [identityOwner.method, quote.method],
        `Mint quote ${quote.quoteId} at ${normalizedMintUrl} already exists for method ${identityOwner.method}`,
      );
    }
    const existing = await this.getMintQuote(normalizedMintUrl, quote.method, quote.quoteId);
    const key = this.makeKey(normalizedMintUrl, quote.method, quote.quoteId);
    const canonicalQuote = isStatefulMintQuote(quote)
      ? {
          ...quote,
          state: deriveBolt11MintQuoteState(quote.amountPaid, quote.amountIssued),
        }
      : quote;
    memoryMapSet(
      this.quotes,
      key,
      cloneMemoryValue({
        ...canonicalQuote,
        mintUrl: normalizedMintUrl,
        quote: quote.quoteId,
        createdAt: existing?.createdAt ?? quote.createdAt,
        updatedAt: now,
      }),
    );
  }

  async setMintQuoteState(
    mintUrl: string,
    method: string,
    quoteId: string,
    state: MintMethodRemoteState,
    observedAt = Date.now(),
  ): Promise<void> {
    const key = this.makeKey(mintUrl, method, quoteId);
    const existing = memoryMapGet(this.quotes, key);
    if (!existing) return;
    if (!isStatefulMintQuote(existing)) return;
    memoryMapSet(
      this.quotes,
      key,
      cloneMemoryValue(applyBolt11MintQuoteStateFallback(existing, state, observedAt)),
    );
  }

  async getPendingMintQuotes(method?: string): Promise<MintQuote[]> {
    const result: MintQuote[] = [];
    const quotes = memoryMapValues(this.quotes);
    for (let index = 0; index < quotes.length; index += 1) {
      const q = quotes[index]!;
      if (method && q.method !== method) continue;
      if (isMintQuotePending(q)) memoryArrayPush(result, cloneMemoryValue(q));
    }
    return result;
  }
}
