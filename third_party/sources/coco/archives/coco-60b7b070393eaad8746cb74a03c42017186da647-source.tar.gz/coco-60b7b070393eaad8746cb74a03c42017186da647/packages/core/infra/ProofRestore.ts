import { type Keys, type Proof, type Wallet } from '@cashu/cashu-ts';
import { assertSameUnit, normalizeUnit } from '@core/amounts.ts';
import type { Keyset } from '@core/models/Keyset.ts';
import { deserializeOutputData, type SerializedOutputData } from '@core/utils.ts';
import {
  getProofStateYs,
  validateProofStateResponse,
  type ReclaimOutputObservation,
} from '@core/operations/send/SendRemote.ts';

/**
 * Recovery-only NUT-09 observation. Unlike ordinary Restore, incomplete evidence is never
 * collapsed into an empty result.
 */
export async function observeOutputProofs(
  wallet: Pick<Wallet, 'mint' | 'checkProofsStates'>,
  keysets: readonly Keyset[],
  unit: string,
  serialized: SerializedOutputData,
): Promise<ReclaimOutputObservation> {
  const outputData = deserializeOutputData(serialized);
  const expected = [...outputData.keep, ...outputData.send];
  if (expected.length === 0) {
    return { status: 'inconclusive', reason: 'malformed', outputs: [] };
  }

  try {
    const result = await wallet.mint.restore({
      outputs: expected.map((output) => output.blindedMessage),
    });
    if (!Array.isArray(result.outputs) || !Array.isArray(result.signatures)) {
      return { status: 'inconclusive', reason: 'malformed', outputs: [] };
    }
    if (result.outputs.length === 0 && result.signatures.length === 0) {
      return { status: 'none' };
    }
    if (result.outputs.length !== result.signatures.length) {
      return { status: 'inconclusive', reason: 'malformed', outputs: [] };
    }

    const expectedByB = new Map(
      expected.map((output) => [output.blindedMessage.B_, output] as const),
    );
    if (expectedByB.size !== expected.length) {
      return { status: 'inconclusive', reason: 'malformed', outputs: [] };
    }
    const seen = new Set<string>();
    const proofs: Proof[] = [];
    for (let index = 0; index < result.outputs.length; index++) {
      const returned = result.outputs[index];
      const signature = result.signatures[index];
      const B_ = returned?.B_;
      if (!B_ || seen.has(B_) || !signature) {
        return { status: 'inconclusive', reason: 'malformed', outputs: [] };
      }
      const output = expectedByB.get(B_);
      if (!output) {
        return { status: 'inconclusive', reason: 'unmatched', outputs: [] };
      }
      if (
        returned.id !== output.blindedMessage.id ||
        String(returned.amount) !== String(output.blindedMessage.amount) ||
        signature.id !== output.blindedMessage.id ||
        String(signature.amount) !== String(output.blindedMessage.amount)
      ) {
        return { status: 'inconclusive', reason: 'unmatched', outputs: [] };
      }
      const keyset = keysets.find((candidate) => candidate.id === signature.id);
      if (!keyset) {
        return { status: 'inconclusive', reason: 'unmatched', outputs: [] };
      }
      try {
        assertSameUnit(normalizeUnit(keyset.unit), normalizeUnit(unit), 'Restored proof keyset');
        proofs.push(output.toProof(signature, { id: keyset.id, keys: keyset.keypairs as Keys }));
      } catch {
        return { status: 'inconclusive', reason: 'malformed', outputs: [] };
      }
      seen.add(B_);
    }

    let response: unknown;
    try {
      response = await wallet.mint.check({ Ys: getProofStateYs(proofs) });
    } catch {
      return { status: 'inconclusive', reason: 'unavailable', outputs: [] };
    }
    const rawStates =
      response && typeof response === 'object' && !Array.isArray(response)
        ? (response as { states?: unknown }).states
        : undefined;
    const observation = validateProofStateResponse(proofs, rawStates);
    if (observation.status !== 'complete') {
      return {
        status: 'inconclusive',
        reason: observation.reason === 'unmatched' ? 'unmatched' : 'malformed',
        outputs: [],
      };
    }
    const stateBySecret = new Map(
      observation.inputs.map(({ secret, state }) => [secret, state] as const),
    );
    const outputs = proofs.map((proof) => ({ proof, state: stateBySecret.get(proof.secret)! }));
    return proofs.length === expected.length
      ? { status: 'complete', outputs }
      : { status: 'partial', outputs, missingOutputs: expected.length - proofs.length };
  } catch {
    return { status: 'inconclusive', reason: 'unavailable', outputs: [] };
  }
}

/** Remote restoration and local unblinding only. The owning workflow persists candidate proofs. */
export async function restoreOutputProofs(
  wallet: Pick<Wallet, 'mint' | 'checkProofsStates'>,
  keysets: readonly Keyset[],
  unit: string,
  serialized: SerializedOutputData,
): Promise<Proof[]> {
  const outputData = deserializeOutputData(serialized);
  const outputs = [...outputData.keep, ...outputData.send];
  if (outputs.length === 0) return [];
  const result = await wallet.mint.restore({
    outputs: outputs.map((output) => output.blindedMessage),
  });
  const restored: Proof[] = [];
  for (let i = 0; i < result.outputs.length; i++) {
    const output = outputs.find(
      (candidate) => candidate.blindedMessage.B_ === result.outputs[i]?.B_,
    );
    const signature = result.signatures[i];
    if (!output || !signature) continue;
    const keyset = keysets.find((candidate) => candidate.id === signature.id);
    if (!keyset) continue;
    assertSameUnit(normalizeUnit(keyset.unit), normalizeUnit(unit), 'Restored proof keyset');
    restored.push(output.toProof(signature, { id: keyset.id, keys: keyset.keypairs as Keys }));
  }
  if (restored.length === 0) return [];
  const states = await wallet.checkProofsStates(restored);
  return restored.filter((_, index) => states[index]?.state === 'UNSPENT');
}
