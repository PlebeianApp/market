import {
  Amount,
  OutputData,
  createBlindSignature,
  hashToCurve,
  pointFromHex,
  type Proof,
  type ProofState,
} from '@cashu/cashu-ts';
import { secp256k1 } from '@noble/curves/secp256k1.js';
import { bytesToHex } from '@noble/curves/utils.js';
import { describe, expect, it, mock } from 'bun:test';
import type {
  PendingSendOperation,
  RollingBackSendOperation,
} from '../../operations/send/SendOperation.ts';
import type { ReclaimOutputObservation } from '../../operations/send/SendRemote.ts';
import type { CoreProof } from '../../types.ts';
import {
  deserializeOutputData,
  getSecretsFromSerializedOutputData,
  serializeOutputData,
} from '../../utils.ts';
import { createSendEnvironment } from '../fixtures/SendEnvironment.ts';
import { testMintKeypairs, testMintKeysetId } from '../fixtures/MintMetadata.ts';
import {
  commitRefundReclaimPlan,
  type RefundReclaimPlan,
} from '../../operations/send/RefundReclaimPlan.ts';
import { CashuSendRemote } from '../../infra/handlers/send/CashuSendRemote.ts';
import type { MintRequestFn } from '../../infra/MintRequestProvider.ts';

const mintUrl = 'https://mint.test';
const refundSecret = new Uint8Array(32).fill(2);
const recipientSecret = new Uint8Array(32).fill(3);
const refundPublicKey = bytesToHex(secp256k1.getPublicKey(refundSecret, true));
const recipientPublicKey = bytesToHex(secp256k1.getPublicKey(recipientSecret, true));

async function setupPendingRefund() {
  const environment = await createSendEnvironment();
  await environment.repositories.keyRingRepository.setPersistedKeyPair({
    purpose: 'p2pk',
    publicKeyHex: refundPublicKey,
    secretKey: refundSecret,
  });
  const id = `refund-${crypto.randomUUID()}`;
  const sendOutputs = OutputData.createP2PKData(
    {
      kind: 'P2PK',
      data: recipientPublicKey,
      locktime: Math.floor(Date.now() / 1000) - 60,
      refundKeys: [refundPublicKey],
    },
    Amount.from(10),
    { id: testMintKeysetId(), keys: testMintKeypairs },
  );
  const outputData = serializeOutputData({ keep: [], send: sendOutputs });
  const sendProofs: CoreProof[] = sendOutputs.map((output) => ({
    id: output.blindedMessage.id,
    amount: Amount.from(output.blindedMessage.amount),
    secret: new TextDecoder().decode(output.secret),
    C: `C-${output.blindedMessage.B_}`,
    mintUrl,
    unit: 'sat',
    state: 'inflight',
    createdByOperationId: id,
  }));
  const operation: PendingSendOperation = {
    id,
    state: 'pending',
    mintUrl,
    amount: Amount.from(10),
    unit: 'sat',
    method: 'p2pk',
    methodData: {
      options: {
        kind: 'P2PK',
        data: recipientPublicKey,
        locktime: Math.floor(Date.now() / 1000) - 60,
        refundKeys: [refundPublicKey],
      },
    },
    createdAt: 100,
    updatedAt: 200,
    revision: 2,
    needsSwap: true,
    fee: Amount.zero(),
    inputAmount: Amount.from(10),
    inputProofSecrets: ['original-input'],
    outputData,
    token: { mint: mintUrl, unit: 'sat', proofs: sendProofs },
  };
  await environment.repositories.proofRepository.saveProofs(mintUrl, sendProofs);
  await environment.repositories.sendOperationRepository.create(operation);
  return { ...environment, operation, sendProofs };
}

function outputProofs(operation: RollingBackSendOperation): Proof[] {
  const data = deserializeOutputData(operation.reclaimData!.outputData);
  return data.keep.map((output) => ({
    id: output.blindedMessage.id,
    amount: Amount.from(output.blindedMessage.amount),
    secret: new TextDecoder().decode(output.secret),
    C: `reclaimed-${output.blindedMessage.B_}`,
  }));
}

function states(proofs: readonly Proof[], state: ProofState['state']): ProofState[] {
  const encoder = new TextEncoder();
  return proofs.map((proof) => ({
    Y: hashToCurve(encoder.encode(proof.secret)).toHex(true),
    state,
    witness: null,
  }));
}

function statesWithFirstWitness(
  proofs: readonly Proof[],
  witness: unknown,
  includeWitness = true,
): unknown[] {
  return states(proofs, 'UNSPENT').map((state, index) => {
    if (index !== 0) return state;
    if (includeWitness) return { ...state, witness };
    const { witness: _witness, ...withoutWitness } = state;
    return withoutWitness;
  });
}

function completeObservation(
  operation: RollingBackSendOperation,
  state: ProofState['state'] = 'UNSPENT',
): ReclaimOutputObservation {
  return {
    status: 'complete',
    outputs: outputProofs(operation).map((proof, index) => ({
      proof,
      state: states([proof], state)[0]!,
    })),
  };
}

async function interruptAfterBegin() {
  const environment = await setupPendingRefund();
  environment.remote.reclaim.mockRejectedValueOnce(new Error('response lost'));
  await expect(
    environment.service.reclaim(environment.operation.id, { spendingPath: 'refund' }),
  ).rejects.toThrow('response lost');
  const rolling = (await environment.repositories.sendOperationRepository.getById(
    environment.operation.id,
  )) as RollingBackSendOperation;
  expect(rolling.state).toBe('rolling_back');
  expect(rolling.reclaimData?.spendingPath).toBe('refund');
  return { ...environment, rolling };
}

type CommittedRefundPlan = RefundReclaimPlan & { planCommitment: string };

const completionTamperCases: ReadonlyArray<readonly [string, (plan: CommittedRefundPlan) => void]> =
  [
    ['version', (plan) => void Object.assign(plan, { version: 2 })],
    ['operation ID', (plan) => void (plan.operationId += '-changed')],
    ['mint', (plan) => void (plan.mintUrl = 'https://other.test')],
    ['unit', (plan) => void (plan.unit = 'usd')],
    ['input order', (plan) => void plan.inputProofSecrets.reverse()],
    [
      'ownership',
      (plan) => void (plan.inputOwnership = plan.inputOwnership === 'created' ? 'used' : 'created'),
    ],
    [
      'spending path',
      (plan) =>
        void Object.assign(plan as unknown as Record<string, unknown>, { spendingPath: 'default' }),
    ],
    ['condition', (plan) => void (plan.conditionFingerprint = '00'.repeat(32))],
    ['refund key', (plan) => void (plan.refundPublicKeyX = '00'.repeat(32))],
    ['output bytes', (plan) => void (plan.outputData.keep[0]!.blindingFactor += '00')],
    [
      'nested output key order after an authenticated revision',
      (plan) => {
        const output = plan.outputData.keep[0]!;
        plan.outputData.keep[0] = Object.fromEntries(
          Object.entries(output).reverse(),
        ) as typeof output;
      },
    ],
    ['keyset allocation', (plan) => void (plan.allocation.keysetId = 'changed-keyset')],
    ['counter allocation', (plan) => void (plan.allocation.counterStart += 1)],
    ['commitment', (plan) => void (plan.planCommitment = '00'.repeat(32))],
    [
      'undefined extension field',
      (plan) =>
        void Object.assign(plan as unknown as Record<string, unknown>, { injected: undefined }),
    ],
  ];

async function persistTamperedPlan(
  environment: Awaited<ReturnType<typeof interruptAfterBegin>>,
  tamper: (plan: CommittedRefundPlan) => void,
) {
  const plan = structuredClone(environment.rolling.reclaimData) as CommittedRefundPlan;
  tamper(plan);
  const transitioned = await environment.repositories.sendOperationRepository.transition({
    operationId: environment.rolling.id,
    expectedState: 'rolling_back',
    expectedRevision: environment.rolling.revision ?? 0,
    next: { ...environment.rolling, reclaimData: plan },
  });
  expect(transitioned).toBe(true);
}

async function tamperPlanDuringRemote(
  environment: Awaited<ReturnType<typeof setupPendingRefund>>,
  tamper: (plan: CommittedRefundPlan) => void,
): Promise<RollingBackSendOperation> {
  const current = (await environment.repositories.sendOperationRepository.getById(
    environment.operation.id,
  )) as RollingBackSendOperation;
  const authenticatedShape = structuredClone(current);
  const plan = structuredClone(current.reclaimData) as CommittedRefundPlan;
  tamper(plan);
  const transitioned = await environment.repositories.sendOperationRepository.transition({
    operationId: current.id,
    expectedState: 'rolling_back',
    expectedRevision: current.revision ?? 0,
    next: { ...current, reclaimData: plan },
  });
  expect(transitioned).toBe(true);
  return authenticatedShape;
}

type RefundWireOutput = { id: string; amount: number | string | Amount; B_: string };

function refundSigningKey(amount: string): Uint8Array {
  const scalarByAmount: Record<string, number> = { '1': 1, '2': 2, '4': 3, '8': 4 };
  const scalar = scalarByAmount[amount];
  if (!scalar) throw new Error(`No fake-mint signing key for amount ${amount}`);
  const key = new Uint8Array(32);
  key[31] = scalar;
  return key;
}

function createFakeMintRefundRemote(options: { failFirstSwap?: boolean } = {}) {
  let swapCalls = 0;
  const calls: Array<{ endpoint: string; body?: Record<string, unknown> }> = [];
  const request: MintRequestFn = async <T>({
    endpoint,
    requestBody,
  }: Parameters<MintRequestFn>[0]): Promise<T> => {
    calls.push({ endpoint, body: requestBody });
    if (endpoint.endsWith('/swap')) {
      swapCalls += 1;
      if (options.failFirstSwap && swapCalls === 1) {
        throw new Error('fake mint unavailable before spend');
      }
      const outputs = requestBody!.outputs as RefundWireOutput[];
      return {
        signatures: outputs.map((output) => {
          const amount = Amount.from(output.amount).toString();
          const signature = createBlindSignature(
            pointFromHex(output.B_),
            refundSigningKey(amount),
            output.id,
          );
          return { id: output.id, amount: output.amount, C_: signature.C_.toHex(true) };
        }),
      } as T;
    }
    if (endpoint.endsWith('/restore')) {
      return { outputs: [], signatures: [] } as T;
    }
    if (endpoint.endsWith('/checkstate')) {
      return {
        states: (requestBody!.Ys as string[]).map((Y) => ({
          Y,
          state: 'UNSPENT',
          witness: null,
        })),
      } as T;
    }
    throw new Error(`Unexpected fake-mint endpoint: ${endpoint}`);
  };
  return {
    remote: new CashuSendRemote(
      { getAuthProvider: () => undefined },
      { getRequestFn: () => request },
    ),
    calls,
    get swapCalls() {
      return swapCalls;
    },
  };
}

async function expectRefundValueConserved(
  environment: Awaited<ReturnType<typeof setupPendingRefund>>,
): Promise<void> {
  const ready = await environment.repositories.proofRepository.getAvailableProofs(mintUrl, {
    unit: 'sat',
  });
  expect(Amount.sum(ready.map((proof) => proof.amount)).toString()).toBe('10');
  const originals = await environment.repositories.proofRepository.getProofsBySecrets(
    mintUrl,
    environment.sendProofs.map((proof) => proof.secret),
  );
  expect(originals.every((proof) => proof.state === 'spent')).toBe(true);
}

function expectOwnedRefundSeedsZeroized(
  environment: Awaited<ReturnType<typeof setupPendingRefund>>,
  expected: { returned: number; deterministic: number },
): void {
  expect(environment.returnedSeedBuffers).toHaveLength(expected.returned);
  expect(environment.deterministicSeedBuffers).toHaveLength(expected.deterministic);
  for (const seed of [
    ...environment.returnedSeedBuffers,
    ...environment.deterministicSeedBuffers,
  ]) {
    expect(seed).toHaveLength(64);
    expect(seed.every((byte) => byte === 0)).toBe(true);
  }
  expect(environment.seedSource).toHaveLength(64);
  expect(environment.seedSource.every((byte) => byte === 1)).toBe(true);
}

describe('SendOperationService P2PK refund reclaim', () => {
  it('reclaims through the real CashuSendRemote with detached valid Amount inputs', async () => {
    const environment = await setupPendingRefund();
    const fakeMint = createFakeMintRefundRemote();
    const result = await environment
      .buildService({ remote: fakeMint.remote })
      .reclaim(environment.operation.id, { spendingPath: 'refund' });

    expect(result.id).toBe(environment.operation.id);
    expect(result.state).toBe('rolled_back');
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolled_back');
    expect(fakeMint.swapCalls).toBe(1);
    expect(environment.seedLoadTransactionStates.length).toBeGreaterThanOrEqual(2);
    expect(environment.seedLoadTransactionStates.every((transactionOpen) => !transactionOpen)).toBe(
      true,
    );
    expectOwnedRefundSeedsZeroized(environment, { returned: 3, deterministic: 2 });
    await expectRefundValueConserved(environment);
  });

  it('zeroizes every retained refund seed when durable authentication rejects', async () => {
    const environment = await interruptAfterBegin();
    await persistTamperedPlan(environment, (plan) => {
      plan.planCommitment = '00'.repeat(32);
    });
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs.mockClear();

    const result = await environment.buildService().reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });

    expect(result.state).toBe('rolling_back');
    expect(environment.remote.observeReclaimOutputs).not.toHaveBeenCalled();
    expect(environment.remote.reclaim).not.toHaveBeenCalled();
    expectOwnedRefundSeedsZeroized(environment, { returned: 3, deterministic: 1 });
  });

  it('zeroizes every retained refund seed when completion rejects authenticated state', async () => {
    const environment = await setupPendingRefund();
    environment.remote.reclaim.mockImplementationOnce(async () => {
      const original = await tamperPlanDuringRemote(environment, (plan) => {
        plan.planCommitment = '11'.repeat(32);
      });
      return outputProofs(original);
    });

    await expect(
      environment.service.reclaim(environment.operation.id, { spendingPath: 'refund' }),
    ).rejects.toThrow('changed before completion');

    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolling_back');
    expectOwnedRefundSeedsZeroized(environment, { returned: 3, deterministic: 1 });
  });

  it('retains one owned completion seed across transaction retries and zeroizes every copy', async () => {
    const environment = await setupPendingRefund();
    let transactionsBeforeCompletion = -1;
    environment.remote.reclaim.mockImplementationOnce(async () => {
      const current = (await environment.repositories.sendOperationRepository.getById(
        environment.operation.id,
      )) as RollingBackSendOperation;
      transactionsBeforeCompletion = environment.repositories.transactionCount;
      environment.repositories.transactionConflictsRemaining = 1;
      return outputProofs(current);
    });

    const result = await environment.service.reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });

    expect(result.state).toBe('rolled_back');
    expect(environment.repositories.transactionCount - transactionsBeforeCompletion).toBe(2);
    expectOwnedRefundSeedsZeroized(environment, { returned: 3, deterministic: 3 });
    await expectRefundValueConserved(environment);
  });

  it('retries the exact rolling_back Send through CashuSendRemote after a pre-effect failure', async () => {
    const environment = await setupPendingRefund();
    const fakeMint = createFakeMintRefundRemote({ failFirstSwap: true });
    await expect(
      environment
        .buildService({ remote: fakeMint.remote })
        .reclaim(environment.operation.id, { spendingPath: 'refund' }),
    ).rejects.toThrow('fake mint unavailable before spend');
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolling_back');

    const recovered = await environment
      .buildService({ remote: fakeMint.remote })
      .reclaim(environment.operation.id, { spendingPath: 'refund' });
    expect(recovered.id).toBe(environment.operation.id);
    expect(recovered.state).toBe('rolled_back');
    expect(fakeMint.swapCalls).toBe(2);
    expect(
      (await environment.repositories.sendOperationRepository.getByMintUrl(mintUrl)).filter(
        (operation) => operation.id === environment.operation.id,
      ),
    ).toHaveLength(1);
    await expectRefundValueConserved(environment);
  });

  it('rejects an unexpected nested durable extension before any restart Restore or reclaim I/O', async () => {
    const environment = await interruptAfterBegin();
    await persistTamperedPlan(environment, (plan) => {
      (plan.outputData.keep[0]!.blindedMessage as unknown as Record<string, unknown>).extension = {
        attackerControlled: true,
      };
    });
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs.mockClear();
    environment.remote.observeReclaimInputStates.mockClear();

    const result = await environment.buildService().reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });

    expect(result.state).toBe('rolling_back');
    expect(environment.remote.observeReclaimOutputs).not.toHaveBeenCalled();
    expect(environment.remote.observeReclaimInputStates).not.toHaveBeenCalled();
    expect(environment.remote.reclaim).not.toHaveBeenCalled();
    expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
  });

  it('persists the full plan before remote I/O and never logs secret or witness material', async () => {
    const environment = await setupPendingRefund();
    environment.remote.reclaim.mockImplementationOnce(async (inputs, outputData) => {
      const stored = (await environment.repositories.sendOperationRepository.getById(
        environment.operation.id,
      )) as RollingBackSendOperation;
      expect(stored.state).toBe('rolling_back');
      expect(stored.reclaimData).toMatchObject({
        spendingPath: 'refund',
        inputProofSecrets: environment.sendProofs.map((proof) => proof.secret),
        outputData,
        refundPublicKeyX: refundPublicKey.slice(2),
      });
      expect(
        stored.reclaimData?.spendingPath === 'refund'
          ? stored.reclaimData.conditionFingerprint
          : undefined,
      ).toHaveLength(64);
      expect(inputs.every((proof) => proof.witness !== undefined)).toBe(true);
      expect(JSON.stringify(stored)).not.toContain('signatures');
      return outputProofs(stored);
    });

    const result = await environment.service.reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });

    expect(result.state).toBe('rolled_back');
    const logged = JSON.stringify([
      environment.logger.debug.mock.calls,
      environment.logger.info.mock.calls,
      environment.logger.warn.mock.calls,
      environment.logger.error.mock.calls,
    ]);
    expect(logged).not.toContain(bytesToHex(refundSecret));
    expect(logged).not.toContain(environment.sendProofs[0]!.secret);
    expect(logged).not.toContain('signatures');
    expect(environment.remote.reclaim).toHaveBeenCalledTimes(1);
  });

  it.each(completionTamperCases)(
    'rejects a between-authentication-and-initial-completion %s mutation with zero credit',
    async (_name, tamper) => {
      const environment = await setupPendingRefund();
      environment.remote.reclaim.mockImplementationOnce(async () => {
        const original = await tamperPlanDuringRemote(environment, tamper);
        return outputProofs(original);
      });

      await expect(
        environment.service.reclaim(environment.operation.id, { spendingPath: 'refund' }),
      ).rejects.toThrow('changed before completion');
      expect(
        (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
          ?.state,
      ).toBe('rolling_back');
      expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual(
        [],
      );
    },
  );

  it('rejects the exact mutable transport-alias substitution with stale commitment and alternate proofs', async () => {
    const environment = await setupPendingRefund();
    let originalCommitment = '';
    environment.remote.reclaim.mockImplementationOnce(async (_inputs, transportOutputData) => {
      const alternate = serializeOutputData({
        keep: OutputData.createDeterministicData(
          Amount.from(10),
          new Uint8Array(32).fill(77),
          800,
          { id: testMintKeysetId(), keys: testMintKeypairs },
        ),
        send: [],
      });
      transportOutputData.keep.splice(0, transportOutputData.keep.length, ...alternate.keep);
      transportOutputData.send.splice(0, transportOutputData.send.length, ...alternate.send);

      const current = (await environment.repositories.sendOperationRepository.getById(
        environment.operation.id,
      )) as RollingBackSendOperation;
      const replacement = structuredClone(current.reclaimData) as CommittedRefundPlan;
      originalCommitment = replacement.planCommitment;
      replacement.outputData = structuredClone(transportOutputData);
      expect(
        await environment.repositories.sendOperationRepository.transition({
          operationId: current.id,
          expectedState: 'rolling_back',
          expectedRevision: current.revision ?? 0,
          next: { ...current, reclaimData: replacement },
        }),
      ).toBe(true);
      return outputProofs({ ...current, reclaimData: replacement });
    });

    await expect(
      environment.service.reclaim(environment.operation.id, { spendingPath: 'refund' }),
    ).rejects.toThrow('changed before completion');
    const stored = (await environment.repositories.sendOperationRepository.getById(
      environment.operation.id,
    )) as RollingBackSendOperation;
    expect(stored.state).toBe('rolling_back');
    expect(stored.reclaimData?.spendingPath).toBe('refund');
    if (stored.reclaimData?.spendingPath !== 'refund') throw new Error('missing refund plan');
    expect(stored.reclaimData.planCommitment).toBe(originalCommitment);
    expect(commitRefundReclaimPlan(stored.reclaimData, new Uint8Array(64).fill(1))).not.toBe(
      originalCommitment,
    );
    expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
  });

  it('rejects a durable refund-plan ABA that restores plan bytes under a later revision', async () => {
    const environment = await setupPendingRefund();
    environment.remote.reclaim.mockImplementationOnce(async () => {
      const original = (await environment.repositories.sendOperationRepository.getById(
        environment.operation.id,
      )) as RollingBackSendOperation;
      const changed = structuredClone(original.reclaimData) as CommittedRefundPlan;
      changed.conditionFingerprint = 'ab'.repeat(32);
      expect(
        await environment.repositories.sendOperationRepository.transition({
          operationId: original.id,
          expectedState: 'rolling_back',
          expectedRevision: original.revision ?? 0,
          next: { ...original, revision: (original.revision ?? 0) + 1, reclaimData: changed },
        }),
      ).toBe(true);
      const changedOperation = (await environment.repositories.sendOperationRepository.getById(
        original.id,
      )) as RollingBackSendOperation;
      expect(
        await environment.repositories.sendOperationRepository.transition({
          operationId: original.id,
          expectedState: 'rolling_back',
          expectedRevision: changedOperation.revision ?? 0,
          next: {
            ...original,
            revision: (changedOperation.revision ?? 0) + 1,
            reclaimData: structuredClone(original.reclaimData),
          },
        }),
      ).toBe(true);
      return outputProofs(original);
    });

    await expect(
      environment.service.reclaim(environment.operation.id, { spendingPath: 'refund' }),
    ).rejects.toThrow('changed before completion');
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolling_back');
    expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
  });

  it('rejects a commitment mutation during Restore completion with zero credit', async () => {
    const environment = await interruptAfterBegin();
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs.mockImplementationOnce(async () => {
      const original = await tamperPlanDuringRemote(environment, (plan) => {
        plan.planCommitment = '11'.repeat(32);
      });
      return completeObservation(original);
    });
    await expect(
      environment.buildService().reclaim(environment.operation.id, { spendingPath: 'refund' }),
    ).rejects.toThrow('changed before completion');
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolling_back');
    expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
  });

  it('rejects a commitment mutation before ambiguous replay Restore completion', async () => {
    const environment = await interruptAfterBegin();
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs
      .mockResolvedValueOnce({ status: 'none' })
      .mockImplementationOnce(async () => completeObservation(environment.rolling));
    environment.remote.checkProofStates.mockResolvedValueOnce(
      states(environment.sendProofs, 'UNSPENT'),
    );
    environment.remote.reclaim.mockImplementationOnce(async () => {
      await tamperPlanDuringRemote(environment, (plan) => {
        plan.planCommitment = '22'.repeat(32);
      });
      throw new Error('response lost after mutation');
    });
    await expect(
      environment.buildService().reclaim(environment.operation.id, { spendingPath: 'refund' }),
    ).rejects.toThrow('changed before completion');
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolling_back');
    expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
  });

  it('returns rolled_back and finalized operations idempotently without remote work', async () => {
    const rolled = await setupPendingRefund();
    rolled.remote.reclaim.mockImplementationOnce(async (_inputs, _data) => {
      const current = (await rolled.repositories.sendOperationRepository.getById(
        rolled.operation.id,
      )) as RollingBackSendOperation;
      return outputProofs(current);
    });
    await rolled.service.reclaim(rolled.operation.id, { spendingPath: 'refund' });
    rolled.remote.reclaim.mockClear();
    rolled.remote.observeReclaimOutputs.mockClear();
    expect(
      (await rolled.service.reclaim(rolled.operation.id, { spendingPath: 'refund' })).state,
    ).toBe('rolled_back');
    expect(rolled.remote.reclaim).not.toHaveBeenCalled();
    expect(rolled.remote.observeReclaimOutputs).not.toHaveBeenCalled();

    const finalized = await setupPendingRefund();
    await finalized.repositories.sendOperationRepository.transition({
      operationId: finalized.operation.id,
      expectedState: 'pending',
      expectedRevision: 2,
      next: { ...finalized.operation, state: 'finalized', revision: 3 },
    });
    expect(
      (await finalized.service.reclaim(finalized.operation.id, { spendingPath: 'refund' })).state,
    ).toBe('finalized');
    expect(finalized.remote.open).not.toHaveBeenCalled();
  });

  it('serializes concurrent calls into one plan and one wallet credit', async () => {
    const environment = await setupPendingRefund();
    let release!: () => void;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    environment.remote.reclaim.mockImplementationOnce(async () => {
      await gate;
      const current = (await environment.repositories.sendOperationRepository.getById(
        environment.operation.id,
      )) as RollingBackSendOperation;
      return outputProofs(current);
    });
    const first = environment.service.reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });
    const second = environment.service.reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });
    await new Promise((resolve) => setTimeout(resolve, 0));
    release();
    const results = await Promise.all([first, second]);
    expect(results.map((result) => result.state)).toEqual(['rolled_back', 'rolled_back']);
    expect(environment.remote.reclaim).toHaveBeenCalledTimes(1);
    expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toHaveLength(
      outputProofs(results[0] as RollingBackSendOperation).length,
    );
  });

  it('recovers a crash/lost response from complete UNSPENT Restore without replay', async () => {
    const environment = await interruptAfterBegin();
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs.mockResolvedValueOnce(
      completeObservation(environment.rolling),
    );
    const result = await environment.buildService().reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });
    expect(result.state).toBe('rolled_back');
    expect(environment.remote.reclaim).not.toHaveBeenCalled();
    expectOwnedRefundSeedsZeroized(environment, { returned: 4, deterministic: 2 });
    await expectRefundValueConserved(environment);
  });

  it.each([
    [
      'partial',
      (operation: RollingBackSendOperation): ReclaimOutputObservation => {
        const complete = completeObservation(operation);
        if (complete.status !== 'complete') throw new Error('Expected complete fixture');
        return {
          status: 'partial',
          outputs: complete.outputs.slice(0, 1),
          missingOutputs: outputProofs(operation).length - 1,
        };
      },
    ],
    [
      'pending output',
      (operation: RollingBackSendOperation) => completeObservation(operation, 'PENDING'),
    ],
    [
      'spent output',
      (operation: RollingBackSendOperation) => completeObservation(operation, 'SPENT'),
    ],
    [
      'unavailable',
      (): ReclaimOutputObservation => ({
        status: 'inconclusive',
        reason: 'unavailable',
        outputs: [],
      }),
    ],
  ] as const)(
    'keeps %s Restore evidence rolling_back without replay or credit',
    async (_name, observe) => {
      const environment = await interruptAfterBegin();
      environment.remote.reclaim.mockClear();
      environment.remote.observeReclaimOutputs.mockResolvedValueOnce(observe(environment.rolling));
      const result = await environment.buildService().reclaim(environment.operation.id, {
        spendingPath: 'refund',
      });
      expect(result.state).toBe('rolling_back');
      expect(environment.remote.reclaim).not.toHaveBeenCalled();
      expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual(
        [],
      );
    },
  );

  it('replays the same plan once only after Restore NONE and every input is UNSPENT', async () => {
    const environment = await interruptAfterBegin();
    const originalPlan = structuredClone(environment.rolling.reclaimData);
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs.mockResolvedValueOnce({ status: 'none' });
    environment.remote.checkProofStates.mockResolvedValueOnce(
      states(environment.sendProofs, 'UNSPENT'),
    );
    environment.remote.reclaim.mockImplementationOnce(async (_inputs, outputData) => {
      expect(outputData).toEqual(originalPlan!.outputData);
      const current = (await environment.repositories.sendOperationRepository.getById(
        environment.operation.id,
      )) as RollingBackSendOperation;
      expect(current.reclaimData).toEqual(originalPlan);
      return outputProofs(current);
    });
    const result = await environment.buildService().reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });
    expect(result.state).toBe('rolled_back');
    expect(environment.remote.reclaim).toHaveBeenCalledTimes(1);
  });

  it.each([
    [
      'operation ID',
      (plan: CommittedRefundPlan): void => {
        plan.operationId = 'substituted-operation';
      },
    ],
    [
      'mint URL',
      (plan: CommittedRefundPlan): void => {
        plan.mintUrl = 'https://other-mint.test';
      },
    ],
    [
      'unit',
      (plan: CommittedRefundPlan): void => {
        plan.unit = 'usd';
      },
    ],
    [
      'ordered input secrets',
      (plan: CommittedRefundPlan): void => {
        plan.inputProofSecrets.reverse();
      },
    ],
    [
      'input ownership',
      (plan: CommittedRefundPlan): void => {
        plan.inputOwnership = plan.inputOwnership === 'created' ? 'used' : 'created';
      },
    ],
    [
      'spending path',
      (plan: CommittedRefundPlan): void => {
        Object.assign(plan, { spendingPath: 'default' as unknown as 'refund' });
      },
    ],
    [
      'condition fingerprint',
      (plan: CommittedRefundPlan): void => {
        plan.conditionFingerprint = '00'.repeat(32);
      },
    ],
    [
      'refund authority',
      (plan: CommittedRefundPlan): void => {
        plan.refundPublicKeyX = '11'.repeat(32);
      },
    ],
    [
      'counter allocation',
      (plan: CommittedRefundPlan) => {
        plan.allocation.counterStart += 1;
        plan.allocation.counterEnd += 1;
      },
    ],
    [
      'valid same-value output plan',
      (plan: CommittedRefundPlan) => {
        plan.outputData = serializeOutputData({
          keep: OutputData.createDeterministicData(
            Amount.from(10),
            new Uint8Array(64).fill(1),
            plan.allocation.counterStart + 100,
            { id: testMintKeysetId(), keys: testMintKeypairs },
          ),
          send: [],
        });
      },
    ],
  ] as const)(
    'keeps an unauthenticated %s substitution rolling_back with zero dispatch or credit',
    async (_name, tamper) => {
      const environment = await interruptAfterBegin();
      environment.remote.open.mockClear();
      environment.remote.reclaim.mockClear();
      environment.remote.observeReclaimOutputs.mockClear();
      environment.remote.checkProofStates.mockClear();
      await persistTamperedPlan(environment, tamper);

      await environment.buildService().recoverPendingOperations();

      expect(
        (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
          ?.state,
      ).toBe('rolling_back');
      expect(environment.remote.open).not.toHaveBeenCalled();
      expect(environment.remote.reclaim).not.toHaveBeenCalled();
      expect(environment.remote.observeReclaimOutputs).not.toHaveBeenCalled();
      expect(environment.remote.checkProofStates).not.toHaveBeenCalled();
      expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual(
        [],
      );
    },
  );

  it.each([
    ['spent', (proofs: Proof[]) => states(proofs, 'SPENT')],
    ['pending', (proofs: Proof[]) => states(proofs, 'PENDING')],
    [
      'mixed',
      (proofs: Proof[]) =>
        states(proofs, 'UNSPENT').map((state, index) =>
          index === 0 ? state : { ...state, state: 'SPENT' as const },
        ),
    ],
    ['incomplete', (proofs: Proof[]) => states(proofs, 'UNSPENT').slice(0, -1)],
  ] as const)(
    'keeps %s input evidence rolling_back without replay',
    async (_name, observeInputs) => {
      const environment = await interruptAfterBegin();
      environment.remote.reclaim.mockClear();
      environment.remote.observeReclaimOutputs.mockResolvedValueOnce({ status: 'none' });
      environment.remote.checkProofStates.mockResolvedValueOnce(
        observeInputs(environment.sendProofs),
      );
      const result = await environment.buildService().reclaim(environment.operation.id, {
        spendingPath: 'refund',
      });
      expect(result.state).toBe('rolling_back');
      expect(environment.remote.reclaim).not.toHaveBeenCalled();
    },
  );

  it.each([
    [
      'Y1 wrong Y',
      (proofs: Proof[]) => {
        const exact = states(proofs, 'UNSPENT');
        return [{ ...exact[0]!, Y: `02${'11'.repeat(32)}` }, ...exact.slice(1)];
      },
      false,
    ],
    [
      'Y2 duplicate Y',
      (proofs: Proof[]) => {
        const exact = states(proofs, 'UNSPENT');
        return exact.map((state) => ({ ...state, Y: exact[0]!.Y }));
      },
      false,
    ],
    ['Y3 missing Y', (proofs: Proof[]) => states(proofs, 'UNSPENT').slice(0, -1), false],
    [
      'Y4 extra Y',
      (proofs: Proof[]) => [
        ...states(proofs, 'UNSPENT'),
        { Y: `03${'22'.repeat(32)}`, state: 'UNSPENT', witness: null },
      ],
      false,
    ],
    ['Y5 reordered valid Ys', (proofs: Proof[]) => states(proofs, 'UNSPENT').reverse(), true],
    [
      'Y6 invalid state enum',
      (proofs: Proof[]) =>
        states(proofs, 'UNSPENT').map((state, index) =>
          index === 0 ? { ...state, state: 'UNKNOWN' } : state,
        ),
      false,
    ],
    ['Y7 null response', () => null, false],
    ['Y8 non-array object response', () => ({ states: [] }), false],
    [
      'Y9 malformed item',
      (proofs: Proof[]) =>
        states(proofs, 'UNSPENT').map((state, index) => (index === 0 ? { Y: state.Y } : state)),
      false,
    ],
    ['Y10 valid exact set all UNSPENT', (proofs: Proof[]) => states(proofs, 'UNSPENT'), true],
  ] as const)(
    '%s controls replay only with complete exact input evidence',
    async (_name, response, shouldReplay) => {
      const environment = await interruptAfterBegin();
      environment.remote.reclaim.mockClear();
      environment.remote.observeReclaimOutputs.mockResolvedValueOnce({ status: 'none' });
      environment.remote.checkProofStates.mockResolvedValueOnce(
        response(environment.sendProofs) as ProofState[],
      );
      if (shouldReplay) {
        environment.remote.reclaim.mockImplementationOnce(async () =>
          outputProofs(environment.rolling),
        );
      }

      const result = await environment.buildService().reclaim(environment.operation.id, {
        spendingPath: 'refund',
      });

      expect(result.state).toBe(shouldReplay ? 'rolled_back' : 'rolling_back');
      expect(environment.remote.reclaim).toHaveBeenCalledTimes(shouldReplay ? 1 : 0);
    },
  );

  it.each([
    ['W1 missing witness', (proofs: Proof[]) => statesWithFirstWitness(proofs, null, false), false],
    ['W2 witness undefined', (proofs: Proof[]) => statesWithFirstWitness(proofs, undefined), false],
    ['W3 witness object', (proofs: Proof[]) => statesWithFirstWitness(proofs, {}), false],
    ['W4 witness array', (proofs: Proof[]) => statesWithFirstWitness(proofs, []), false],
    ['W5 witness number', (proofs: Proof[]) => statesWithFirstWitness(proofs, 7), false],
    ['W6 witness boolean', (proofs: Proof[]) => statesWithFirstWitness(proofs, true), false],
    ['W7 empty witness string', (proofs: Proof[]) => statesWithFirstWitness(proofs, ''), true],
    [
      'W8 serialized witness string',
      (proofs: Proof[]) =>
        statesWithFirstWitness(proofs, JSON.stringify({ signatures: ['signature'] })),
      true,
    ],
    ['W9 null witness', (proofs: Proof[]) => statesWithFirstWitness(proofs, null), true],
  ] as const)(
    '%s controls replay through strict witness validation',
    async (_name, response, shouldReplay) => {
      const environment = await interruptAfterBegin();
      environment.remote.reclaim.mockClear();
      environment.remote.observeReclaimOutputs.mockResolvedValueOnce({ status: 'none' });
      environment.remote.checkProofStates.mockResolvedValueOnce(
        response(environment.sendProofs) as ProofState[],
      );
      if (shouldReplay) {
        environment.remote.reclaim.mockImplementationOnce(async () =>
          outputProofs(environment.rolling),
        );
      }

      const result = await environment.buildService().reclaim(environment.operation.id, {
        spendingPath: 'refund',
      });

      expect(result.state).toBe(shouldReplay ? 'rolled_back' : 'rolling_back');
      expect(environment.remote.reclaim).toHaveBeenCalledTimes(shouldReplay ? 1 : 0);
      if (!shouldReplay) {
        expect(await environment.repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual(
          [],
        );
      }
    },
  );

  it('restores again after an ambiguous same-plan replay and credits only complete UNSPENT outputs', async () => {
    const environment = await interruptAfterBegin();
    environment.remote.reclaim.mockClear();
    environment.remote.observeReclaimOutputs
      .mockResolvedValueOnce({ status: 'none' })
      .mockResolvedValueOnce(completeObservation(environment.rolling));
    environment.remote.checkProofStates.mockResolvedValueOnce(
      states(environment.sendProofs, 'UNSPENT'),
    );
    environment.remote.reclaim.mockRejectedValueOnce(new Error('replay response lost'));
    const result = await environment.buildService().reclaim(environment.operation.id, {
      spendingPath: 'refund',
    });
    expect(result.state).toBe('rolled_back');
    expect(environment.remote.observeReclaimOutputs).toHaveBeenCalledTimes(2);
    expect(environment.remote.reclaim).toHaveBeenCalledTimes(1);
  });

  it('startup recovery resumes a refund plan without allocating a second output plan', async () => {
    const environment = await interruptAfterBegin();
    const originalPlan = structuredClone(environment.rolling.reclaimData);
    const counter = await environment.repositories.counterRepository.getCounter(
      mintUrl,
      testMintKeysetId(),
    );
    environment.remote.observeReclaimOutputs.mockResolvedValueOnce(
      completeObservation(environment.rolling),
    );
    await environment.buildService().recoverPendingOperations();
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.state,
    ).toBe('rolled_back');
    expect(
      (await environment.repositories.sendOperationRepository.getById(environment.operation.id))
        ?.reclaimData,
    ).toEqual(originalPlan);
    expect(
      await environment.repositories.counterRepository.getCounter(mintUrl, testMintKeysetId()),
    ).toEqual(counter);
  });
});
