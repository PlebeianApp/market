import { Amount } from '@cashu/cashu-ts';
import { beforeEach, describe, expect, it, mock } from 'bun:test';
import { QuoteApi } from '../../api/QuoteApi.ts';
import type { MeltOpsApi } from '../../api/MeltOpsApi.ts';
import type { MeltQuote } from '../../models/MeltQuote.ts';
import type { MintQuote } from '../../models/MintQuote.ts';
import type { QuoteLifecycle } from '../../quotes/QuoteLifecycle.ts';

const mintUrl = 'https://mint.test';
const quoteId = 'quote-1';

type MintCreateInput = Parameters<QuoteApi['mint']['create']>[0];
type MintImportInput = Parameters<QuoteApi['mint']['import']>[0];
type MeltCreateInput = Parameters<QuoteApi['melt']['create']>[0];

function assertMethodRequirementsRemain(): void {
  // @ts-expect-error Mint quote creation still requires method.
  const mintCreateWithoutMethod: MintCreateInput = { mintUrl, amount: Amount.from(10) };
  // @ts-expect-error Mint quote import still requires method.
  const mintImportWithoutMethod: MintImportInput = {
    mintUrl,
    quote: {
      quote: quoteId,
      request: 'lnbc1mint',
      amount: Amount.from(10),
      unit: 'sat',
      expiry: Math.floor(Date.now() / 1000) + 3600,
      state: 'UNPAID',
    },
  };
  // @ts-expect-error Melt quote creation still requires method.
  const meltCreateWithoutMethod: MeltCreateInput = {
    mintUrl,
    methodData: { invoice: 'lnbc1melt' },
  };
  void [mintCreateWithoutMethod, mintImportWithoutMethod, meltCreateWithoutMethod];
}

const makeMintQuote = (): MintQuote<'bolt11'> => ({
  mintUrl,
  method: 'bolt11',
  quoteId,
  quote: quoteId,
  request: 'lnbc1mint',
  amount: Amount.from(10),
  unit: 'sat',
  expiry: Math.floor(Date.now() / 1000) + 3600,
  state: 'UNPAID',
  reusable: false,
  amountPaid: Amount.zero(),
  amountIssued: Amount.zero(),
  remoteUpdatedAt: null,
  quoteData: {
    amount: Amount.from(10),
  },
  createdAt: Date.now(),
  updatedAt: Date.now(),
});

const makeMeltQuote = (): MeltQuote<'bolt11'> => ({
  mintUrl,
  method: 'bolt11',
  quoteId,
  quote: quoteId,
  request: 'lnbc1melt',
  amount: Amount.from(10),
  unit: 'sat',
  fee_reserve: Amount.from(1),
  expiry: Math.floor(Date.now() / 1000) + 3600,
  state: 'UNPAID',
  payment_preimage: null,
  lastObservedRemoteState: 'UNPAID',
  lastObservedRemoteStateAt: Date.now(),
  createdAt: Date.now(),
  updatedAt: Date.now(),
});

describe('QuoteApi', () => {
  let api: QuoteApi;
  let quoteLifecycle: QuoteLifecycle;
  let mintQuote: MintQuote<'bolt11'>;
  let meltQuote: MeltQuote<'bolt11'>;

  beforeEach(() => {
    mintQuote = makeMintQuote();
    meltQuote = makeMeltQuote();
    quoteLifecycle = {
      createMintQuote: mock(async () => mintQuote),
      importMintQuote: mock(async () => mintQuote),
      getMintQuoteById: mock(async () => mintQuote),
      getPendingMintQuotes: mock(async () => [mintQuote]),
      refreshMintQuoteById: mock(async () => ({ ...mintQuote, state: 'PAID' })),
      createMeltQuote: mock(async () => meltQuote),
      getMeltQuoteById: mock(async () => meltQuote),
      getPendingMeltQuotes: mock(async () => [meltQuote]),
      refreshMeltQuoteById: mock(async () => ({ ...meltQuote, state: 'PENDING' })),
    } as unknown as QuoteLifecycle;

    api = new QuoteApi(quoteLifecycle);
  });

  it('delegates mint quote methods', async () => {
    await expect(
      api.mint.create({ mintUrl, amount: Amount.from(10), method: 'bolt11' }),
    ).resolves.toBe(mintQuote);
    await expect(api.mint.get({ mintUrl, quoteId })).resolves.toBe(mintQuote);
    await expect(
      api.mint.import({
        mintUrl,
        method: 'bolt11',
        quote: {
          quote: quoteId,
          request: 'lnbc1mint',
          amount: Amount.from(10),
          unit: 'sat',
          expiry: mintQuote.expiry,
          state: 'UNPAID',
        },
      }),
    ).resolves.toBe(mintQuote);
    await expect(api.mint.listPending({ method: 'bolt11' })).resolves.toEqual([mintQuote]);
    await expect(api.mint.refresh({ mintUrl, quoteId })).resolves.toMatchObject({
      state: 'PAID',
    });

    expect(quoteLifecycle.createMintQuote).toHaveBeenCalledWith(mintUrl, 'bolt11', {
      amount: { amount: Amount.from(10), unit: 'sat' },
    });
    expect(quoteLifecycle.importMintQuote).toHaveBeenCalledWith(mintUrl, 'bolt11', {
      quote: quoteId,
      request: 'lnbc1mint',
      amount: Amount.from(10),
      unit: 'sat',
      expiry: mintQuote.expiry,
      state: 'UNPAID',
    });
    expect(quoteLifecycle.getMintQuoteById).toHaveBeenCalledWith({ mintUrl, quoteId });
    expect(quoteLifecycle.getPendingMintQuotes).toHaveBeenCalledWith('bolt11');
    expect(quoteLifecycle.refreshMintQuoteById).toHaveBeenCalledWith({ mintUrl, quoteId });
  });

  it('delegates onchain mint quote creation without an amount', async () => {
    await expect(api.mint.create({ mintUrl, method: 'onchain', unit: 'sat' })).resolves.toBe(
      mintQuote,
    );

    expect(quoteLifecycle.createMintQuote).toHaveBeenCalledWith(mintUrl, 'onchain', {
      unit: 'sat',
    });
  });

  it('delegates opt-in locked BOLT11 quote creation', async () => {
    await expect(
      api.mint.create({
        mintUrl,
        method: 'bolt11',
        amount: Amount.from(10),
        locked: true,
      }),
    ).resolves.toBe(mintQuote);

    expect(quoteLifecycle.createMintQuote).toHaveBeenCalledWith(mintUrl, 'bolt11', {
      amount: { amount: Amount.from(10), unit: 'sat' },
      locked: true,
    });
  });

  it('delegates BOLT12 mint quote creation with optional amount data', async () => {
    await expect(
      api.mint.create({
        mintUrl,
        method: 'bolt12',
        unit: 'sat',
        amount: Amount.from(10),
        description: 'coffee',
      }),
    ).resolves.toBe(mintQuote);

    expect(quoteLifecycle.createMintQuote).toHaveBeenCalledWith(mintUrl, 'bolt12', {
      unit: 'sat',
      amount: { amount: Amount.from(10), unit: 'sat' },
      description: 'coffee',
    });
  });

  it('delegates amountless BOLT12 mint quote creation without undefined amount', async () => {
    await expect(
      api.mint.create({
        mintUrl,
        method: 'bolt12',
        unit: 'sat',
        description: 'coffee',
      }),
    ).resolves.toBe(mintQuote);

    expect(quoteLifecycle.createMintQuote).toHaveBeenCalledWith(mintUrl, 'bolt12', {
      unit: 'sat',
      description: 'coffee',
    });
  });

  it('returns null for absent methodless quote lookups', async () => {
    (quoteLifecycle.getMintQuoteById as any).mockImplementationOnce(async () => null);
    (quoteLifecycle.getMeltQuoteById as any).mockImplementationOnce(async () => null);

    await expect(api.mint.get({ mintUrl, quoteId: 'missing-mint' })).resolves.toBeNull();
    await expect(api.melt.get({ mintUrl, quoteId: 'missing-melt' })).resolves.toBeNull();
  });

  it('delegates melt quote methods', async () => {
    await expect(
      api.melt.create({
        mintUrl,
        method: 'bolt11',
        methodData: { invoice: 'lnbc1melt' },
      }),
    ).resolves.toBe(meltQuote);
    await expect(api.melt.get({ mintUrl, quoteId })).resolves.toBe(meltQuote);
    await expect(api.melt.listPending({ method: 'bolt11' })).resolves.toEqual([meltQuote]);
    await expect(api.melt.refresh({ mintUrl, quoteId })).resolves.toMatchObject({
      state: 'PENDING',
    });

    expect(quoteLifecycle.createMeltQuote).toHaveBeenCalledWith(
      mintUrl,
      'bolt11',
      { invoice: 'lnbc1melt' },
      undefined,
    );
    expect(quoteLifecycle.getMeltQuoteById).toHaveBeenCalledWith({ mintUrl, quoteId });
    expect(quoteLifecycle.getPendingMeltQuotes).toHaveBeenCalledWith('bolt11');
    expect(quoteLifecycle.refreshMeltQuoteById).toHaveBeenCalledWith({ mintUrl, quoteId });
  });

  it('types created BOLT melt quotes as direct prepare inputs', async () => {
    const meltOps = {
      prepare: mock(async () => undefined),
    } as unknown as Pick<MeltOpsApi, 'prepare'>;

    const quote = await api.melt.create({
      mintUrl,
      method: 'bolt11',
      methodData: { invoice: 'lnbc1melt' },
    });

    await meltOps.prepare({ quote });

    expect(meltOps.prepare).toHaveBeenCalledWith({ quote });
  });

  it('keeps method required for quote creation and import inputs', () => {
    assertMethodRequirementsRemain();
  });
});
