import { WalletAuthorityValidationError } from '../models/Error.ts';

export type WalletAuthorityStatus = 'active' | 'released';

export interface WalletAuthorityIdentity {
  namespace: string;
  ownerId: string;
}

export interface WalletAuthority extends WalletAuthorityIdentity {
  generation: number;
  status: WalletAuthorityStatus;
}

export type WalletAuthorityState = 'unacquired' | 'active' | 'stale' | 'released';

/** Validate the stable store namespace and ephemeral runtime owner identity. */
export function validateWalletAuthorityIdentity(
  identity: WalletAuthorityIdentity,
): WalletAuthorityIdentity {
  const candidate = identity as WalletAuthorityIdentity | null | undefined;
  for (const [field, value] of [
    ['namespace', candidate?.namespace],
    ['ownerId', candidate?.ownerId],
  ] as const) {
    if (typeof value !== 'string' || !value.trim() || value.trim() !== value) {
      throw new WalletAuthorityValidationError(
        `Wallet authority ${field} must be non-empty without surrounding whitespace`,
      );
    }
  }
  return identity;
}
