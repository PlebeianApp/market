import { PaymentRequest } from '@cashu/cashu-ts';
import { describe, expect, test } from 'bun:test';

const CORE_ROOT = new URL('../../', import.meta.url).pathname.replace(/\/$/, '');

type Loaded = {
  initializeCoco: (config: any) => Promise<any>;
  MemoryRepositories: new () => any;
};

const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

async function probe(label: string, modulePath: string): Promise<void> {
  const core = (await import(modulePath)) as unknown as Loaded;
  const encoded = new PaymentRequest([], `round6-alias-${label}`, undefined, 'sat', [
    'https://original-mint.invalid',
  ]).toEncodedRequest();
  let loggedPaymentRequest: any;
  let returnedPaymentRequest: any;
  const logger: any = {
    error() {},
    warn() {},
    debug() {},
    info(_message: string, ...meta: any[]) {
      for (const item of meta) {
        if (item?.decodedPaymentRequest) loggedPaymentRequest = item.decodedPaymentRequest;
      }
    },
    child() {
      return this;
    },
  };
  const manager = await core.initializeCoco({
    repo: new core.MemoryRepositories(),
    seedGetter: async () => new Uint8Array(64),
    logger,
    plugins: [
      {
        name: `round6-class-alias-${label}`,
        required: ['paymentRequestService'],
        async onInit(context: any) {
          const resolved = await context.services.paymentRequestService.parse(encoded);
          returnedPaymentRequest = resolved.paymentRequest;
        },
      },
    ],
    ...disabledRuntime,
  });
  try {
    expect(returnedPaymentRequest).not.toBe(loggedPaymentRequest);
    expect(Object.isFrozen(returnedPaymentRequest)).toBe(true);
    expect(Object.isFrozen(returnedPaymentRequest.mints)).toBe(true);
    returnedPaymentRequest.mints.push('https://plugin-mutated.invalid');
    expect(returnedPaymentRequest.mints).not.toContain('https://plugin-mutated.invalid');
    expect(loggedPaymentRequest.mints).not.toContain('https://plugin-mutated.invalid');
    expect(returnedPaymentRequest.toEncodedRequest()).toBe(encoded);
  } finally {
    await manager.dispose();
  }
}

describe('round-six plugin return detachment', () => {
  test('PaymentRequest is detached in source', () => probe('source', `${CORE_ROOT}/index.ts`));
  test('PaymentRequest is detached in dist', () => probe('dist', `${CORE_ROOT}/dist/index.js`));
});
