import {
  getP2PKWitnessSignatures,
  parseP2PKSecret,
  schnorrVerifyMessage,
  type Proof,
  type Secret,
} from '@cashu/cashu-ts';
import { bytesToHex } from '@noble/curves/utils.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { ProofValidationError } from '@core/models/Error.ts';
import type { P2pkSigner } from '@core/keypairs/P2pkSigner.ts';
import { canonicalP2pkWireKeyX } from '@core/keypairs/P2pkSigner.ts';
import {
  resolveP2pkOptions,
  type PrepareContext,
  type PreparedRefundReclaim,
  type RefundReclaimContext,
  type SendMethodHandler,
  type SendPreparationPlan,
} from '@core/operations/send/SendMethodHandler.ts';

/** Local output policy for tokens locked to a recipient's NUT-11 P2PK condition. */
export class P2pkSendHandler implements SendMethodHandler<'p2pk'> {
  readonly canReclaim = true;

  constructor(
    private readonly signer?: P2pkSigner,
    private readonly nowSeconds: () => number = () => Math.floor(Date.now() / 1000),
  ) {}

  prepare(ctx: PrepareContext<'p2pk'>): SendPreparationPlan {
    const options = resolveP2pkOptions(ctx.operation.methodData);
    if (ctx.mintInfo.nuts?.['11']?.supported !== true) {
      throw new ProofValidationError(
        `NUT-11 support is required for P2PK send but is not advertised by mint ${ctx.operation.mintUrl}`,
      );
    }
    return {
      forceSwap: true,
      fixedSendOutputs: ctx.outputDataCreator.createP2PKData(
        options,
        ctx.operation.amount,
        ctx.activeKeys,
      ),
    };
  }

  async prepareReclaim(ctx: RefundReclaimContext): Promise<PreparedRefundReclaim> {
    if (!this.signer) {
      throw new ProofValidationError('P2PK refund signer is unavailable');
    }
    if (ctx.inputProofs.length === 0) {
      throw new ProofValidationError('P2PK refund requires operation-owned proofs');
    }

    const conditions = ctx.inputProofs.map((proof) => parseRefundCondition(proof));
    const expected = conditions[0]!;
    if (this.nowSeconds() <= expected.locktime) {
      throw new ProofValidationError('P2PK refund locktime has not strictly expired');
    }
    if (conditions.some((condition) => condition.fingerprint !== expected.fingerprint)) {
      throw new ProofValidationError('P2PK refund proofs have heterogeneous conditions');
    }

    const inputProofs: Proof[] = [];
    for (const proof of ctx.inputProofs) {
      const signed = await this.signer.signProof(
        { ...proof, witness: undefined },
        expected.refundX,
      );
      const signatures = getP2PKWitnessSignatures(signed.witness);
      if (
        signatures.length !== 1 ||
        !schnorrVerifyMessage(signatures[0]!, proof.secret, expected.refundX)
      ) {
        throw new ProofValidationError('P2PK refund signer returned an invalid witness');
      }
      inputProofs.push(signed);
    }
    return {
      inputProofs,
      spendingPath: 'refund',
      conditionFingerprint: expected.fingerprint,
      refundPublicKeyX: expected.refundX,
    };
  }
}

type RefundCondition = {
  locktime: number;
  refundX: string;
  fingerprint: string;
};

const ACCEPTED_TAGS = new Set(['locktime', 'refund', 'n_sigs', 'n_sigs_refund', 'sigflag']);

function parseRefundCondition(proof: Proof): RefundCondition {
  if (proof.p2pk_e !== undefined) {
    throw new ProofValidationError('P2PK refund does not support blinded signer keys');
  }
  let secret: Secret;
  try {
    secret = parseP2PKSecret(proof.secret);
  } catch {
    throw new ProofValidationError('Malformed P2PK refund condition');
  }
  if (secret[0] !== 'P2PK') {
    throw new ProofValidationError('Refund proof is not P2PK');
  }
  const data = secret[1];
  const tags = data.tags ?? [];
  if (tags.some((tag) => !ACCEPTED_TAGS.has(tag[0] ?? ''))) {
    throw new ProofValidationError('P2PK refund condition contains unsupported tags');
  }
  const byName = new Map(tags.map((tag) => [tag[0], tag]));
  const exactScalar = (name: string): string | undefined => {
    const tag = byName.get(name);
    if (!tag) return undefined;
    if (tag.length !== 2 || !tag[1]) {
      throw new ProofValidationError(`Malformed P2PK ${name} tag`);
    }
    return tag[1];
  };
  const locktimeRaw = exactScalar('locktime');
  const refundRaw = exactScalar('refund');
  if (!locktimeRaw || !refundRaw) {
    throw new ProofValidationError('P2PK refund requires one locktime and one refund key');
  }
  const locktime = Number(locktimeRaw);
  if (!Number.isSafeInteger(locktime) || locktime <= 0 || String(locktime) !== locktimeRaw) {
    throw new ProofValidationError('P2PK refund locktime is invalid');
  }
  if ((exactScalar('n_sigs') ?? '1') !== '1') {
    throw new ProofValidationError('P2PK refund supports only n_sigs = 1');
  }
  if ((exactScalar('n_sigs_refund') ?? '1') !== '1') {
    throw new ProofValidationError('P2PK refund supports only n_sigs_refund = 1');
  }
  if ((exactScalar('sigflag') ?? 'SIG_INPUTS') !== 'SIG_INPUTS') {
    throw new ProofValidationError('P2PK refund supports only SIG_INPUTS');
  }
  const recipientX = canonicalP2pkWireKeyX(data.data);
  const refundX = canonicalP2pkWireKeyX(refundRaw);
  if (recipientX === refundX) {
    throw new ProofValidationError('P2PK recipient and refund keys must differ');
  }
  const canonical = {
    version: 1,
    kind: 'P2PK',
    recipientX,
    refundX,
    locktime,
    nSigs: 1,
    nSigsRefund: 1,
    sigflag: 'SIG_INPUTS',
  };
  return {
    locktime,
    refundX,
    fingerprint: bytesToHex(sha256(new TextEncoder().encode(JSON.stringify(canonical)))),
  };
}
