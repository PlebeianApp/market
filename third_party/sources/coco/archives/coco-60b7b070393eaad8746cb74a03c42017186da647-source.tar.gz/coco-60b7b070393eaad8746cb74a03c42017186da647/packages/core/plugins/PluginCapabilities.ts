import { Amount, OutputData, PaymentRequest, Wallet, type OutputDataLike } from '@cashu/cashu-ts';
import type { QuoteApi } from '../api/QuoteApi.ts';
import type { EventBus, EventHandler } from '../events/EventBus.ts';
import type { CoreEvents } from '../events/types.ts';
import type { SubscriptionCallback, SubscriptionManager } from '../infra/SubscriptionManager.ts';
import type { Logger } from '../logging/Logger.ts';
import type { MeltOperationService } from '../operations/melt/MeltOperationService.ts';
import type { MintOperationService } from '../operations/mint/MintOperationService.ts';
import type { ReceiveOperationService } from '../operations/receive/ReceiveOperationService.ts';
import type { SendOperationService } from '../operations/send/SendOperationService.ts';
import type {
  CounterService,
  HistoryService,
  KeyRingService,
  MintService,
  PaymentRequestReceiveService,
  PaymentRequestService,
  ProofService,
  TokenService,
  WalletRestoreService,
} from '../services/index.ts';
import type { PaymentRequestReceiveTransportHandler } from '../infra/handlers/paymentRequestReceive/index.ts';
import type { ServiceKey, ServiceMap } from './types.ts';
import type { CapabilityLifecycleGate } from './CapabilityLifecycle.ts';
import { rejectSafely, resolveSafely, thenSafely } from './SafeAsync.ts';
import type {
  PluginEventHandler,
  PluginEventCapability,
  PluginPaymentRequestReceiveCapability,
  PluginQuoteCapability,
  PluginSubscriptionCapability,
} from './capabilityTypes.ts';

type CapabilityFunction = (...args: never[]) => unknown;
type CapabilityRecord = Record<string, CapabilityFunction | object>;

const NativeError = Error;
const NativeArray = Array;
const NativeBigInt = BigInt;
const NativeDate = Date;
const NativeNumber = Number;
const NativeResponse = typeof Response === 'undefined' ? undefined : Response;
const NativeDataView = DataView;
const NativeArrayBuffer = ArrayBuffer;
const nativeArrayBufferSlice = ArrayBuffer.prototype.slice;
const nativeArrayIsArray = Array.isArray;
const nativeArrayBufferIsView = ArrayBuffer.isView;
const nativeCreate = Object.create;
const nativeDefineProperty = Object.defineProperty;
const nativeEntries = Object.entries;
const nativeFreeze = Object.freeze;
const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const nativeGetPrototypeOf = Object.getPrototypeOf;
const nativeNumberIsSafeInteger = Number.isSafeInteger;
const nativeKeys = Object.keys;
const nativeOwnKeys = Reflect.ownKeys;
const nativeReflectApply = Reflect.apply;
const nativeSetPrototypeOf = Object.setPrototypeOf;
const nativeValues = Object.values;
const nativeWeakMapGet = WeakMap.prototype.get;
const nativeWeakMapSet = WeakMap.prototype.set;
const nativeWeakSetHas = WeakSet.prototype.has;
const nativeResponseClone = NativeResponse?.prototype.clone;
const nativeDateGetTime = Date.prototype.getTime;
const nativeOutputDataToProof = OutputData.prototype.toProof;
const objectPrototype = Object.prototype;
const arrayPrototype = Array.prototype;
const uint8ArrayPrototype = Uint8Array.prototype;
const responsePrototype = NativeResponse?.prototype;
const amountPrototype = Amount.prototype;
const outputDataPrototype = OutputData.prototype;
const paymentRequestPrototype = PaymentRequest.prototype;
const walletPrototype = Wallet.prototype;
const datePrototype = Date.prototype;
const arrayBufferPrototype = ArrayBuffer.prototype;
const dataViewPrototype = DataView.prototype;
const mutableCollectionPrototypes = nativeFreeze([
  Map.prototype,
  Set.prototype,
  WeakMap.prototype,
  WeakSet.prototype,
]);
const errorPrototypes = nativeFreeze([
  Error.prototype,
  TypeError.prototype,
  RangeError.prototype,
  ReferenceError.prototype,
  SyntaxError.prototype,
  URIError.prototype,
  EvalError.prototype,
]);
const typedArrayPrototype = nativeGetPrototypeOf(uint8ArrayPrototype);
const typedArrayBufferGetter = nativeGetOwnPropertyDescriptor(typedArrayPrototype, 'buffer')?.get;
const typedArrayByteOffsetGetter = nativeGetOwnPropertyDescriptor(
  typedArrayPrototype,
  'byteOffset',
)?.get;
const typedArrayByteLengthGetter = nativeGetOwnPropertyDescriptor(
  typedArrayPrototype,
  'byteLength',
)?.get;
const dataViewBufferGetter = nativeGetOwnPropertyDescriptor(dataViewPrototype, 'buffer')?.get;
const dataViewByteOffsetGetter = nativeGetOwnPropertyDescriptor(
  dataViewPrototype,
  'byteOffset',
)?.get;
const dataViewByteLengthGetter = nativeGetOwnPropertyDescriptor(
  dataViewPrototype,
  'byteLength',
)?.get;
const typedArrayConstructors = nativeFreeze([
  Uint8Array,
  Uint8ClampedArray,
  Int8Array,
  Uint16Array,
  Int16Array,
  Uint32Array,
  Int32Array,
  Float32Array,
  Float64Array,
  BigInt64Array,
  BigUint64Array,
]);
const typedArrayPrototypes = nativeFreeze(typedArrayConstructors.map((Ctor) => Ctor.prototype));

function applyIntrinsic<T>(fn: Function, receiver: unknown, args: readonly unknown[]): T {
  return nativeReflectApply(fn, receiver, args) as T;
}

function weakMapGet<K extends object, V>(map: WeakMap<K, V>, key: K): V | undefined {
  return applyIntrinsic<V | undefined>(nativeWeakMapGet, map, [key]);
}

function weakMapSet<K extends object, V>(map: WeakMap<K, V>, key: K, value: V): void {
  applyIntrinsic(nativeWeakMapSet, map, [key, value]);
}

function weakSetHas<T extends object>(set: WeakSet<T>, value: T): boolean {
  return applyIntrinsic<boolean>(nativeWeakSetHas, set, [value]);
}

export type PluginCapabilityFactoryMap = Readonly<{
  [K in ServiceKey]: () => ServiceMap[K];
}>;

export interface PluginCapabilitySources {
  mintService: MintService;
  proofService: ProofService;
  keyRingService: KeyRingService;
  walletRestoreService: WalletRestoreService;
  counterService: CounterService;
  tokenService: TokenService;
  historyService: HistoryService;
  sendOperationService: SendOperationService;
  receiveOperationService: ReceiveOperationService;
  meltOperationService: MeltOperationService;
  mintOperationService: MintOperationService;
  quotes: QuoteApi;
  paymentRequestService: PaymentRequestService;
  paymentRequestReceiveService: PaymentRequestReceiveService;
  subscriptions: SubscriptionManager;
  eventBus: EventBus<CoreEvents>;
  logger: Logger;
}

/** Static review manifest. Internal method additions never enter a plugin facade automatically. */
export const PLUGIN_CAPABILITY_METHODS = Object.freeze({
  mintService: Object.freeze([
    'addMintByUrl',
    'updateMintData',
    'isTrustedMint',
    'refreshAndCommitIfStale',
    'ensureUpdatedMint',
    'deleteMint',
    'getMintInfo',
    'supportsNut',
    'supportsNut29MintQuoteCheck',
    'getNut29MintQuoteCheckLimit',
    'assertNutSupported',
    'checkPaymentMethodCapability',
    'getMintMethodUnitCapability',
    'listPaymentMethodCapabilities',
    'assertMethodUnitSupported',
    'getAllMints',
    'getAllTrustedMints',
    'trustMint',
    'untrustMint',
  ]),
  proofService: Object.freeze([
    'calculateSendAmountWithFees',
    'createOutputsAndIncrementCounters',
    'saveProofs',
    'getReadyProofs',
    'getAllReadyProofs',
    'getBalance',
    'getSpendableBalance',
    'getBalanceBreakdown',
    'getBalances',
    'getSpendableBalances',
    'getBalancesByMint',
    'getBalancesByMintAndUnit',
    'getBalanceTotal',
    'getBalancesByUnit',
    'getBalanceTotalByUnit',
    'getBalancesBreakdown',
    'getTrustedBalances',
    'getTrustedSpendableBalances',
    'getTrustedBalancesBreakdown',
    'setProofState',
    'reserveProofs',
    'releaseProofs',
    'restoreProofsToReady',
    'deleteProofs',
    'wipeProofsByKeysetId',
    'selectProofsToSend',
    'getProofsByKeysetId',
    'hasProofsForKeyset',
    'prepareProofsForReceiving',
    'createBlankOutputs',
  ]),
  keyRingService: Object.freeze([
    'generateNewKeyPair',
    'generateMintQuoteKeyPair',
    'addKeyPair',
    'removeKeyPair',
    'getKeyPair',
    'getMintQuoteKeyPair',
    'getLatestKeyPair',
    'getAllKeyPairs',
    'signProof',
  ]),
  walletRestoreService: Object.freeze(['sweepKeyset', 'restoreKeyset']),
  counterService: Object.freeze(['getCounter', 'incrementCounter', 'overwriteCounter']),
  tokenService: Object.freeze(['decodeToken']),
  historyService: Object.freeze([
    'getPaginatedHistory',
    'getHistoryEntryById',
    'getOperationIdFromHistoryEntry',
  ]),
  sendOperationService: Object.freeze([
    'init',
    'prepare',
    'execute',
    'send',
    'finalize',
    'rollback',
    'reclaim',
    'getOperation',
    'getPendingOperations',
    'getPreparedOperations',
  ]),
  receiveOperationService: Object.freeze([
    'prepareCallerOwned',
    'init',
    'prepare',
    'receive',
    'execute',
    'finalize',
    'rollback',
    'getOperation',
    'getPendingOperations',
    'getPreparedOperations',
  ]),
  meltOperationService: Object.freeze([
    'init',
    'prepareExistingQuote',
    'prepare',
    'execute',
    'finalize',
    'rollback',
    'getOperation',
    'getOperationByQuote',
    'getOperationByQuoteIdentity',
    'listOperationsByQuote',
    'getPendingOperations',
    'getPreparedOperations',
  ]),
  mintOperationService: Object.freeze([
    'prepare',
    'execute',
    'finalize',
    'getOperation',
    'getOperationByQuote',
    'getOperationsForQuote',
    'listOperationsByQuote',
    'claimMintQuote',
    'claimPendingMintQuotes',
    'getMintQuoteClaimability',
    'getInFlightOperations',
    'getPendingOperations',
    'observePendingOperation',
    'checkPendingOperation',
  ]),
  quotes: Object.freeze(['mint', 'melt']),
  paymentRequestService: Object.freeze(['parse', 'prepare', 'execute']),
  paymentRequestReceiveService: Object.freeze([
    'registerTransportHandler',
    'create',
    'cancel',
    'get',
    'list',
    'claimPayload',
    'ingestPayload',
  ]),
  subscriptions: Object.freeze(['subscribe', 'unsubscribe', 'pause', 'resume', 'getDiagnostics']),
  eventBus: Object.freeze(['on', 'once', 'off']),
  logger: Object.freeze(['error', 'warn', 'info', 'debug']),
} satisfies Readonly<Record<ServiceKey, readonly string[]>>);

export const PLUGIN_QUOTE_CAPABILITY_METHODS = Object.freeze({
  mint: Object.freeze(['create', 'get', 'import', 'listPending', 'refresh']),
  melt: Object.freeze(['create', 'get', 'listPending', 'refresh']),
});

/** Construct plugin-local capability factories around private implementation objects. */
export function createPluginCapabilityFactories(
  sources: PluginCapabilitySources,
  lifecycle: CapabilityLifecycleGate,
  privilegedObjects: readonly object[] = [],
): PluginCapabilityFactoryMap {
  const forbidden = new WeakSet<object>([
    ...nativeValues(sources),
    lifecycle as object,
    ...privilegedObjects,
  ]);
  const { asyncCall, syncCall } = createBoundaryCalls(forbidden, lifecycle);

  return freezeRecord({
    mintService: () =>
      freezeFacade({
        addMintByUrl: (...args: Parameters<MintService['addMintByUrl']>) =>
          asyncCall(() => sources.mintService.addMintByUrl(...args)),
        updateMintData: (...args: Parameters<MintService['updateMintData']>) =>
          asyncCall(() => sources.mintService.updateMintData(...args)),
        isTrustedMint: (...args: Parameters<MintService['isTrustedMint']>) =>
          asyncCall(() => sources.mintService.isTrustedMint(...args)),
        refreshAndCommitIfStale: (...args: Parameters<MintService['refreshAndCommitIfStale']>) =>
          asyncCall(() => sources.mintService.refreshAndCommitIfStale(...args)),
        ensureUpdatedMint: (...args: Parameters<MintService['ensureUpdatedMint']>) =>
          asyncCall(() => sources.mintService.ensureUpdatedMint(...args)),
        deleteMint: (...args: Parameters<MintService['deleteMint']>) =>
          asyncCall(() => sources.mintService.deleteMint(...args)),
        getMintInfo: (...args: Parameters<MintService['getMintInfo']>) =>
          asyncCall(() => sources.mintService.getMintInfo(...args)),
        supportsNut: (...args: Parameters<MintService['supportsNut']>) =>
          asyncCall(() => sources.mintService.supportsNut(...args)),
        supportsNut29MintQuoteCheck: (
          ...args: Parameters<MintService['supportsNut29MintQuoteCheck']>
        ) => asyncCall(() => sources.mintService.supportsNut29MintQuoteCheck(...args)),
        getNut29MintQuoteCheckLimit: (
          ...args: Parameters<MintService['getNut29MintQuoteCheckLimit']>
        ) => asyncCall(() => sources.mintService.getNut29MintQuoteCheckLimit(...args)),
        assertNutSupported: (...args: Parameters<MintService['assertNutSupported']>) =>
          asyncCall(() => sources.mintService.assertNutSupported(...args)),
        checkPaymentMethodCapability: (
          ...args: Parameters<MintService['checkPaymentMethodCapability']>
        ) => asyncCall(() => sources.mintService.checkPaymentMethodCapability(...args)),
        getMintMethodUnitCapability: (
          ...args: Parameters<MintService['getMintMethodUnitCapability']>
        ) => asyncCall(() => sources.mintService.getMintMethodUnitCapability(...args)),
        listPaymentMethodCapabilities: (
          ...args: Parameters<MintService['listPaymentMethodCapabilities']>
        ) => asyncCall(() => sources.mintService.listPaymentMethodCapabilities(...args)),
        assertMethodUnitSupported: (
          ...args: Parameters<MintService['assertMethodUnitSupported']>
        ) => asyncCall(() => sources.mintService.assertMethodUnitSupported(...args)),
        getAllMints: () => asyncCall(() => sources.mintService.getAllMints()),
        getAllTrustedMints: () => asyncCall(() => sources.mintService.getAllTrustedMints()),
        trustMint: (...args: Parameters<MintService['trustMint']>) =>
          asyncCall(() => sources.mintService.trustMint(...args)),
        untrustMint: (...args: Parameters<MintService['untrustMint']>) =>
          asyncCall(() => sources.mintService.untrustMint(...args)),
      }),
    proofService: () =>
      freezeFacade({
        calculateSendAmountWithFees: (
          ...args: Parameters<ProofService['calculateSendAmountWithFees']>
        ) => asyncCall(() => sources.proofService.calculateSendAmountWithFees(...args)),
        createOutputsAndIncrementCounters: (
          ...args: Parameters<ProofService['createOutputsAndIncrementCounters']>
        ) => asyncCall(() => sources.proofService.createOutputsAndIncrementCounters(...args)),
        saveProofs: (...args: Parameters<ProofService['saveProofs']>) =>
          asyncCall(() => sources.proofService.saveProofs(...args)),
        getReadyProofs: (...args: Parameters<ProofService['getReadyProofs']>) =>
          asyncCall(() => sources.proofService.getReadyProofs(...args)),
        getAllReadyProofs: (...args: Parameters<ProofService['getAllReadyProofs']>) =>
          asyncCall(() => sources.proofService.getAllReadyProofs(...args)),
        getBalance: (...args: Parameters<ProofService['getBalance']>) =>
          asyncCall(() => sources.proofService.getBalance(...args)),
        getSpendableBalance: (...args: Parameters<ProofService['getSpendableBalance']>) =>
          asyncCall(() => sources.proofService.getSpendableBalance(...args)),
        getBalanceBreakdown: (...args: Parameters<ProofService['getBalanceBreakdown']>) =>
          asyncCall(() => sources.proofService.getBalanceBreakdown(...args)),
        getBalances: () => asyncCall(() => sources.proofService.getBalances()),
        getSpendableBalances: () => asyncCall(() => sources.proofService.getSpendableBalances()),
        getBalancesByMint: (...args: Parameters<ProofService['getBalancesByMint']>) =>
          asyncCall(() => sources.proofService.getBalancesByMint(...args)),
        getBalancesByMintAndUnit: (...args: Parameters<ProofService['getBalancesByMintAndUnit']>) =>
          asyncCall(() => sources.proofService.getBalancesByMintAndUnit(...args)),
        getBalanceTotal: (...args: Parameters<ProofService['getBalanceTotal']>) =>
          asyncCall(() => sources.proofService.getBalanceTotal(...args)),
        getBalancesByUnit: (...args: Parameters<ProofService['getBalancesByUnit']>) =>
          asyncCall(() => sources.proofService.getBalancesByUnit(...args)),
        getBalanceTotalByUnit: (...args: Parameters<ProofService['getBalanceTotalByUnit']>) =>
          asyncCall(() => sources.proofService.getBalanceTotalByUnit(...args)),
        getBalancesBreakdown: () => asyncCall(() => sources.proofService.getBalancesBreakdown()),
        getTrustedBalances: () => asyncCall(() => sources.proofService.getTrustedBalances()),
        getTrustedSpendableBalances: () =>
          asyncCall(() => sources.proofService.getTrustedSpendableBalances()),
        getTrustedBalancesBreakdown: () =>
          asyncCall(() => sources.proofService.getTrustedBalancesBreakdown()),
        setProofState: (...args: Parameters<ProofService['setProofState']>) =>
          asyncCall(() => sources.proofService.setProofState(...args)),
        reserveProofs: (...args: Parameters<ProofService['reserveProofs']>) =>
          asyncCall(() => sources.proofService.reserveProofs(...args)),
        releaseProofs: (...args: Parameters<ProofService['releaseProofs']>) =>
          asyncCall(() => sources.proofService.releaseProofs(...args)),
        restoreProofsToReady: (...args: Parameters<ProofService['restoreProofsToReady']>) =>
          asyncCall(() => sources.proofService.restoreProofsToReady(...args)),
        deleteProofs: (...args: Parameters<ProofService['deleteProofs']>) =>
          asyncCall(() => sources.proofService.deleteProofs(...args)),
        wipeProofsByKeysetId: (...args: Parameters<ProofService['wipeProofsByKeysetId']>) =>
          asyncCall(() => sources.proofService.wipeProofsByKeysetId(...args)),
        selectProofsToSend: (...args: Parameters<ProofService['selectProofsToSend']>) =>
          asyncCall(() => sources.proofService.selectProofsToSend(...args)),
        getProofsByKeysetId: (...args: Parameters<ProofService['getProofsByKeysetId']>) =>
          asyncCall(() => sources.proofService.getProofsByKeysetId(...args)),
        hasProofsForKeyset: (...args: Parameters<ProofService['hasProofsForKeyset']>) =>
          asyncCall(() => sources.proofService.hasProofsForKeyset(...args)),
        prepareProofsForReceiving: (
          ...args: Parameters<ProofService['prepareProofsForReceiving']>
        ) => asyncCall(() => sources.proofService.prepareProofsForReceiving(...args)),
        createBlankOutputs: (...args: Parameters<ProofService['createBlankOutputs']>) =>
          asyncCall(() => sources.proofService.createBlankOutputs(...args)),
      }),
    keyRingService: () =>
      freezeFacade({
        generateNewKeyPair: (options?: { dumpSecretKey?: boolean }) =>
          asyncCall(() => sources.keyRingService.generateNewKeyPair(options as never)),
        generateMintQuoteKeyPair: () =>
          asyncCall(() => sources.keyRingService.generateMintQuoteKeyPair()),
        addKeyPair: (...args: Parameters<KeyRingService['addKeyPair']>) =>
          asyncCall(() => sources.keyRingService.addKeyPair(...args)),
        removeKeyPair: (...args: Parameters<KeyRingService['removeKeyPair']>) =>
          asyncCall(() => sources.keyRingService.removeKeyPair(...args)),
        getKeyPair: (...args: Parameters<KeyRingService['getKeyPair']>) =>
          asyncCall(() => sources.keyRingService.getKeyPair(...args)),
        getMintQuoteKeyPair: (...args: Parameters<KeyRingService['getMintQuoteKeyPair']>) =>
          asyncCall(() => sources.keyRingService.getMintQuoteKeyPair(...args)),
        getLatestKeyPair: () => asyncCall(() => sources.keyRingService.getLatestKeyPair()),
        getAllKeyPairs: () => asyncCall(() => sources.keyRingService.getAllKeyPairs()),
        signProof: (...args: Parameters<KeyRingService['signProof']>) =>
          asyncCall(() => sources.keyRingService.signProof(...args)),
      }),
    walletRestoreService: () =>
      freezeFacade({
        sweepKeyset: (...args: Parameters<WalletRestoreService['sweepKeyset']>) =>
          asyncCall(() => sources.walletRestoreService.sweepKeyset(...args)),
        restoreKeyset: (...args: Parameters<WalletRestoreService['restoreKeyset']>) =>
          asyncCall(() => sources.walletRestoreService.restoreKeyset(...args)),
      }),
    counterService: () =>
      freezeFacade({
        getCounter: (...args: Parameters<CounterService['getCounter']>) =>
          asyncCall(() => sources.counterService.getCounter(...args)),
        incrementCounter: (...args: Parameters<CounterService['incrementCounter']>) =>
          asyncCall(() => sources.counterService.incrementCounter(...args)),
        overwriteCounter: (...args: Parameters<CounterService['overwriteCounter']>) =>
          asyncCall(() => sources.counterService.overwriteCounter(...args)),
      }),
    tokenService: () =>
      freezeFacade({
        decodeToken: (...args: Parameters<TokenService['decodeToken']>) =>
          asyncCall(() => sources.tokenService.decodeToken(...args)),
      }),
    historyService: () =>
      freezeFacade({
        getPaginatedHistory: (...args: Parameters<HistoryService['getPaginatedHistory']>) =>
          asyncCall(() => sources.historyService.getPaginatedHistory(...args)),
        getHistoryEntryById: (...args: Parameters<HistoryService['getHistoryEntryById']>) =>
          asyncCall(() => sources.historyService.getHistoryEntryById(...args)),
        getOperationIdFromHistoryEntry: (
          ...args: Parameters<HistoryService['getOperationIdFromHistoryEntry']>
        ) => asyncCall(() => sources.historyService.getOperationIdFromHistoryEntry(...args)),
      }),
    sendOperationService: () =>
      freezeFacade({
        init: (...args: Parameters<SendOperationService['init']>) =>
          asyncCall(() => sources.sendOperationService.init(...args)),
        prepare: (...args: Parameters<SendOperationService['prepare']>) =>
          asyncCall(() => sources.sendOperationService.prepare(...args)),
        execute: (...args: Parameters<SendOperationService['execute']>) =>
          asyncCall(() => sources.sendOperationService.execute(...args)),
        send: (...args: Parameters<SendOperationService['send']>) =>
          asyncCall(() => sources.sendOperationService.send(...args)),
        finalize: (...args: Parameters<SendOperationService['finalize']>) =>
          asyncCall(() => sources.sendOperationService.finalize(...args)),
        rollback: (...args: Parameters<SendOperationService['rollback']>) =>
          asyncCall(() => sources.sendOperationService.rollback(...args)),
        reclaim: (...args: Parameters<SendOperationService['reclaim']>) =>
          asyncCall(() => sources.sendOperationService.reclaim(...args)),
        getOperation: (...args: Parameters<SendOperationService['getOperation']>) =>
          asyncCall(() => sources.sendOperationService.getOperation(...args)),
        getPendingOperations: () =>
          asyncCall(() => sources.sendOperationService.getPendingOperations()),
        getPreparedOperations: () =>
          asyncCall(() => sources.sendOperationService.getPreparedOperations()),
      }),
    receiveOperationService: () =>
      freezeFacade({
        prepareCallerOwned: (...args: Parameters<ReceiveOperationService['prepareCallerOwned']>) =>
          asyncCall(() => sources.receiveOperationService.prepareCallerOwned(...args)),
        init: (...args: Parameters<ReceiveOperationService['init']>) =>
          asyncCall(() => sources.receiveOperationService.init(...args)),
        prepare: (...args: Parameters<ReceiveOperationService['prepare']>) =>
          asyncCall(() => sources.receiveOperationService.prepare(...args)),
        receive: (...args: Parameters<ReceiveOperationService['receive']>) =>
          asyncCall(() => sources.receiveOperationService.receive(...args)),
        execute: (...args: Parameters<ReceiveOperationService['execute']>) =>
          asyncCall(() => sources.receiveOperationService.execute(...args)),
        finalize: (...args: Parameters<ReceiveOperationService['finalize']>) =>
          asyncCall(() => sources.receiveOperationService.finalize(...args)),
        rollback: (...args: Parameters<ReceiveOperationService['rollback']>) =>
          asyncCall(() => sources.receiveOperationService.rollback(...args)),
        getOperation: (...args: Parameters<ReceiveOperationService['getOperation']>) =>
          asyncCall(() => sources.receiveOperationService.getOperation(...args)),
        getPendingOperations: () =>
          asyncCall(() => sources.receiveOperationService.getPendingOperations()),
        getPreparedOperations: () =>
          asyncCall(() => sources.receiveOperationService.getPreparedOperations()),
      }),
    meltOperationService: () =>
      freezeFacade({
        init: (...args: Parameters<MeltOperationService['init']>) =>
          asyncCall(() => sources.meltOperationService.init(...args)),
        prepareExistingQuote: (...args: Parameters<MeltOperationService['prepareExistingQuote']>) =>
          asyncCall(() => sources.meltOperationService.prepareExistingQuote(...args)),
        prepare: (...args: Parameters<MeltOperationService['prepare']>) =>
          asyncCall(() => sources.meltOperationService.prepare(...args)),
        execute: (...args: Parameters<MeltOperationService['execute']>) =>
          asyncCall(() => sources.meltOperationService.execute(...args)),
        finalize: (...args: Parameters<MeltOperationService['finalize']>) =>
          asyncCall(() => sources.meltOperationService.finalize(...args)),
        rollback: (...args: Parameters<MeltOperationService['rollback']>) =>
          asyncCall(() => sources.meltOperationService.rollback(...args)),
        getOperation: (...args: Parameters<MeltOperationService['getOperation']>) =>
          asyncCall(() => sources.meltOperationService.getOperation(...args)),
        getOperationByQuote: (...args: Parameters<MeltOperationService['getOperationByQuote']>) =>
          asyncCall(() => sources.meltOperationService.getOperationByQuote(...args)),
        getOperationByQuoteIdentity: (
          ...args: Parameters<MeltOperationService['getOperationByQuoteIdentity']>
        ) => asyncCall(() => sources.meltOperationService.getOperationByQuoteIdentity(...args)),
        listOperationsByQuote: (
          ...args: Parameters<MeltOperationService['listOperationsByQuote']>
        ) => asyncCall(() => sources.meltOperationService.listOperationsByQuote(...args)),
        getPendingOperations: () =>
          asyncCall(() => sources.meltOperationService.getPendingOperations()),
        getPreparedOperations: () =>
          asyncCall(() => sources.meltOperationService.getPreparedOperations()),
      }),
    mintOperationService: () =>
      freezeFacade({
        prepare: (...args: Parameters<MintOperationService['prepare']>) =>
          asyncCall(() => sources.mintOperationService.prepare(...args)),
        execute: (...args: Parameters<MintOperationService['execute']>) =>
          asyncCall(() => sources.mintOperationService.execute(...args)),
        finalize: (...args: Parameters<MintOperationService['finalize']>) =>
          asyncCall(() => sources.mintOperationService.finalize(...args)),
        getOperation: (...args: Parameters<MintOperationService['getOperation']>) =>
          asyncCall(() => sources.mintOperationService.getOperation(...args)),
        getOperationByQuote: (...args: Parameters<MintOperationService['getOperationByQuote']>) =>
          asyncCall(() => sources.mintOperationService.getOperationByQuote(...args)),
        getOperationsForQuote: (
          ...args: Parameters<MintOperationService['getOperationsForQuote']>
        ) => asyncCall(() => sources.mintOperationService.getOperationsForQuote(...args)),
        listOperationsByQuote: (
          ...args: Parameters<MintOperationService['listOperationsByQuote']>
        ) => asyncCall(() => sources.mintOperationService.listOperationsByQuote(...args)),
        claimMintQuote: (...args: Parameters<MintOperationService['claimMintQuote']>) =>
          asyncCall(() => sources.mintOperationService.claimMintQuote(...args)),
        claimPendingMintQuotes: (
          ...args: Parameters<MintOperationService['claimPendingMintQuotes']>
        ) => asyncCall(() => sources.mintOperationService.claimPendingMintQuotes(...args)),
        getMintQuoteClaimability: (
          ...args: Parameters<MintOperationService['getMintQuoteClaimability']>
        ) => asyncCall(() => sources.mintOperationService.getMintQuoteClaimability(...args)),
        getInFlightOperations: () =>
          asyncCall(() => sources.mintOperationService.getInFlightOperations()),
        getPendingOperations: () =>
          asyncCall(() => sources.mintOperationService.getPendingOperations()),
        observePendingOperation: (
          ...args: Parameters<MintOperationService['observePendingOperation']>
        ) => asyncCall(() => sources.mintOperationService.observePendingOperation(...args)),
        checkPendingOperation: (
          ...args: Parameters<MintOperationService['checkPendingOperation']>
        ) => asyncCall(() => sources.mintOperationService.checkPendingOperation(...args)),
      }),
    quotes: () => createQuoteCapability(sources.quotes, asyncCall),
    paymentRequestService: () =>
      freezeFacade({
        parse: (...args: Parameters<PaymentRequestService['parse']>) =>
          asyncCall(() => sources.paymentRequestService.parse(...args)),
        prepare: (...args: Parameters<PaymentRequestService['prepare']>) =>
          asyncCall(() => sources.paymentRequestService.prepare(...args)),
        execute: (...args: Parameters<PaymentRequestService['execute']>) =>
          asyncCall(() => sources.paymentRequestService.execute(...args)),
      }),
    paymentRequestReceiveService: () =>
      createPaymentRequestReceiveCapability(
        sources.paymentRequestReceiveService,
        forbidden,
        asyncCall,
        lifecycle,
      ),
    subscriptions: () =>
      createSubscriptionCapability(
        sources.subscriptions,
        forbidden,
        asyncCall,
        syncCall,
        lifecycle,
      ),
    eventBus: () => createEventCapability(sources.eventBus, forbidden, lifecycle),
    logger: () =>
      freezeFacade({
        error: (message: string, ...meta: unknown[]) =>
          syncCall(() => sources.logger.error(message, ...meta)),
        warn: (message: string, ...meta: unknown[]) =>
          syncCall(() => sources.logger.warn(message, ...meta)),
        info: (message: string, ...meta: unknown[]) =>
          syncCall(() => sources.logger.info(message, ...meta)),
        debug: (message: string, ...meta: unknown[]) =>
          syncCall(() => sources.logger.debug(message, ...meta)),
      }),
  }) as PluginCapabilityFactoryMap;
}

interface BoundaryCalls {
  asyncCall<T>(work: () => T | PromiseLike<T>): Promise<T>;
  syncCall<T>(work: () => T): T;
}

function createBoundaryCalls(
  forbidden: WeakSet<object>,
  lifecycle: CapabilityLifecycleGate,
): BoundaryCalls {
  return {
    asyncCall<T>(work: () => T | PromiseLike<T>): Promise<T> {
      let complete: (() => void) | undefined;
      let result: T | PromiseLike<T>;
      try {
        complete = lifecycle.beginOperation();
        result = work();
      } catch (error) {
        complete?.();
        return rejectSafely(sanitizePluginError(error));
      }
      let pending: Promise<T>;
      try {
        pending = resolveSafely(result);
      } catch (error) {
        complete();
        return rejectSafely(sanitizePluginError(error));
      }
      return thenSafely(
        pending,
        (value) => {
          try {
            lifecycle.assertActive();
            return sanitizePluginValue(value, forbidden, lifecycle) as T;
          } catch (error) {
            throw sanitizePluginError(error);
          } finally {
            complete?.();
          }
        },
        (error) => {
          complete?.();
          throw sanitizePluginError(error);
        },
      );
    },
    syncCall<T>(work: () => T): T {
      let complete: (() => void) | undefined;
      try {
        complete = lifecycle.beginOperation();
        const value = work();
        lifecycle.assertActive();
        return sanitizePluginValue(value, forbidden, lifecycle) as T;
      } catch (error) {
        throw sanitizePluginError(error);
      } finally {
        complete?.();
      }
    },
  };
}

/** @internal Lifecycle-aware public Manager facade; the backing manager remains private. */
export function createLifecycleSubscriptionFacade(
  subscriptions: SubscriptionManager,
  lifecycle: CapabilityLifecycleGate,
  privilegedObjects: readonly object[] = [],
): PluginSubscriptionCapability {
  const forbidden = new WeakSet<object>([subscriptions, lifecycle as object, ...privilegedObjects]);
  const { asyncCall, syncCall } = createBoundaryCalls(forbidden, lifecycle);
  return createSubscriptionCapability(subscriptions, forbidden, asyncCall, syncCall, lifecycle);
}

function createQuoteCapability(
  quotes: QuoteApi,
  asyncCall: <T>(work: () => T | PromiseLike<T>) => Promise<T>,
): PluginQuoteCapability {
  const mint = freezeFacade({
    create: (...args: Parameters<QuoteApi['mint']['create']>) =>
      asyncCall(() => quotes.mint.create(...args)),
    get: (...args: Parameters<QuoteApi['mint']['get']>) =>
      asyncCall(() => quotes.mint.get(...args)),
    import: (...args: Parameters<QuoteApi['mint']['import']>) =>
      asyncCall(() => quotes.mint.import(...args)),
    listPending: (...args: Parameters<QuoteApi['mint']['listPending']>) =>
      asyncCall(() => quotes.mint.listPending(...args)),
    refresh: (...args: Parameters<QuoteApi['mint']['refresh']>) =>
      asyncCall(() => quotes.mint.refresh(...args)),
  });
  const melt = freezeFacade({
    create: (...args: Parameters<QuoteApi['melt']['create']>) =>
      asyncCall(() => quotes.melt.create(...args)),
    get: (...args: Parameters<QuoteApi['melt']['get']>) =>
      asyncCall(() => quotes.melt.get(...args)),
    listPending: (...args: Parameters<QuoteApi['melt']['listPending']>) =>
      asyncCall(() => quotes.melt.listPending(...args)),
    refresh: (...args: Parameters<QuoteApi['melt']['refresh']>) =>
      asyncCall(() => quotes.melt.refresh(...args)),
  });
  return freezeRecord({ mint, melt }) as unknown as PluginQuoteCapability;
}

function createPaymentRequestReceiveCapability(
  service: PaymentRequestReceiveService,
  forbidden: WeakSet<object>,
  asyncCall: <T>(work: () => T | PromiseLike<T>) => Promise<T>,
  lifecycle: CapabilityLifecycleGate,
): PluginPaymentRequestReceiveCapability {
  return freezeFacade({
    registerTransportHandler: (handler: PaymentRequestReceiveTransportHandler) => {
      let complete: (() => void) | undefined;
      try {
        complete = lifecycle.beginOperation();
        const safeHandler: PaymentRequestReceiveTransportHandler = {
          type: handler.type,
          ...(handler.createRequestTransport
            ? {
                createRequestTransport: (input) =>
                  asyncCall(() =>
                    resolveSafely(
                      handler.createRequestTransport!(
                        sanitizePluginValue(input, forbidden, lifecycle) as never,
                      ),
                    ),
                  ) as never,
              }
            : {}),
          activate: (operation) =>
            asyncCall(() =>
              resolveSafely(
                handler.activate(sanitizePluginValue(operation, forbidden, lifecycle) as never),
              ),
            ),
          deactivate: (operation) => {
            if (!lifecycle.isActive()) return;
            return asyncCall(() =>
              resolveSafely(
                handler.deactivate(sanitizePluginValue(operation, forbidden, lifecycle) as never),
              ),
            );
          },
        };
        const unregister = service.registerTransportHandler(safeHandler);
        lifecycle.assertActive();
        return hardenFunction(() => {
          if (!lifecycle.isActive()) return;
          try {
            unregister();
          } catch (error) {
            throw sanitizePluginError(error);
          }
        });
      } catch (error) {
        throw sanitizePluginError(error);
      } finally {
        complete?.();
      }
    },
    create: (...args: Parameters<PaymentRequestReceiveService['create']>) =>
      asyncCall(() => service.create(...args)),
    cancel: (...args: Parameters<PaymentRequestReceiveService['cancel']>) =>
      asyncCall(() => service.cancel(...args)),
    get: (...args: Parameters<PaymentRequestReceiveService['get']>) =>
      asyncCall(() => service.get(...args)),
    list: (...args: Parameters<PaymentRequestReceiveService['list']>) =>
      asyncCall(() => service.list(...args)),
    claimPayload: (...args: Parameters<PaymentRequestReceiveService['claimPayload']>) =>
      asyncCall(() => service.claimPayload(...args)),
    ingestPayload: (...args: Parameters<PaymentRequestReceiveService['ingestPayload']>) =>
      asyncCall(() => service.ingestPayload(...args)),
  });
}

function createSubscriptionCapability(
  subscriptions: SubscriptionManager,
  forbidden: WeakSet<object>,
  asyncCall: <T>(work: () => T | PromiseLike<T>) => Promise<T>,
  syncCall: <T>(work: () => T) => T,
  lifecycle: CapabilityLifecycleGate,
): PluginSubscriptionCapability {
  return freezeFacade({
    subscribe: async <TPayload = unknown>(
      mintUrl: string,
      kind: Parameters<SubscriptionManager['subscribe']>[1],
      filters: string[],
      callback?: SubscriptionCallback<TPayload>,
    ) => {
      const wrapped = callback
        ? hardenFunction((payload: TPayload) =>
            asyncCall(() =>
              resolveSafely(
                callback(sanitizePluginValue(payload, forbidden, lifecycle) as TPayload),
              ),
            ),
          )
        : undefined;
      let complete: (() => void) | undefined;
      let subscription: Awaited<ReturnType<SubscriptionManager['subscribe']>> | undefined;
      try {
        complete = lifecycle.beginOperation();
        subscription = await subscriptions.subscribe(mintUrl, kind, [...filters], wrapped);
        lifecycle.assertActive();
      } catch (error) {
        try {
          await subscription?.unsubscribe();
        } catch {
          // Best-effort rollback of a subscription that raced lifecycle revocation.
        }
        throw sanitizePluginError(error);
      } finally {
        complete?.();
      }
      if (!subscription) {
        throw new Error('Subscription manager did not return a subscription');
      }
      return freezeRecord({
        subId: subscription.subId,
        unsubscribe: hardenFunction(() => {
          if (!lifecycle.isActive()) return resolveSafely(undefined);
          return asyncCall(() => subscription.unsubscribe());
        }),
      });
    },
    unsubscribe: (...args: Parameters<SubscriptionManager['unsubscribe']>) => {
      if (!lifecycle.isActive()) return resolveSafely(undefined);
      return asyncCall(() => subscriptions.unsubscribe(...args));
    },
    pause: () => syncCall(() => subscriptions.pause()),
    resume: () => syncCall(() => subscriptions.resume()),
    getDiagnostics: () =>
      lifecycle.isActive()
        ? syncCall(() => subscriptions.getDiagnostics())
        : createInactiveSubscriptionDiagnostics(),
  }) as unknown as PluginSubscriptionCapability;
}

function createInactiveSubscriptionDiagnostics(): ReturnType<
  SubscriptionManager['getDiagnostics']
> {
  return freezeRecord({
    subscriptions: Object.freeze([]),
    activeMintCount: 0,
    transportCount: 0,
    paused: true,
  });
}

function createEventCapability(
  eventBus: EventBus<CoreEvents>,
  forbidden: WeakSet<object>,
  lifecycle: CapabilityLifecycleGate,
): PluginEventCapability {
  const wrappers = new Map<keyof CoreEvents, WeakMap<object, EventHandler<never>>>();
  const wrap = <E extends keyof CoreEvents>(
    event: E,
    handler: PluginEventHandler<CoreEvents[E]>,
  ): EventHandler<CoreEvents[E]> => {
    let byHandler = wrappers.get(event);
    if (!byHandler) {
      byHandler = new WeakMap();
      wrappers.set(event, byHandler);
    }
    const existing = byHandler.get(handler as object);
    if (existing) return existing as EventHandler<CoreEvents[E]>;
    const wrapped = hardenFunction((payload: CoreEvents[E]) => {
      if (!lifecycle.isActive()) return;
      let complete: (() => void) | undefined;
      try {
        complete = lifecycle.beginOperation();
        const result = handler(sanitizePluginValue(payload, forbidden, lifecycle) as CoreEvents[E]);
        const pending = resolveSafely(result);
        // EventBus delivery must not be held hostage by plugin thenables. Accounting remains active
        // until settlement, while a terminal rejection handler prevents unhandled-rejection noise.
        void thenSafely(
          pending,
          () => {
            complete?.();
          },
          () => {
            complete?.();
          },
        );
        return;
      } catch (error) {
        complete?.();
        throw sanitizePluginError(error);
      }
    });
    byHandler.set(handler as object, wrapped as EventHandler<never>);
    return wrapped;
  };
  const remove = <E extends keyof CoreEvents>(
    event: E,
    handler: PluginEventHandler<CoreEvents[E]>,
  ) => wrappers.get(event)?.get(handler as object) as EventHandler<CoreEvents[E]> | undefined;

  return freezeFacade({
    on: <E extends keyof CoreEvents>(event: E, handler: PluginEventHandler<CoreEvents[E]>) => {
      let complete: (() => void) | undefined;
      try {
        complete = lifecycle.beginOperation();
        const wrapped = wrap(event, handler);
        const unsubscribe = eventBus.on(event, wrapped);
        lifecycle.assertActive();
        return hardenFunction(() => {
          if (!lifecycle.isActive()) return;
          try {
            return unsubscribe();
          } catch (error) {
            throw sanitizePluginError(error);
          }
        });
      } catch (error) {
        throw sanitizePluginError(error);
      } finally {
        complete?.();
      }
    },
    once: <E extends keyof CoreEvents>(event: E, handler: PluginEventHandler<CoreEvents[E]>) => {
      let complete: (() => void) | undefined;
      try {
        complete = lifecycle.beginOperation();
        const wrapped = wrap(event, handler);
        const unsubscribe = eventBus.once(event, wrapped);
        lifecycle.assertActive();
        return hardenFunction(() => {
          if (!lifecycle.isActive()) return;
          try {
            return unsubscribe();
          } catch (error) {
            throw sanitizePluginError(error);
          }
        });
      } catch (error) {
        throw sanitizePluginError(error);
      } finally {
        complete?.();
      }
    },
    off: <E extends keyof CoreEvents>(event: E, handler: PluginEventHandler<CoreEvents[E]>) => {
      if (!lifecycle.isActive()) return;
      const wrapped = remove(event, handler);
      if (!wrapped) return;
      let complete: (() => void) | undefined;
      try {
        complete = lifecycle.beginOperation();
        eventBus.off(event, wrapped);
      } catch (error) {
        throw sanitizePluginError(error);
      } finally {
        complete?.();
      }
    },
  }) as unknown as PluginEventCapability;
}

function freezeFacade<T extends CapabilityRecord>(entries: T): T {
  const facade = nativeCreate(null) as T;
  for (const [key, value] of nativeEntries(entries)) {
    nativeDefineProperty(facade, key, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: typeof value === 'function' ? hardenFunction(value as CapabilityFunction) : value,
    });
  }
  return nativeFreeze(facade);
}

export function freezeRecord<T extends object>(entries: T): Readonly<T> {
  const record = nativeCreate(null) as T;
  for (const key of nativeKeys(entries) as Array<keyof T>) {
    nativeDefineProperty(record, key, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: entries[key],
    });
  }
  return nativeFreeze(record);
}

export function hardenFunction<T extends (...args: never[]) => unknown>(fn: T): T {
  nativeSetPrototypeOf(fn, null);
  return nativeFreeze(fn);
}

function sanitizePluginError(error: unknown): Error {
  let message = 'Plugin capability failed';
  let name = 'Error';
  if (typeof error === 'object' && error !== null) {
    const messageDescriptor = nativeGetOwnPropertyDescriptor(error, 'message');
    const nameDescriptor = nativeGetOwnPropertyDescriptor(error, 'name');
    if (
      messageDescriptor &&
      'value' in messageDescriptor &&
      typeof messageDescriptor.value === 'string'
    ) {
      message = messageDescriptor.value;
    }
    if (nameDescriptor && 'value' in nameDescriptor && typeof nameDescriptor.value === 'string') {
      name = nameDescriptor.value;
    }
  } else if (
    typeof error === 'string' ||
    typeof error === 'number' ||
    typeof error === 'boolean' ||
    typeof error === 'bigint'
  ) {
    message = `${error}`;
  }
  const safe = new NativeError(message);
  nativeDefineProperty(safe, 'name', {
    configurable: false,
    enumerable: false,
    writable: false,
    value: name,
  });
  return nativeFreeze(safe);
}

function sanitizePluginValue(
  value: unknown,
  forbidden: WeakSet<object>,
  lifecycle: CapabilityLifecycleGate,
  seen = new WeakMap<object, unknown>(),
): unknown {
  if (
    value === null ||
    value === undefined ||
    typeof value === 'string' ||
    typeof value === 'number' ||
    typeof value === 'boolean' ||
    typeof value === 'bigint'
  ) {
    return value;
  }
  if (typeof value === 'symbol' || typeof value === 'function') {
    throw new TypeError('Plugin capability returned an unsupported value');
  }
  if (weakSetHas(forbidden, value))
    throw new TypeError('Plugin capability attempted to return privileged state');
  const prototype = nativeGetPrototypeOf(value);
  if (prototype === walletPrototype)
    throw new TypeError('Plugin capability must not return a Cashu Wallet');
  if (prototype === paymentRequestPrototype) {
    return sanitizePaymentRequest(value as PaymentRequest, forbidden, lifecycle, seen);
  }
  if (isOutputDataLike(value)) {
    const existing = weakMapGet(seen, value);
    if (existing) return existing;
    const source = detachOutputData(value);
    const safe = nativeCreate(null) as Record<string, unknown>;
    weakMapSet(seen, value, safe);
    const fields = ['blindedMessage', 'blindingFactor', 'secret', 'ephemeralE'] as const;
    for (let index = 0; index < fields.length; index += 1) {
      const key = fields[index]!;
      const field = readOwnDataProperty(source, key, false);
      if (field === undefined && key === 'ephemeralE') continue;
      nativeDefineProperty(safe, key, {
        configurable: false,
        enumerable: true,
        writable: false,
        value: sanitizePluginValue(field, forbidden, lifecycle, seen),
      });
    }
    nativeDefineProperty(safe, 'toProof', {
      configurable: false,
      enumerable: true,
      writable: false,
      value: hardenFunction((...args: Parameters<OutputDataLike['toProof']>) => {
        const complete = lifecycle.beginOperation();
        try {
          const proof = applyIntrinsic<ReturnType<OutputDataLike['toProof']>>(
            nativeOutputDataToProof,
            source,
            args,
          );
          lifecycle.assertActive();
          return sanitizePluginValue(proof, forbidden, lifecycle);
        } catch (error) {
          throw sanitizePluginError(error);
        } finally {
          complete();
        }
      }),
    });
    return nativeFreeze(safe);
  }
  if (nativeArrayBufferIsView(value)) {
    return detachArrayBufferView(value, prototype);
  }
  if (prototype === arrayBufferPrototype) {
    return applyIntrinsic<ArrayBuffer>(nativeArrayBufferSlice, value, [0]);
  }
  if (prototype === amountPrototype) {
    return nativeFreeze(createAmountFromBigInt(readAmountBigInt(value)));
  }
  if (prototype === datePrototype) {
    const timestamp = applyIntrinsic<number>(nativeDateGetTime, value, []);
    return nativeFreeze(new NativeDate(timestamp));
  }
  if (NativeResponse && nativeResponseClone && prototype === responsePrototype) {
    return nativeFreeze(applyIntrinsic<Response>(nativeResponseClone, value, []));
  }

  const existing = weakMapGet(seen, value);
  if (existing) return existing;
  if (nativeArrayIsArray(value)) {
    return sanitizeArray(value, forbidden, lifecycle, seen);
  }
  for (let index = 0; index < mutableCollectionPrototypes.length; index += 1) {
    if (prototype === mutableCollectionPrototypes[index]) {
      throw new TypeError('Plugin capability returned a mutable collection');
    }
  }
  for (let index = 0; index < errorPrototypes.length; index += 1) {
    if (prototype === errorPrototypes[index]) return sanitizePluginError(value);
  }

  if (prototype === objectPrototype || prototype === null) {
    const result = nativeCreate(null) as Record<string, unknown>;
    weakMapSet(seen, value, result);
    const keys = nativeOwnKeys(value);
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index]!;
      if (typeof key !== 'string') throw new TypeError('Plugin capability returned a symbol field');
      const descriptor = nativeGetOwnPropertyDescriptor(value, key);
      if (!descriptor || !('value' in descriptor)) {
        throw new TypeError('Plugin capability returned an accessor field');
      }
      nativeDefineProperty(result, key, {
        configurable: false,
        enumerable: descriptor.enumerable,
        writable: false,
        value: sanitizePluginValue(descriptor.value, forbidden, lifecycle, seen),
      });
    }
    return nativeFreeze(result);
  }

  throw new TypeError('Plugin capability returned an unsupported class instance');
}

function sanitizeArray(
  source: unknown[],
  forbidden: WeakSet<object>,
  lifecycle: CapabilityLifecycleGate,
  seen: WeakMap<object, unknown>,
): readonly unknown[] {
  const lengthDescriptor = nativeGetOwnPropertyDescriptor(source, 'length');
  const length = lengthDescriptor && 'value' in lengthDescriptor ? lengthDescriptor.value : -1;
  if (!nativeNumberIsSafeInteger(length) || length < 0) {
    throw new TypeError('Plugin capability returned an invalid array');
  }
  const keys = nativeOwnKeys(source);
  for (let index = 0; index < keys.length; index += 1) {
    const key = keys[index]!;
    if (typeof key !== 'string') throw new TypeError('Plugin capability returned a symbol field');
    if (key === 'length') continue;
    const numeric = NativeNumber(key);
    if (
      !nativeNumberIsSafeInteger(numeric) ||
      numeric < 0 ||
      numeric >= length ||
      `${numeric}` !== key
    ) {
      throw new TypeError('Plugin capability returned an array with unsupported properties');
    }
  }
  const result = new NativeArray(length) as unknown[];
  weakMapSet(seen, source, result);
  for (let index = 0; index < length; index += 1) {
    const descriptor = nativeGetOwnPropertyDescriptor(source, `${index}`);
    if (!descriptor) continue;
    if (!('value' in descriptor)) {
      throw new TypeError('Plugin capability returned an accessor field');
    }
    nativeDefineProperty(result, `${index}`, {
      configurable: false,
      enumerable: descriptor.enumerable,
      writable: false,
      value: sanitizePluginValue(descriptor.value, forbidden, lifecycle, seen),
    });
  }
  return nativeFreeze(result);
}

function detachArrayBufferView(value: ArrayBufferView, prototype: object | null): ArrayBufferView {
  let buffer: ArrayBufferLike;
  let byteOffset: number;
  let byteLength: number;
  let constructorIndex = -1;
  if (prototype === dataViewPrototype) {
    if (!dataViewBufferGetter || !dataViewByteOffsetGetter || !dataViewByteLengthGetter) {
      throw new TypeError('DataView intrinsics are unavailable');
    }
    buffer = applyIntrinsic<ArrayBufferLike>(dataViewBufferGetter, value, []);
    byteOffset = applyIntrinsic<number>(dataViewByteOffsetGetter, value, []);
    byteLength = applyIntrinsic<number>(dataViewByteLengthGetter, value, []);
  } else {
    for (let index = 0; index < typedArrayPrototypes.length; index += 1) {
      if (prototype === typedArrayPrototypes[index]) {
        constructorIndex = index;
        break;
      }
    }
    if (
      constructorIndex < 0 ||
      !typedArrayBufferGetter ||
      !typedArrayByteOffsetGetter ||
      !typedArrayByteLengthGetter
    ) {
      throw new TypeError('Plugin capability returned an unsupported ArrayBuffer view');
    }
    buffer = applyIntrinsic<ArrayBufferLike>(typedArrayBufferGetter, value, []);
    byteOffset = applyIntrinsic<number>(typedArrayByteOffsetGetter, value, []);
    byteLength = applyIntrinsic<number>(typedArrayByteLengthGetter, value, []);
  }
  if (nativeGetPrototypeOf(buffer) !== arrayBufferPrototype) {
    throw new TypeError('Plugin capability returned an unsupported ArrayBuffer backing store');
  }
  const copy = applyIntrinsic<ArrayBuffer>(nativeArrayBufferSlice, buffer, [
    byteOffset,
    byteOffset + byteLength,
  ]);
  if (constructorIndex < 0) return new NativeDataView(copy);
  const Ctor = typedArrayConstructors[constructorIndex]!;
  return new Ctor(copy);
}

function readAmountBigInt(source: object): bigint {
  const value = readOwnDataProperty(source, 'value');
  if (typeof value !== 'bigint' || value < 0n) {
    throw new TypeError('Plugin capability returned an invalid Amount');
  }
  return value;
}

function createAmountFromBigInt(value: bigint): Amount {
  if (value < 0n) throw new TypeError('Plugin capability returned an invalid Amount');
  const detached = nativeCreate(amountPrototype) as Amount;
  nativeDefineProperty(detached, 'value', {
    configurable: false,
    enumerable: true,
    writable: false,
    value,
  });
  return nativeFreeze(detached) as Amount;
}

function detachAmountLike(value: unknown): Amount {
  if (
    typeof value === 'object' &&
    value !== null &&
    nativeGetPrototypeOf(value) === amountPrototype
  ) {
    return createAmountFromBigInt(readAmountBigInt(value));
  }
  if (typeof value !== 'bigint' && typeof value !== 'number' && typeof value !== 'string') {
    throw new TypeError('Plugin capability returned invalid OutputData amount');
  }
  let normalized: bigint;
  if (typeof value === 'bigint') {
    normalized = value;
  } else if (typeof value === 'number') {
    if (!nativeNumberIsSafeInteger(value) || value < 0) {
      throw new TypeError('Plugin capability returned invalid OutputData amount');
    }
    normalized = NativeBigInt(value);
  } else {
    try {
      normalized = NativeBigInt(value);
    } catch {
      throw new TypeError('Plugin capability returned invalid OutputData amount');
    }
    if (`${normalized}` !== value) {
      throw new TypeError('Plugin capability returned invalid OutputData amount');
    }
  }
  return createAmountFromBigInt(normalized);
}

function detachOutputData(source: OutputDataLike): OutputData {
  const blindedMessage = readOwnDataProperty(source, 'blindedMessage');
  if (typeof blindedMessage !== 'object' || blindedMessage === null) {
    throw new TypeError('Plugin capability returned invalid OutputData');
  }
  const amount = readOwnDataProperty(blindedMessage, 'amount');
  const id = readOwnDataProperty(blindedMessage, 'id');
  const blindedPoint = readOwnDataProperty(blindedMessage, 'B_');
  const blindingFactor = readOwnDataProperty(source, 'blindingFactor');
  const secret = readOwnDataProperty(source, 'secret');
  const ephemeralE = readOwnDataProperty(source, 'ephemeralE', false);
  if (
    typeof id !== 'string' ||
    typeof blindedPoint !== 'string' ||
    typeof blindingFactor !== 'bigint' ||
    typeof secret !== 'object' ||
    secret === null ||
    nativeGetPrototypeOf(secret) !== uint8ArrayPrototype ||
    (ephemeralE !== undefined && typeof ephemeralE !== 'string')
  ) {
    throw new TypeError('Plugin capability returned invalid OutputData');
  }
  const detachedAmount = detachAmountLike(amount);
  const detachedSecret = detachArrayBufferView(secret as Uint8Array, uint8ArrayPrototype);
  const detached = nativeCreate(outputDataPrototype) as OutputData;
  const fields: ReadonlyArray<readonly [string, unknown]> = [
    ['blindedMessage', nativeFreeze({ amount: detachedAmount, id, B_: blindedPoint })],
    ['blindingFactor', blindingFactor],
    ['secret', detachedSecret],
    ['ephemeralE', ephemeralE],
  ];
  for (let index = 0; index < fields.length; index += 1) {
    const [key, field] = fields[index]!;
    nativeDefineProperty(detached, key, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: field,
    });
  }
  return nativeFreeze(detached);
}

function readOwnDataProperty(source: object, key: PropertyKey, required = true): unknown {
  const descriptor = nativeGetOwnPropertyDescriptor(source, key);
  if (!descriptor) {
    if (!required) return undefined;
    throw new TypeError(`Plugin capability returned a value missing ${String(key)}`);
  }
  if (!('value' in descriptor)) {
    throw new TypeError('Plugin capability returned an accessor field');
  }
  return descriptor.value;
}

function sanitizePaymentRequest(
  source: PaymentRequest,
  forbidden: WeakSet<object>,
  lifecycle: CapabilityLifecycleGate,
  seen: WeakMap<object, unknown>,
): PaymentRequest {
  const existing = weakMapGet(seen, source);
  if (existing) return existing as PaymentRequest;

  const detached = nativeCreate(paymentRequestPrototype) as PaymentRequest;
  weakMapSet(seen, source, detached);
  const transportValue = readOwnDataProperty(source, 'transport', false);
  const id = readOwnDataProperty(source, 'id', false);
  const amountValue = readOwnDataProperty(source, 'amount', false);
  const unit = readOwnDataProperty(source, 'unit', false);
  const mintsValue = readOwnDataProperty(source, 'mints', false);
  const description = readOwnDataProperty(source, 'description', false);
  const singleUse = readOwnDataProperty(source, 'singleUse');
  const nut10Value = readOwnDataProperty(source, 'nut10', false);
  if (
    (id !== undefined && typeof id !== 'string') ||
    (unit !== undefined && typeof unit !== 'string') ||
    (description !== undefined && typeof description !== 'string') ||
    typeof singleUse !== 'boolean'
  ) {
    throw new TypeError('Plugin capability returned an invalid PaymentRequest');
  }
  const transport =
    transportValue === undefined
      ? undefined
      : (sanitizePluginValue(
          transportValue,
          forbidden,
          lifecycle,
          seen,
        ) as PaymentRequest['transport']);
  const mints =
    mintsValue === undefined
      ? undefined
      : (detachPaymentRequestMints(mintsValue) as PaymentRequest['mints']);
  const nut10 =
    nut10Value === undefined
      ? undefined
      : (sanitizePluginValue(nut10Value, forbidden, lifecycle, seen) as PaymentRequest['nut10']);
  const amount = amountValue === undefined ? undefined : detachAmountLike(amountValue);

  const fields: ReadonlyArray<readonly [string, unknown]> = [
    ['transport', transport],
    ['id', id],
    ['amount', amount],
    ['unit', unit],
    ['mints', mints],
    ['description', description],
    ['singleUse', singleUse],
    ['nut10', nut10],
  ];
  for (let index = 0; index < fields.length; index += 1) {
    const [key, field] = fields[index]!;
    nativeDefineProperty(detached, key, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: field,
    });
  }
  return nativeFreeze(detached);
}

function detachPaymentRequestMints(value: unknown): readonly string[] {
  if (!nativeArrayIsArray(value) || nativeGetPrototypeOf(value) !== arrayPrototype) {
    throw new TypeError('Plugin capability returned invalid PaymentRequest mints');
  }
  const lengthDescriptor = nativeGetOwnPropertyDescriptor(value, 'length');
  const length = lengthDescriptor && 'value' in lengthDescriptor ? lengthDescriptor.value : -1;
  if (!nativeNumberIsSafeInteger(length) || length < 0) {
    throw new TypeError('Plugin capability returned invalid PaymentRequest mints');
  }
  const detached = new NativeArray(length) as string[];
  for (let index = 0; index < length; index += 1) {
    const descriptor = nativeGetOwnPropertyDescriptor(value, `${index}`);
    if (!descriptor || !('value' in descriptor) || typeof descriptor.value !== 'string') {
      throw new TypeError('Plugin capability returned invalid PaymentRequest mints');
    }
    nativeDefineProperty(detached, `${index}`, {
      configurable: true,
      enumerable: true,
      writable: true,
      value: descriptor.value,
    });
  }
  return createMutationTolerantFrozenArray(detached);
}

/** Frozen detached arrays keep familiar mutators as harmless plugin-local no-ops. */
function createMutationTolerantFrozenArray<T>(values: readonly T[]): readonly T[] {
  const lengthDescriptor = nativeGetOwnPropertyDescriptor(values, 'length');
  const length = lengthDescriptor && 'value' in lengthDescriptor ? lengthDescriptor.value : 0;
  const result = new NativeArray(length) as T[];
  for (let index = 0; index < length; index += 1) {
    const descriptor = nativeGetOwnPropertyDescriptor(values, `${index}`);
    if (!descriptor || !('value' in descriptor)) {
      throw new TypeError('Plugin capability returned an invalid array');
    }
    nativeDefineProperty(result, `${index}`, {
      configurable: true,
      enumerable: true,
      writable: true,
      value: descriptor.value,
    });
  }
  const noChangeLength = hardenFunction(() => result.length);
  const noItem = hardenFunction(() => undefined);
  const noItems = hardenFunction(() => nativeFreeze(new NativeArray(0)));
  const returnSelf = hardenFunction(() => result);
  const methods: Readonly<Record<string, (...args: never[]) => unknown>> = {
    push: noChangeLength,
    unshift: noChangeLength,
    pop: noItem,
    shift: noItem,
    splice: noItems,
    sort: returnSelf,
    reverse: returnSelf,
    copyWithin: returnSelf,
    fill: returnSelf,
  };
  const methodEntries = nativeEntries(methods);
  for (let index = 0; index < methodEntries.length; index += 1) {
    const [name, method] = methodEntries[index]!;
    nativeDefineProperty(result, name, {
      configurable: false,
      enumerable: false,
      writable: false,
      value: method,
    });
  }
  return nativeFreeze(result);
}

function isOutputDataLike(value: object): value is OutputDataLike {
  const prototype = nativeGetPrototypeOf(value);
  if (prototype === outputDataPrototype) return true;
  if (prototype !== objectPrototype && prototype !== null) return false;
  const required = ['blindedMessage', 'blindingFactor', 'secret', 'toProof'] as const;
  for (let index = 0; index < required.length; index += 1) {
    const descriptor = nativeGetOwnPropertyDescriptor(value, required[index]!);
    if (!descriptor || !('value' in descriptor)) return false;
  }
  return true;
}
