import type {
  PluginCounterCapability,
  PluginEventCapability,
  PluginHistoryCapability,
  PluginKeyRingCapability,
  PluginLoggerCapability,
  PluginMeltOperationCapability,
  PluginMintCapability,
  PluginMintOperationCapability,
  PluginPaymentRequestCapability,
  PluginPaymentRequestReceiveCapability,
  PluginProofCapability,
  PluginQuoteCapability,
  PluginReceiveOperationCapability,
  PluginSendOperationCapability,
  PluginSubscriptionCapability,
  PluginTokenCapability,
  PluginWalletRestoreCapability,
} from './capabilityTypes.ts';

export type ServiceKey = keyof ServiceMap;

/**
 * Stable service surface available to plugin authors through PluginContext.services.
 *
 * Plugins opt into individual services by listing their keys in Plugin.required. Removing,
 * renaming, or narrowing a key in this map is a public plugin API change.
 */
export interface ServiceMap {
  mintService: PluginMintCapability;
  proofService: PluginProofCapability;
  keyRingService: PluginKeyRingCapability;
  walletRestoreService: PluginWalletRestoreCapability;
  counterService: PluginCounterCapability;
  tokenService: PluginTokenCapability;
  historyService: PluginHistoryCapability;
  sendOperationService: PluginSendOperationCapability;
  receiveOperationService: PluginReceiveOperationCapability;
  meltOperationService: PluginMeltOperationCapability;
  mintOperationService: PluginMintOperationCapability;
  quotes: PluginQuoteCapability;
  paymentRequestService: PluginPaymentRequestCapability;
  paymentRequestReceiveService: PluginPaymentRequestReceiveCapability;
  subscriptions: PluginSubscriptionCapability;
  eventBus: PluginEventCapability;
  logger: PluginLoggerCapability;
}

export interface PluginContext<Req extends readonly ServiceKey[] = readonly ServiceKey[]> {
  services: Pick<ServiceMap, Req[number]>;
  /**
   * Register an API extension accessible via manager.ext.<key>
   * This capability is valid only while the onInit/onReady hook receiving this context is running.
   * Retaining it after the hook settles or Manager disposal causes the call to reject.
   * @param key - Unique primitive string containing 1 to 128 UTF-16 code units. Values are never coerced.
   * @param api - The API object to expose
   * @throws ExtensionRegistrationError if key is already registered
   * @throws TypeError if key is not a bounded non-empty primitive string
   */
  registerExtension<K extends string>(key: K, api: unknown): void;
}

export type CleanupFn = () => void | Promise<void>;
export type Cleanup = void | CleanupFn | Promise<void | CleanupFn>;

export interface Plugin<Req extends readonly ServiceKey[] = readonly ServiceKey[]> {
  name: string;
  required: Req;
  optional?: readonly ServiceKey[];
  onInit?(ctx: PluginContext<Req>): Cleanup;
  onReady?(ctx: PluginContext<Req>): Cleanup;
  onDispose?(): void | Promise<void>;
}

/**
 * Base interface for plugin extensions.
 * Plugin authors should augment this interface via module augmentation:
 *
 * @example
 * declare module '@cashu/coco-core/plugin' {
 *   interface PluginExtensions {
 *     myPlugin: MyPluginApi;
 *   }
 * }
 */
export interface PluginExtensions {}

/**
 * Error thrown when a plugin attempts to register an extension key that is already registered.
 */
export class ExtensionRegistrationError extends Error {
  constructor(pluginName: string, key: string) {
    super(
      `Plugin "${pluginName}" attempted to register extension "${key}", but it is already registered`,
    );
    this.name = 'ExtensionRegistrationError';
  }
}

/**
 * Error thrown when the same plugin instance is registered more than once.
 */
export class DuplicatePluginRegistrationError extends Error {
  constructor(pluginName: string) {
    super(`Plugin "${pluginName}" is already registered`);
    this.name = 'DuplicatePluginRegistrationError';
  }
}
