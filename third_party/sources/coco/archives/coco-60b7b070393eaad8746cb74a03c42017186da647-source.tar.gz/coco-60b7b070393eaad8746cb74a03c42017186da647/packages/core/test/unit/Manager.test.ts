import {
  Amount,
  deriveKeysetId,
  OutputData,
  type OutputDataCreator,
  type OutputDataLike,
  type SerializedBlindedSignature,
} from '@cashu/cashu-ts';
import { describe, it, beforeEach, expect, mock } from 'bun:test';

import { CocoInitializationError, initializeCoco, type CocoConfig, Manager } from '../../Manager';
import type { CoreEvents } from '../../events/types';
import type { Mint } from '../../models/Mint';
import { meltQuoteFromBolt11Response } from '../../models/MeltQuote';
import { mintQuoteFromBolt11Fixture as mintQuoteFromBolt11Response } from '../normalizedMintQuoteFixtures.ts';
import type { PendingMeltOperation } from '../../operations/melt';
import type { PendingMintOperation } from '../../operations/mint';
import { MeltOperationService } from '../../operations/melt/MeltOperationService.ts';
import { MintOperationService } from '../../operations/mint/MintOperationService.ts';
import { createSendOperation } from '../../operations/send/SendOperation.ts';
import { SendOperationService } from '../../operations/send/SendOperationService.ts';
import { MemoryRepositories } from '../../repositories/memory';
import { MemoryLegacyMintQuoteRepository } from '../../repositories/memory/MemoryLegacyMintQuoteRepository.ts';
import { NullLogger } from '../../logging';
import type { FinalizedReceiveOperation } from '../../operations/receive/ReceiveOperation';
import type { Plugin, PluginProofCapability, PluginQuoteCapability } from '../../plugin';
import type { ServiceKey, ServiceMap } from '../../plugins/types.ts';
import { PaymentRequestReceiveService } from '../../services/PaymentRequestReceiveService.ts';
import { MintService } from '../../services/MintService.ts';
import type { CoreProof, MintInfo } from '../../types';
import { makeOutputDataCreator } from '../fixtures/OutputDataCreator.ts';
import { createTestMemoryRepositories } from '../fixtures/TestMemoryRepositories.ts';
import { WalletAuthorityConflictError, WalletAuthorityLifecycleError } from '../../models/Error.ts';

let serviceCaptureId = 0;
function capturePlugin<const Keys extends readonly ServiceKey[]>(...required: Keys) {
  let captured: Pick<ServiceMap, Keys[number]> | undefined;
  const plugin: Plugin<Keys> = {
    name: `manager-test-service-capture-${++serviceCaptureId}`,
    required,
    onInit(context) {
      captured = context.services;
    },
  };
  return {
    plugin,
    services(): Pick<ServiceMap, Keys[number]> {
      if (!captured) throw new Error('Test service capture has not initialized');
      return captured;
    },
  };
}

describe('initializeCoco', () => {
  let repositories: MemoryRepositories;
  let seedGetter: () => Promise<Uint8Array>;
  let baseConfig: Pick<CocoConfig, 'repo' | 'seedGetter'>;

  beforeEach(() => {
    repositories = new MemoryRepositories();
    seedGetter = async () => new Uint8Array(32);
    baseConfig = {
      repo: repositories,
      seedGetter,
    };
  });

  const mintUrl = 'https://output-creator.test';
  const keypairs = {
    '1': '0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798',
  };
  const keysetId = deriveKeysetId(keypairs, { unit: 'sat' });
  const usdKeysetId = deriveKeysetId(keypairs, { unit: 'usd' });
  const secondMintUrl = 'https://second-output-creator.test';

  let seedOwner = 0;
  async function seedRepositories(work: (seedRoot: MemoryRepositories) => Promise<void>) {
    const seedRoot = repositories;
    await seedRoot.init();
    await seedRoot.acquireAuthority({
      namespace: 'default',
      ownerId: `manager-test-seed-${++seedOwner}`,
    });
    try {
      await work(seedRoot);
    } finally {
      await seedRoot.releaseAuthority();
    }
    repositories = seedRoot.createPeer();
    baseConfig = { repo: repositories, seedGetter };
  }

  async function seedOutputCreatorMint(): Promise<void> {
    await seedRepositories(async (seedRoot) => {
      const now = Math.floor(Date.now() / 1000);
      for (const url of [mintUrl, secondMintUrl]) {
        await seedRoot.mintRepository.addNewMint({
          mintUrl: url,
          name: url,
          mintInfo: {
            name: 'Output Creator Test Mint',
            version: '1.0.0',
            pubkey: '',
            contact: [],
            nuts: {
              '4': { methods: [], disabled: false },
              '5': { methods: [], disabled: false },
            },
          } as MintInfo,
          trusted: true,
          createdAt: now,
          updatedAt: now,
        });
      }
      await seedRoot.keysetRepository.addKeyset({
        mintUrl,
        id: keysetId,
        unit: 'sat',
        keypairs,
        active: true,
        feePpk: 0,
      });
      await seedRoot.keysetRepository.addKeyset({
        mintUrl,
        id: usdKeysetId,
        unit: 'usd',
        keypairs,
        active: true,
        feePpk: 0,
      });
      await seedRoot.keysetRepository.addKeyset({
        mintUrl: secondMintUrl,
        id: keysetId,
        unit: 'sat',
        keypairs,
        active: true,
        feePpk: 0,
      });
    });
  }

  const disabledRuntime = {
    watchers: {
      mintOperationWatcher: { disabled: true },
      proofStateWatcher: { disabled: true },
      meltQuoteWatcher: { disabled: true },
    },
    processors: {
      mintOperationProcessor: { disabled: true },
      meltSettlementProcessor: { disabled: true },
    },
  } satisfies Pick<CocoConfig, 'watchers' | 'processors'>;

  it('acquires authority and completes all recovery before autonomous work starts', async () => {
    const events: string[] = [];
    const repo = new MemoryRepositories();
    const originalInit = repo.init.bind(repo);
    const originalAcquire = repo.acquireAuthority.bind(repo);
    repo.init = mock(async () => {
      events.push('open-storage');
      await originalInit();
    });
    repo.acquireAuthority = mock(async (identity) => {
      events.push('acquire-authority');
      return originalAcquire(identity);
    });

    const originals = {
      mintWatcher: Manager.prototype.enableMintOperationWatcher,
      proofWatcher: Manager.prototype.enableProofStateWatcher,
      meltWatcher: Manager.prototype.enableMeltQuoteWatcher,
      mintProcessor: Manager.prototype.enableMintOperationProcessor,
      meltProcessor: Manager.prototype.enableMeltSettlementProcessor,
    };
    let manager: Manager | undefined;

    Manager.prototype.enableMintOperationWatcher = mock(async () => {
      events.push('start-mint-watcher');
    });
    Manager.prototype.enableProofStateWatcher = mock(async () => {
      events.push('start-proof-watcher');
    });
    Manager.prototype.enableMeltQuoteWatcher = mock(async () => {
      events.push('start-melt-watcher');
    });
    Manager.prototype.enableMintOperationProcessor = mock(async () => {
      events.push('start-mint-processor');
      return true;
    });
    Manager.prototype.enableMeltSettlementProcessor = mock(async () => {
      events.push('start-melt-processor');
      return true;
    });

    try {
      manager = await initializeCoco({
        repo,
        seedGetter,
        authority: { namespace: 'wallet', ownerId: 'runtime-a' },
        plugins: [
          {
            name: 'startup-order-adversary',
            required: ['sendOperationService'] as const,
            onInit: async ({ services }) => {
              events.push('plugin-on-init-attempt-send');
              await services.sendOperationService
                .prepare({ id: 'on-init-send', mintUrl: 'https://mint.test' } as never)
                .catch(() => undefined);
            },
            onReady: async ({ services }) => {
              events.push('plugin-on-ready-attempt-send');
              await services.sendOperationService
                .execute({ id: 'on-ready-send' } as never)
                .catch(() => undefined);
            },
          },
        ],
      });
    } finally {
      Manager.prototype.enableMintOperationWatcher = originals.mintWatcher;
      Manager.prototype.enableProofStateWatcher = originals.proofWatcher;
      Manager.prototype.enableMeltQuoteWatcher = originals.meltWatcher;
      Manager.prototype.enableMintOperationProcessor = originals.mintProcessor;
      Manager.prototype.enableMeltSettlementProcessor = originals.meltProcessor;
    }

    expect(events).toEqual([
      'open-storage',
      'acquire-authority',
      'plugin-on-init-attempt-send',
      'plugin-on-ready-attempt-send',
      'start-mint-watcher',
      'start-proof-watcher',
      'start-melt-watcher',
      'start-mint-processor',
      'start-melt-processor',
    ]);
    await manager?.dispose();
  });

  it('adopts only the exact active capability already held by the supplied repository root', async () => {
    const adopted = new MemoryRepositories();
    await adopted.init();
    const capability = await adopted.acquireAuthority({
      namespace: 'wallet',
      ownerId: 'preacquired-runtime',
    });
    const manager = await initializeCoco({ repo: adopted, seedGetter, ...disabledRuntime });
    expect(adopted.getAuthority()).toEqual(capability);
    await manager.dispose();

    const mismatched = new MemoryRepositories();
    await mismatched.init();
    await mismatched.acquireAuthority({ namespace: 'wallet', ownerId: 'actual-owner' });
    await expect(
      initializeCoco({
        repo: mismatched,
        seedGetter,
        authority: { namespace: 'wallet', ownerId: 'different-owner' },
        ...disabledRuntime,
      }),
    ).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);
    expect(mismatched.getAuthorityState()).toBe('active');
    await mismatched.releaseAuthority();
  });

  it('attaches an exact active repository root to only one Manager session', async () => {
    const root = new MemoryRepositories();
    await root.init();
    const capability = await root.acquireAuthority({
      namespace: 'wallet',
      ownerId: 'single-attachment',
    });

    const managerA = await initializeCoco({
      repo: root,
      seedGetter: async () => new Uint8Array(64),
      ...disabledRuntime,
    });
    try {
      await expect(initializeCoco({ repo: root, seedGetter, ...disabledRuntime })).rejects.toThrow(
        'already attached to an active Manager',
      );
      await expect(
        initializeCoco({
          repo: root,
          seedGetter,
          authority: capability,
          ...disabledRuntime,
        }),
      ).rejects.toThrow('already attached to an active Manager');

      expect(root.getAuthority()).toEqual(capability);
      const generated = await managerA.keyring.generateKeyPair(true);
      expect(generated.derivationIndex).toBe(0);
    } finally {
      await managerA.dispose();
    }
    expect(root.getAuthorityState()).toBe('released');
  });

  it('rolls back the exact-root attachment after confirmed startup cleanup', async () => {
    const root = new MemoryRepositories();
    const originalReconcile = MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes;
    MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = mock(async () => {
      throw new Error('startup failure');
    });
    try {
      await expect(
        initializeCoco({ repo: root, seedGetter, ...disabledRuntime }),
      ).rejects.toMatchObject({ cleanupState: 'confirmed' });
    } finally {
      MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = originalReconcile;
    }

    expect(root.getAuthorityState()).toBe('released');
    let retryError: unknown;
    try {
      await initializeCoco({ repo: root, seedGetter, ...disabledRuntime });
    } catch (error) {
      retryError = error;
    }
    expect(retryError).toBeInstanceOf(WalletAuthorityLifecycleError);
    expect((retryError as Error).message).not.toContain('already attached');
  });

  it('fences an older Manager when a second Manager takes over the same store', async () => {
    const first = new MemoryRepositories();
    const second = first.createPeer();
    const seed = async () => new Uint8Array(64);
    const managerA = await initializeCoco({
      repo: first,
      seedGetter: seed,
      authority: { namespace: 'wallet', ownerId: 'runtime-a' },
      ...disabledRuntime,
    });
    const managerB = await initializeCoco({
      repo: second,
      seedGetter: seed,
      authority: { namespace: 'wallet', ownerId: 'runtime-b' },
      ...disabledRuntime,
    });

    try {
      await expect(managerA.keyring.generateKeyPair(true)).rejects.toBeInstanceOf(
        WalletAuthorityConflictError,
      );
      const key = await managerB.keyring.generateKeyPair(true);
      expect(key.derivationIndex).toBe(0);
    } finally {
      await expect(managerA.dispose()).rejects.toBeInstanceOf(AggregateError);
      await managerB.dispose();
    }
  });

  function makeOutput(marker: string, id = keysetId): OutputDataLike {
    return {
      blindedMessage: { amount: Amount.from(1), id, B_: marker },
      blindingFactor: 19n,
      secret: new Uint8Array([1, 2, 3]),
      toProof: mock(() => {
        throw new Error('not used while preparing outputs');
      }),
    };
  }

  describe('default behavior', () => {
    it('propagates a custom output data creator through initialized services', async () => {
      await seedOutputCreatorMint();
      const outputCreatorSeed = new Uint8Array(64);
      const deterministicOutput = makeOutput('custom-deterministic');
      const creatorReceivers: OutputDataCreator[] = [];
      const randomOutputs: OutputDataLike[] = [];
      const createDeterministicData = mock(function (
        this: OutputDataCreator,
        ..._args: Parameters<OutputDataCreator['createDeterministicData']>
      ) {
        creatorReceivers.push(this);
        return [deterministicOutput];
      });
      const createRandomData = mock(function (
        this: OutputDataCreator,
        ...args: Parameters<OutputDataCreator['createRandomData']>
      ) {
        creatorReceivers.push(this);
        const output = makeOutput(`custom-random-${args[1].id}`, args[1].id);
        randomOutputs.push(output);
        return [output];
      });
      const outputDataCreator = makeOutputDataCreator({
        createDeterministicData,
        createRandomData,
      });
      let proofService: PluginProofCapability | undefined;
      const plugin: Plugin<['proofService']> = {
        name: 'output-creator-acceptance',
        required: ['proofService'],
        onReady: ({ services }) => {
          proofService = services.proofService;
        },
      };

      const manager = await initializeCoco({
        ...baseConfig,
        ...disabledRuntime,
        seedGetter: async () => outputCreatorSeed,
        outputDataCreator,
        plugins: [plugin],
      });
      const originalCreateDeterministicData = OutputData.createDeterministicData;
      const originalCreateRandomData = OutputData.createRandomData;
      OutputData.createDeterministicData = () => {
        throw new Error('built-in deterministic creation must not be used');
      };
      OutputData.createRandomData = () => {
        throw new Error('built-in random creation must not be used');
      };

      try {
        const outputs = await proofService!.createOutputsAndIncrementCounters(mintUrl, {
          keep: { amount: Amount.from(1), unit: 'sat' },
          send: { amount: Amount.zero(), unit: 'sat' },
        });

        expect(outputs.keep).toHaveLength(1);
        expect(outputs.keep[0]).not.toBe(deterministicOutput);
        expect(outputs.keep[0]).toMatchObject({
          blindedMessage: deterministicOutput.blindedMessage,
          blindingFactor: deterministicOutput.blindingFactor,
          secret: deterministicOutput.secret,
        });
        expect(typeof outputs.keep[0]!.toProof).toBe('function');
        expect(Object.getPrototypeOf(outputs.keep[0]!)).toBeNull();
        expect(Object.isFrozen(outputs.keep[0]!)).toBe(true);
        const deterministicCall = createDeterministicData.mock.calls[0];
        expect(deterministicCall?.[0]).toEqual(Amount.from(1));
        expect(deterministicCall?.[1]).toEqual(new Uint8Array(64));
        expect(deterministicCall?.[2]).toBe(0);
        expect(deterministicCall?.[3]?.id).toBe(keysetId);
        expect(randomOutputs).toEqual([]);
        expect(createRandomData).not.toHaveBeenCalled();
        expect(creatorReceivers).toHaveLength(1);
        for (const receiver of creatorReceivers) {
          expect(receiver).toBe(outputDataCreator);
        }
      } finally {
        OutputData.createDeterministicData = originalCreateDeterministicData;
        OutputData.createRandomData = originalCreateRandomData;
        await manager.dispose();
      }
    });

    it('uses cashu-ts output construction when no creator is configured', async () => {
      await seedOutputCreatorMint();
      const outputCreatorSeed = new Uint8Array(64);
      const builtInOutput = makeOutput('built-in-deterministic');
      const createDeterministicData = mock(() => [builtInOutput]);
      const originalCreateDeterministicData = OutputData.createDeterministicData;
      OutputData.createDeterministicData = createDeterministicData;
      let proofService: PluginProofCapability | undefined;
      const plugin: Plugin<['proofService']> = {
        name: 'default-output-creator-acceptance',
        required: ['proofService'],
        onReady: ({ services }) => {
          proofService = services.proofService;
        },
      };
      let manager: Manager | undefined;

      try {
        manager = await initializeCoco({
          ...baseConfig,
          ...disabledRuntime,
          seedGetter: async () => outputCreatorSeed,
          plugins: [plugin],
        });
        const outputs = await proofService!.createOutputsAndIncrementCounters(mintUrl, {
          keep: { amount: Amount.from(1), unit: 'sat' },
          send: { amount: Amount.zero(), unit: 'sat' },
        });

        expect(outputs.keep).toHaveLength(1);
        expect(outputs.keep[0]).not.toBe(builtInOutput);
        expect(outputs.keep[0]).toMatchObject({
          blindedMessage: builtInOutput.blindedMessage,
          blindingFactor: builtInOutput.blindingFactor,
          secret: builtInOutput.secret,
        });
        expect(typeof outputs.keep[0]!.toProof).toBe('function');
        expect(createDeterministicData).toHaveBeenCalledTimes(1);
      } finally {
        OutputData.createDeterministicData = originalCreateDeterministicData;
        await manager?.dispose();
      }
    });

    it('should enable all watchers and processors by default', async () => {
      const manager = await initializeCoco(baseConfig);

      // Check that manager is created
      expect(manager).toBeInstanceOf(Manager);

      // Verify watchers are running (they have isRunning methods)
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);

      // Verify processors are running
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.disableMintOperationWatcher();
      await manager.disableProofStateWatcher();
      await manager.disableMeltQuoteWatcher();
      await manager.disableMintOperationProcessor();
      await manager.disableMeltSettlementProcessor();
    });

    it('should initialize repositories', async () => {
      const originalInit = repositories.init.bind(repositories);
      const initSpy = mock(() => originalInit());
      repositories.init = initSpy;

      const manager = await initializeCoco({
        ...baseConfig,
        repo: repositories,
      });

      expect(initSpy).toHaveBeenCalled();
      await manager.dispose();
    });

    it('should dispose a partially initialized Manager when startup fails', async () => {
      const originalReconcile =
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes;
      const startupError = new Error('legacy quote reconciliation failed');
      const onInit = mock(async () => {});
      const onReady = mock(async () => {});
      const onDispose = mock(async () => {});
      const cleanup = mock(async () => {});
      MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = mock(async () => {
        throw startupError;
      });

      try {
        await initializeCoco({
          ...baseConfig,
          ...disabledRuntime,
          plugins: [
            {
              name: 'cleanup-observer',
              required: [],
              onInit: async () => {
                await onInit();
                return cleanup;
              },
              onReady,
              onDispose,
            },
          ],
        });
        throw new Error('expected initialization to fail');
      } catch (error) {
        expect(error).toBeInstanceOf(CocoInitializationError);
        expect((error as CocoInitializationError).cleanupState).toBe('confirmed');
        expect((error as CocoInitializationError).cause).toBe(startupError);
      } finally {
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = originalReconcile;
      }

      expect(onInit).not.toHaveBeenCalled();
      expect(onReady).not.toHaveBeenCalled();
      expect(onDispose).not.toHaveBeenCalled();
      expect(cleanup).not.toHaveBeenCalled();
    });

    it('should report when partial initialization cleanup fails', async () => {
      const cleanupError = new Error('cleanup failed');
      const originalReconcile =
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes;
      const originalRelease = repositories.releaseAuthority.bind(repositories);
      const release = mock(async () => {
        throw cleanupError;
      });
      MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = mock(async () => {
        throw new Error('legacy quote reconciliation failed');
      });
      repositories.releaseAuthority = release;

      try {
        await initializeCoco({
          ...baseConfig,
          ...disabledRuntime,
        });
        throw new Error('expected initialization to fail');
      } catch (error) {
        expect(error).toBeInstanceOf(CocoInitializationError);
        expect((error as CocoInitializationError).cleanupState).toBe('unconfirmed');
        expect((error as CocoInitializationError).cause).toBeInstanceOf(AggregateError);
      } finally {
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = originalReconcile;
        repositories.releaseAuthority = originalRelease;
      }

      expect(release).toHaveBeenCalledTimes(1);
      await expect(initializeCoco({ ...baseConfig, ...disabledRuntime })).rejects.toThrow(
        'already attached to an active Manager',
      );
    });

    it('preserves the root attachment when authority release returns false', async () => {
      const originalReconcile =
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes;
      const originalRelease = repositories.releaseAuthority.bind(repositories);
      const release = mock(async () => false);
      MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = mock(async () => {
        throw new Error('legacy quote reconciliation failed');
      });
      repositories.releaseAuthority = release;

      try {
        await expect(initializeCoco({ ...baseConfig, ...disabledRuntime })).rejects.toMatchObject({
          cleanupState: 'unconfirmed',
        });
      } finally {
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = originalReconcile;
        repositories.releaseAuthority = originalRelease;
      }

      expect(release).toHaveBeenCalledTimes(1);
      await expect(initializeCoco({ ...baseConfig, ...disabledRuntime })).rejects.toThrow(
        'already attached to an active Manager',
      );
    });

    it('should report initialized plugin cleanup failures as unconfirmed initialization cleanup', async () => {
      const originalWatcher = Manager.prototype.enableMintOperationWatcher;
      const originalConsoleError = console.error;
      const startupError = new Error('watcher startup failed');
      const cleanupError = new Error('plugin cleanup failed');
      console.error = mock(() => {});
      Manager.prototype.enableMintOperationWatcher = mock(async () => {
        throw startupError;
      });

      try {
        await initializeCoco({
          ...baseConfig,
          watchers: {
            proofStateWatcher: { disabled: true },
            meltQuoteWatcher: { disabled: true },
          },
          processors: disabledRuntime.processors,
          plugins: [
            {
              name: 'failing-cleanup',
              required: [],
              onDispose: () => {
                throw cleanupError;
              },
            },
          ],
        });
        throw new Error('expected initialization to fail');
      } catch (error) {
        expect(error).toBeInstanceOf(CocoInitializationError);
        expect((error as CocoInitializationError).cleanupState).toBe('unconfirmed');
        expect((error as CocoInitializationError).cause).toBeInstanceOf(AggregateError);
      } finally {
        Manager.prototype.enableMintOperationWatcher = originalWatcher;
        console.error = originalConsoleError;
      }
    });

    it('should expose the dedicated payment requests api', async () => {
      const manager = await initializeCoco(baseConfig);

      expect(Object.getPrototypeOf(manager.paymentRequests)).toBeNull();
      expect(Object.isFrozen(manager.paymentRequests)).toBe(true);
      expect(typeof manager.paymentRequests.parse).toBe('function');

      await manager.disableMintOperationWatcher();
      await manager.disableProofStateWatcher();
      await manager.disableMintOperationProcessor();
    });

    it('should expose the dedicated quotes api', async () => {
      const manager = await initializeCoco(baseConfig);

      expect(Object.getPrototypeOf(manager.quotes)).toBeNull();
      expect(Object.isFrozen(manager.quotes)).toBe(true);
      expect(typeof manager.quotes.mint.create).toBe('function');

      await manager.disableMintOperationWatcher();
      await manager.disableProofStateWatcher();
      await manager.disableMintOperationProcessor();
    });

    it('should allocate keys atomically through the public keyring api', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        ...disabledRuntime,
        seedGetter: async () => new Uint8Array(64),
      });

      const [first, second] = await Promise.all([
        manager.keyring.generateKeyPair(true),
        manager.keyring.generateKeyPair(true),
      ]);

      expect(new Set([first.derivationIndex, second.derivationIndex])).toEqual(new Set([0, 1]));
      expect(await repositories.keyRingRepository.getAllPersistedKeyPairs('p2pk')).toHaveLength(2);

      await manager.dispose();
    });

    it('should expose the quote api to plugins', async () => {
      let pluginQuotes: PluginQuoteCapability | undefined;
      const plugin: Plugin<['quotes']> = {
        name: 'quotes-plugin',
        required: ['quotes'],
        onReady: ({ services }) => {
          pluginQuotes = services.quotes;
        },
      };

      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [plugin],
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });

      expect(pluginQuotes).not.toBe(manager.quotes);
      expect(Object.getPrototypeOf(pluginQuotes!)).toBeNull();
      expect(Object.isFrozen(pluginQuotes!)).toBe(true);
      expect(Object.getPrototypeOf(pluginQuotes!.mint)).toBeNull();
      expect(Object.isFrozen(pluginQuotes!.mint)).toBe(true);

      await manager.dispose();
    });

    it('should let plugins import canonical mint quotes through the quote api', async () => {
      const mintUrl = 'https://mint.test';
      const quoteId = 'plugin-import-quote';
      const now = Math.floor(Date.now() / 1000);
      await seedRepositories(async (seedRoot) => {
        await seedRoot.mintRepository.addNewMint({
          mintUrl,
          name: mintUrl,
          mintInfo: {
            nuts: {
              '4': { methods: [{ method: 'bolt11', unit: 'sat' }] },
            },
          } as MintInfo,
          trusted: true,
          createdAt: now,
          updatedAt: now,
        } satisfies Mint);
      });

      let importedQuoteId: string | undefined;
      const plugin: Plugin<['quotes']> = {
        name: 'quotes-import-plugin',
        required: ['quotes'],
        onReady: async ({ services }) => {
          const quote = await services.quotes.mint.import({
            mintUrl,
            method: 'bolt11',
            quote: {
              quote: quoteId,
              request: 'lnbc1pluginimportquote',
              amount: Amount.from(21),
              unit: 'sat',
              expiry: 4_102_444_800,
              state: 'PAID',
            },
          });
          importedQuoteId = quote.quoteId;
        },
      };

      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [plugin],
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });

      expect(importedQuoteId).toBe(quoteId);
      await expect(manager.quotes.mint.get({ mintUrl, quoteId })).resolves.toMatchObject({
        mintUrl,
        quoteId,
        method: 'bolt11',
        state: 'PAID',
      });

      await manager.dispose();
    });

    it('does not reconcile canonical quote-only rows into mint operations on startup', async () => {
      await seedRepositories(async (seedRoot) => {
        await seedRoot.mintQuoteRepository.upsertMintQuote(
          mintQuoteFromBolt11Response('https://mint.test', {
            quote: 'quote-only-restart',
            request: 'lnbc1quoteonlyrestart',
            amount: Amount.from(10),
            unit: 'sat',
            expiry: Math.floor(Date.now() / 1000) + 3600,
            state: 'UNPAID',
          }),
        );
      });

      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });

      const operations =
        await repositories.mintOperationRepository.getByMintUrl('https://mint.test');
      const pendingQuotes = await manager.quotes.mint.listPending();

      expect(operations).toHaveLength(0);
      expect(pendingQuotes.map((quote) => quote.quoteId)).toEqual(['quote-only-restart']);
    });

    it('exposes subscribe-only events that receive sanitized Core-owned payloads', async () => {
      const capture = capturePlugin('eventBus', 'counterService');
      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [capture.plugin],
        ...disabledRuntime,
      });
      const observedCounters: number[] = [];
      capture.services().eventBus.on('counter:updated', ({ counter }) => {
        observedCounters.push(counter);
      });

      const returned = await capture
        .services()
        .counterService.overwriteCounter('https://mint.test', 'keyset-1', 3);

      expect(observedCounters).toEqual([3]);
      expect(returned).toEqual({
        mintUrl: 'https://mint.test',
        keysetId: 'keyset-1',
        counter: 3,
      });
      expect(Object.getPrototypeOf(returned)).toBeNull();
      expect(Object.isFrozen(returned)).toBe(true);

      await manager.dispose();
    });

    it('does not expose Core event publication to plugins', async () => {
      const capture = capturePlugin('eventBus');
      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [capture.plugin],
        ...disabledRuntime,
      });

      expect(Object.keys(capture.services().eventBus).sort()).toEqual(['off', 'on', 'once']);
      expect(
        (capture.services().eventBus as unknown as Record<string, unknown>).emit,
      ).toBeUndefined();
      expect(Object.getPrototypeOf(capture.services().eventBus)).toBeNull();
      expect(Object.isFrozen(capture.services().eventBus)).toBe(true);

      await manager.dispose();
    });

    it('should use NullLogger by default', async () => {
      const capture = capturePlugin('logger');
      const manager = await initializeCoco({ ...baseConfig, plugins: [capture.plugin] });

      expect(Object.keys(capture.services().logger).sort()).toEqual([
        'debug',
        'error',
        'info',
        'warn',
      ]);
      expect(Object.getPrototypeOf(capture.services().logger)).toBeNull();
      expect(Object.isFrozen(capture.services().logger)).toBe(true);
      expect(manager.ops.send).toBeDefined();
      expect(manager.ops.receive).toBeDefined();
      expect(manager.ops.mint).toBeDefined();
      expect(manager.ops.melt).toBeDefined();

      await manager.disableMintOperationWatcher();
      await manager.disableProofStateWatcher();
      await manager.disableMintOperationProcessor();
    });

    it('should accept custom logger', async () => {
      const customLogger = new NullLogger();
      const capture = capturePlugin('logger');
      const manager = await initializeCoco({
        ...baseConfig,
        logger: customLogger,
        plugins: [capture.plugin],
      });

      expect(capture.services().logger).not.toBe(customLogger);
      expect(Object.getPrototypeOf(capture.services().logger)).toBeNull();
      expect(Object.isFrozen(capture.services().logger)).toBe(true);

      await manager.disableMintOperationWatcher();
      await manager.disableProofStateWatcher();
      await manager.disableMintOperationProcessor();
    });

    it('should initialize plugins once before returning', async () => {
      const counters = { init: 0, ready: 0 };
      const extension = { ok: true };

      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [
          {
            name: 'plugin-init',
            required: [],
            onInit: (ctx) => {
              counters.init += 1;
              ctx.registerExtension('pluginInit', extension);
            },
            onReady: () => {
              counters.ready += 1;
            },
          },
        ],
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });

      expect(counters).toEqual({ init: 1, ready: 1 });
      expect((manager.ext as Record<string, unknown>).pluginInit).toBe(extension);
    });

    it('should recover payment-request receive attempts during startup', async () => {
      const now = Date.now();
      await seedRepositories(async (seedRoot) => {
        await seedRoot.paymentRequestReceiveOperationRepository.create({
          id: 'payment-request-receive-1',
          requestId: 'request-id',
          encodedRequest: 'CREQB-test',
          state: 'active',
          transport: 'inband',
          amount: Amount.from(100),
          unit: 'sat',
          mints: ['https://mint.test'],
          singleUse: true,
          createdAt: now,
          updatedAt: now,
        });
        await seedRoot.paymentRequestReceiveAttemptRepository.create({
          id: 'attempt-1',
          requestOperationId: 'payment-request-receive-1',
          requestId: 'request-id',
          transport: 'inband',
          payloadHash: 'payload-hash-1',
          mintUrl: 'https://mint.test',
          unit: 'sat',
          grossAmount: Amount.from(100),
          receiveOperationId: 'receive-op-1',
          state: 'receiving',
          createdAt: now,
          updatedAt: now,
        });
        await seedRoot.receiveOperationRepository.create({
          id: 'receive-op-1',
          state: 'finalized',
          mintUrl: 'https://mint.test',
          unit: 'sat',
          amount: Amount.from(100),
          fee: Amount.from(1),
          inputProofs: [],
          outputData: { keep: [], send: [] },
          source: {
            type: 'payment-request',
            requestOperationId: 'payment-request-receive-1',
            requestId: 'request-id',
            attemptId: 'attempt-1',
            transport: 'inband',
          },
          createdAt: now,
          updatedAt: now,
        } satisfies FinalizedReceiveOperation);
      });

      await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });

      const attempt =
        await repositories.paymentRequestReceiveAttemptRepository.getById('attempt-1');
      const operation = await repositories.paymentRequestReceiveOperationRepository.getById(
        'payment-request-receive-1',
      );

      expect(attempt?.state).toBe('finalized');
      expect(attempt?.fee?.equals(Amount.from(1))).toBe(true);
      expect(attempt?.netAmount?.equals(Amount.from(99))).toBe(true);
      expect(operation?.state).toBe('completed');
    });
  });

  function makePendingMintOperation(id: string, quoteId: string): PendingMintOperation {
    return {
      id,
      state: 'pending',
      mintUrl: 'https://mint.test',
      method: 'bolt11',
      methodData: {},
      amount: Amount.from(100),
      unit: 'sat',
      quoteId,
      request: 'lnbc100',
      expiry: null,
      outputData: { keep: [], send: [] },
      createdAt: 1_000,
      updatedAt: 2_000,
    };
  }

  function makePendingMeltOperation(
    id: string,
    quoteId: string,
    overrides: Partial<PendingMeltOperation> = {},
  ): PendingMeltOperation {
    return {
      id,
      state: 'pending',
      mintUrl: 'https://mint.test',
      method: 'bolt11',
      methodData: { invoice: 'lnbc100' },
      amount: Amount.from(100),
      quoteId,
      fee_reserve: Amount.from(1),
      swap_fee: Amount.from(0),
      needsSwap: false,
      inputAmount: Amount.from(101),
      inputProofSecrets: [`input-${id}`],
      changeOutputData: { keep: [], send: [] },
      createdAt: 1_000,
      updatedAt: 2_000,
      ...overrides,
      unit: overrides.unit ?? 'sat',
    };
  }

  function makeInputProof(secret: string, operationId: string): CoreProof {
    return {
      amount: Amount.from(101),
      C: `C_${secret}`,
      id: 'keyset-1',
      secret,
      mintUrl: 'https://mint.test',
      unit: 'sat',
      state: 'ready',
      usedByOperationId: operationId,
    };
  }

  function makeMeltQuote(
    quoteId: string,
    state: 'UNPAID' | 'PENDING' | 'PAID',
    options: { expired?: boolean; change?: SerializedBlindedSignature[] } = {},
  ) {
    return meltQuoteFromBolt11Response('https://mint.test', {
      quote: quoteId,
      request: 'lnbc100',
      amount: Amount.from(100),
      unit: 'sat',
      fee_reserve: Amount.from(1),
      expiry: Math.floor(Date.now() / 1000) + (options.expired ? -60 : 3600),
      state,
      payment_preimage: state === 'PAID' ? 'preimage-123' : null,
      change: options.change,
    });
  }

  const flushDeferredInitialChecks = async () => {
    await new Promise((resolve) => setTimeout(resolve, 0));
    await Promise.resolve();
  };

  describe('melt watcher and settlement lifecycle', () => {
    it('starts melt quote watching and settlement processing by default', async () => {
      const manager = await initializeCoco(baseConfig);

      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('resumes pending canonical melt quote watches and pending operation interest on startup', async () => {
      const canonicalQuote = makeMeltQuote('melt-canonical-startup', 'PENDING');
      const expiredOperationQuote = makeMeltQuote('melt-expired-operation-startup', 'PENDING', {
        expired: true,
      });
      const expiredOperation = makePendingMeltOperation(
        'melt-op-expired-startup',
        expiredOperationQuote.quoteId,
      );

      await seedRepositories(async (seedRoot) => {
        await seedRoot.meltQuoteRepository.upsertMeltQuote(canonicalQuote);
        await seedRoot.meltQuoteRepository.upsertMeltQuote(expiredOperationQuote);
        await seedRoot.meltOperationRepository.create(expiredOperation);
      });
      const manager = await initializeCoco({
        ...baseConfig,
        ...disabledRuntime,
      });
      manager.subscriptions.pause();
      const checkPendingOperation = mock(async () => 'stay_pending' as const);
      const originalIsTrustedMint = MintService.prototype.isTrustedMint;
      const originalCheckPending = MeltOperationService.prototype.checkPendingOperation;
      MintService.prototype.isTrustedMint = mock(async () => true);
      MeltOperationService.prototype.checkPendingOperation = checkPendingOperation;
      try {
        await manager.enableMeltQuoteWatcher();
        await manager.enableMeltSettlementProcessor();
        await flushDeferredInitialChecks();

        const subscriptions = manager.subscriptions.getDiagnostics().subscriptions;

        expect(subscriptions).toHaveLength(2);
        expect(subscriptions.map((subscription) => subscription.kind).sort()).toEqual([
          'bolt11_melt_quote',
          'bolt11_melt_quote',
        ]);
        expect(subscriptions.map((subscription) => subscription.filters[0]).sort()).toEqual([
          'melt-canonical-startup',
          'melt-expired-operation-startup',
        ]);
        expect(checkPendingOperation).toHaveBeenCalledWith(expiredOperation.id);
      } finally {
        MintService.prototype.isTrustedMint = originalIsTrustedMint;
        MeltOperationService.prototype.checkPendingOperation = originalCheckPending;
        await manager.dispose();
      }
    });

    it('attaches melt quote watching when settlement processing starts first', async () => {
      const expiredOperationQuote = makeMeltQuote('melt-expired-operation-first', 'PENDING', {
        expired: true,
      });
      const expiredOperation = makePendingMeltOperation(
        'melt-op-expired-first',
        expiredOperationQuote.quoteId,
      );

      await seedRepositories(async (seedRoot) => {
        await seedRoot.meltQuoteRepository.upsertMeltQuote(expiredOperationQuote);
        await seedRoot.meltOperationRepository.create(expiredOperation);
      });
      const manager = await initializeCoco({
        ...baseConfig,
        ...disabledRuntime,
      });
      manager.subscriptions.pause();
      const checkPendingOperation = mock(async () => 'stay_pending' as const);
      const originalIsTrustedMint = MintService.prototype.isTrustedMint;
      const originalCheckPending = MeltOperationService.prototype.checkPendingOperation;
      MintService.prototype.isTrustedMint = mock(async () => true);
      MeltOperationService.prototype.checkPendingOperation = checkPendingOperation;
      try {
        await manager.enableMeltSettlementProcessor();
        await manager.enableMeltQuoteWatcher();
        await flushDeferredInitialChecks();

        const subscriptions = manager.subscriptions.getDiagnostics().subscriptions;

        expect(subscriptions).toHaveLength(1);
        expect(subscriptions.map((subscription) => subscription.kind)).toEqual([
          'bolt11_melt_quote',
        ]);
        expect(subscriptions.map((subscription) => subscription.filters[0])).toEqual([
          'melt-expired-operation-first',
        ]);
        expect(checkPendingOperation).toHaveBeenCalledWith(expiredOperation.id);
      } finally {
        MintService.prototype.isTrustedMint = originalIsTrustedMint;
        MeltOperationService.prototype.checkPendingOperation = originalCheckPending;
        await manager.dispose();
      }
    });

    it('settles a pending melt operation from a canonical melt quote update', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        ...disabledRuntime,
      });

      const operation = makePendingMeltOperation('melt-op-settle', 'melt-quote-settle');
      await repositories.proofRepository.saveProofs('https://mint.test', [
        makeInputProof(operation.inputProofSecrets[0]!, operation.id),
      ]);
      await repositories.meltOperationRepository.create(operation);
      await repositories.meltQuoteRepository.upsertMeltQuote(
        makeMeltQuote(operation.quoteId, 'PENDING'),
      );

      const paidQuote = makeMeltQuote(operation.quoteId, 'PAID', { change: [] });
      await repositories.meltQuoteRepository.upsertMeltQuote(paidQuote);
      await manager.ops.melt.refresh(operation.id);

      await expect(
        repositories.meltOperationRepository.getById(operation.id),
      ).resolves.toMatchObject({
        state: 'finalized',
        finalizedData: { preimage: 'preimage-123' },
      });
      await expect(
        repositories.proofRepository.getProofBySecret(
          operation.mintUrl,
          operation.inputProofSecrets[0]!,
        ),
      ).resolves.toMatchObject({ state: 'spent' });

      await manager.dispose();
    });
  });

  describe('watchers configuration', () => {
    it('should disable mintOperationWatcher when explicitly disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should disable proofStateWatcher when explicitly disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          proofStateWatcher: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);

      await manager.disableMintOperationWatcher();
      await manager.disableMintOperationProcessor();
    });

    it('should disable meltQuoteWatcher when explicitly disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          meltQuoteWatcher: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should disable all watchers when all are explicitly disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should pass options to mintOperationWatcher when not disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: {
            watchExistingPendingOnStart: false,
          },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);

      await manager.dispose();
    });

    it('should enable with options even when disabled is explicitly false', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: {
            disabled: false,
            watchExistingPendingOnStart: true,
          },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);

      await manager.dispose();
    });

    it('should pass options to meltQuoteWatcher when not disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          meltQuoteWatcher: {
            watchExistingPendingQuotesOnStart: false,
          },
        },
      });

      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);

      await manager.dispose();
    });
  });

  describe('processors configuration', () => {
    it('should disable mintOperationProcessor when explicitly disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);

      await manager.disableMintOperationWatcher();
      await manager.disableProofStateWatcher();
    });

    it('should disable meltSettlementProcessor when explicitly disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        processors: {
          meltSettlementProcessor: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);

      await manager.dispose();
    });

    it('should pass options to mintOperationProcessor when not disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        processors: {
          mintOperationProcessor: {
            processIntervalMs: 5000,
            maxRetries: 3,
          },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);

      await manager.dispose();
    });

    it('should enable with options even when disabled is explicitly false', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        processors: {
          mintOperationProcessor: {
            disabled: false,
            processIntervalMs: 1000,
          },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);

      await manager.dispose();
    });

    it('should pass options to meltSettlementProcessor when not disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        processors: {
          meltSettlementProcessor: {
            initializeExistingPendingOperationsOnStart: false,
          },
        },
      });

      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });
  });

  describe('mixed configuration', () => {
    it('should handle mixed enabled/disabled watchers and processors', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: false },
        },
        processors: {
          mintOperationProcessor: { disabled: false },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);

      await manager.disableProofStateWatcher();
      await manager.disableMintOperationProcessor();
    });

    it('should support options with mixed configuration', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: {
            watchExistingPendingOnStart: false,
          },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: {
            processIntervalMs: 10000,
            maxRetries: 5,
          },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });
  });

  describe('plugins', () => {
    it('rejects the removed seed service before an invalid plugin hook can run', async () => {
      const onInit = mock(() => {});
      await expect(
        initializeCoco({
          ...baseConfig,
          ...disabledRuntime,
          plugins: [
            {
              name: 'removed-seed-service-adversary',
              required: ['seedService'],
              onInit,
            } as unknown as Plugin,
          ],
        }),
      ).rejects.toBeInstanceOf(CocoInitializationError);
      expect(onInit).not.toHaveBeenCalled();
    });

    it('keeps privileged implementation objects outside the reachable public graph', async () => {
      const manager = await initializeCoco({ ...baseConfig, ...disabledRuntime });
      const forbidden = new Set([
        'seedService',
        'repositories',
        'pluginHost',
        'mintService',
        'walletService',
        'proofService',
        'eventBus',
        'mintAdapter',
        'mintRequestProvider',
        'transactionRunner',
        'db',
        'database',
      ]);
      const visited = new Set<object>();
      const inspect = (value: unknown, path: string): void => {
        if (value === null || (typeof value !== 'object' && typeof value !== 'function')) return;
        const object = value as object;
        if (visited.has(object)) return;
        visited.add(object);
        for (const key of Reflect.ownKeys(object)) {
          if (typeof key === 'string') expect(forbidden.has(key), `${path}.${key}`).toBe(false);
          const descriptor = Object.getOwnPropertyDescriptor(object, key);
          if (descriptor && 'value' in descriptor && typeof descriptor.value !== 'function') {
            inspect(descriptor.value, `${path}.${String(key)}`);
          }
        }
        const prototype = Object.getPrototypeOf(object);
        if (prototype && prototype !== Object.prototype && prototype !== Function.prototype) {
          for (const key of Reflect.ownKeys(prototype)) {
            if (typeof key === 'string') {
              expect(forbidden.has(key), `${path}.[[Prototype]].${key}`).toBe(false);
            }
          }
        }
      };

      expect((manager as unknown as Record<string, unknown>).seedService).toBeUndefined();
      expect((manager as unknown as Record<string, unknown>).repositories).toBeUndefined();
      inspect(manager, 'manager');
      await manager.dispose();
    });

    it('keeps activation in private state despite reflected fields and forged constructor arguments', async () => {
      const repositories = await createTestMemoryRepositories();
      const onInit = mock(() => {});
      const manager = new (Manager as unknown as new (...args: unknown[]) => Manager)(
        repositories,
        seedGetter,
        new NullLogger(),
        undefined,
        [{ name: 'private-state-adversary', required: [] as const, onInit }],
        undefined,
        undefined,
        undefined,
        undefined,
        Symbol.for('coco-manager-boot-capability'),
      );
      expect(Object.getOwnPropertyNames(manager)).not.toContain('quiescentRecoveryComplete');
      expect(Object.getOwnPropertyNames(manager)).not.toContain('factoryBoot');
      Reflect.set(manager, 'quiescentRecoveryComplete', true);
      Reflect.set(manager, 'factoryBoot', true);

      await expect(manager.initPlugins()).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);
      expect(onInit).not.toHaveBeenCalled();
      expect('completeQuiescentRecovery' in manager).toBe(false);
      await manager.dispose();
    });

    it('runs private factory recovery even when the public reconciliation method is replaced', async () => {
      const originalPublic = Manager.prototype.reconcileLegacyMintQuotes;
      const originalRepository =
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes;
      const publicReplacement = mock(async () => ({ reconciled: [], skipped: [] }));
      let durableRecoveryRan = false;
      let pluginObservedRecovery = false;
      Manager.prototype.reconcileLegacyMintQuotes = publicReplacement;
      MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = mock(async function (
        this: MemoryLegacyMintQuoteRepository,
        mintUrl?: string,
      ) {
        durableRecoveryRan = true;
        return originalRepository.call(this, mintUrl);
      });
      let manager: Manager | undefined;
      try {
        manager = await initializeCoco({
          ...baseConfig,
          ...disabledRuntime,
          plugins: [
            {
              name: 'private-recovery-observer',
              required: [],
              onInit: () => {
                pluginObservedRecovery = durableRecoveryRan;
              },
            },
          ],
        });
      } finally {
        Manager.prototype.reconcileLegacyMintQuotes = originalPublic;
        MemoryLegacyMintQuoteRepository.prototype.getPendingLegacyMintQuotes = originalRepository;
        await manager?.dispose();
      }
      expect(publicReplacement).not.toHaveBeenCalled();
      expect(durableRecoveryRan).toBe(true);
      expect(pluginObservedRecovery).toBe(true);
    });

    it('completes durable recovery before plugins despite combined intrinsic and prototype patches', async () => {
      const operationId = 'manager-private-recovery-init';
      await seedRepositories(async (seedRoot) => {
        await seedRoot.sendOperationRepository.create(
          createSendOperation(
            operationId,
            mintUrl,
            { amount: Amount.from(1), unit: 'sat' },
            { method: 'default', methodData: {} },
          ),
        );
      });

      const originalPublicMethods = {
        reconcile: Manager.prototype.reconcileLegacyMintQuotes,
        send: SendOperationService.prototype.recoverPendingOperations,
        melt: MeltOperationService.prototype.recoverPendingOperations,
        receive: PaymentRequestReceiveService.prototype.recoverPendingAttempts,
        mint: MintOperationService.prototype.recoverPendingOperations,
      };
      const forbiddenPublicCall = mock(async () => {
        throw new Error('public recovery path was invoked');
      });
      Manager.prototype.reconcileLegacyMintQuotes = forbiddenPublicCall;
      SendOperationService.prototype.recoverPendingOperations = forbiddenPublicCall;
      MeltOperationService.prototype.recoverPendingOperations = forbiddenPublicCall;
      PaymentRequestReceiveService.prototype.recoverPendingAttempts = forbiddenPublicCall;
      MintOperationService.prototype.recoverPendingOperations = forbiddenPublicCall;

      const nativeCall = Function.prototype.call;
      const nativeApply = Function.prototype.apply;
      const nativeBind = Function.prototype.bind;
      const nativeReflectApply = Reflect.apply;
      const skipped: string[] = [];
      const classifyRecovery = (target: Function, receiver: unknown): string | undefined => {
        const functionName = target.name;
        const receiverName = (receiver as { constructor?: { name?: string } } | null)?.constructor
          ?.name;
        if (
          (functionName === 'recoverPendingOperations' ||
            functionName === 'recoverPendingAttempts') &&
          (receiverName === 'SendOperationService' ||
            receiverName === 'MeltOperationService' ||
            receiverName === 'PaymentRequestReceiveService' ||
            receiverName === 'MintOperationService')
        ) {
          return `${receiverName}.${functionName}`;
        }
        return undefined;
      };

      Function.prototype.call = function redTeamCall(thisArg: unknown, ...args: unknown[]) {
        const classified = classifyRecovery(this, thisArg);
        if (classified) {
          skipped.push(`call:${classified}`);
          return Promise.resolve();
        }
        return nativeReflectApply(nativeCall, this, [thisArg, ...args]);
      };
      Function.prototype.apply = function redTeamApply(thisArg: unknown, args?: unknown) {
        const classified = classifyRecovery(this, thisArg);
        if (classified) {
          skipped.push(`apply:${classified}`);
          return Promise.resolve();
        }
        return nativeReflectApply(nativeApply, this, [thisArg, args]);
      };
      Function.prototype.bind = function redTeamBind(thisArg: unknown, ...args: unknown[]) {
        const classified = classifyRecovery(this, thisArg);
        if (classified) {
          skipped.push(`bind:${classified}`);
          return () => Promise.resolve();
        }
        return nativeReflectApply(nativeBind, this, [thisArg, ...args]);
      };
      Reflect.apply = function redTeamReflectApply(
        target: Function,
        thisArg: unknown,
        args: ArrayLike<unknown>,
      ) {
        const classified = classifyRecovery(target, thisArg);
        if (classified) {
          skipped.push(`reflect:${classified}`);
          return Promise.resolve();
        }
        return nativeReflectApply(target, thisArg, args);
      } as typeof Reflect.apply;

      let manager: Manager | undefined;
      let pluginObservedCleanup = false;
      let recoveryFactoryReachable = true;
      try {
        manager = await initializeCoco({
          ...baseConfig,
          ...disabledRuntime,
          plugins: [
            {
              name: 'intrinsic-patch-recovery-observer',
              required: ['sendOperationService'],
              async onInit({ services }) {
                pluginObservedCleanup =
                  (await repositories.sendOperationRepository.getById(operationId)) === null;
                const constructor = (
                  services.sendOperationService as unknown as Record<string, unknown>
                ).constructor as unknown as Record<string, unknown> | undefined;
                recoveryFactoryReachable = typeof constructor?.createRecoveryTask === 'function';
              },
            },
          ],
        });
      } finally {
        Reflect.apply = nativeReflectApply;
        Function.prototype.bind = nativeBind;
        Function.prototype.apply = nativeApply;
        Function.prototype.call = nativeCall;
        Manager.prototype.reconcileLegacyMintQuotes = originalPublicMethods.reconcile;
        SendOperationService.prototype.recoverPendingOperations = originalPublicMethods.send;
        MeltOperationService.prototype.recoverPendingOperations = originalPublicMethods.melt;
        PaymentRequestReceiveService.prototype.recoverPendingAttempts =
          originalPublicMethods.receive;
        MintOperationService.prototype.recoverPendingOperations = originalPublicMethods.mint;
        await manager?.dispose();
      }

      expect(skipped).toEqual([]);
      expect(forbiddenPublicCall).not.toHaveBeenCalled();
      expect(pluginObservedCleanup).toBe(true);
      expect(recoveryFactoryReachable).toBe(false);
      expect(await repositories.sendOperationRepository.getById(operationId)).toBeNull();
    });

    it('keeps every directly constructed Manager permanently quiescent', async () => {
      const repositories = await createTestMemoryRepositories();
      const onInit = mock(() => {});
      const onReady = mock(() => {});
      const onDispose = mock(() => {});
      const manager = new Manager(repositories, seedGetter, new NullLogger(), undefined, [
        { name: 'quiescent-plugin-guard', required: [] as const, onInit, onReady, onDispose },
      ]);

      await expect(manager.initPlugins()).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);
      expect(onInit).not.toHaveBeenCalled();
      expect('completeQuiescentRecovery' in manager).toBe(false);
      await expect(manager.enableMintOperationWatcher()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableProofStateWatcher()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMeltQuoteWatcher()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMintOperationProcessor()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMeltSettlementProcessor()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.resumeSubscriptions()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      const runtimeInit = mock(() => {});
      const runtimeDispose = mock(() => {});
      expect(() =>
        manager.use({
          name: 'dynamic-quiescent-plugin',
          required: [] as const,
          onInit: runtimeInit,
          onDispose: runtimeDispose,
        }),
      ).toThrow(WalletAuthorityLifecycleError);
      await manager.dispose();
      expect(onInit).not.toHaveBeenCalled();
      expect(onReady).not.toHaveBeenCalled();
      expect(onDispose).not.toHaveBeenCalled();
      expect(runtimeInit).not.toHaveBeenCalled();
      expect(runtimeDispose).not.toHaveBeenCalled();
    });

    it('should initialize with plugins', async () => {
      const pluginInitMock = mock(() => {});
      const plugin = {
        name: 'test-plugin',
        required: [] as const,
        onInit: pluginInitMock,
      };

      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [plugin],
      });

      // Wait a bit for async plugin initialization
      await new Promise((resolve) => setTimeout(resolve, 100));

      expect(pluginInitMock).toHaveBeenCalled();

      await manager.dispose();
    });

    it('should reject duplicate plugin instance registration', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
        },
      });
      const plugin = {
        name: 'duplicate-plugin',
        required: [] as const,
      };

      manager.use(plugin);

      expect(() => manager.use(plugin)).toThrow('Plugin "duplicate-plugin" is already registered');
    });
  });

  describe('dispose', () => {
    it('should stop owned watchers, processors, and active subscriptions', async () => {
      const manager = await initializeCoco(baseConfig);

      manager.subscriptions.pause();
      await manager.subscriptions.subscribe('https://mint.test', 'bolt11_mint_quote', ['quote-1']);

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);
      expect(manager.subscriptions.getDiagnostics()).toMatchObject({
        activeMintCount: 1,
        transportCount: 1,
      });
      expect(manager.subscriptions.getDiagnostics().subscriptions).toHaveLength(1);

      await manager.dispose();

      expect(() => manager.getRuntimeStatus()).toThrow(WalletAuthorityLifecycleError);
      expect(manager.subscriptions.getDiagnostics()).toMatchObject({
        activeMintCount: 0,
        transportCount: 0,
      });
      expect(manager.subscriptions.getDiagnostics().subscriptions).toHaveLength(0);
    });

    it('should run plugin disposal and cleanup only once', async () => {
      const onDispose = mock(() => {});
      const cleanup = mock(() => {});

      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [
          {
            name: 'dispose-plugin',
            required: [] as const,
            onInit: () => cleanup,
            onDispose,
          },
        ],
      });

      await manager.dispose();
      await manager.dispose();

      expect(onDispose).toHaveBeenCalledTimes(1);
      expect(cleanup).toHaveBeenCalledTimes(1);
    });

    it('should not recreate subscription transports during plugin cleanup', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [
          {
            name: 'subscription-cleanup-plugin',
            required: ['subscriptions'] as const,
            onInit: async ({ services }) => {
              services.subscriptions.pause();
              const subscription = await services.subscriptions.subscribe(
                'https://mint.test',
                'bolt11_mint_quote',
                ['quote-plugin'],
              );
              return () => subscription.unsubscribe();
            },
          },
        ],
      });
      expect(manager.subscriptions.getDiagnostics()).toMatchObject({
        activeMintCount: 1,
        transportCount: 1,
      });
      expect(manager.subscriptions.getDiagnostics().subscriptions).toHaveLength(1);

      await manager.dispose();

      expect(manager.subscriptions.getDiagnostics()).toMatchObject({
        activeMintCount: 0,
        transportCount: 0,
      });
      expect(manager.subscriptions.getDiagnostics().subscriptions).toHaveLength(0);
    });

    it('should not restart background work after disposal', async () => {
      const manager = await initializeCoco(baseConfig);

      await manager.dispose();
      await expect(manager.resumeSubscriptions()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMintOperationWatcher()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableProofStateWatcher()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMintOperationProcessor()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMeltQuoteWatcher()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );
      await expect(manager.enableMeltSettlementProcessor()).rejects.toBeInstanceOf(
        WalletAuthorityLifecycleError,
      );

      expect(() => manager.getRuntimeStatus()).toThrow(WalletAuthorityLifecycleError);
    });
  });

  describe('edge cases', () => {
    it('should handle empty watchers config object', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {},
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);

      await manager.dispose();
    });

    it('should handle empty processors config object', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        processors: {},
      });

      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should handle empty config objects for both watchers and processors', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {},
        processors: {},
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should handle all features disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);

      // Should still have API access
      expect(manager.mint).toBeDefined();
      expect(manager.wallet).toBeDefined();
    });
  });

  describe('API availability', () => {
    it('should expose all public APIs regardless of watcher/processor config', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });

      expect(manager.mint).toBeDefined();
      expect(manager.wallet).toBeDefined();
      expect(manager.history).toBeDefined();
      expect(manager.subscriptions).toBeDefined();
    });

    it('exposes typed event subscription helpers and manager-owned event side effects', async () => {
      const capture = capturePlugin('counterService');
      const manager = await initializeCoco({
        ...baseConfig,
        plugins: [capture.plugin],
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });

      const observedCounters: number[] = [];
      const onCounter = ({ counter }: CoreEvents['counter:updated']) => {
        observedCounters.push(counter);
      };
      manager.on('counter:updated', onCounter);
      await capture.services().counterService.overwriteCounter('https://mint.test', 'keyset-1', 1);
      manager.off('counter:updated', onCounter);
      await capture.services().counterService.overwriteCounter('https://mint.test', 'keyset-1', 2);

      const onceCounters: number[] = [];
      manager.once('counter:updated', ({ counter }) => {
        onceCounters.push(counter);
      });
      await capture.services().counterService.overwriteCounter('https://mint.test', 'keyset-1', 3);
      await capture.services().counterService.overwriteCounter('https://mint.test', 'keyset-1', 4);

      expect(observedCounters).toEqual([1]);
      expect(onceCounters).toEqual([3]);
    });

    it('requeues pending mint operations from canonical accounting', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });
      const operation = makePendingMintOperation('mint-op-paid', 'quote-paid');
      await repositories.mintOperationRepository.create(operation);
      await repositories.mintQuoteRepository.upsertMintQuote(
        mintQuoteFromBolt11Response(operation.mintUrl, {
          quote: operation.quoteId,
          request: operation.request,
          amount: operation.amount,
          unit: operation.unit,
          expiry: Math.floor(Date.now() / 1000) + 3600,
          state: 'UNPAID',
          amount_paid: operation.amount,
          amount_issued: Amount.zero(),
        }),
      );

      const requeuedOperationIds: string[] = [];
      manager.on('mint-op:requeue', ({ operationId }) => {
        requeuedOperationIds.push(operationId);
      });

      const originalIsTrustedMint = MintService.prototype.isTrustedMint;
      MintService.prototype.isTrustedMint = mock(async () => true);
      try {
        const result = await manager.requeuePaidMintQuotes();

        expect(result.requeued).toEqual([operation.quoteId]);
        expect(requeuedOperationIds).toEqual([operation.id]);
      } finally {
        MintService.prototype.isTrustedMint = originalIsTrustedMint;
        await manager.dispose();
      }
    });
  });

  describe('pause and resume subscriptions', () => {
    it('should pause and stop all watchers and processors', async () => {
      const manager = await initializeCoco(baseConfig);

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.pauseSubscriptions();

      // After pause, watchers and processor are disabled (set to undefined)
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);
    });

    it('should resume and restart all watchers and processors', async () => {
      const manager = await initializeCoco(baseConfig);

      await manager.pauseSubscriptions();
      await manager.resumeSubscriptions();

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should be idempotent - multiple pause calls should not error', async () => {
      const manager = await initializeCoco(baseConfig);

      await manager.pauseSubscriptions();
      await manager.pauseSubscriptions();
      await manager.pauseSubscriptions();

      // After pause, watchers and processor are disabled (set to undefined)
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);
    });

    it('should be idempotent - multiple resume calls should not error', async () => {
      const manager = await initializeCoco(baseConfig);

      await manager.pauseSubscriptions();
      await manager.resumeSubscriptions();
      await manager.resumeSubscriptions();
      await manager.resumeSubscriptions();

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should handle resume without prior pause (OS connection teardown scenario)', async () => {
      const manager = await initializeCoco(baseConfig);

      // Simulate OS killing connections - just call resume without pause
      await manager.resumeSubscriptions();

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should respect original configuration - disabled watchers stay disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: false },
          meltQuoteWatcher: { disabled: false },
        },
        processors: {
          mintOperationProcessor: { disabled: false },
          meltSettlementProcessor: { disabled: false },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.pauseSubscriptions();
      await manager.resumeSubscriptions();

      // mintOperationWatcher should remain undefined (was disabled)
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      // Others should be running again
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(true);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(true);

      await manager.dispose();
    });

    it('should respect original configuration - disabled processor stays disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: false },
          proofStateWatcher: { disabled: false },
          meltQuoteWatcher: { disabled: false },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });

      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);

      await manager.pauseSubscriptions();
      await manager.resumeSubscriptions();

      // Watchers should be running again
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(true);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(true);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(true);
      // Processor should remain undefined (was disabled)
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);

      await manager.dispose();
    });

    it('should handle all features disabled', async () => {
      const manager = await initializeCoco({
        ...baseConfig,
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });

      await manager.pauseSubscriptions();
      await manager.resumeSubscriptions();

      // All should remain undefined
      expect(manager.getRuntimeStatus().mintOperationWatcher).toBe(false);
      expect(manager.getRuntimeStatus().proofStateWatcher).toBe(false);
      expect(manager.getRuntimeStatus().meltQuoteWatcher).toBe(false);
      expect(manager.getRuntimeStatus().mintOperationProcessor).toBe(false);
      expect(manager.getRuntimeStatus().meltSettlementProcessor).toBe(false);
    });
  });
});
