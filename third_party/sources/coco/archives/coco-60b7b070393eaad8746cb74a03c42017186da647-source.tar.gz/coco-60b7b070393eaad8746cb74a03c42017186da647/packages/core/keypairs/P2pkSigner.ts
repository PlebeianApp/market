import type { Proof } from '@cashu/cashu-ts';
import { schnorr, secp256k1 } from '@noble/curves/secp256k1.js';
import { bytesToHex } from '@noble/curves/utils.js';
import { sha256 } from '@noble/hashes/sha2.js';
import type { KeypairQueries } from './KeypairQueries.ts';
import { ProofValidationError } from '@core/models/Error.ts';

/** Canonical NUT-11 signer identity: lowercase x-coordinate without 02/03 parity. */
export function canonicalP2pkKeyX(publicKey: string): string {
  const normalized = publicKey.toLowerCase();
  const x =
    normalized.length === 66 && (normalized.startsWith('02') || normalized.startsWith('03'))
      ? normalized.slice(2)
      : normalized;
  if (!/^[0-9a-f]{64}$/.test(x)) {
    throw new ProofValidationError('Invalid P2PK public key');
  }
  try {
    secp256k1.Point.fromHex(`02${x}`);
  } catch {
    throw new ProofValidationError('Invalid P2PK public key');
  }
  return x;
}

/** Validate a NUT-11 condition key's compressed wire form before reducing it to x-only identity. */
export function canonicalP2pkWireKeyX(publicKey: string): string {
  const normalized = publicKey.toLowerCase();
  if (
    !/^[0-9a-f]{66}$/.test(normalized) ||
    (!normalized.startsWith('02') && !normalized.startsWith('03'))
  ) {
    throw new ProofValidationError('P2PK condition key must be a compressed secp256k1 key');
  }
  try {
    secp256k1.Point.fromHex(normalized);
  } catch {
    throw new ProofValidationError('P2PK condition key is not a valid secp256k1 point');
  }
  return normalized.slice(2);
}

/** Signs with existing keys. Never allocates a key or writes Wallet state. */
export interface P2pkSigner {
  signProof(proof: Proof, publicKey: string): Promise<Proof>;
}

export class KeypairP2pkSigner implements P2pkSigner {
  constructor(private readonly keys: Pick<KeypairQueries, 'getAllPersistedKeyPairs'>) {}

  async signProof(proof: Proof, publicKey: string): Promise<Proof> {
    if (!proof.secret || typeof proof.secret !== 'string') {
      throw new Error('Proof secret is required and must be a string');
    }
    const requestedX = canonicalP2pkKeyX(publicKey);
    const keyPairs = await this.keys.getAllPersistedKeyPairs('p2pk');
    const keyPair = keyPairs.find((candidate) => {
      try {
        return canonicalP2pkKeyX(candidate.publicKeyHex) === requestedX;
      } catch {
        return false;
      }
    });
    if (!keyPair) {
      throw new ProofValidationError('No persisted refund authority matches the proof condition');
    }
    const derivedX = bytesToHex(schnorr.getPublicKey(keyPair.secretKey));
    if (derivedX !== requestedX) {
      throw new ProofValidationError('Persisted refund authority does not match its private key');
    }
    const signature = schnorr.sign(
      sha256(new TextEncoder().encode(proof.secret)),
      keyPair.secretKey,
    );
    return { ...proof, witness: JSON.stringify({ signatures: [bytesToHex(signature)] }) };
  }
}
