/**
 * Owns asynchronous commands and repository calls for one transaction attempt. Failure revokes
 * further work; calls already executing settle before the adapter may roll back or retry.
 * This helper has no authority to open, commit, or roll back a transaction.
 */
const NativeMap = Map;
const NativePromise = Promise;
const NativeProxy = Proxy;
const NativeSet = Set;
const NativeWeakMap = WeakMap;
const nativeCreate = Object.create;
const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const nativeGetPrototypeOf = Object.getPrototypeOf;
const nativeReflectApply = Reflect.apply;
const nativeReflectGet = Reflect.get;
const nativeMapGet = Map.prototype.get;
const nativeMapHas = Map.prototype.has;
const nativeMapSet = Map.prototype.set;
const nativePromiseAll = Promise.all;
const nativePromiseReject = Promise.reject;
const nativePromiseResolve = Promise.resolve;
const nativePromiseThen = Promise.prototype.then;
const nativeSetAdd = Set.prototype.add;
const nativeSetDelete = Set.prototype.delete;
const nativeSetSize = nativeGetOwnPropertyDescriptor(Set.prototype, 'size')!.get!;
const nativeSetValues = Set.prototype.values;
const nativeWeakMapGet = WeakMap.prototype.get;
const nativeWeakMapHas = WeakMap.prototype.has;
const nativeWeakMapSet = WeakMap.prototype.set;
const nativeSetIteratorNext = nativeGetPrototypeOf(
  nativeReflectApply(nativeSetValues, new NativeSet(), []),
).next as () => IteratorResult<unknown>;

export class TransactionLifetime {
  private readonly pending = new NativeSet<Promise<void>>();
  private failure: { error: unknown } | undefined;
  private closed = false;

  /** Wrap modules on access, preserving inherited bindings and each getter's original receiver. */
  bind<T extends { [K in keyof T]: object }>(modules: T): T {
    const bound = new NativeWeakMap<object, object>();
    // A null-prototype target avoids exposing the source shape and permits lifetime wrappers even
    // when repository facades deliberately contain non-configurable functions.
    return new NativeProxy(nativeCreate(null) as T, {
      get: (_target, property) => {
        const module: unknown = nativeReflectGet(modules, property, modules);
        if (typeof module !== 'object' || module === null) return module;
        if (!(nativeReflectApply(nativeWeakMapHas, bound, [module]) as boolean)) {
          nativeReflectApply(nativeWeakMapSet, bound, [module, this.bindModule(module)]);
        }
        return nativeReflectApply(nativeWeakMapGet, bound, [module]);
      },
    });
  }

  async run<T>(work: () => Promise<T>): Promise<T> {
    let result!: T;
    try {
      try {
        result = await work();
      } catch (error) {
        this.fail(error);
      }

      // A callback may finish before its siblings (Promise.all failure, Promise.race, or an
      // omitted await). Draining may discover further calls made by an executing command.
      while ((nativeReflectApply(nativeSetSize, this.pending, []) as number) > 0) {
        const snapshot: Promise<void>[] = [];
        const iterator = nativeReflectApply(nativeSetValues, this.pending, []) as SetIterator<
          Promise<void>
        >;
        while (true) {
          const next = nativeReflectApply(nativeSetIteratorNext, iterator, []) as IteratorResult<
            Promise<void>
          >;
          if (next.done) break;
          snapshot[snapshot.length] = next.value;
        }
        await nativeReflectApply(nativePromiseAll, NativePromise, [snapshot]);
      }
      if (this.failure) throw this.failure.error;
      return result;
    } finally {
      this.closed = true;
    }
  }

  private bindModule<T extends object>(module: T): T {
    const methods = new NativeMap<PropertyKey, unknown>();
    return new NativeProxy(nativeCreate(null) as T, {
      get: (_target, property) => {
        const value: unknown = nativeReflectGet(module, property, module);
        if (typeof value !== 'function') return value;
        if (!(nativeReflectApply(nativeMapHas, methods, [property]) as boolean)) {
          nativeReflectApply(nativeMapSet, methods, [
            property,
            (...args: unknown[]) =>
              this.invoke(() => nativeReflectApply(value, module, args) as Promise<unknown>),
          ]);
        }
        return nativeReflectApply(nativeMapGet, methods, [property]);
      },
    });
  }

  private invoke<T>(call: () => Promise<T>): Promise<T> {
    let result: Promise<T>;
    try {
      if (this.closed) throw new Error('Wallet transaction scope is closed');
      if (this.failure) throw this.failure.error;
      result = nativeReflectApply(nativePromiseResolve, NativePromise, [call()]) as Promise<T>;
    } catch (error) {
      this.fail(error);
      result = nativeReflectApply(nativePromiseReject, NativePromise, [error]) as Promise<T>;
    }

    const observed = nativeReflectApply(nativePromiseThen, result, [
      (value: T) => value,
      (error: unknown) => {
        this.fail(error);
        throw error;
      },
    ]) as Promise<T>;
    // Observe every rejection even when the caller drops its promise. The first failure is
    // rethrown by run(), so catching a command failure cannot commit a partial transaction.
    const settled = nativeReflectApply(nativePromiseThen, observed, [
      () => {
        nativeReflectApply(nativeSetDelete, this.pending, [settled]);
      },
      () => {
        nativeReflectApply(nativeSetDelete, this.pending, [settled]);
      },
    ]) as Promise<void>;
    nativeReflectApply(nativeSetAdd, this.pending, [settled]);
    return observed;
  }

  private fail(error: unknown): void {
    this.failure ??= { error };
  }
}
