import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';

let ownerSequence = 0;

/**
 * Unit-test fixture only. Production code must use initializeCoco() or explicitly perform the
 * repository init/acquire lifecycle before constructing services.
 */
export async function activateTestMemoryRepositories<T extends MemoryRepositories>(
  repositories: T,
): Promise<T> {
  if (repositories.getAuthorityState() !== 'unacquired') return repositories;
  await repositories.init();
  await repositories.acquireAuthority({
    namespace: 'core-test-wallet',
    ownerId: `core-test-${++ownerSequence}`,
  });
  return repositories;
}

/** Test-only constructor kept outside every production package export. */
export async function createTestMemoryRepositories(): Promise<MemoryRepositories> {
  return activateTestMemoryRepositories(new MemoryRepositories());
}
