import { describe, expect, test } from 'bun:test';

const CORE_ROOT = new URL('../..', import.meta.url).pathname.replace(/\/$/, '');
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

async function probeDuplicateEvaluators(
  label: string,
  winnerModulePath: string,
  loserModulePaths: readonly string[],
): Promise<void> {
  const winnerCore: any = await import(winnerModulePath);
  const loserCores = await Promise.all(
    loserModulePaths.map((path) => import(path) as Promise<any>),
  );
  const root = new winnerCore.MemoryRepositories();
  const originalInit = root.init.bind(root);
  let initCalls = 0;
  root.init = async () => {
    initCalls += 1;
    return originalInit();
  };
  const pluginRuns: string[] = [];
  const mintUrl = `https://round9-${label}.invalid`;
  const makeConfig = (owner: string, counter: number) => ({
    repo: root,
    seedGetter: async () => new Uint8Array(64).fill(0x59),
    authority: { namespace: `round9-${label}`, ownerId: 'shared-owner' },
    plugins: [
      {
        name: `round9-${label}-${owner}`,
        required: ['counterService'] as const,
        async onInit({ services }: any) {
          pluginRuns.push(owner);
          await services.counterService.overwriteCounter(mintUrl, 'keyset', counter);
        },
      },
    ],
    ...disabledRuntime,
  });

  const winner = await winnerCore.initializeCoco(makeConfig('winner', 1));
  const authority = root.getAuthority();
  expect(authority?.generation).toBe(1);
  expect(initCalls).toBe(1);
  initCalls = 0;
  try {
    for (let index = 0; index < loserCores.length; index += 1) {
      await expect(
        loserCores[index].initializeCoco(makeConfig(`loser-${index}`, index + 2)),
      ).rejects.toThrow('already attached to an active Manager');
    }
    const transparent = new Proxy(root, {});
    await expect(
      loserCores[0].initializeCoco({ ...makeConfig('proxy-loser', 99), repo: transparent }),
    ).rejects.toThrow('already attached to an active Manager');

    expect(root.getAuthority()).toEqual(authority);
    expect(initCalls).toBe(0);
    expect(pluginRuns).toEqual(['winner']);
    expect((await root.counterRepository.getCounter(mintUrl, 'keyset'))?.counter).toBe(1);
  } finally {
    await winner.dispose();
  }

  expect(root.getAuthorityState()).toBe('released');
  const postDisposeToken = root.claimSessionAttachment();
  expect(root.releaseSessionAttachment(postDisposeToken)).toBe(true);
}

describe('root-owned Manager session attachment', () => {
  test('coordinates independently evaluated source and emitted Core modules', async () => {
    await probeDuplicateEvaluators('source-winner', `${CORE_ROOT}/index.ts`, [
      `${CORE_ROOT}/index.ts?round9-source-duplicate`,
      `${CORE_ROOT}/dist/index.js`,
      `${CORE_ROOT}/dist/index.js?round9-dist-duplicate-a`,
    ]);
  });

  test('coordinates an emitted winner with source and duplicate emitted modules', async () => {
    await probeDuplicateEvaluators('dist-winner', `${CORE_ROOT}/dist/index.js`, [
      `${CORE_ROOT}/dist/index.js?round9-dist-duplicate-b`,
      `${CORE_ROOT}/index.ts?round9-source-duplicate-b`,
    ]);
  });

  test('admits exactly one concurrent initializer across independent evaluators', async () => {
    const source: any = await import(`${CORE_ROOT}/index.ts?round9-concurrent-source`);
    const dist: any = await import(`${CORE_ROOT}/dist/index.js?round9-concurrent-dist`);
    const duplicateDist: any = await import(
      `${CORE_ROOT}/dist/index.js?round9-concurrent-dist-copy`
    );
    const root = new source.MemoryRepositories();
    const pluginRuns: string[] = [];
    const config = (label: string) => ({
      repo: root,
      seedGetter: async () => new Uint8Array(64),
      plugins: [
        {
          name: `round9-concurrent-${label}`,
          onInit: () => {
            pluginRuns.push(label);
          },
        },
      ],
      ...disabledRuntime,
    });
    const outcomes = await Promise.allSettled([
      source.initializeCoco(config('source')),
      dist.initializeCoco(config('dist')),
      duplicateDist.initializeCoco(config('duplicate-dist')),
    ]);
    const winners = outcomes.filter(
      (outcome): outcome is PromiseFulfilledResult<any> => outcome.status === 'fulfilled',
    );
    const losers = outcomes.filter(
      (outcome): outcome is PromiseRejectedResult => outcome.status === 'rejected',
    );
    expect(winners).toHaveLength(1);
    expect(losers).toHaveLength(2);
    expect(losers.every(({ reason }) => String(reason).includes('already attached'))).toBe(true);
    expect(pluginRuns).toHaveLength(1);
    expect(root.getAuthority()?.generation).toBe(1);
    const [winner] = winners;
    if (!winner) throw new Error('Concurrent attachment test did not produce a winner');
    await winner.value.dispose();
  });

  test('rejects a re-entrant initializer before repository startup', async () => {
    const source: any = await import(`${CORE_ROOT}/index.ts?round9-reentrant-source`);
    const dist: any = await import(`${CORE_ROOT}/dist/index.js?round9-reentrant-dist`);
    const root = new source.MemoryRepositories();
    const originalInit = root.init.bind(root);
    let nested: Promise<unknown> | undefined;
    let nestedPluginRuns = 0;
    root.init = async () => {
      const nestedAttempt = dist.initializeCoco({
        repo: root,
        seedGetter: async () => new Uint8Array(64),
        plugins: [
          {
            name: 'round9-reentrant-loser',
            onInit: () => {
              nestedPluginRuns += 1;
            },
          },
        ],
        ...disabledRuntime,
      });
      nested = nestedAttempt;
      void nestedAttempt.catch(() => undefined);
      await originalInit();
    };

    const winner = await source.initializeCoco({
      repo: root,
      seedGetter: async () => new Uint8Array(64),
      ...disabledRuntime,
    });
    try {
      expect(nested).toBeDefined();
      await expect(nested!).rejects.toThrow('already attached to an active Manager');
      expect(nestedPluginRuns).toBe(0);
      expect(root.getAuthority()?.generation).toBe(1);
    } finally {
      await winner.dispose();
    }
  });
});
