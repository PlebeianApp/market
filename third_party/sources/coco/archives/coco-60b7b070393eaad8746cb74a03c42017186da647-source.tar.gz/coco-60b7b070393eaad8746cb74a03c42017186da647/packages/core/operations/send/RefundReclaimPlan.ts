import { bytesToHex } from '@noble/curves/utils.js';
import { hmac } from '@noble/hashes/hmac.js';
import { sha256 } from '@noble/hashes/sha2.js';
import type { SerializedOutput, SerializedOutputData, StoredBlindedMessage } from '@core/utils.ts';

export interface RefundReclaimPlan {
  version: 1;
  operationId: string;
  mintUrl: string;
  unit: string;
  inputProofSecrets: string[];
  inputOwnership: 'created' | 'used';
  spendingPath: 'refund';
  conditionFingerprint: string;
  refundPublicKeyX: string;
  outputData: SerializedOutputData;
  allocation: { keysetId: string; counterStart: number; counterEnd: number };
}

export type CommittedRefundReclaimPlan = RefundReclaimPlan & { planCommitment: string };

/** Flat, immutable completion authority captured before remote I/O. */
export interface RefundReclaimAuthorization {
  version: 1;
  operationId: string;
  canonicalPlan: string;
  operationBinding: string;
  planCommitment: string;
}

const DOMAIN = 'coco:p2pk-refund-plan:v1:';
const PLAN_KEYS = [
  'version',
  'operationId',
  'mintUrl',
  'unit',
  'inputProofSecrets',
  'inputOwnership',
  'spendingPath',
  'conditionFingerprint',
  'refundPublicKeyX',
  'outputData',
  'allocation',
] as const;

/** Seed-authenticated commitment over every persisted reclaim-plan field. */
export function commitRefundReclaimPlan(
  plan: RefundReclaimPlan | CommittedRefundReclaimPlan,
  seed: Uint8Array,
): string {
  if (hasOwnDataProperty(plan, 'planCommitment')) {
    const committed = parseCommittedRefundReclaimPlan(plan);
    return commitCanonical(serializeRefundPlanWithoutCommitment(committed), seed);
  }
  assertRefundReclaimPlan(plan, false);
  return commitCanonical(serializeRefundValue(plan), seed);
}

/** Strictly parse the persisted plan before it can influence Restore or reclaim I/O. */
export function parseCommittedRefundReclaimPlan(value: unknown): CommittedRefundReclaimPlan {
  assertRefundReclaimPlan(value, true);
  return value as CommittedRefundReclaimPlan;
}

/** Verify a strict persisted plan against its original seed-authenticated commitment. */
export function verifyCommittedRefundReclaimPlan(
  value: unknown,
  seed: Uint8Array,
): CommittedRefundReclaimPlan {
  const plan = parseCommittedRefundReclaimPlan(value);
  if (commitCanonical(serializeRefundPlanWithoutCommitment(plan), seed) !== plan.planCommitment) {
    throw new TypeError('Refund reclaim plan commitment is invalid');
  }
  return plan;
}

/** Canonical byte representation used to pin an authenticated durable plan across remote I/O. */
export function serializeCommittedRefundReclaimPlan(plan: CommittedRefundReclaimPlan): string {
  parseCommittedRefundReclaimPlan(plan);
  return serializeRefundValue(plan);
}

export function cloneCommittedRefundReclaimPlan(
  plan: CommittedRefundReclaimPlan,
): CommittedRefundReclaimPlan {
  parseCommittedRefundReclaimPlan(plan);
  return clonePlanValue(plan) as CommittedRefundReclaimPlan;
}

/** Canonical representation for operation fields bound to the authenticated refund request. */
export function serializeRefundOperationBinding(binding: unknown): string {
  return serializeRefundValue(binding);
}

/**
 * Deterministic, type-sensitive representation. Accessors, custom prototypes, symbols, holes,
 * undefined values, non-enumerable fields, and array extensions are rejected before evaluation.
 */
export function serializeRefundValue(value: unknown): string {
  return JSON.stringify(canonicalPlanValue(value, '$'));
}

/** Create transport data that shares no mutable object with authenticated completion state. */
export function cloneRefundOutputData(outputData: SerializedOutputData): SerializedOutputData {
  assertSerializedOutputData(outputData, '$.outputData');
  return clonePlanValue(outputData) as SerializedOutputData;
}

/** Keep the service-owned request template immutable; transports receive clones of this value. */
export function freezeRefundOutputData(outputData: SerializedOutputData): SerializedOutputData {
  return freezePlanValue(cloneRefundOutputData(outputData)) as SerializedOutputData;
}

function serializeRefundPlanWithoutCommitment(plan: CommittedRefundReclaimPlan): string {
  const unsigned = Object.create(null) as Record<string, unknown>;
  for (const key of PLAN_KEYS) unsigned[key] = readDataProperty(plan, key, '$');
  return serializeRefundValue(unsigned);
}

function commitCanonical(canonical: string, seed: Uint8Array): string {
  return bytesToHex(hmac(sha256, seed, new TextEncoder().encode(DOMAIN + canonical)));
}

function assertRefundReclaimPlan(value: unknown, committed: boolean): void {
  const path = '$';
  const plan = assertExactRecord(
    value,
    committed ? [...PLAN_KEYS, 'planCommitment'] : [...PLAN_KEYS],
    path,
  );
  assertLiteral(readDataProperty(plan, 'version', path), 1, `${path}.version`);
  assertNonEmptyString(readDataProperty(plan, 'operationId', path), `${path}.operationId`);
  assertNonEmptyString(readDataProperty(plan, 'mintUrl', path), `${path}.mintUrl`);
  assertNonEmptyString(readDataProperty(plan, 'unit', path), `${path}.unit`);
  assertStringArray(readDataProperty(plan, 'inputProofSecrets', path), `${path}.inputProofSecrets`);
  assertOneOf(
    readDataProperty(plan, 'inputOwnership', path),
    ['created', 'used'],
    `${path}.inputOwnership`,
  );
  assertLiteral(readDataProperty(plan, 'spendingPath', path), 'refund', `${path}.spendingPath`);
  assertNonEmptyString(
    readDataProperty(plan, 'conditionFingerprint', path),
    `${path}.conditionFingerprint`,
  );
  assertNonEmptyString(
    readDataProperty(plan, 'refundPublicKeyX', path),
    `${path}.refundPublicKeyX`,
  );
  assertSerializedOutputData(readDataProperty(plan, 'outputData', path), `${path}.outputData`);
  const allocation = assertExactRecord(
    readDataProperty(plan, 'allocation', path),
    ['keysetId', 'counterStart', 'counterEnd'],
    `${path}.allocation`,
  );
  assertNonEmptyString(
    readDataProperty(allocation, 'keysetId', `${path}.allocation`),
    `${path}.allocation.keysetId`,
  );
  assertSafeInteger(
    readDataProperty(allocation, 'counterStart', `${path}.allocation`),
    `${path}.allocation.counterStart`,
  );
  assertSafeInteger(
    readDataProperty(allocation, 'counterEnd', `${path}.allocation`),
    `${path}.allocation.counterEnd`,
  );
  if (committed) {
    assertNonEmptyString(readDataProperty(plan, 'planCommitment', path), `${path}.planCommitment`);
  }
}

function assertSerializedOutputData(
  value: unknown,
  path: string,
): asserts value is SerializedOutputData {
  const data = assertExactRecord(value, ['keep', 'send'], path);
  assertOutputArray(readDataProperty(data, 'keep', path), `${path}.keep`);
  assertOutputArray(readDataProperty(data, 'send', path), `${path}.send`);
}

function assertOutputArray(value: unknown, path: string): asserts value is SerializedOutput[] {
  assertExactArray(value, path);
  for (let index = 0; index < value.length; index++)
    assertOutput(value[index], `${path}[${index}]`);
}

function assertOutput(value: unknown, path: string): asserts value is SerializedOutput {
  const required = ['blindedMessage', 'blindingFactor', 'secret'];
  const record = assertExactRecord(
    value,
    hasOwnDataProperty(value, 'ephemeralE') ? [...required, 'ephemeralE'] : required,
    path,
  );
  assertBlindedMessage(readDataProperty(record, 'blindedMessage', path), `${path}.blindedMessage`);
  assertNonEmptyString(readDataProperty(record, 'blindingFactor', path), `${path}.blindingFactor`);
  assertNonEmptyString(readDataProperty(record, 'secret', path), `${path}.secret`);
  if (hasOwnDataProperty(record, 'ephemeralE')) {
    assertNonEmptyString(readDataProperty(record, 'ephemeralE', path), `${path}.ephemeralE`);
  }
}

function assertBlindedMessage(value: unknown, path: string): asserts value is StoredBlindedMessage {
  const record = assertExactRecord(value, ['amount', 'id', 'B_'], path);
  const amount = readDataProperty(record, 'amount', path);
  if (typeof amount !== 'string' && typeof amount !== 'number') {
    throw new TypeError(`${path}.amount must be a string or number`);
  }
  if (typeof amount === 'number' && !Number.isFinite(amount)) {
    throw new TypeError(`${path}.amount must be finite`);
  }
  assertNonEmptyString(readDataProperty(record, 'id', path), `${path}.id`);
  assertNonEmptyString(readDataProperty(record, 'B_', path), `${path}.B_`);
}

function canonicalPlanValue(value: unknown, path: string): unknown {
  if (value === null) return ['null'];
  if (typeof value === 'string') return ['string', value];
  if (typeof value === 'boolean') return ['boolean', value];
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new TypeError(`${path} contains a non-finite number`);
    return ['number', Object.is(value, -0) ? '-0' : String(value)];
  }
  if (Array.isArray(value)) {
    assertExactArray(value, path);
    return ['array', value.map((entry, index) => canonicalPlanValue(entry, `${path}[${index}]`))];
  }
  if (typeof value === 'object') {
    const record = assertPlainRecord(value, path);
    return [
      'object',
      Object.keys(record)
        .sort()
        .map((key) => [
          key,
          canonicalPlanValue(readDataProperty(record, key, path), `${path}.${key}`),
        ]),
    ];
  }
  throw new TypeError(`${path} contains unsupported ${typeof value} data`);
}

function assertPlainRecord(value: unknown, path: string): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError(`${path} must be a plain object`);
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    throw new TypeError(`${path} must have an intrinsic plain-object prototype`);
  }
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== 'string') throw new TypeError(`${path} contains a symbol property`);
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) {
      throw new TypeError(`${path}.${key} must be an enumerable data property`);
    }
    if (descriptor.value === undefined) throw new TypeError(`${path}.${key} must not be undefined`);
  }
  return value as Record<string, unknown>;
}

function assertExactRecord(
  value: unknown,
  expectedKeys: readonly string[],
  path: string,
): Record<string, unknown> {
  const record = assertPlainRecord(value, path);
  const actual = Object.keys(record).sort();
  const expected = [...expectedKeys].sort();
  if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) {
    throw new TypeError(`${path} has an unexpected or missing field`);
  }
  return record;
}

function assertExactArray(value: unknown, path: string): asserts value is unknown[] {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) {
    throw new TypeError(`${path} must be an intrinsic array`);
  }
  const expectedKeys = new Set<string>(['length']);
  for (let index = 0; index < value.length; index++) expectedKeys.add(String(index));
  const actualKeys = Reflect.ownKeys(value);
  for (const key of actualKeys) {
    if (typeof key !== 'string' || !expectedKeys.has(key)) {
      throw new TypeError(`${path} contains an array extension`);
    }
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !('value' in descriptor))
      throw new TypeError(`${path} contains an accessor`);
    if (key !== 'length' && (!descriptor.enumerable || descriptor.value === undefined)) {
      throw new TypeError(`${path}[${key}] must be an enumerable defined value`);
    }
  }
  if (actualKeys.length !== expectedKeys.size) throw new TypeError(`${path} contains a hole`);
}

function readDataProperty(record: object, key: string, path: string): unknown {
  const descriptor = Object.getOwnPropertyDescriptor(record, key);
  if (!descriptor || !('value' in descriptor)) throw new TypeError(`${path}.${key} is not data`);
  return descriptor.value;
}

function hasOwnDataProperty(value: unknown, key: string): boolean {
  if (value === null || typeof value !== 'object') return false;
  const descriptor = Object.getOwnPropertyDescriptor(value, key);
  if (!descriptor) return false;
  if (!('value' in descriptor)) throw new TypeError(`$.${key} is not data`);
  return true;
}

function assertStringArray(value: unknown, path: string): asserts value is string[] {
  assertExactArray(value, path);
  for (let index = 0; index < value.length; index++) {
    if (typeof value[index] !== 'string' || !value[index]) {
      throw new TypeError(`${path}[${index}] must be a non-empty string`);
    }
  }
}

function assertNonEmptyString(value: unknown, path: string): asserts value is string {
  if (typeof value !== 'string' || value.length === 0)
    throw new TypeError(`${path} must be a string`);
}

function assertSafeInteger(value: unknown, path: string): asserts value is number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) {
    throw new TypeError(`${path} must be a safe integer`);
  }
}

function assertLiteral<T extends string | number>(value: unknown, expected: T, path: string): void {
  if (value !== expected) throw new TypeError(`${path} is invalid`);
}

function assertOneOf<T extends string>(value: unknown, expected: readonly T[], path: string): void {
  if (typeof value !== 'string' || !expected.includes(value as T)) {
    throw new TypeError(`${path} is invalid`);
  }
}

function clonePlanValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(clonePlanValue);
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(
      Object.keys(value).map((key) => [key, clonePlanValue(readDataProperty(value, key, '$'))]),
    );
  }
  return value;
}

function freezePlanValue(value: unknown): unknown {
  if (Array.isArray(value)) {
    for (const entry of value) freezePlanValue(entry);
    return Object.freeze(value);
  }
  if (value !== null && typeof value === 'object') {
    for (const entry of Object.values(value as Record<string, unknown>)) freezePlanValue(entry);
    return Object.freeze(value);
  }
  return value;
}
