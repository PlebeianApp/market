import type { Keypair, KeypairPurpose } from '../../models/Keypair';
import type { KeyRingRepository } from '..';
import {
  createMemoryMap,
  memoryArrayIndexOf,
  memoryArrayPush,
  memoryArrayRemoveAt,
  memoryMapDelete,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

const DEFAULT_KEYPAIR_PURPOSE: KeypairPurpose = 'p2pk';

export class MemoryKeyRingRepository implements KeyRingRepository {
  private keyPairs: Map<string, Keypair> = createMemoryMap();
  private insertionOrder: string[] = [];
  private highWaterMarks: Map<KeypairPurpose, number> = createMemoryMap();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryKeyRingRepository): void {
    this.keyPairs = cloneMemoryRepositoryStateValue(source.keyPairs);
    this.insertionOrder = cloneMemoryRepositoryStateValue(source.insertionOrder);
    this.highWaterMarks = cloneMemoryRepositoryStateValue(source.highWaterMarks);
  }

  async getPersistedKeyPair(publicKey: string, purpose?: KeypairPurpose): Promise<Keypair | null> {
    const keyPair = memoryMapGet(this.keyPairs, publicKey);
    if (!keyPair) return null;
    if (purpose && (keyPair.purpose ?? DEFAULT_KEYPAIR_PURPOSE) !== purpose) return null;
    return cloneMemoryValue(keyPair);
  }

  async setPersistedKeyPair(keyPair: Keypair): Promise<void> {
    if (!memoryMapHas(this.keyPairs, keyPair.publicKeyHex)) {
      memoryArrayPush(this.insertionOrder, keyPair.publicKeyHex);
    }

    // Preserve existing derivationIndex if new one is not provided
    const existing = memoryMapGet(this.keyPairs, keyPair.publicKeyHex);
    let derivationIndex = keyPair.derivationIndex;
    if (derivationIndex == null) {
      if (existing?.derivationIndex != null) {
        derivationIndex = existing.derivationIndex;
      }
    }

    memoryMapSet(
      this.keyPairs,
      keyPair.publicKeyHex,
      cloneMemoryValue({
        ...keyPair,
        derivationIndex,
        purpose: keyPair.purpose ?? existing?.purpose ?? DEFAULT_KEYPAIR_PURPOSE,
      }),
    );
  }

  async deletePersistedKeyPair(publicKey: string, purpose?: KeypairPurpose): Promise<void> {
    if (purpose) {
      const existing = memoryMapGet(this.keyPairs, publicKey);
      if (existing && (existing.purpose ?? DEFAULT_KEYPAIR_PURPOSE) !== purpose) return;
    }

    memoryMapDelete(this.keyPairs, publicKey);
    const index = memoryArrayIndexOf(this.insertionOrder, publicKey);
    if (index !== -1) {
      memoryArrayRemoveAt(this.insertionOrder, index);
    }
  }

  async getAllPersistedKeyPairs(purpose?: KeypairPurpose): Promise<Keypair[]> {
    const values = memoryMapValues(this.keyPairs);
    const result: Keypair[] = [];
    for (let index = 0; index < values.length; index += 1) {
      const keyPair = values[index]!;
      if (!purpose || (keyPair.purpose ?? DEFAULT_KEYPAIR_PURPOSE) === purpose) {
        memoryArrayPush(result, cloneMemoryValue(keyPair));
      }
    }
    return result;
  }

  async getLatestKeyPair(purpose?: KeypairPurpose): Promise<Keypair | null> {
    for (let i = this.insertionOrder.length - 1; i >= 0; i--) {
      const keyPair = memoryMapGet(this.keyPairs, this.insertionOrder[i]!);
      if (!keyPair) continue;
      if (!purpose || (keyPair.purpose ?? DEFAULT_KEYPAIR_PURPOSE) === purpose) {
        return cloneMemoryValue(keyPair);
      }
    }

    return null;
  }

  async getLastAllocatedIndex(purpose: KeypairPurpose): Promise<number | null> {
    return memoryMapGet(this.highWaterMarks, purpose) ?? null;
  }

  async getHighestStoredDerivationIndex(purpose: KeypairPurpose): Promise<number | null> {
    let highest: number | null = null;
    const keyPairs = memoryMapValues(this.keyPairs);
    for (let index = 0; index < keyPairs.length; index += 1) {
      const keypair = keyPairs[index]!;
      if ((keypair.purpose ?? DEFAULT_KEYPAIR_PURPOSE) !== purpose) continue;
      if (
        keypair.derivationIndex != null &&
        (highest === null || keypair.derivationIndex > highest)
      ) {
        highest = keypair.derivationIndex;
      }
    }
    return highest;
  }

  async setLastAllocatedIndex(purpose: KeypairPurpose, derivationIndex: number): Promise<void> {
    memoryMapSet(this.highWaterMarks, purpose, derivationIndex);
  }
}
