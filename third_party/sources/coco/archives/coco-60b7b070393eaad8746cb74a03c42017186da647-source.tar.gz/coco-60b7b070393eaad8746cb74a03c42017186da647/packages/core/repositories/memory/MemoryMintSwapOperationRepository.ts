import {
  isMintSwapAutomaticState,
  isMintSwapTerminalState,
  type MintSwapOperation,
} from '../../operations/mintSwap/MintSwapOperation.ts';
import type { MintSwapOperationRepository } from '../../operations/mintSwap/MintSwapOperationRepository.ts';
import { parseMintSwapOperation } from '../../operations/mintSwap/parseMintSwapOperation.ts';
import { validateMintSwapTransition } from '../../operations/mintSwap/validateMintSwapTransition.ts';
import {
  createMemoryMap,
  createMemorySet,
  memoryArrayPush,
  memoryArraySlice,
  memoryArraySort,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
  memorySetAdd,
  memorySetHas,
} from './MemoryCollectionIntrinsics.ts';
import { cloneMemoryValue } from './MemoryRepositoryTransaction.ts';

const nativeJsonStringify = JSON.stringify;
const nativeNumberIsSafeInteger = Number.isSafeInteger;

function quoteKey(quote: MintSwapOperation['sourceQuote']): string {
  return nativeJsonStringify([quote.mintUrl, quote.method, quote.quoteId]);
}

function compareCreated(a: MintSwapOperation, b: MintSwapOperation): number {
  return a.createdAt - b.createdAt || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
}

/**
 * Dormant, standalone memory implementation. Every mutation runs synchronously to completion,
 * without an await between validation, uniqueness checks, and writes. This is the repository's
 * own serialization boundary; it makes no cross-repository Wallet rollback guarantee.
 */
export class MemoryMintSwapOperationRepository implements MintSwapOperationRepository {
  private readonly operations = createMemoryMap<string, MintSwapOperation>();
  private readonly sourceQuotes = createMemorySet<string>();
  private readonly destinationQuotes = createMemorySet<string>();
  private readonly sourceChildren = createMemorySet<string>();
  private readonly destinationChildren = createMemorySet<string>();

  async create(operation: MintSwapOperation): Promise<void> {
    const parsed = parseMintSwapOperation(cloneMemoryValue(operation));
    if (parsed.revision !== 0) throw new TypeError('Mint Swap creation requires revision zero');
    const sourceQuote = quoteKey(parsed.sourceQuote);
    const destinationQuote = quoteKey(parsed.destinationQuote);
    if (memoryMapHas(this.operations, parsed.id))
      throw new Error('Mint Swap parent identity already exists');
    if (memorySetHas(this.sourceQuotes, sourceQuote))
      throw new Error('Mint Swap source quote already exists');
    if (memorySetHas(this.destinationQuotes, destinationQuote))
      throw new Error('Mint Swap destination quote already exists');
    if (memorySetHas(this.sourceChildren, parsed.sourceOperationId))
      throw new Error('Mint Swap source child already exists');
    if (memorySetHas(this.destinationChildren, parsed.destinationOperationId))
      throw new Error('Mint Swap destination child already exists');

    memoryMapSet(this.operations, parsed.id, parsed);
    memorySetAdd(this.sourceQuotes, sourceQuote);
    memorySetAdd(this.destinationQuotes, destinationQuote);
    memorySetAdd(this.sourceChildren, parsed.sourceOperationId);
    memorySetAdd(this.destinationChildren, parsed.destinationOperationId);
  }

  async getById(id: string): Promise<MintSwapOperation | null> {
    const operation = memoryMapGet(this.operations, id);
    return operation ? parseMintSwapOperation(operation) : null;
  }

  async transition(
    command: Parameters<MintSwapOperationRepository['transition']>[0],
  ): Promise<boolean> {
    const detachedCommand = cloneMemoryValue(command);
    const current = memoryMapGet(this.operations, detachedCommand.operationId);
    if (
      !current ||
      current.state !== detachedCommand.expectedState ||
      current.revision !== detachedCommand.expectedRevision
    ) {
      return false;
    }
    const next = parseMintSwapOperation({
      ...detachedCommand.next,
      revision: detachedCommand.expectedRevision + 1,
    });
    validateMintSwapTransition(current, next);
    memoryMapSet(this.operations, detachedCommand.operationId, next);
    return true;
  }

  async listActive(): Promise<MintSwapOperation[]> {
    const result: MintSwapOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (!isMintSwapTerminalState(operation.state)) {
        memoryArrayPush(result, parseMintSwapOperation(operation));
      }
    }
    return memoryArraySort(result, compareCreated);
  }

  async listDue(now: number, limit: number): Promise<MintSwapOperation[]> {
    if (
      !nativeNumberIsSafeInteger(now) ||
      now < 0 ||
      !nativeNumberIsSafeInteger(limit) ||
      limit < 0
    ) {
      throw new TypeError('Mint Swap due scan requires nonnegative safe integer time and limit');
    }
    if (limit === 0) return [];
    const due: MintSwapOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (
        isMintSwapAutomaticState(operation.state) &&
        operation.retry.nextAttemptAt !== null &&
        operation.retry.nextAttemptAt <= now
      ) {
        memoryArrayPush(due, operation);
      }
    }
    memoryArraySort(
      due,
      (a, b) => a.retry.nextAttemptAt! - b.retry.nextAttemptAt! || compareCreated(a, b),
    );
    const selected = memoryArraySlice(due, 0, limit);
    for (let index = 0; index < selected.length; index += 1) {
      selected[index] = parseMintSwapOperation(selected[index]!);
    }
    return selected;
  }
}
