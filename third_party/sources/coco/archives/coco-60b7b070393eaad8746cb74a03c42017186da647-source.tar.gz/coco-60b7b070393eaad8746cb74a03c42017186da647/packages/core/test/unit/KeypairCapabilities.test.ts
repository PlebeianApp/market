import { describe, expect, it } from 'bun:test';
import { schnorr } from '@noble/curves/secp256k1.js';
import { bytesToHex, hexToBytes } from '@noble/curves/utils.js';
import { sha256 } from '@noble/hashes/sha2.js';
import type { Proof } from '@cashu/cashu-ts';
import { KeypairDerivation } from '../../keypairs/KeypairDerivation.ts';
import { KeypairP2pkSigner } from '../../keypairs/P2pkSigner.ts';

describe('shared keypair capabilities', () => {
  it('prepares derivation once and reuses it synchronously without loading the seed again', async () => {
    let reads = 0;
    const derivation = new KeypairDerivation(async () => {
      reads++;
      return new Uint8Array(64);
    });
    const input = await derivation.prepare('p2pk');
    const first = input.derive(0);
    expect(input.derive(0)).toEqual(first);
    expect(input.derive(1).publicKeyHex).not.toBe(first.publicKeyHex);
    expect(reads).toBe(1);
  });

  it('signs through a read-only interface and never creates a missing key', async () => {
    const secretKey = new Uint8Array(32).fill(1);
    const publicKeyHex = '02' + bytesToHex(schnorr.getPublicKey(secretKey));
    let reads = 0;
    const signer = new KeypairP2pkSigner({
      async getAllPersistedKeyPairs(purpose) {
        reads++;
        expect(purpose).toBe('p2pk');
        return [{ secretKey, publicKeyHex, purpose }];
      },
    });
    const proof = { secret: 'proof-secret' } as Proof;
    const signed = await signer.signProof(proof, publicKeyHex);
    if (typeof signed.witness !== 'string') throw new Error('Expected a serialized witness');
    const witness = JSON.parse(signed.witness) as { signatures: string[] };
    expect(
      schnorr.verify(
        hexToBytes(witness.signatures[0]!),
        sha256(new TextEncoder().encode(proof.secret)),
        schnorr.getPublicKey(secretKey),
      ),
    ).toBe(true);
    expect(proof.witness).toBeUndefined();
    const missingPublicKeyX = bytesToHex(schnorr.getPublicKey(new Uint8Array(32).fill(2)));
    await expect(signer.signProof(proof, missingPublicKeyX)).rejects.toThrow(
      'No persisted refund authority',
    );
    expect(reads).toBe(2);
  });

  it('rejects a stored public identity whose private key derives a different signer', async () => {
    const secretKey = new Uint8Array(32).fill(3);
    const committedX = bytesToHex(schnorr.getPublicKey(new Uint8Array(32).fill(4)));
    const signer = new KeypairP2pkSigner({
      async getAllPersistedKeyPairs() {
        return [{ secretKey, publicKeyHex: `02${committedX}`, purpose: 'p2pk' }];
      },
    });
    await expect(signer.signProof({ secret: 'proof' } as Proof, committedX)).rejects.toThrow(
      'does not match its private key',
    );
  });
});
