import type { RepositoryTransactionScope } from './index.ts';

const nativeCreate = Object.create;
const nativeDefineProperty = Object.defineProperty;
const nativeFreeze = Object.freeze;
const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const nativeGetPrototypeOf = Object.getPrototypeOf;
const nativeKeys = Object.keys;
const nativeReflectApply = Reflect.apply;
const nativeSetHas = Set.prototype.has;

export type RepositoryName = keyof RepositoryTransactionScope;

/**
 * Public repository methods that are safe to execute without a write transaction.
 *
 * This is intentionally an allowlist. A method added to an adapter is therefore treated as a
 * mutation until it has been reviewed and explicitly classified as read-only here. That default
 * is part of the Wallet Authority fence: an omitted or adapter-specific callable must never gain
 * an unfenced root execution path merely because it is absent from the mutation manifest.
 */
const readOnlyMethods: Record<RepositoryName, ReadonlySet<string>> = {
  mintRepository: new Set([
    'isTrustedMint',
    'getMintByUrl',
    'findMintByUrl',
    'getAllMints',
    'getAllTrustedMints',
  ]),
  keyRingRepository: new Set([
    'getPersistedKeyPair',
    'getAllPersistedKeyPairs',
    'getLatestKeyPair',
    'getLastAllocatedIndex',
    'getHighestStoredDerivationIndex',
  ]),
  counterRepository: new Set(['getCounter']),
  keysetRepository: new Set(['getKeysetsByMintUrl', 'getKeysetById']),
  proofRepository: new Set([
    'getReadyProofs',
    'getInflightProofs',
    'getAllReadyProofs',
    'getProofsByKeysetId',
    'getProofBySecret',
    'getProofsBySecrets',
    'getProofsByOperationId',
    'getAvailableProofs',
    'getReservedProofs',
  ]),
  mintQuoteRepository: new Set(['getMintQuoteById', 'getMintQuote', 'getPendingMintQuotes']),
  legacyMintQuoteRepository: new Set(['getPendingLegacyMintQuotes']),
  meltQuoteRepository: new Set(['getMeltQuoteById', 'getMeltQuote', 'getPendingMeltQuotes']),
  historyRepository: new Set([
    'getPaginatedHistoryEntries',
    'getHistoryEntryById',
    'getSendHistoryEntry',
    'getReceiveHistoryEntry',
  ]),
  sendOperationRepository: new Set([
    'getById',
    'getByState',
    'getPending',
    'getByMintUrl',
    'getAll',
  ]),
  meltOperationRepository: new Set([
    'getById',
    'getByState',
    'getPending',
    'getByMintUrl',
    'getByQuoteId',
    'getAll',
  ]),
  authSessionRepository: new Set(['getSession', 'getAllSessions']),
  mintOperationRepository: new Set([
    'getById',
    'getByState',
    'getPending',
    'getByMintUrl',
    'getByQuoteId',
    'getAll',
  ]),
  receiveOperationRepository: new Set([
    'getById',
    'getByState',
    'getPending',
    'getByMintUrl',
    'getByPaymentRequestAttemptId',
    'getAll',
  ]),
  paymentRequestReceiveOperationRepository: new Set([
    'getById',
    'getByState',
    'getActiveByRequestId',
    'list',
  ]),
  paymentRequestReceiveAttemptRepository: new Set([
    'getById',
    'getByRequestOperationId',
    'getByReceiveOperationId',
    'getByTransportMessageId',
    'getByPayloadHash',
    'getByRequestIdAndPayloadHash',
    'getByState',
  ]),
};

/** Explicit mutators are retained as an auditable completeness manifest. */
const mutationMethods: Record<RepositoryName, ReadonlySet<string>> = {
  mintRepository: new Set([
    'addNewMint',
    'addOrUpdateMint',
    'updateMint',
    'setMintTrusted',
    'deleteMint',
  ]),
  keyRingRepository: new Set([
    'setPersistedKeyPair',
    'deletePersistedKeyPair',
    'setLastAllocatedIndex',
  ]),
  counterRepository: new Set(['setCounter']),
  keysetRepository: new Set(['updateKeyset', 'addKeyset', 'deleteKeyset']),
  proofRepository: new Set([
    'saveProofs',
    'setProofState',
    'deleteProofs',
    'wipeProofsByKeysetId',
    'reserveProofs',
    'releaseProofs',
    'setCreatedByOperation',
  ]),
  mintQuoteRepository: new Set(['upsertMintQuote', 'setMintQuoteState']),
  legacyMintQuoteRepository: new Set(['upsertMintQuote']),
  meltQuoteRepository: new Set(['upsertMeltQuote']),
  historyRepository: new Set(['addLegacyHistoryEntry']),
  sendOperationRepository: new Set(['create', 'update', 'transition', 'delete']),
  meltOperationRepository: new Set(['create', 'update', 'delete']),
  authSessionRepository: new Set(['saveSession', 'deleteSession']),
  mintOperationRepository: new Set(['create', 'update', 'delete']),
  receiveOperationRepository: new Set(['create', 'update', 'transition', 'delete']),
  paymentRequestReceiveOperationRepository: new Set(['create', 'update']),
  paymentRequestReceiveAttemptRepository: new Set(['create', 'update', 'delete']),
};

/** True only for a callable that has been explicitly reviewed as read-only. */
export function isRepositoryReadOnly(repository: RepositoryName, method: PropertyKey): boolean {
  return (
    typeof method === 'string' &&
    (nativeReflectApply(nativeSetHas, readOnlyMethods[repository], [method]) as boolean)
  );
}

/**
 * True when a root repository call must pass through the durable monetary commit fence.
 * Unknown methods are mutations by default; the explicit mutation manifest is an audit aid and
 * never grants authority by omission.
 */
export function isRepositoryMutation(repository: RepositoryName, method: PropertyKey): boolean {
  return !isRepositoryReadOnly(repository, method);
}

/** Internal test/review surface for proving every adapter prototype method is classified. */
export function getRepositoryMethodClassification(
  repository: RepositoryName,
  method: string,
): 'read' | 'mutation' | 'unknown-mutation' {
  if (nativeReflectApply(nativeSetHas, readOnlyMethods[repository], [method]) as boolean)
    return 'read';
  if (nativeReflectApply(nativeSetHas, mutationMethods[repository], [method]) as boolean)
    return 'mutation';
  return 'unknown-mutation';
}

const repositoryFacadeMethods = {} as Record<RepositoryName, readonly string[]>;
for (const repository of nativeKeys(readOnlyMethods) as RepositoryName[]) {
  repositoryFacadeMethods[repository] = nativeFreeze([
    ...new Set([...readOnlyMethods[repository], ...mutationMethods[repository]]),
  ]);
}
nativeFreeze(repositoryFacadeMethods);

/**
 * Return the complete, reviewed public method surface for a repository.
 *
 * The returned list is derived only from the static manifests above. It never reflects over an
 * adapter implementation, because doing so could evaluate attacker-controlled proxy/accessor
 * behaviour before the method has been classified.
 */
export function getRepositoryFacadeMethods(repository: RepositoryName): readonly string[] {
  return repositoryFacadeMethods[repository];
}

/**
 * Construct a non-reflective repository boundary.
 *
 * The facade has no prototype, contains only own immutable wrapper functions, and exposes no
 * reference to the implementation object. Unknown, inherited, symbol, accessor, and future
 * properties are absent until they have been classified in the manifests above.
 */
export function createRepositoryFacade<Key extends RepositoryName>(
  repository: Key,
  invoke: (method: string, args: readonly unknown[]) => unknown,
): RepositoryTransactionScope[Key] {
  const facade = nativeCreate(null) as Record<string, unknown>;
  const methods = getRepositoryFacadeMethods(repository);
  for (let index = 0; index < methods.length; index += 1) {
    const method = methods[index]!;
    nativeDefineProperty(facade, method, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: (...args: unknown[]) => invoke(method, args),
    });
  }
  return nativeFreeze(facade) as unknown as RepositoryTransactionScope[Key];
}

/**
 * Invoke one classified adapter method without evaluating getters or proxy traps.
 *
 * Classification happens before implementation inspection. Only a data-property function found
 * through ordinary own property descriptors is accepted; accessors are rejected without being
 * evaluated. Adapter implementations are trusted internal objects, but this rule keeps a modified
 * prototype from turning repository property access itself into a mutation side channel.
 */
export function invokeRepositoryMethod<Key extends RepositoryName>(
  repository: Key,
  target: RepositoryTransactionScope[Key],
  method: string,
  args: readonly unknown[],
): unknown {
  if (getRepositoryMethodClassification(repository, method) === 'unknown-mutation') {
    throw new TypeError(`Unclassified repository method: ${String(repository)}.${method}`);
  }

  let owner: object | null = target as object;
  while (owner !== null) {
    const descriptor = nativeGetOwnPropertyDescriptor(owner, method);
    if (descriptor) {
      if (!('value' in descriptor) || typeof descriptor.value !== 'function') {
        throw new TypeError(`Repository method is not a data function: ${repository}.${method}`);
      }
      return nativeReflectApply(
        descriptor.value as (...values: unknown[]) => unknown,
        target,
        args,
      );
    }
    owner = nativeGetPrototypeOf(owner);
  }
  throw new TypeError(`Repository method is unavailable: ${repository}.${method}`);
}
