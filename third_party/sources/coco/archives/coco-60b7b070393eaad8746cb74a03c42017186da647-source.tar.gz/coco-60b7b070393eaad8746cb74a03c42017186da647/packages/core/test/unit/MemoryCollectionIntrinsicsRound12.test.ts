import { afterAll, describe, expect, it } from 'bun:test';
import { cp, mkdtemp, rm } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Amount } from '@cashu/cashu-ts';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';

const coreRoot = dirname(dirname(dirname(fileURLToPath(import.meta.url))));
const NativeArray = Array;
const NativeMap = Map;
const NativePromise = Promise;
const NativeProxy = Proxy;
const NativeSet = Set;
const NativeUint8Array = Uint8Array;
const NativeWeakMap = WeakMap;
const nativeArrayIterator = Array.prototype[Symbol.iterator];
const nativeArrayMap = Array.prototype.map;
const nativeArrayPush = Array.prototype.push;
const nativeArraySlice = Array.prototype.slice;
const nativeArraySort = Array.prototype.sort;
const nativeMapClear = Map.prototype.clear;
const nativeMapDelete = Map.prototype.delete;
const nativeMapEntries = Map.prototype.entries;
const nativeMapForEach = Map.prototype.forEach;
const nativeMapGet = Map.prototype.get;
const nativeMapHas = Map.prototype.has;
const nativeMapIterator = Map.prototype[Symbol.iterator];
const nativeMapKeys = Map.prototype.keys;
const nativeMapSet = Map.prototype.set;
const nativeMapValues = Map.prototype.values;
const nativeReflectApply = Reflect.apply;
const nativeSetAdd = Set.prototype.add;
const nativeSetDelete = Set.prototype.delete;
const nativeSetHas = Set.prototype.has;
const nativeSetIterator = Set.prototype[Symbol.iterator];
const nativeSetValues = Set.prototype.values;
const nativeUint8ArrayIterator = Uint8Array.prototype[Symbol.iterator];
const nativeUint8ArraySet = Uint8Array.prototype.set;
const nativeUint8ArraySlice = Uint8Array.prototype.slice;

type MemoryRoot = InstanceType<typeof MemoryRepositories>;
type MemoryRootConstructor = new () => MemoryRoot;
type MemoryModule = { MemoryRepositories: MemoryRootConstructor };

const emitted = (await import(
  `${pathToFileURL(join(coreRoot, 'dist/index.js')).href}?round12-memory-intrinsics-dist`
)) as unknown as MemoryModule;
const copiedDirectory = await mkdtemp(join(coreRoot, '.round12-packed-copy-'));
await cp(join(coreRoot, 'dist'), join(copiedDirectory, 'dist'), { recursive: true });
const copied = (await import(
  `${pathToFileURL(join(copiedDirectory, 'dist/index.js')).href}?round12-memory-intrinsics-copy`
)) as unknown as MemoryModule;

afterAll(() => rm(copiedDirectory, { recursive: true, force: true }));

function deferred(): { promise: Promise<void>; resolve: () => void } {
  let resolve!: () => void;
  const promise = new NativePromise<void>((done) => {
    resolve = done;
  });
  return { promise, resolve };
}

function proof(secret: string) {
  return {
    id: '00round12',
    amount: Amount.from(1),
    secret,
    C: '02round12',
    mintUrl: 'https://round12-collection.invalid',
    unit: 'sat',
    state: 'ready' as const,
  };
}

function sendOperation(id: string) {
  return {
    id,
    state: 'init' as const,
    mintUrl: 'https://round12-collection.invalid',
    amount: Amount.from(1),
    unit: 'sat',
    method: 'default' as const,
    methodData: {},
    createdAt: 1,
    updatedAt: 1,
    revision: 0,
  };
}

function runMemoryCollectionIntrinsicContract(label: string, Root: MemoryRootConstructor): void {
  describe(`${label} Memory collection intrinsic boundary`, () => {
    it('constructs private stores through pre-import constructors and exposes no forgeable store', async () => {
      const capturedMaps: Map<unknown, unknown>[] = [];
      const capturedSets: Set<unknown>[] = [];
      const capturedWeakMaps: WeakMap<object, unknown>[] = [];
      const capturedBytes: Uint8Array[] = [];

      class CapturingMap<Key, Value> extends NativeMap<Key, Value> {
        constructor(entries?: readonly (readonly [Key, Value])[] | null) {
          super(entries);
          capturedMaps[capturedMaps.length] = this as Map<unknown, unknown>;
        }
      }
      class CapturingSet<Value> extends NativeSet<Value> {
        constructor(values?: readonly Value[] | null) {
          super(values);
          capturedSets[capturedSets.length] = this as Set<unknown>;
        }
      }
      class CapturingWeakMap<Key extends object, Value> extends NativeWeakMap<Key, Value> {
        constructor(entries?: readonly (readonly [Key, Value])[] | null) {
          super(entries);
          capturedWeakMaps[capturedWeakMaps.length] = this as WeakMap<object, unknown>;
        }
      }
      class CapturingUint8Array extends NativeUint8Array {
        constructor(length: number) {
          super(length);
          capturedBytes[capturedBytes.length] = this;
        }
      }
      const failConstructor = function (): never {
        throw new Error('post-import constructor was consulted');
      };

      let root!: MemoryRoot;
      try {
        globalThis.Map = CapturingMap as unknown as MapConstructor;
        globalThis.Set = CapturingSet as unknown as SetConstructor;
        globalThis.WeakMap = CapturingWeakMap as unknown as WeakMapConstructor;
        globalThis.Array = failConstructor as unknown as ArrayConstructor;
        globalThis.Uint8Array = CapturingUint8Array as unknown as Uint8ArrayConstructor;
        globalThis.Proxy = failConstructor as unknown as ProxyConstructor;
        root = new Root();
      } finally {
        globalThis.Proxy = NativeProxy;
        globalThis.Uint8Array = NativeUint8Array;
        globalThis.Array = NativeArray;
        globalThis.WeakMap = NativeWeakMap;
        globalThis.Set = NativeSet;
        globalThis.Map = NativeMap;
      }

      expect(capturedMaps).toHaveLength(0);
      expect(capturedSets).toHaveLength(0);
      expect(capturedWeakMaps).toHaveLength(0);
      expect(capturedBytes).toHaveLength(0);
      await root.init();
      await expect(
        root.counterRepository.setCounter('https://round12-collection.invalid', 'keyset', 91),
      ).rejects.toThrow();
      await expect(
        root.proofRepository.saveProofs('https://round12-collection.invalid', [proof('forged')]),
      ).rejects.toThrow();
      await expect(
        root.sendOperationRepository.create(sendOperation('forged-send')),
      ).rejects.toThrow();
      expect(
        await root.counterRepository.getCounter('https://round12-collection.invalid', 'keyset'),
      ).toBeNull();
      expect(
        await root.proofRepository.getProofBySecret('https://round12-collection.invalid', 'forged'),
      ).toBeNull();
      expect(await root.sendOperationRepository.getById('forged-send')).toBeNull();
    });

    it('never dispatches private stores through poisoned collection prototypes or iterators', async () => {
      const mintUrl = 'https://round12-collection.invalid';
      const counterKey = `${mintUrl}::keyset`;
      const secret = 'round12-proof';
      const operationId = 'round12-send';
      const root = new Root();
      await root.init();
      await root.acquireAuthority({ namespace: `round12-${label}`, ownerId: 'owner' });
      await root.counterRepository.setCounter(mintUrl, 'keyset', 1);
      await root.proofRepository.saveProofs(mintUrl, [proof(secret)]);
      await root.sendOperationRepository.create(sendOperation(operationId));
      await root.keyRingRepository.setPersistedKeyPair({
        publicKeyHex: `02${'12'.repeat(32)}`,
        secretKey: new NativeUint8Array([13, 14, 15]),
        purpose: 'p2pk',
      });

      const captured = new NativeSet<object>();
      const record = (receiver: object): void => {
        nativeReflectApply(nativeSetAdd, captured, [receiver]);
      };
      const isTargetMap = (receiver: Map<unknown, unknown>): boolean => {
        return (
          (nativeReflectApply(nativeMapHas, receiver, [counterKey]) as boolean) ||
          (nativeReflectApply(nativeMapHas, receiver, [mintUrl]) as boolean) ||
          (nativeReflectApply(nativeMapHas, receiver, [secret]) as boolean) ||
          (nativeReflectApply(nativeMapHas, receiver, [operationId]) as boolean)
        );
      };
      const recordMap = (receiver: Map<unknown, unknown>): void => {
        if (isTargetMap(receiver)) record(receiver);
      };

      try {
        Map.prototype.get = function (key) {
          recordMap(this);
          return nativeReflectApply(nativeMapGet, this, [key]);
        };
        Map.prototype.set = function (key, value) {
          recordMap(this);
          return nativeReflectApply(nativeMapSet, this, [key, value]);
        };
        Map.prototype.has = function (key) {
          recordMap(this);
          return nativeReflectApply(nativeMapHas, this, [key]);
        };
        Map.prototype.delete = function (key) {
          recordMap(this);
          return nativeReflectApply(nativeMapDelete, this, [key]);
        };
        Map.prototype.clear = function () {
          recordMap(this);
          return nativeReflectApply(nativeMapClear, this, []);
        };
        Map.prototype.keys = function () {
          recordMap(this);
          return nativeReflectApply(nativeMapKeys, this, []);
        };
        Map.prototype.values = function () {
          recordMap(this);
          return nativeReflectApply(nativeMapValues, this, []);
        };
        Map.prototype.entries = function () {
          recordMap(this);
          return nativeReflectApply(nativeMapEntries, this, []);
        };
        Map.prototype.forEach = function (callback, thisArg) {
          recordMap(this);
          return nativeReflectApply(nativeMapForEach, this, [callback, thisArg]);
        };
        Map.prototype[Symbol.iterator] = function () {
          recordMap(this);
          return nativeReflectApply(nativeMapIterator, this, []);
        };
        Set.prototype.add = function (value) {
          if (value === secret || value === mintUrl || value === 'sat') record(this);
          return nativeReflectApply(nativeSetAdd, this, [value]);
        };
        Set.prototype.has = function (value) {
          if (value === secret || value === mintUrl || value === 'sat') record(this);
          return nativeReflectApply(nativeSetHas, this, [value]);
        };
        Set.prototype.delete = function (value) {
          if (value === secret || value === mintUrl || value === 'sat') record(this);
          return nativeReflectApply(nativeSetDelete, this, [value]);
        };
        Set.prototype.values = function () {
          return nativeReflectApply(nativeSetValues, this, []);
        };
        Set.prototype[Symbol.iterator] = function () {
          return nativeReflectApply(nativeSetIterator, this, []);
        };
        Array.prototype.map = function (callback, thisArg) {
          return nativeReflectApply(nativeArrayMap, this, [callback, thisArg]);
        };
        Array.prototype.push = function (...values) {
          return nativeReflectApply(nativeArrayPush, this, values);
        };
        Array.prototype.slice = function (start, end) {
          return nativeReflectApply(nativeArraySlice, this, [start, end]);
        };
        Array.prototype.sort = function (compare) {
          return nativeReflectApply(nativeArraySort, this, [compare]);
        };
        Array.prototype[Symbol.iterator] = function () {
          return nativeReflectApply(nativeArrayIterator, this, []);
        };
        Uint8Array.prototype.slice = function (start, end) {
          if (this[0] === 13) record(this);
          return nativeReflectApply(nativeUint8ArraySlice, this, [start, end]);
        };
        Uint8Array.prototype.set = function (source, offset) {
          if (this[0] === 13 || source[0] === 13) record(this);
          return nativeReflectApply(nativeUint8ArraySet, this, [source, offset]);
        };
        Uint8Array.prototype[Symbol.iterator] = function () {
          if (this[0] === 13) record(this);
          return nativeReflectApply(nativeUint8ArrayIterator, this, []);
        };

        expect((await root.counterRepository.getCounter(mintUrl, 'keyset'))?.counter).toBe(1);
        expect((await root.proofRepository.getProofBySecret(mintUrl, secret))?.secret).toBe(secret);
        expect(await root.proofRepository.getAllReadyProofs({ unit: 'sat' })).toHaveLength(1);
        expect((await root.sendOperationRepository.getById(operationId))?.id).toBe(operationId);
        expect(await root.sendOperationRepository.getByState('init')).toHaveLength(1);
        expect(
          await root.keyRingRepository.getPersistedKeyPair(`02${'12'.repeat(32)}`, 'p2pk'),
        ).not.toBeNull();
        await root.withTransaction(async (scope) => {
          await scope.counterRepository.setCounter(mintUrl, 'keyset', 2);
          expect(await scope.proofRepository.getProofsBySecrets(mintUrl, [secret])).toHaveLength(1);
          expect(await scope.sendOperationRepository.getByState('init')).toHaveLength(1);
        });
      } finally {
        Uint8Array.prototype[Symbol.iterator] = nativeUint8ArrayIterator;
        Uint8Array.prototype.set = nativeUint8ArraySet;
        Uint8Array.prototype.slice = nativeUint8ArraySlice;
        Array.prototype[Symbol.iterator] = nativeArrayIterator;
        Array.prototype.sort = nativeArraySort;
        Array.prototype.slice = nativeArraySlice;
        Array.prototype.push = nativeArrayPush;
        Array.prototype.map = nativeArrayMap;
        Set.prototype[Symbol.iterator] = nativeSetIterator;
        Set.prototype.values = nativeSetValues;
        Set.prototype.delete = nativeSetDelete;
        Set.prototype.has = nativeSetHas;
        Set.prototype.add = nativeSetAdd;
        Map.prototype[Symbol.iterator] = nativeMapIterator;
        Map.prototype.forEach = nativeMapForEach;
        Map.prototype.entries = nativeMapEntries;
        Map.prototype.values = nativeMapValues;
        Map.prototype.keys = nativeMapKeys;
        Map.prototype.clear = nativeMapClear;
        Map.prototype.delete = nativeMapDelete;
        Map.prototype.has = nativeMapHas;
        Map.prototype.set = nativeMapSet;
        Map.prototype.get = nativeMapGet;
      }

      expect(captured.size).toBe(0);
      expect((await root.counterRepository.getCounter(mintUrl, 'keyset'))?.counter).toBe(2);
      await root.releaseAuthority();
      await expect(root.counterRepository.setCounter(mintUrl, 'keyset', 41)).rejects.toThrow();
      expect((await root.counterRepository.getCounter(mintUrl, 'keyset'))?.counter).toBe(2);
    });

    it('serializes transactions through the pre-import Promise constructor', async () => {
      const root = new Root();
      await root.init();
      await root.acquireAuthority({ namespace: `round12-promise-${label}`, ownerId: 'owner' });
      const firstEntered = deferred();
      const releaseFirst = deferred();
      let firstReleased = false;
      let secondEnteredBeforeRelease = false;

      class PrematurePromise<Value> extends NativePromise<Value> {
        constructor(
          executor: (
            resolve: (value: Value | PromiseLike<Value>) => void,
            reject: (reason?: unknown) => void,
          ) => void,
        ) {
          super((resolve, reject) => {
            executor(resolve, reject);
            resolve(undefined as Value);
          });
        }
        static override get [Symbol.species](): PromiseConstructor {
          return NativePromise;
        }
      }

      let first!: Promise<void>;
      let second!: Promise<void>;
      try {
        globalThis.Promise = PrematurePromise as unknown as PromiseConstructor;
        first = root.withTransaction(async (scope) => {
          await scope.counterRepository.setCounter('https://round12-promise.invalid', 'keyset', 1);
          firstEntered.resolve();
          await releaseFirst.promise;
          firstReleased = true;
        });
        await firstEntered.promise;
        second = root.withTransaction(async (scope) => {
          secondEnteredBeforeRelease = !firstReleased;
          await scope.counterRepository.setCounter('https://round12-promise.invalid', 'keyset', 2);
        });
        await NativePromise.resolve();
        await NativePromise.resolve();
        expect(secondEnteredBeforeRelease).toBe(false);
      } finally {
        globalThis.Promise = NativePromise;
        releaseFirst.resolve();
      }

      await first;
      await second;
      expect(secondEnteredBeforeRelease).toBe(false);
      expect(
        (await root.counterRepository.getCounter('https://round12-promise.invalid', 'keyset'))
          ?.counter,
      ).toBe(2);
    });
  });
}

runMemoryCollectionIntrinsicContract('source', MemoryRepositories);
runMemoryCollectionIntrinsicContract('dist', emitted.MemoryRepositories);
runMemoryCollectionIntrinsicContract('copied-dist', copied.MemoryRepositories);
