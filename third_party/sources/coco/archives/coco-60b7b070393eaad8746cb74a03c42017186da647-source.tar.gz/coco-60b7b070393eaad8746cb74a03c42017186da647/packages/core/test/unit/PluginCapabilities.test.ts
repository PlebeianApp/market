import { Amount, deriveKeysetId } from '@cashu/cashu-ts';
import { describe, expect, it } from 'bun:test';

import { initializeCoco, type CocoConfig, type Manager } from '../../Manager.ts';
import type { Plugin, PluginContext, ServiceKey, ServiceMap } from '../../plugin.ts';
import {
  PLUGIN_CAPABILITY_METHODS,
  PLUGIN_QUOTE_CAPABILITY_METHODS,
  createPluginCapabilityFactories,
} from '../../plugins/PluginCapabilities.ts';
import { createCapabilityLifecycleAuthority } from '../../plugins/CapabilityLifecycle.ts';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import type { MintInfo } from '../../types.ts';

const mintUrl = 'https://offline-plugin-capability.invalid';
const keypairs = {
  '1': '0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798',
};
const keysetId = deriveKeysetId(keypairs, { unit: 'sat' });
const seed = new Uint8Array(64).fill(0x42);
const serviceKeys = Object.keys(PLUGIN_CAPABILITY_METHODS) as ServiceKey[];
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
} satisfies Pick<CocoConfig, 'watchers' | 'processors'>;

async function createOfflineRepository(): Promise<{
  repository: MemoryRepositories;
  privileged: Set<object>;
}> {
  const seedRoot = new MemoryRepositories();
  await seedRoot.init();
  await seedRoot.acquireAuthority({ namespace: 'plugin-capability-test', ownerId: 'seed' });
  const now = Math.floor(Date.now() / 1000);
  await seedRoot.mintRepository.addNewMint({
    mintUrl,
    name: 'Offline Capability Mint',
    mintInfo: {
      name: 'Offline Capability Mint',
      version: 'NUT-00-TEST',
      pubkey: '',
      contact: [],
      nuts: {
        '4': { methods: [{ method: 'bolt11', unit: 'sat' }], disabled: false },
        '5': { methods: [{ method: 'bolt11', unit: 'sat' }], disabled: false },
      },
    } as unknown as MintInfo,
    trusted: true,
    createdAt: now,
    updatedAt: now,
  });
  await seedRoot.keysetRepository.addKeyset({
    mintUrl,
    id: keysetId,
    unit: 'sat',
    keypairs,
    active: true,
    feePpk: 0,
  });
  await seedRoot.counterRepository.setCounter(mintUrl, keysetId, 7);
  await seedRoot.releaseAuthority();

  const repository = seedRoot.createPeer();
  const privileged = new Set<object>([
    repository,
    repository.mintRepository,
    repository.keyRingRepository,
    repository.counterRepository,
    repository.keysetRepository,
    repository.proofRepository,
    repository.mintQuoteRepository,
    repository.legacyMintQuoteRepository,
    repository.meltQuoteRepository,
    repository.historyRepository,
    repository.sendOperationRepository,
    repository.meltOperationRepository,
    repository.authSessionRepository,
    repository.mintOperationRepository,
    repository.receiveOperationRepository,
    repository.paymentRequestReceiveOperationRepository,
    repository.paymentRequestReceiveAttemptRepository,
  ]);
  return { repository, privileged };
}

function assertNoPrivilegedReachability(root: unknown, privileged: Set<object>): void {
  const seen = new Set<object>();
  const pending: unknown[] = [root];
  while (pending.length > 0) {
    const value = pending.pop();
    if ((typeof value !== 'object' && typeof value !== 'function') || value === null) continue;
    if (seen.has(value)) continue;
    seen.add(value);
    expect(privileged.has(value)).toBe(false);

    for (const key of Reflect.ownKeys(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      expect(descriptor).toBeDefined();
      if (!descriptor || !('value' in descriptor)) continue;
      pending.push(descriptor.value);
    }
  }
}

function assertCapabilityShape(key: ServiceKey, capability: object): void {
  expect(Object.getPrototypeOf(capability)).toBeNull();
  expect(Object.isFrozen(capability)).toBe(true);
  expect(Object.getOwnPropertySymbols(capability)).toEqual([]);
  expect(Object.keys(capability)).toEqual([...PLUGIN_CAPABILITY_METHODS[key]]);
  for (const method of Object.keys(capability)) {
    const descriptor = Object.getOwnPropertyDescriptor(capability, method);
    expect(descriptor).toMatchObject({
      configurable: false,
      enumerable: true,
      writable: false,
    });
    if (key === 'quotes') {
      const quoteCapability = descriptor!.value as Record<string, unknown>;
      expect(Object.getPrototypeOf(quoteCapability)).toBeNull();
      expect(Object.isFrozen(quoteCapability)).toBe(true);
      expect(Object.keys(quoteCapability)).toEqual([
        ...PLUGIN_QUOTE_CAPABILITY_METHODS[method as 'mint' | 'melt'],
      ]);
      for (const quoteMethod of Object.values(quoteCapability)) {
        expect(typeof quoteMethod).toBe('function');
        expect(Object.getPrototypeOf(quoteMethod)).toBeNull();
        expect(Object.isFrozen(quoteMethod)).toBe(true);
      }
    } else {
      expect(typeof descriptor?.value).toBe('function');
      expect(Object.getPrototypeOf(descriptor!.value)).toBeNull();
      expect(Object.isFrozen(descriptor!.value)).toBe(true);
      expect((descriptor!.value as Record<string, unknown>).constructor).toBeUndefined();
    }
  }
}

function emptyCapabilitySources(overrides: Record<string, unknown> = {}): never {
  return {
    ...Object.fromEntries(serviceKeys.map((key) => [key, Object.create(null)])),
    ...overrides,
  } as never;
}

function representativeCapabilityCalls(services: ServiceMap): Array<() => unknown> {
  return [
    () => services.mintService.getAllMints(),
    () => services.proofService.getBalances(),
    () => services.keyRingService.getAllKeyPairs(),
    () => services.walletRestoreService.sweepKeyset('mint', 'keyset', new Uint8Array()),
    () => services.counterService.getCounter('mint', 'keyset'),
    () => services.tokenService.decodeToken('token', 'mint'),
    () => services.historyService.getPaginatedHistory(),
    () => services.sendOperationService.getOperation('operation'),
    () => services.receiveOperationService.getOperation('operation'),
    () => services.meltOperationService.getOperation('operation'),
    () => services.mintOperationService.getOperation('operation'),
    () => services.quotes.mint.get({ mintUrl, quoteId: 'quote' }),
    () => services.paymentRequestService.parse('request'),
    () => services.paymentRequestReceiveService.get('operation'),
    () => services.subscriptions.pause(),
    () => services.eventBus.on('counter:updated', () => {}),
    () => services.logger.info('diagnostic'),
  ];
}

async function expectCapabilityRejected(call: () => unknown): Promise<void> {
  let rejected = false;
  try {
    await call();
  } catch {
    rejected = true;
  }
  expect(rejected).toBe(true);
}

describe('plugin capability boundary', () => {
  it('keeps all 17 capability facades inactive before activation and after revocation', async () => {
    const lifecycle = createCapabilityLifecycleAuthority();
    const factories = createPluginCapabilityFactories(emptyCapabilitySources(), lifecycle);
    const services = Object.fromEntries(
      serviceKeys.map((key) => [key, factories[key]()]),
    ) as unknown as ServiceMap;

    for (const call of representativeCapabilityCalls(services)) {
      await expectCapabilityRejected(call);
    }

    lifecycle.activate();
    await lifecycle.revoke();
    for (const call of representativeCapabilityCalls(services)) {
      await expectCapabilityRejected(call);
    }
  });

  it('clones Response values and rejects unsupported class instances without freezing Core state', async () => {
    const lifecycle = createCapabilityLifecycleAuthority();
    lifecycle.activate();
    const originalResponse = new Response('core body', {
      status: 202,
      headers: { 'x-core': 'original' },
    });
    class UnsupportedDomainValue {
      nested = { mutable: true };
    }
    const unsupported = new UnsupportedDomainValue();
    const factories = createPluginCapabilityFactories(
      emptyCapabilitySources({
        paymentRequestService: {
          execute: async () => originalResponse,
        },
        historyService: {
          getHistoryEntryById: async () => unsupported,
        },
      }),
      lifecycle,
    );

    const detachedResponse = (await factories
      .paymentRequestService()
      .execute({} as never)) as unknown as Response;
    expect(detachedResponse).not.toBe(originalResponse);
    expect(detachedResponse.status).toBe(202);
    expect(detachedResponse.headers.get('x-core')).toBe('original');
    detachedResponse.headers.set('x-core', 'plugin');
    expect(originalResponse.headers.get('x-core')).toBe('original');
    expect(await detachedResponse.text()).toBe('core body');
    expect(await originalResponse.text()).toBe('core body');

    await expect(factories.historyService().getHistoryEntryById('unsupported')).rejects.toThrow(
      'unsupported class instance',
    );
    expect(Object.isFrozen(unsupported)).toBe(false);
    expect(Object.isFrozen(unsupported.nested)).toBe(false);
  });

  it('rejects accessor and symbol return graphs without evaluating getters', async () => {
    const lifecycle = createCapabilityLifecycleAuthority();
    lifecycle.activate();
    let getterCalls = 0;
    const blindedMessage = { id: 'keyset', B_: 'point' } as Record<string, unknown>;
    Object.defineProperty(blindedMessage, 'amount', {
      enumerable: true,
      get() {
        getterCalls++;
        return 1;
      },
    });
    const output = {
      blindedMessage,
      blindingFactor: 1n,
      secret: new Uint8Array([1]),
      ephemeralE: undefined,
      toProof() {
        return {};
      },
    };
    const accessorRecord = Object.create(null) as Record<string, unknown>;
    Object.defineProperty(accessorRecord, 'unsafe', {
      enumerable: true,
      get() {
        getterCalls++;
        return 'secret';
      },
    });
    const symbolRecord = { [Symbol('hidden')]: 'secret' };
    const factories = createPluginCapabilityFactories(
      emptyCapabilitySources({
        proofService: { createBlankOutputs: async () => [output] },
        historyService: {
          getHistoryEntryById: async (id: string) =>
            id === 'accessor' ? accessorRecord : symbolRecord,
        },
      }),
      lifecycle,
    );

    await expect(
      factories.proofService().createBlankOutputs(mintUrl, {
        amount: 1n,
        unit: 'sat',
      } as never),
    ).rejects.toThrow('accessor field');
    await expect(factories.historyService().getHistoryEntryById('accessor')).rejects.toThrow(
      'accessor field',
    );
    await expect(factories.historyService().getHistoryEntryById('symbol')).rejects.toThrow(
      'symbol field',
    );
    expect(getterCalls).toBe(0);
  });

  it('detaches supported values through captured intrinsics after prototype poisoning', async () => {
    const lifecycle = createCapabilityLifecycleAuthority();
    lifecycle.activate();
    const originalArrayMap = Array.prototype.map;
    const originalArrayIterator = Array.prototype[Symbol.iterator];
    const originalAmountToBigInt = Amount.prototype.toBigInt;
    const originalResponseClone = Response.prototype.clone;
    const originalArrayBufferSlice = ArrayBuffer.prototype.slice;
    const originalUint8Set = Uint8Array.prototype.set;
    const originalDateGetTime = Date.prototype.getTime;
    const originalGetPrototypeOf = Object.getPrototypeOf;
    const originalGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
    const originalDefineProperty = Object.defineProperty;
    const originalFreeze = Object.freeze;
    const originalOwnKeys = Reflect.ownKeys;
    const originalApply = Reflect.apply;
    let poisonedCalls = 0;
    let poisoned = false;
    const source = {
      amount: Amount.from(7n),
      array: ['safe'],
      bytes: new Uint8Array([1, 2, 3]),
      buffer: new Uint8Array([4, 5]).buffer,
      view: new DataView(new Uint8Array([6, 7]).buffer),
      date: new Date(1234),
      response: new Response('detached', { headers: { 'x-core': 'yes' } }),
    };
    const poison = () => {
      if (poisoned) return;
      poisoned = true;
      const trap = (name: string) => () => {
        poisonedCalls += 1;
        throw new Error(`poisoned intrinsic reached: ${name}`);
      };
      Array.prototype.map = trap('Array.map') as never;
      Array.prototype[Symbol.iterator] = trap('Array.iterator') as never;
      Amount.prototype.toBigInt = trap('Amount.toBigInt') as never;
      Response.prototype.clone = trap('Response.clone') as never;
      ArrayBuffer.prototype.slice = trap('ArrayBuffer.slice') as never;
      Uint8Array.prototype.set = trap('Uint8Array.set') as never;
      Date.prototype.getTime = trap('Date.getTime') as never;
      Object.getPrototypeOf = trap('Object.getPrototypeOf') as never;
      Object.getOwnPropertyDescriptor = trap('Object.getOwnPropertyDescriptor') as never;
      Object.defineProperty = trap('Object.defineProperty') as never;
      Object.freeze = trap('Object.freeze') as never;
      Reflect.ownKeys = trap('Reflect.ownKeys') as never;
      Reflect.apply = trap('Reflect.apply') as never;
    };
    const restore = () => {
      Array.prototype.map = originalArrayMap;
      Array.prototype[Symbol.iterator] = originalArrayIterator;
      Amount.prototype.toBigInt = originalAmountToBigInt;
      Response.prototype.clone = originalResponseClone;
      ArrayBuffer.prototype.slice = originalArrayBufferSlice;
      Uint8Array.prototype.set = originalUint8Set;
      Date.prototype.getTime = originalDateGetTime;
      Object.getPrototypeOf = originalGetPrototypeOf;
      Object.getOwnPropertyDescriptor = originalGetOwnPropertyDescriptor;
      Object.defineProperty = originalDefineProperty;
      Object.freeze = originalFreeze;
      Reflect.ownKeys = originalOwnKeys;
      Reflect.apply = originalApply;
    };
    const factories = createPluginCapabilityFactories(
      emptyCapabilitySources({
        historyService: {
          async getHistoryEntryById() {
            poison();
            return source;
          },
        },
      }),
      lifecycle,
    );

    let detached: any;
    try {
      detached = await factories.historyService().getHistoryEntryById('poison');
    } finally {
      restore();
    }
    expect(poisonedCalls).toBe(0);
    expect(detached).not.toBe(source);
    expect(detached.array).not.toBe(source.array);
    expect(detached.bytes).not.toBe(source.bytes);
    expect(detached.buffer).not.toBe(source.buffer);
    expect(detached.view).not.toBe(source.view);
    expect(detached.amount).not.toBe(source.amount);
    expect(detached.amount.toBigInt()).toBe(7n);
    expect(detached.date.getTime()).toBe(1234);
    expect(detached.response).not.toBe(source.response);
    expect(await detached.response.text()).toBe('detached');
    expect(await source.response.text()).toBe('detached');
    expect(Object.isFrozen(source)).toBe(false);
    expect(Object.isFrozen(source.array)).toBe(false);
  });

  it('sanitizes synchronous failures before they cross an async capability wrapper', async () => {
    const privileged = { secret: 'implementation-only' };
    const rawError = Object.assign(new Error('synchronous implementation failure'), {
      cause: privileged,
      implementation: privileged,
    });
    const lifecycle = createCapabilityLifecycleAuthority();
    lifecycle.activate();
    const factories = createPluginCapabilityFactories(
      {
        mintService: {
          isTrustedMint(): Promise<boolean> {
            throw rawError;
          },
        },
      } as never,
      lifecycle,
    );
    const capability = factories.mintService();

    let received: unknown;
    try {
      await capability.isTrustedMint(mintUrl);
    } catch (error) {
      received = error;
    }

    expect(received).toBeInstanceOf(Error);
    expect(received).not.toBe(rawError);
    expect((received as Error & { cause?: unknown }).cause).toBeUndefined();
    expect((received as Error & { implementation?: unknown }).implementation).toBeUndefined();
    expect(Object.isFrozen(received!)).toBe(true);
  });

  it('closes the supported-service repository and wallet-seed exploit chains offline', async () => {
    const { repository, privileged } = await createOfflineRepository();
    let initContext: PluginContext | undefined;
    let readyContext: PluginContext | undefined;
    const plugin: Plugin = {
      name: 'offline-privileged-reachability-adversary',
      required: serviceKeys,
      onInit(context) {
        initContext = context;
      },
      onReady(context) {
        readyContext = context;
      },
    };
    const manager = await initializeCoco({
      repo: repository,
      seedGetter: async () => seed,
      authority: { namespace: 'plugin-capability-test', ownerId: 'runtime' },
      plugins: [plugin],
      ...disabledRuntime,
    });

    try {
      const services = initContext!.services as ServiceMap;
      const keyRing = services.keyRingService as unknown as Record<string, unknown>;
      const restore = services.walletRestoreService as unknown as Record<string, unknown>;
      const mint = services.mintService as unknown as Record<string, unknown>;
      const counter = services.counterService as unknown as Record<string, unknown>;
      const transactions = keyRing.transactions as Record<string, unknown> | undefined;
      const runner = transactions?.runner as Record<string, unknown> | undefined;
      const exposedRoot = runner?.repositories;
      const rawWalletService = restore.walletService as
        | { getWallet?: (url: string) => Promise<unknown> }
        | undefined;
      const rawWallet = await rawWalletService?.getWallet?.(mintUrl);
      const leakedSeed = (rawWallet as { _seed?: unknown } | undefined)?._seed;

      expect(exposedRoot).toBeUndefined();
      expect(rawWalletService).toBeUndefined();
      expect(mint.mintRepo).toBeUndefined();
      expect(counter.counterRepo).toBeUndefined();
      expect(leakedSeed).toBeUndefined();
      expect(leakedSeed instanceof Uint8Array && leakedSeed.every((v, i) => v === seed[i])).toBe(
        false,
      );

      expect(await services.mintService.getMintInfo(mintUrl)).toMatchObject({
        name: 'Offline Capability Mint',
      });
      expect(await services.counterService.getCounter(mintUrl, keysetId)).toMatchObject({
        counter: 7,
      });
      expect(await services.keyRingService.getAllKeyPairs()).toEqual([]);
      expect(Object.keys(services.walletRestoreService)).toEqual(['sweepKeyset', 'restoreKeyset']);

      expect(initContext).not.toBe(readyContext);
      expect(initContext!.services).not.toBe(readyContext!.services);
      expect(initContext!.services.keyRingService).not.toBe(readyContext!.services.keyRingService);
      assertNoPrivilegedReachability(initContext, privileged);
      assertNoPrivilegedReachability(readyContext, privileged);
    } finally {
      await manager.dispose();
    }
  });

  it('keeps every capability explicit, immutable, plugin-local, and fenced after release', async () => {
    const { repository, privileged } = await createOfflineRepository();
    let firstContext: PluginContext | undefined;
    let secondContext: PluginContext | undefined;
    let observedPayload: unknown;
    let resolveSecond!: () => void;
    const secondReady = new Promise<void>((resolve) => {
      resolveSecond = resolve;
    });
    const first: Plugin = {
      name: 'all-capabilities-audit-a',
      required: serviceKeys,
      onInit(context) {
        firstContext = context;
      },
    };
    const second: Plugin = {
      name: 'all-capabilities-audit-b',
      required: serviceKeys,
      onInit(context) {
        secondContext = context;
        resolveSecond();
      },
    };
    const manager: Manager = await initializeCoco({
      repo: repository,
      seedGetter: async () => seed,
      authority: { namespace: 'plugin-capability-test', ownerId: 'runtime' },
      plugins: [first],
      ...disabledRuntime,
    });
    manager.use(second);
    await secondReady;

    const services = firstContext!.services as ServiceMap;
    try {
      expect(Object.getPrototypeOf(firstContext)).toBeNull();
      expect(Object.isFrozen(firstContext)).toBe(true);
      expect(Object.getPrototypeOf(services)).toBeNull();
      expect(Object.isFrozen(services)).toBe(true);
      expect(Object.getOwnPropertySymbols(services)).toEqual([]);

      for (const key of serviceKeys) {
        const capability = services[key] as object;
        assertCapabilityShape(key, capability);
        expect(capability).not.toBe((secondContext!.services as ServiceMap)[key]);
        assertNoPrivilegedReachability(capability, privileged);
      }

      const mintFacade = services.mintService as unknown as Record<string, unknown>;
      const trusted = mintFacade.isTrustedMint as (url: string) => Promise<boolean>;
      expect((trusted as unknown as Record<string, unknown>).call).toBeUndefined();
      expect((trusted as unknown as Record<string, unknown>).apply).toBeUndefined();
      expect((trusted as unknown as Record<string, unknown>).bind).toBeUndefined();
      expect((trusted as unknown as Record<string, unknown>).constructor).toBeUndefined();
      expect(await trusted(mintUrl)).toBe(true);
      expect(await Function.prototype.call.call(trusted, null, mintUrl)).toBe(true);
      expect(await Reflect.apply(new Proxy(trusted, {}), null, [mintUrl])).toBe(true);
      expect(() => new (trusted as unknown as new () => object)()).toThrow();
      expect(() => Object.setPrototypeOf(services.mintService, {})).toThrow();
      expect(() =>
        Object.defineProperty(services.mintService, 'target', { value: repository }),
      ).toThrow();
      expect(() => {
        (firstContext as unknown as { services: unknown }).services = repository;
      }).toThrow();
      expect(Function.prototype.toString.call(trusted)).not.toContain('seedGetter');

      services.eventBus.on('counter:updated', (payload) => {
        observedPayload = payload;
      });
      const counter = await services.counterService.overwriteCounter(mintUrl, keysetId, 8);
      expect(counter).toMatchObject({ counter: 8 });
      expect(Object.getPrototypeOf(counter)).toBeNull();
      expect(Object.isFrozen(counter)).toBe(true);
      expect(observedPayload).toMatchObject({ counter: 8 });
      expect(Object.getPrototypeOf(observedPayload!)).toBeNull();
      expect(Object.isFrozen(observedPayload!)).toBe(true);

      const safeResults = await Promise.all([
        services.mintService.getAllMints(),
        services.proofService.getBalances(),
        services.keyRingService.getAllKeyPairs(),
        services.historyService.getPaginatedHistory(),
        services.sendOperationService.getOperation('missing-send'),
        services.receiveOperationService.getOperation('missing-receive'),
        services.meltOperationService.getOperation('missing-melt'),
        services.mintOperationService.getOperation('missing-mint'),
        services.quotes.mint.get({ mintUrl, quoteId: 'missing-mint-quote' }),
        services.quotes.melt.get({ mintUrl, quoteId: 'missing-melt-quote' }),
        services.paymentRequestReceiveService.get('missing-payment-request'),
      ]);
      for (const result of safeResults) assertNoPrivilegedReachability(result, privileged);
      const diagnostics = services.subscriptions.getDiagnostics();
      assertNoPrivilegedReachability(diagnostics, privileged);
      expect(Object.isFrozen(diagnostics)).toBe(true);

      let sanitizedError: unknown;
      try {
        await services.paymentRequestService.parse('not-a-payment-request');
      } catch (error) {
        sanitizedError = error;
      }
      expect(sanitizedError).toBeInstanceOf(Error);
      expect((sanitizedError as Error & { cause?: unknown }).cause).toBeUndefined();
      expect(Object.isFrozen(sanitizedError!)).toBe(true);
    } finally {
      await manager.dispose();
    }

    const capturedCounter = services.counterService.overwriteCounter;
    await expect(capturedCounter(mintUrl, keysetId, 41)).rejects.toThrow(/authority|released/i);
    expect((await repository.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(8);
  });
});
