import {
  type Proof,
  Mint,
  Wallet,
  sumProofs,
  type OutputConfig,
  type OutputDataCreator,
} from '@cashu/cashu-ts';
import { mapProofToCoreProof } from '@core/utils';
import type { ProofService } from './ProofService';
import type { CounterService } from './CounterService';
import type { Logger } from '../logging/Logger.ts';
import type { WalletService } from './WalletService.ts';
import type { MintRequestProvider } from '../infra/MintRequestProvider.ts';
import { DEFAULT_UNIT, normalizeUnit } from '../amounts.ts';

export class WalletRestoreService {
  readonly #proofService: ProofService;
  readonly #counterService: CounterService;
  readonly #walletService: WalletService;
  readonly #requestProvider: MintRequestProvider;
  readonly #logger?: Logger;
  readonly #outputDataCreator?: OutputDataCreator;

  // Defaults for batch restore behavior
  readonly #restoreGapLimit = 300;
  readonly #restoreBatchSize = 100;
  readonly #restoreStartCounter = 0;

  constructor(
    proofService: ProofService,
    counterService: CounterService,
    walletService: WalletService,
    requestProvider: MintRequestProvider,
    logger?: Logger,
    outputDataCreator?: OutputDataCreator,
  ) {
    this.#proofService = proofService;
    this.#counterService = counterService;
    this.#walletService = walletService;
    this.#requestProvider = requestProvider;
    this.#logger = logger;
    this.#outputDataCreator = outputDataCreator;
  }

  async sweepKeyset(
    mintUrl: string,
    keysetId: string,
    bip39seed: Uint8Array,
    unit = DEFAULT_UNIT,
  ): Promise<void> {
    const normalizedUnit = normalizeUnit(unit, { defaultUnit: DEFAULT_UNIT });
    this.#logger?.debug('Sweeping keyset', { mintUrl, keysetId });
    const { wallet } = await this.#walletService.getWalletWithActiveKeysetId(
      mintUrl,
      normalizedUnit,
    );
    const requestFn = this.#requestProvider.getRequestFn(mintUrl);
    const sweepWallet = new Wallet(new Mint(mintUrl, { customRequest: requestFn }), {
      bip39seed,
      unit: normalizedUnit,
      outputDataCreator: this.#outputDataCreator,
    });
    await sweepWallet.loadMint();

    const { proofs } = await sweepWallet.batchRestore({
      gapLimit: this.#restoreGapLimit,
      batchSize: this.#restoreBatchSize,
      counter: this.#restoreStartCounter,
      keysetId,
      filterSpent: false,
    });

    if (proofs.length === 0) {
      this.#logger?.warn('No proofs to sweep', { mintUrl, keysetId });
      return;
    }

    this.#logger?.debug('Proofs found for sweep', {
      mintUrl,
      keysetId,
      count: proofs.length,
    });

    const states = await sweepWallet.checkProofsStates(proofs);
    if (!Array.isArray(states) || states.length !== proofs.length) {
      this.#logger?.error('Malformed state check', {
        mintUrl,
        keysetId,
        statesLength: (states as unknown as { length?: number })?.length,
        proofsLength: proofs.length,
      });
      throw new Error('Malformed state check');
    }
    const checkedProofs: { spent: Proof[]; ready: Proof[] } = { spent: [], ready: [] };
    for (const [index, state] of states.entries()) {
      if (!proofs[index]) {
        this.#logger?.error('Proof not found', { mintUrl, keysetId, index });
        throw new Error('Proof not found');
      }
      if (state.state === 'SPENT') {
        checkedProofs.spent.push(proofs[index]);
      } else {
        checkedProofs.ready.push(proofs[index]);
      }
    }

    this.#logger?.debug('Checked proof states', {
      mintUrl,
      keysetId,
      ready: checkedProofs.ready.length,
      spent: checkedProofs.spent.length,
    });

    if (checkedProofs.ready.length === 0) {
      this.#logger?.warn('No ready proofs to sweep, all spent', {
        mintUrl,
        keysetId,
        spentCount: checkedProofs.spent.length,
      });
      return;
    }

    const sweepFee = sweepWallet.getFeesForProofs(checkedProofs.ready);
    const sweepAmount = sumProofs(checkedProofs.ready);

    if (sweepAmount.lessThanOrEqual(sweepFee)) {
      this.#logger?.warn('Sweep amount is less than fee', {
        mintUrl,
        keysetId,
        amount: sweepAmount,
        fee: sweepFee,
      });
      return;
    }

    const sweepTotalAmount = sweepAmount.subtract(sweepFee);

    this.#logger?.debug('Sweep calculation', {
      mintUrl,
      keysetId,
      amount: sweepAmount,
      fee: sweepFee,
      total: sweepTotalAmount,
    });

    const outputAmounts = {
      keep: { amount: sweepTotalAmount.subtract(sweepTotalAmount), unit: normalizedUnit },
      send: { amount: sweepTotalAmount, unit: normalizedUnit },
    };
    const outputResults = await this.#proofService.createOutputsAndIncrementCounters(
      mintUrl,
      outputAmounts,
    );
    const outputConfig: OutputConfig = {
      send: { type: 'custom', data: outputResults.send },
      keep: { type: 'custom', data: outputResults.keep },
    };
    const { send, keep } = await wallet.send(
      sweepTotalAmount,
      checkedProofs.ready,
      undefined,
      outputConfig,
    );
    await this.#proofService.saveProofs(
      mintUrl,
      mapProofToCoreProof(mintUrl, 'ready', [...keep, ...send], { unit: normalizedUnit }),
    );

    this.#logger?.info('Keyset sweep completed', {
      mintUrl,
      keysetId,
      readyProofs: checkedProofs.ready.length,
      spentProofs: checkedProofs.spent.length,
      sweptAmount: sweepAmount,
      fee: sweepFee,
    });
  }

  /**
   * Restore and persist proofs for a single keyset.
   * Enforces the invariant: restored proofs must be >= previously stored proofs.
   * Throws on any validation or persistence error. No transactions are used here.
   */
  async restoreKeyset(
    mintUrl: string,
    wallet: Wallet,
    keysetId: string,
    unit = DEFAULT_UNIT,
  ): Promise<void> {
    const normalizedUnit = normalizeUnit(unit, { defaultUnit: DEFAULT_UNIT });
    this.#logger?.debug('Restoring keyset', { mintUrl, keysetId });
    const oldProofs = await this.#proofService.getProofsByKeysetId(mintUrl, keysetId);
    this.#logger?.debug('Existing proofs before restore', {
      mintUrl,
      keysetId,
      count: oldProofs.length,
    });

    const { proofs, lastCounterWithSignature } = await wallet.batchRestore({
      gapLimit: this.#restoreGapLimit,
      batchSize: this.#restoreBatchSize,
      counter: this.#restoreStartCounter,
      keysetId,
      filterSpent: false,
    });

    if (proofs.length === 0) {
      this.#logger?.warn('No proofs to restore', { mintUrl, keysetId });
      return;
    }

    this.#logger?.info('Batch restore result', {
      mintUrl,
      keysetId,
      restored: proofs.length,
      lastCounterWithSignature,
    });

    // Hard requirement: restored proofs must be >= previously stored proofs
    if (oldProofs.length > proofs.length) {
      this.#logger?.warn('Restored fewer proofs than previously stored', {
        mintUrl,
        keysetId,
        previous: oldProofs.length,
        restored: proofs.length,
      });
      throw new Error('Restored less proofs than expected.');
    }

    const states = await wallet.checkProofsStates(proofs);
    if (!Array.isArray(states) || states.length !== proofs.length) {
      this.#logger?.error('Malformed state check', {
        mintUrl,
        keysetId,
        statesLength: (states as unknown as { length?: number })?.length,
        proofsLength: proofs.length,
      });
      throw new Error('Malformed state check');
    }

    const checkedProofs: { spent: Proof[]; ready: Proof[] } = { spent: [], ready: [] };
    for (const [index, state] of states.entries()) {
      if (!proofs[index]) {
        this.#logger?.error('Proof not found', { mintUrl, keysetId, index });
        throw new Error('Proof not found');
      }
      if (state.state === 'SPENT') {
        checkedProofs.spent.push(proofs[index]);
      } else {
        checkedProofs.ready.push(proofs[index]);
      }
    }

    this.#logger?.debug('Checked proof states', {
      mintUrl,
      keysetId,
      ready: checkedProofs.ready.length,
      spent: checkedProofs.spent.length,
    });

    const newCounter = lastCounterWithSignature ? lastCounterWithSignature + 1 : 0;

    await this.#counterService.overwriteCounter(mintUrl, keysetId, newCounter);
    this.#logger?.debug('Requested counter overwrite for keyset', {
      mintUrl,
      keysetId,
      counter: newCounter,
    });

    await this.#proofService.saveProofs(
      mintUrl,
      mapProofToCoreProof(mintUrl, 'ready', checkedProofs.ready, { unit: normalizedUnit }),
    );
    this.#logger?.info('Saved restored proofs for keyset', {
      mintUrl,
      keysetId,
      total: checkedProofs.ready.length + checkedProofs.spent.length,
    });
  }
}
