import type {
  AuthSessionRepository,
  CounterRepository,
  HistoryProjectionRepository,
  KeyRingRepository,
  KeysetRepository,
  LegacyMintQuoteRepository,
  MeltQuoteRepository,
  MeltOperationRepository,
  MintQuoteRepository,
  MintRepository,
  ProofRepository,
  Repositories,
  RepositoryTransactionScope,
  SendOperationRepository,
  MintOperationRepository,
  PaymentRequestReceiveAttemptRepository,
  PaymentRequestReceiveOperationRepository,
  ReceiveOperationRepository,
} from '../index.ts';
import type {
  WalletAuthority,
  WalletAuthorityIdentity,
  WalletAuthorityState,
} from '../WalletAuthority.ts';
import { validateWalletAuthorityIdentity } from '../WalletAuthority.ts';
import {
  createRepositoryFacade,
  invokeRepositoryMethod,
  isRepositoryMutation,
} from '../RepositoryMutation.ts';
import {
  WalletAuthorityConflictError,
  WalletAuthorityGenerationExhaustedError,
  WalletAuthorityLifecycleError,
  WalletAuthorityNotAcquiredError,
  WalletAuthorityValidationError,
} from '../../models/Error.ts';
import { MemoryAuthSessionRepository } from './MemoryAuthSessionRepository';
import { MemoryCounterRepository } from './MemoryCounterRepository';
import { MemoryHistoryRepository } from './MemoryHistoryRepository';
import { MemoryKeyRingRepository } from './MemoryKeyRingRepository';
import { MemoryKeysetRepository } from './MemoryKeysetRepository';
import { MemoryMeltOperationRepository } from './MemoryMeltOperationRepository';
import { MemoryMeltQuoteRepository } from './MemoryMeltQuoteRepository';
import { MemoryLegacyMintQuoteRepository } from './MemoryLegacyMintQuoteRepository';
import { MemoryMintQuoteRepository } from './MemoryMintQuoteRepository';
import { MemoryMintRepository } from './MemoryMintRepository';
import { MemoryProofRepository } from './MemoryProofRepository';
import { MemorySendOperationRepository } from './MemorySendOperationRepository';
import { MemoryMintOperationRepository } from './MemoryMintOperationRepository';
import { MemoryReceiveOperationRepository } from './MemoryReceiveOperationRepository';
import {
  MemoryPaymentRequestReceiveAttemptRepository,
  MemoryPaymentRequestReceiveOperationRepository,
} from './MemoryPaymentRequestReceiveRepository';
import {
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
  type MemoryRepositoryStateOwner,
} from './MemoryRepositoryTransaction.ts';
import { MemoryOperationIdOwnership } from '../OperationIdOwnership.ts';
import {
  createMemoryMap,
  createMemoryPromise,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
  resolveMemoryPromise,
} from './MemoryCollectionIntrinsics.ts';

const nativeCreate = Object.create;
const nativeDefineProperty = Object.defineProperty;
const nativeDefineProperties = Object.defineProperties;
const nativeFreeze = Object.freeze;
const nativeKeys = Object.keys;

export class MemoryRepositories implements Repositories {
  mintRepository!: MintRepository;
  keyRingRepository!: KeyRingRepository;
  counterRepository!: CounterRepository;
  keysetRepository!: KeysetRepository;
  proofRepository!: ProofRepository;
  mintQuoteRepository!: MintQuoteRepository;
  legacyMintQuoteRepository!: LegacyMintQuoteRepository;
  meltQuoteRepository!: MeltQuoteRepository;
  historyRepository!: HistoryProjectionRepository;
  sendOperationRepository!: SendOperationRepository;
  meltOperationRepository!: MeltOperationRepository;
  authSessionRepository!: AuthSessionRepository;
  mintOperationRepository!: MintOperationRepository;
  receiveOperationRepository!: ReceiveOperationRepository;
  paymentRequestReceiveOperationRepository!: PaymentRequestReceiveOperationRepository;
  paymentRequestReceiveAttemptRepository!: PaymentRequestReceiveAttemptRepository;

  #backend = new MemoryRepositoryBackend();
  #initialized = false;
  #heldAuthority: WalletAuthority | null = null;
  #authorityState: WalletAuthorityState = 'unacquired';
  readonly claimSessionAttachment!: () => unknown;
  readonly releaseSessionAttachment!: (token: unknown) => boolean;

  constructor() {
    let sessionAttachment: object | null = null;
    nativeDefineProperties(this, {
      claimSessionAttachment: {
        configurable: false,
        enumerable: false,
        writable: false,
        value: (): unknown => {
          if (sessionAttachment !== null) {
            throw new WalletAuthorityLifecycleError(
              'The repository root is already attached to an active Manager',
            );
          }
          const token = (): void => {};
          sessionAttachment = token;
          return token;
        },
      },
      releaseSessionAttachment: {
        configurable: false,
        enumerable: false,
        writable: false,
        value: (token: unknown): boolean => {
          if (token !== sessionAttachment || sessionAttachment === null) return false;
          sessionAttachment = null;
          return true;
        },
      },
    });
    this.#initializeRepositoryProperties();
  }

  /** Create another runtime root over the same durable in-memory database. */
  createPeer(): MemoryRepositories {
    const peer = new MemoryRepositories();
    peer.#backend = this.#backend;
    return peer;
  }

  #initializeRepositoryProperties(): void {
    const keys = nativeKeys(this.#backend.state) as (keyof MemoryRepositoryState)[];
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index]!;
      nativeDefineProperty(this, key, {
        configurable: false,
        enumerable: true,
        writable: false,
        value: this.#wrapRootRepository(key),
      });
    }
  }

  async init(): Promise<void> {
    this.#initialized = true;
  }

  async acquireAuthority(identity: WalletAuthorityIdentity): Promise<WalletAuthority> {
    validateWalletAuthorityIdentity(identity);
    if (!this.#initialized)
      throw new WalletAuthorityLifecycleError('Repository is not initialized');
    if (this.#authorityState !== 'unacquired') {
      throw new WalletAuthorityLifecycleError(
        `Repository authority is already ${this.#authorityState}; create a new repository root`,
      );
    }
    const authority = await this.#runExclusive(async () => {
      const storeAuthority = memoryMapValues(this.#backend.authorities)[0];
      if (storeAuthority && storeAuthority.namespace !== identity.namespace) {
        throw new WalletAuthorityValidationError(
          `Wallet store is bound to namespace ${storeAuthority.namespace}, not ${identity.namespace}`,
        );
      }
      const previous = memoryMapGet(this.#backend.authorities, identity.namespace);
      const generation = (previous?.generation ?? 0) + 1;
      if (!Number.isSafeInteger(generation) || generation < 1) {
        throw new WalletAuthorityGenerationExhaustedError(identity.namespace);
      }
      const next: WalletAuthority = { ...identity, generation, status: 'active' };
      memoryMapSet(this.#backend.authorities, identity.namespace, next);
      return { ...next };
    });
    this.#heldAuthority = authority;
    this.#authorityState = 'active';
    return { ...authority };
  }

  async releaseAuthority(): Promise<boolean> {
    if (!this.#heldAuthority || this.#authorityState !== 'active') return false;
    const expected = { ...this.#heldAuthority };
    const released = await this.#runExclusive(async () => {
      const current = memoryMapGet(this.#backend.authorities, expected.namespace);
      if (!sameActiveAuthority(current, expected)) return false;
      memoryMapSet(this.#backend.authorities, expected.namespace, {
        ...expected,
        status: 'released',
      });
      return true;
    });
    this.#authorityState = released ? 'released' : 'stale';
    return released;
  }

  getAuthority(): WalletAuthority | null {
    return this.#heldAuthority ? { ...this.#heldAuthority } : null;
  }

  getAuthorityState(): WalletAuthorityState {
    return this.#authorityState;
  }

  async withTransaction<T>(fn: (repos: RepositoryTransactionScope) => Promise<T>): Promise<T> {
    if (!this.#initialized)
      throw new WalletAuthorityLifecycleError('Repository is not initialized');
    const expected = this.#requireAuthority();
    return this.#runExclusive(async () => {
      this.#assertAuthority(expected);
      // The callback only sees a detached snapshot. Copying it back is the atomic commit point.
      const staged = cloneMemoryRepositoryState(this.#backend.state);
      const transactionScope = createMemoryTransactionScope(staged);
      let result: T;
      try {
        result = await fn(transactionScope.scope);
      } finally {
        transactionScope.deactivate();
      }
      this.#assertAuthority(expected);
      copyMemoryRepositoryState(this.#backend.state, staged);
      return result;
    });
  }

  #wrapRootRepository<Key extends keyof MemoryRepositoryState>(
    key: Key,
  ): MemoryRepositoryState[Key] {
    return createRepositoryFacade(key, (method, args) => {
      // Detach and validate before a mutator can enter or queue behind the transaction gate.
      let detachedArgs: readonly unknown[];
      try {
        detachedArgs = cloneMemoryValue(args);
      } catch (error) {
        return createMemoryPromise<never>((_resolve, reject) => reject(error));
      }
      if (isRepositoryMutation(key, method)) {
        return this.withTransaction((scope) =>
          resolveMemoryPromise(invokeRepositoryMethod(key, scope[key], method, detachedArgs)),
        );
      }
      return this.#runRootOperation(() =>
        invokeRepositoryMethod(key, this.#backend.state[key], method, detachedArgs),
      );
    }) as MemoryRepositoryState[Key];
  }

  async #runRootOperation<T>(operation: () => T | Promise<T>): Promise<T> {
    while (this.#backend.pendingTransactionCount > 0) {
      await this.#backend.transactionQueue;
    }
    this.#beginRootOperation();
    try {
      return await operation();
    } finally {
      this.#endRootOperation();
    }
  }

  #beginRootOperation(): void {
    if (this.#backend.activeRootOperationCount === 0) {
      this.#backend.rootOperationsIdle = createMemoryPromise<void>((resolve) => {
        this.#backend.releaseRootOperations = resolve;
      });
    }
    this.#backend.activeRootOperationCount++;
  }

  #endRootOperation(): void {
    this.#backend.activeRootOperationCount--;
    if (this.#backend.activeRootOperationCount === 0) this.#backend.releaseRootOperations();
  }

  async #runExclusive<T>(work: () => Promise<T>): Promise<T> {
    const previous = this.#backend.transactionQueue;
    let release!: () => void;
    this.#backend.transactionQueue = createMemoryPromise<void>((resolve) => (release = resolve));
    this.#backend.pendingTransactionCount++;
    try {
      await previous;
      await this.#backend.rootOperationsIdle;
      return await work();
    } finally {
      this.#backend.pendingTransactionCount--;
      release();
    }
  }

  #requireAuthority(): WalletAuthority {
    if (!this.#heldAuthority) throw new WalletAuthorityNotAcquiredError();
    this.#assertAuthority(this.#heldAuthority);
    return { ...this.#heldAuthority };
  }

  #assertAuthority(expected: WalletAuthority): void {
    const current = memoryMapGet(this.#backend.authorities, expected.namespace);
    if (!sameActiveAuthority(current, expected)) {
      this.#authorityState = 'stale';
      throw new WalletAuthorityConflictError(
        expected.namespace,
        expected.generation,
        current?.generation,
      );
    }
  }
}

class MemoryRepositoryBackend {
  readonly state = createMemoryRepositoryState();
  readonly authorities = createMemoryMap<string, WalletAuthority>();
  transactionQueue: Promise<void> = resolveMemoryPromise(undefined);
  pendingTransactionCount = 0;
  activeRootOperationCount = 0;
  rootOperationsIdle: Promise<void> = resolveMemoryPromise(undefined);
  releaseRootOperations: () => void = () => {};
}

function sameActiveAuthority(
  current: WalletAuthority | undefined,
  expected: WalletAuthority,
): boolean {
  return (
    current?.status === 'active' &&
    current.namespace === expected.namespace &&
    current.ownerId === expected.ownerId &&
    current.generation === expected.generation
  );
}

type MemoryRepositoryState = ReturnType<typeof createMemoryRepositoryState>;

function createMemoryRepositoryState() {
  const operationIds = new MemoryOperationIdOwnership();
  const sendOperationRepository = new MemorySendOperationRepository(operationIds);
  const meltOperationRepository = new MemoryMeltOperationRepository(operationIds);
  const mintOperationRepository = new MemoryMintOperationRepository(operationIds);
  const receiveOperationRepository = new MemoryReceiveOperationRepository(operationIds);
  const mintQuoteRepository = new MemoryMintQuoteRepository();

  const state = {
    mintRepository: new MemoryMintRepository(),
    keyRingRepository: new MemoryKeyRingRepository(),
    counterRepository: new MemoryCounterRepository(),
    keysetRepository: new MemoryKeysetRepository(),
    proofRepository: new MemoryProofRepository(),
    mintQuoteRepository,
    legacyMintQuoteRepository: new MemoryLegacyMintQuoteRepository(),
    meltQuoteRepository: new MemoryMeltQuoteRepository(),
    historyRepository: new MemoryHistoryRepository({
      sendOperationRepository,
      meltOperationRepository,
      mintOperationRepository,
      mintQuoteRepository,
      receiveOperationRepository,
    }),
    sendOperationRepository,
    meltOperationRepository,
    authSessionRepository: new MemoryAuthSessionRepository(),
    mintOperationRepository,
    receiveOperationRepository,
    paymentRequestReceiveOperationRepository: new MemoryPaymentRequestReceiveOperationRepository(
      operationIds,
    ),
    paymentRequestReceiveAttemptRepository: new MemoryPaymentRequestReceiveAttemptRepository(
      operationIds,
    ),
  };

  type StateOwnerConstraint = {
    [Key in keyof typeof state]: MemoryRepositoryStateOwner<(typeof state)[Key]>;
  };
  return state satisfies StateOwnerConstraint;
}

function cloneMemoryRepositoryState(source: MemoryRepositoryState): MemoryRepositoryState {
  const clone = createMemoryRepositoryState();
  copyMemoryRepositoryState(clone, source);
  return clone;
}

function copyMemoryRepositoryState(
  target: MemoryRepositoryState,
  source: MemoryRepositoryState,
): void {
  const keys = nativeKeys(source) as (keyof MemoryRepositoryState)[];
  for (let index = 0; index < keys.length; index += 1) {
    const key = keys[index]!;
    // createMemoryRepositoryState statically enforces the protocol; this loop loses key correlation.
    const targetRepository = target[key] as MemoryRepositoryStateOwner<object>;
    targetRepository[COPY_MEMORY_REPOSITORY_STATE](source[key]);
  }
}

function createMemoryTransactionScope(state: MemoryRepositoryState): {
  scope: RepositoryTransactionScope;
  deactivate(): void;
} {
  let active = true;
  const scope = nativeCreate(null) as RepositoryTransactionScope;
  const keys = nativeKeys(state) as (keyof MemoryRepositoryState)[];
  for (let index = 0; index < keys.length; index += 1) {
    const key = keys[index]!;
    nativeDefineProperty(scope, key, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: createRepositoryFacade(key, (method, args) => {
        if (!active) throw new WalletAuthorityLifecycleError('Repository transaction has ended');
        let detachedArgs: readonly unknown[];
        try {
          detachedArgs = cloneMemoryValue(args);
        } catch (error) {
          return createMemoryPromise<never>((_resolve, reject) => reject(error));
        }
        return invokeRepositoryMethod(key, state[key], method, detachedArgs);
      }),
    });
  }
  nativeFreeze(scope);
  return {
    scope,
    deactivate: () => {
      active = false;
    },
  };
}
