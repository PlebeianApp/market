import { Amount, sumProofs, type Proof, type Token } from '@cashu/cashu-ts';
import { assertOutputProofs } from '@core/proofs/OutputProofs.ts';
import { normalizeUnit } from '@core/amounts.ts';
import {
  OperationIdConflictError,
  ProofValidationError,
  SendOperationConflictError,
  SendOperationIntentConflictError,
} from '@core/models/Error.ts';
import type {
  ExecutingSendOperation,
  FinalizedSendOperation,
  PendingSendOperation,
  PreparedSendOperation,
  RollingBackSendOperation,
  RolledBackSendOperation,
  SendOperation,
} from '@core/operations/send/SendOperation.ts';
import {
  getSendProofSecrets,
  isLegacyTokenlessP2pkSend,
  getKeepProofSecrets,
  isSameSendIntent,
  isTerminalOperation,
} from '@core/operations/send/SendOperation.ts';
import type { SendOperationRepository } from '@core/repositories';
import type { CoreProof } from '@core/types.ts';
import { normalizeMintUrl } from '@core/utils.ts';
import type { ScopedMintMetadataCommands } from '../mints/ScopedMintMetadataCommands.ts';
import type {
  PrepareSendInput,
  PreparedSendResult,
  ExecuteExactSendInput,
  ExecuteExactSendResult,
  BeginSwapExecutionInput,
  ClaimSendRecoveryInput,
  RecoverLegacyExactSendInput,
  RecoveredLegacyExactSend,
  SwapTransportRequest,
  BegunSwapExecution,
  ApplySwapResultInput,
  AppliedSwapResult,
  FailSwapExecutionInput,
  FailedSwapExecution,
  CancelPreparedSendInput,
  CancelledPreparedSend,
  CompletePendingSendInput,
  CompletedPendingSend,
  CleanupLegacyInitResult,
  CleanupOrphanedSendReservationsResult,
  BeginReclaimInput,
  BegunReclaim,
  CompleteReclaimInput,
  CompletedReclaim,
} from '../../send/types.ts';
import type { ScopedProofCommands } from '../proofs/ScopedProofCommands.ts';
import type { ScopedOutputCommands } from '../outputs/ScopedOutputCommands.ts';
import {
  commitRefundReclaimPlan,
  parseCommittedRefundReclaimPlan,
  serializeCommittedRefundReclaimPlan,
  serializeRefundOperationBinding,
  type CommittedRefundReclaimPlan,
} from '@core/operations/send/RefundReclaimPlan.ts';
import type { RefundReclaimPlanVerifier } from '../../../operations/send/RefundReclaimPlanVerifier.ts';

export interface ScopedSendCommands {
  prepare(input: PrepareSendInput): Promise<PreparedSendResult>;
  executeExact(input: ExecuteExactSendInput): Promise<ExecuteExactSendResult>;
  beginExecution(input: BeginSwapExecutionInput): Promise<BegunSwapExecution>;
  claimRecovery(input: ClaimSendRecoveryInput): Promise<BegunSwapExecution>;
  recoverLegacyExact(input: RecoverLegacyExactSendInput): Promise<RecoveredLegacyExactSend>;
  applyResult(input: ApplySwapResultInput): Promise<AppliedSwapResult>;
  failExecution(input: FailSwapExecutionInput): Promise<FailedSwapExecution>;
  cancelPrepared(input: CancelPreparedSendInput): Promise<CancelledPreparedSend>;
  completePending(input: CompletePendingSendInput): Promise<CompletedPendingSend>;
  cleanupOrphanedReservations(): Promise<CleanupOrphanedSendReservationsResult>;
  cleanupLegacyInit(operationId: string): Promise<CleanupLegacyInitResult>;
  beginReclaim(input: BeginReclaimInput): Promise<BegunReclaim>;
  completeReclaim(
    input: CompleteReclaimInput,
    refundReclaimPlanVerifier?: RefundReclaimPlanVerifier,
  ): Promise<CompletedReclaim>;
}

export class RepositorySendCommands implements ScopedSendCommands {
  constructor(
    private readonly sends: SendOperationRepository,
    private readonly otherOperations: ReadonlyArray<{
      type: string;
      repository: {
        getById(id: string): Promise<unknown | null>;
      };
    }>,
    private readonly proofs: ScopedProofCommands,
    private readonly outputs: ScopedOutputCommands,
    private readonly mints: Pick<ScopedMintMetadataCommands, 'assertTrusted'>,
  ) {}

  async prepare(input: PrepareSendInput): Promise<PreparedSendResult> {
    const operation = input.operation;
    const existing = await this.sends.getById(operation.id);
    if (existing) {
      if (
        operation.callerSuppliedId === true &&
        existing.state === 'prepared' &&
        isSameSendIntent(existing, operation)
      ) {
        return { outcome: 'joined', operation: existing };
      }
      if (operation.callerSuppliedId === true && existing.state === 'prepared') {
        throw new SendOperationIntentConflictError(operation.id);
      }
      throw new SendOperationConflictError(
        operation.id,
        `Send operation ${operation.id} already exists in state '${existing.state}'`,
      );
    }

    for (const candidate of this.otherOperations) {
      if (await candidate.repository.getById(operation.id)) {
        throw new OperationIdConflictError(operation.id, candidate.type);
      }
    }

    await this.mints.assertTrusted(operation.mintUrl);
    const selected = await this.proofs.selectAndReserve({
      mintUrl: operation.mintUrl,
      unit: operation.unit,
      operationId: operation.id,
      amount: operation.amount,
      forceSwap: input.forceSwap,
    });
    const inputAmount = sumProofs(selected.proofs);
    const inputProofSecrets = selected.proofs.map((proof) => proof.secret);

    let outputData: PreparedSendOperation['outputData'];
    let counterUpdate: PreparedSendResult['counter'];
    if (selected.needsSwap) {
      const allocation = await this.outputs.allocate({
        mintUrl: operation.mintUrl,
        unit: operation.unit,
        activeKeys: input.activeKeys,
        seed: input.seed,
        keepAmount: inputAmount.subtract(operation.amount.add(selected.fee)),
        sendAmount: operation.amount,
        fixedSendOutputs: input.fixedSendOutputs,
      });
      outputData = allocation.outputData;
      counterUpdate = allocation.counter;
    } else {
      await this.outputs.assertActiveKeys(operation.mintUrl, operation.unit, input.activeKeys);
    }

    const durableOperation = { ...operation };
    delete durableOperation.callerSuppliedId;
    const prepared: PreparedSendOperation = {
      ...durableOperation,
      state: 'prepared',
      revision: 0,
      updatedAt: operation.updatedAt,
      needsSwap: selected.needsSwap,
      fee: selected.fee,
      inputAmount,
      inputProofSecrets,
      outputData,
    };
    await this.sends.create(prepared);

    return {
      outcome: 'created',
      operation: prepared,
      reservation: {
        mintUrl: operation.mintUrl,
        operationId: operation.id,
        secrets: inputProofSecrets,
        amount: inputAmount,
        unit: operation.unit,
      },
      counter: counterUpdate,
    };
  }

  async executeExact(input: ExecuteExactSendInput): Promise<ExecuteExactSendResult> {
    const current = await this.sends.getById(input.operationId);
    const idempotent = getIdempotentExactResult(current, input);
    if (idempotent) return idempotent;

    if (!current || current.state !== 'prepared') {
      throw new SendOperationConflictError(
        input.operationId,
        'Exact Send execution lost a state or revision conflict',
      );
    }
    if (current.needsSwap || current.method !== 'default') {
      throw new ProofValidationError(`Send operation ${input.operationId} requires a mint swap`);
    }

    const proofs = await this.getOwnedReadyInputs(current);
    assertExactInputs(proofs, current);
    const revision = current.revision ?? 0;
    const normalizedMemo = normalizeMemo(input.memo);
    const token: Token = {
      mint: current.mintUrl,
      proofs,
      unit: current.unit,
      ...(normalizedMemo ? { memo: normalizedMemo } : {}),
    };
    const pending: ExecuteExactSendResult['operation'] = {
      ...current,
      state: 'pending',
      updatedAt: input.updatedAt,
      token,
    };

    await this.proofs.markInflight({
      mintUrl: current.mintUrl,
      unit: current.unit,
      operationId: current.id,
      secrets: current.inputProofSecrets,
    });
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'prepared',
      expectedRevision: revision,
      next: pending,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Exact Send execution lost a state or revision conflict',
      );
    }
    pending.revision = revision + 1;

    return { operation: pending, token, committed: true };
  }

  async beginExecution(input: BeginSwapExecutionInput): Promise<BegunSwapExecution> {
    const current = await this.sends.getById(input.operationId);
    if (!current) {
      throw new SendOperationConflictError(input.operationId, 'Send operation not found');
    }
    if (current.state !== 'prepared') {
      throw new SendOperationConflictError(
        input.operationId,
        `Cannot begin Send execution in state ${current.state}`,
      );
    }
    if (!current.needsSwap || !current.outputData) {
      throw new SendOperationConflictError(
        input.operationId,
        'Swap execution requires a prepared swap request',
      );
    }

    const inputProofs = await this.getOwnedReadyInputs(current);
    const revision = current.revision ?? 0;
    const executing: ExecutingSendOperation = {
      ...current,
      state: 'executing',
      revision: revision + 1,
      updatedAt: input.updatedAt,
      executionMemo: input.memo,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'prepared',
      expectedRevision: revision,
      next: executing,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Send execution lost a prepared-state conflict',
      );
    }

    return {
      operation: executing,
      request: {
        mintUrl: executing.mintUrl,
        unit: executing.unit,
        amount: executing.amount,
        inputProofs,
        outputData: current.outputData,
      },
    };
  }

  async claimRecovery(input: ClaimSendRecoveryInput): Promise<BegunSwapExecution> {
    const current = await this.sends.getById(input.operationId);
    if (
      !current ||
      current.state !== 'executing' ||
      !current.needsSwap ||
      !current.outputData ||
      (current.revision ?? 0) !== input.expectedRevision
    ) {
      throw new SendOperationConflictError(
        input.operationId,
        'Send recovery lost an executing-state or revision conflict',
      );
    }
    // Legacy handlers spent inputs before persisting pending. A recovery claim never releases them.
    const inputProofs = await this.proofs.getOwned({
      mintUrl: current.mintUrl,
      unit: current.unit,
      operationId: current.id,
      secrets: current.inputProofSecrets,
      state: ['ready', 'spent'],
    });
    const claimed: ExecutingSendOperation = {
      ...current,
      revision: input.expectedRevision + 1,
      updatedAt: input.updatedAt,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'executing',
      expectedRevision: input.expectedRevision,
      next: claimed,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Send recovery lost an executing-state or revision conflict',
      );
    }
    return {
      operation: claimed,
      request: {
        mintUrl: claimed.mintUrl,
        unit: claimed.unit,
        amount: claimed.amount,
        inputProofs,
        outputData: claimed.outputData!,
      },
    };
  }

  async recoverLegacyExact(input: RecoverLegacyExactSendInput): Promise<RecoveredLegacyExactSend> {
    const current = await this.sends.getById(input.operationId);
    // New exact Sends never enter executing. Legacy rows normalize their absent revision to zero.
    if (
      !current ||
      current.state !== 'executing' ||
      (current.revision ?? 0) !== 0 ||
      current.method !== 'default' ||
      current.needsSwap ||
      current.outputData ||
      ('token' in current && current.token)
    ) {
      throw new SendOperationConflictError(
        input.operationId,
        'Legacy exact Send recovery lost a state or revision conflict',
      );
    }
    const inputs = await this.proofs.getOwned({
      mintUrl: current.mintUrl,
      unit: current.unit,
      operationId: current.id,
      secrets: current.inputProofSecrets,
      state: ['ready', 'inflight'],
    });
    assertExactInputs(inputs, current);
    // The old exact path returned a token only after persisting pending and never submitted inputs.
    await this.proofs.releaseUnsubmitted({
      mintUrl: current.mintUrl,
      unit: current.unit,
      operationId: current.id,
      secrets: current.inputProofSecrets,
    });
    const operation: RolledBackSendOperation = {
      ...current,
      state: 'rolled_back',
      revision: 1,
      updatedAt: input.updatedAt,
      error: 'Recovered legacy exact Send interrupted before token delivery',
    };
    if (
      !(await this.sends.transition({
        operationId: current.id,
        expectedState: 'executing',
        expectedRevision: 0,
        next: operation,
      }))
    ) {
      throw new SendOperationConflictError(current.id, 'Legacy exact Send recovery conflicted');
    }
    return {
      operation,
      readyProofSecrets: inputs
        .filter((proof) => proof.state === 'inflight')
        .map((proof) => proof.secret),
      releasedInputSecrets: [...current.inputProofSecrets],
      committed: true,
    };
  }

  async applyResult(input: ApplySwapResultInput): Promise<AppliedSwapResult> {
    const current = await this.sends.getById(input.operationId);
    if (!current) {
      throw new SendOperationConflictError(input.operationId, 'Send operation not found');
    }
    if (current.state === 'pending') {
      if (
        !current.needsSwap ||
        !current.outputData ||
        !current.token ||
        !sameToken(current.token, input.token)
      ) {
        throw new SendOperationConflictError(
          input.operationId,
          'Send result conflicts with the persisted pending token',
        );
      }
      assertSwapResult(current, input);
      const persistedProofs = (
        await this.proofs.getProofsByOperationId(current.mintUrl, current.id)
      ).filter((proof) => proof.createdByOperationId === current.id);
      if (!sameCoreProofSet(persistedProofs, [...input.keepProofs, ...input.sendProofs])) {
        throw new SendOperationConflictError(
          input.operationId,
          'Send result conflicts with the persisted pending proofs',
        );
      }
      return {
        operation: current,
        savedProofs: [],
        inflightProofSecrets: [],
        spentInputSecrets: [],
        committed: false,
      };
    }
    if (current.state !== 'executing' || !current.needsSwap || !current.outputData) {
      throw new SendOperationConflictError(
        input.operationId,
        `Cannot apply Send result in state ${current.state}`,
      );
    }
    const revision = current.revision ?? 0;
    assertSwapResult(current, input);
    const outputs = [...input.keepProofs, ...input.sendProofs];
    const existing = await this.proofs.getProofsBySecrets(
      current.mintUrl,
      outputs.map((proof) => proof.secret),
    );
    const existingSecrets = new Set(existing.map((proof) => proof.secret));
    if (
      !sameCoreProofSet(
        existing,
        outputs.filter((proof) => existingSecrets.has(proof.secret)),
      )
    ) {
      throw new ProofValidationError(
        'Swap output already exists with conflicting proof data or ownership',
      );
    }
    // Old default recovery saved send outputs as ready. Remove those from the available balance
    // before publishing their pending token, without taking another operation's reservation.
    const sendSecrets = new Set(input.sendProofs.map((proof) => proof.secret));
    const inflightProofSecrets = existing
      .filter((proof) => sendSecrets.has(proof.secret) && proof.state === 'ready')
      .map((proof) => proof.secret);
    if (inflightProofSecrets.length > 0) {
      await this.proofs.markInflight({
        mintUrl: current.mintUrl,
        unit: current.unit,
        operationId: current.id,
        secrets: inflightProofSecrets,
        ownership: 'created',
      });
    }
    // Preserve change reservations and spending, as well as already inflight or spent send outputs.
    const savedProofs = outputs.filter((proof) => !existingSecrets.has(proof.secret));
    await this.proofs.settleSpend({
      mintUrl: current.mintUrl,
      unit: current.unit,
      operationId: current.id,
      secrets: current.inputProofSecrets,
      state: ['ready', 'spent'],
      outputs: savedProofs,
    });

    const pending: PendingSendOperation = {
      ...current,
      state: 'pending',
      revision: (current.revision ?? 0) + 1,
      updatedAt: input.updatedAt,
      token: input.token,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'executing',
      expectedRevision: revision,
      next: pending,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Send result lost an executing-state conflict',
      );
    }

    return {
      operation: pending,
      savedProofs,
      inflightProofSecrets,
      spentInputSecrets: [...current.inputProofSecrets],
      committed: true,
    };
  }

  async failExecution(input: FailSwapExecutionInput): Promise<FailedSwapExecution> {
    const current = await this.sends.getById(input.operationId);
    if (!current) {
      throw new SendOperationConflictError(input.operationId, 'Send operation not found');
    }
    if (current.state === 'rolled_back' && current.error === input.error) {
      return {
        operation: current,
        releasedInputSecrets: [],
        committed: false,
      };
    }
    if (current.state !== 'executing' || !current.needsSwap) {
      throw new SendOperationConflictError(
        input.operationId,
        `Cannot fail Send execution in state ${current.state}`,
      );
    }
    const revision = current.revision ?? 0;
    if (revision !== input.expectedRevision) {
      throw new SendOperationConflictError(
        input.operationId,
        'Send failure lost an executing revision conflict',
      );
    }
    await this.getOwnedReadyInputs(current);
    await this.proofs.releaseOwned(current.mintUrl, current.id, current.inputProofSecrets);
    const failed: RolledBackSendOperation = {
      ...current,
      state: 'rolled_back',
      revision: (current.revision ?? 0) + 1,
      updatedAt: input.updatedAt,
      error: input.error,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'executing',
      expectedRevision: revision,
      next: failed,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Send failure lost an executing-state conflict',
      );
    }

    return {
      operation: failed,
      releasedInputSecrets: [...current.inputProofSecrets],
      committed: true,
    };
  }

  async cancelPrepared(input: CancelPreparedSendInput): Promise<CancelledPreparedSend> {
    const current = await this.sends.getById(input.operationId);
    if (!current) {
      throw new SendOperationConflictError(input.operationId, 'Send operation not found');
    }
    if (current.state === 'rolled_back' && current.error === input.reason) {
      return { operation: current, releasedInputSecrets: [], committed: false };
    }
    if (current.state !== 'prepared') {
      throw new SendOperationConflictError(
        input.operationId,
        'Send cancellation lost a prepared-state or revision conflict',
      );
    }

    const revision = current.revision ?? 0;
    await this.getOwnedReadyInputs(current);
    await this.proofs.releaseOwned(current.mintUrl, current.id, current.inputProofSecrets);
    const rolledBack: RolledBackSendOperation = {
      ...current,
      state: 'rolled_back',
      revision: revision + 1,
      updatedAt: input.updatedAt,
      error: input.reason,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'prepared',
      expectedRevision: revision,
      next: rolledBack,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Send cancellation lost a prepared-state or revision conflict',
      );
    }

    return {
      operation: rolledBack,
      releasedInputSecrets: [...current.inputProofSecrets],
      committed: true,
    };
  }

  async completePending(input: CompletePendingSendInput): Promise<CompletedPendingSend> {
    const current = await this.sends.getById(input.operationId);
    if (!current) {
      throw new SendOperationConflictError(input.operationId, 'Send operation not found');
    }
    if (current.state === 'finalized') {
      return {
        operation: current,
        spentProofSecrets: [],
        releasedInputSecrets: [],
        committed: false,
      };
    }
    if (current.state !== 'pending') {
      throw new SendOperationConflictError(
        input.operationId,
        'Send completion lost a pending-state or revision conflict',
      );
    }

    const revision = current.revision ?? 0;
    const expectedSecrets = getSendProofSecrets(current);
    if (expectedSecrets.length === 0 || new Set(expectedSecrets).size !== expectedSecrets.length) {
      throw new ProofValidationError(`Send operation ${current.id} has invalid send proof data`);
    }
    const observedSecrets = input.spentProofSecrets ?? [];
    if (new Set(observedSecrets).size !== observedSecrets.length) {
      throw new ProofValidationError('Send completion contains duplicate proof observations');
    }
    const expectedSet = new Set(expectedSecrets);
    for (const secret of observedSecrets) {
      if (!expectedSet.has(secret)) {
        throw new ProofValidationError(`Proof ${secret} does not belong to Send operation`);
      }
    }

    const legacyObservation = input.legacyP2pkOutputObservation;
    if (
      legacyObservation &&
      (!isLegacyTokenlessP2pkSend(current) ||
        legacyObservation.expectedRevision !== revision ||
        legacyObservation.mintUrl !== current.mintUrl ||
        legacyObservation.unit !== current.unit ||
        JSON.stringify(legacyObservation.outputData) !== JSON.stringify(current.outputData) ||
        observedSecrets.length !== expectedSecrets.length)
    ) {
      throw new ProofValidationError(
        'Cannot complete legacy P2PK Send: stale or incomplete observation',
      );
    }

    const sendProofs = await this.proofs.getProofsBySecrets(current.mintUrl, expectedSecrets);
    const sendBySecret = new Map(sendProofs.map((proof) => [proof.secret, proof]));
    if (!legacyObservation && sendBySecret.size !== expectedSecrets.length) {
      throw new ProofValidationError('Cannot complete Send operation: missing send proof metadata');
    }
    if (
      !legacyObservation &&
      (!current.token ||
        current.token.mint !== current.mintUrl ||
        normalizeUnit(current.token.unit) !== normalizeUnit(current.unit) ||
        !sameProofSet(current.token.proofs, sendProofs))
    ) {
      throw new ProofValidationError('Send proofs do not match the persisted token');
    }
    for (const secret of expectedSecrets) {
      const proof = sendBySecret.get(secret);
      if (legacyObservation) {
        // Old restore omitted spent outputs. Validate any surviving rows without recreating them.
        if (!proof) continue;
        const output = legacyObservation.outputData.send[expectedSecrets.indexOf(secret)]!;
        if (
          proof.id !== output.blindedMessage.id ||
          !Amount.from(proof.amount).equals(Amount.from(output.blindedMessage.amount))
        ) {
          throw new ProofValidationError('Legacy P2PK proof does not match allocated output');
        }
      }
      const owned = current.needsSwap
        ? proof?.createdByOperationId === current.id
        : proof && canCompleteWithInput(proof, current.id);
      if (
        !proof ||
        !owned ||
        proof.mintUrl !== current.mintUrl ||
        normalizeUnit(proof.unit) !== normalizeUnit(current.unit) ||
        (proof.state !== 'inflight' && proof.state !== 'spent')
      ) {
        throw new ProofValidationError(`Send proof ${secret} is not inflight and operation-owned`);
      }
    }

    const newlySpent = observedSecrets.filter(
      (secret) => sendBySecret.get(secret)?.state === 'inflight',
    );
    if (newlySpent.length > 0) {
      await this.proofs.recordSpent({
        mintUrl: current.mintUrl,
        unit: current.unit,
        operationId: current.id,
        secrets: newlySpent,
        ownership: current.needsSwap ? 'created' : 'used',
      });
    }
    const allSpent = expectedSecrets.every(
      (secret) => observedSecrets.includes(secret) || sendBySecret.get(secret)?.state === 'spent',
    );
    if (!allSpent) {
      return {
        operation: current,
        spentProofSecrets: newlySpent,
        releasedInputSecrets: [],
        committed: newlySpent.length > 0,
      };
    }

    const inputs = await this.proofs.getProofsBySecrets(current.mintUrl, current.inputProofSecrets);
    const inputBySecret = new Map(inputs.map((proof) => [proof.secret, proof]));
    if (inputBySecret.size !== current.inputProofSecrets.length) {
      throw new ProofValidationError(
        'Cannot complete Send operation: missing input proof metadata',
      );
    }
    for (const secret of current.inputProofSecrets) {
      const proof = inputBySecret.get(secret);
      if (
        !proof ||
        !canCompleteWithInput(proof, current.id) ||
        proof.mintUrl !== current.mintUrl ||
        normalizeUnit(proof.unit) !== normalizeUnit(current.unit) ||
        proof.state !== 'spent'
      ) {
        throw new ProofValidationError(`Send input ${secret} is not spent and operation-owned`);
      }
    }
    const releasedInputSecrets = inputs
      .filter((proof) => proof.usedByOperationId === current.id)
      .map((proof) => proof.secret);
    if (releasedInputSecrets.length > 0) {
      await this.proofs.releaseOwned(current.mintUrl, current.id, releasedInputSecrets);
    }

    const finalized: FinalizedSendOperation = {
      ...current,
      state: 'finalized',
      revision: revision + 1,
      updatedAt: input.updatedAt,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'pending',
      expectedRevision: revision,
      next: finalized,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Send completion lost a pending-state or revision conflict',
      );
    }

    return {
      operation: finalized,
      spentProofSecrets: newlySpent,
      releasedInputSecrets,
      committed: true,
    };
  }

  async cleanupLegacyInit(operationId: string): Promise<CleanupLegacyInitResult> {
    const current = await this.sends.getById(operationId);
    if (!current || current.state !== 'init') {
      throw new SendOperationConflictError(operationId, 'Legacy Send init operation not found');
    }
    const operationProofs = await this.proofs.getProofsByOperationId(current.mintUrl, current.id);
    const ownedSecrets = operationProofs
      .filter((proof) => proof.usedByOperationId === current.id)
      .map((proof) => proof.secret);
    if (ownedSecrets.length > 0) {
      await this.proofs.releaseOwned(current.mintUrl, current.id, ownedSecrets);
    }
    await this.sends.delete(current.id);
    return {
      operationId: current.id,
      mintUrl: current.mintUrl,
      releasedProofSecrets: ownedSecrets,
    };
  }

  async cleanupOrphanedReservations(): Promise<CleanupOrphanedSendReservationsResult> {
    const reservedProofs = await this.proofs.getReservedProofs();
    const reservedByMint = new Map<string, CoreProof[]>();
    for (const proof of reservedProofs) {
      if (!proof.usedByOperationId) continue;
      const proofs = reservedByMint.get(proof.mintUrl) ?? [];
      proofs.push(proof);
      reservedByMint.set(proof.mintUrl, proofs);
    }

    const released: CleanupOrphanedSendReservationsResult['released'] = [];
    for (const [mintUrl, reserved] of reservedByMint) {
      const operations = await this.sends.getByMintUrl(mintUrl);
      const operationById = new Map(operations.map((operation) => [operation.id, operation]));
      const secrets = reserved
        .filter((proof) => {
          const operation = operationById.get(proof.usedByOperationId!);
          // A missing Send record does not establish ownership: Melt and future
          // workflows also reserve proofs. Only clean up known terminal Sends.
          return operation !== undefined && isTerminalOperation(operation);
        })
        .map((proof) => proof.secret);
      if (secrets.length > 0) released.push({ mintUrl, secrets });
    }
    for (const group of released) {
      const reserved = reservedByMint.get(group.mintUrl)!;
      const owners = new Set(
        reserved
          .filter((proof) => group.secrets.includes(proof.secret))
          .map((proof) => proof.usedByOperationId!),
      );
      for (const owner of owners) {
        await this.proofs.releaseOwned(
          group.mintUrl,
          owner,
          reserved
            .filter(
              (proof) => proof.usedByOperationId === owner && group.secrets.includes(proof.secret),
            )
            .map((proof) => proof.secret),
        );
      }
    }
    return {
      released,
      count: released.reduce((count, group) => count + group.secrets.length, 0),
    };
  }

  async beginReclaim(input: BeginReclaimInput): Promise<BegunReclaim> {
    const current = await this.sends.getById(input.operationId);
    const refund = input.spendingPath === 'refund';
    if (
      !current ||
      current.state !== 'pending' ||
      (refund ? current.method !== 'p2pk' : current.method !== 'default') ||
      (refund && (current.revision ?? 0) !== input.expectedRevision)
    ) {
      throw new SendOperationConflictError(
        input.operationId,
        'Pending Send reclaim lost a state or revision conflict',
      );
    }
    const sendSecrets = getSendProofSecrets(current);
    if (new Set(sendSecrets).size !== sendSecrets.length) {
      throw new ProofValidationError('Send reclaim inputs must be unique');
    }
    if (
      refund &&
      (input.expectedInputProofSecrets.length !== sendSecrets.length ||
        input.expectedInputProofSecrets.some((secret, index) => secret !== sendSecrets[index]))
    ) {
      throw new SendOperationConflictError(
        current.id,
        'P2PK refund input binding no longer matches the Send operation',
      );
    }
    const associated = await this.proofs.getProofsByOperationId(current.mintUrl, current.id);
    const secrets = associated
      .filter((proof) => sendSecrets.includes(proof.secret) && proof.state === 'inflight')
      .map((proof) => proof.secret);
    const inputProofs = await this.proofs.getOwned({
      mintUrl: current.mintUrl,
      unit: current.unit,
      operationId: current.id,
      secrets,
      state: 'inflight',
      ownership: current.needsSwap ? 'created' : 'used',
    });
    if (
      refund &&
      (inputProofs.length !== sendSecrets.length ||
        !sendSecrets.every((secret) => inputProofs.some((proof) => proof.secret === secret)))
    ) {
      throw new SendOperationConflictError(
        current.id,
        'P2PK refund requires every exact operation-owned inflight proof',
      );
    }
    const orderedInputProofs = refund
      ? sendSecrets.map((secret) => inputProofs.find((proof) => proof.secret === secret)!)
      : inputProofs;
    const total = sumProofs(orderedInputProofs);
    const fee = await this.proofs.getFee(current.mintUrl, current.unit, orderedInputProofs);
    const skippedForFees = orderedInputProofs.length > 0 && total.lessThanOrEqual(fee);
    if (refund && (orderedInputProofs.length === 0 || skippedForFees)) {
      throw new ProofValidationError('P2PK refund cannot allocate a reclaim output after fees');
    }
    const allocation =
      orderedInputProofs.length > 0 && !skippedForFees
        ? await this.outputs.allocate({
            mintUrl: current.mintUrl,
            unit: current.unit,
            activeKeys: input.activeKeys,
            seed: input.seed,
            keepAmount: total.subtract(fee),
            sendAmount: Amount.zero(),
          })
        : undefined;
    const revision = current.revision ?? 0;
    const reclaimData: RollingBackSendOperation['reclaimData'] = allocation
      ? refund
        ? (() => {
            if (!allocation.allocation) {
              throw new ProofValidationError('P2PK refund output allocation is incomplete');
            }
            const plan = {
              version: 1 as const,
              operationId: current.id,
              mintUrl: current.mintUrl,
              unit: normalizeUnit(current.unit),
              inputProofSecrets: [...input.expectedInputProofSecrets],
              inputOwnership: current.needsSwap ? ('created' as const) : ('used' as const),
              outputData: allocation.outputData,
              spendingPath: 'refund' as const,
              conditionFingerprint: input.conditionFingerprint,
              refundPublicKeyX: input.refundPublicKeyX,
              allocation: allocation.allocation,
            };
            return {
              ...plan,
              planCommitment: commitRefundReclaimPlan(plan, input.seed),
            };
          })()
        : { inputProofSecrets: secrets, outputData: allocation.outputData }
      : undefined;
    const rollingBack: RollingBackSendOperation = {
      ...current,
      state: 'rolling_back',
      revision: revision + 1,
      updatedAt: input.updatedAt,
      // Keep the original Send request intact. Reclaim has a separate Output Allocation.
      reclaimData,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'pending',
      expectedRevision: revision,
      next: rollingBack,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Pending Send reclaim lost a state or revision conflict',
      );
    }
    return {
      operation: rollingBack,
      inputProofs: orderedInputProofs,
      counter: allocation?.counter,
      skippedForFees,
    };
  }

  async completeReclaim(
    input: CompleteReclaimInput,
    refundReclaimPlanVerifier?: RefundReclaimPlanVerifier,
  ): Promise<CompletedReclaim> {
    const current = await this.sends.getById(input.operationId);
    if (!current || current.state !== 'rolling_back') {
      throw new SendOperationConflictError(
        input.operationId,
        'Pending Send reclaim completion lost a state or revision conflict',
      );
    }
    const allocation = current.reclaimData;
    if (input.refundAuthorization || allocation?.spendingPath === 'refund') {
      const authorization = input.refundAuthorization;
      let currentPlan: CommittedRefundReclaimPlan | undefined;
      try {
        currentPlan = allocation ? parseCommittedRefundReclaimPlan(allocation) : undefined;
      } catch {
        throw new SendOperationConflictError(
          input.operationId,
          'Authenticated P2PK refund plan changed before completion',
        );
      }
      const expectedOwnership = current.needsSwap ? 'created' : 'used';
      const exactInputs = getSendProofSecrets(current);
      if (
        !authorization ||
        !currentPlan ||
        current.method !== 'p2pk' ||
        currentPlan.version !== 1 ||
        currentPlan.spendingPath !== 'refund' ||
        authorization.version !== 1 ||
        current.id !== authorization.operationId ||
        currentPlan.planCommitment !== authorization.planCommitment ||
        serializeCommittedRefundReclaimPlan(currentPlan) !== authorization.canonicalPlan ||
        currentPlan.operationId !== current.id ||
        currentPlan.mintUrl !== normalizeMintUrl(current.mintUrl) ||
        normalizeUnit(current.unit) !== currentPlan.unit ||
        expectedOwnership !== currentPlan.inputOwnership ||
        exactInputs.length !== currentPlan.inputProofSecrets.length ||
        exactInputs.some((secret, index) => secret !== currentPlan.inputProofSecrets[index]) ||
        serializeRefundOperationBinding({
          version: 1,
          operationId: current.id,
          revision: current.revision ?? 0,
          state: current.state,
          mintUrl: normalizeMintUrl(current.mintUrl),
          unit: normalizeUnit(current.unit),
          method: current.method,
          methodData: current.methodData,
          needsSwap: current.needsSwap,
          inputProofSecrets: exactInputs,
          inputOwnership: expectedOwnership,
        }) !== authorization.operationBinding
      ) {
        throw new SendOperationConflictError(
          input.operationId,
          'Authenticated P2PK refund plan changed before completion',
        );
      }
      let seed: Uint8Array;
      try {
        if (!refundReclaimPlanVerifier) throw new Error('Verifier unavailable');
        seed = refundReclaimPlanVerifier(currentPlan, authorization.planCommitment);
      } catch {
        throw new SendOperationConflictError(
          input.operationId,
          'Authenticated P2PK refund commitment is invalid',
        );
      }
      try {
        await this.outputs.assertDeterministicAllocation({
          mintUrl: current.mintUrl,
          unit: current.unit,
          keysetId: currentPlan.allocation.keysetId,
          counterStart: currentPlan.allocation.counterStart,
          counterEnd: currentPlan.allocation.counterEnd,
          seed,
          outputData: currentPlan.outputData,
        });
      } finally {
        for (let index = 0; index < seed.length; index++) seed[index] = 0;
      }
    }
    const spentProofSecrets = allocation?.inputProofSecrets ?? [];
    if (allocation) {
      assertOutputProofs({
        mintUrl: current.mintUrl,
        unit: current.unit,
        outputData: allocation.outputData,
        kind: 'keep',
        state: 'ready',
        proofs: input.proofs,
      });
      await this.proofs.settleSpend({
        mintUrl: current.mintUrl,
        unit: current.unit,
        operationId: current.id,
        secrets: spentProofSecrets,
        state: ['inflight', 'spent'],
        ownership: current.needsSwap ? 'created' : 'used',
        outputs: input.proofs,
      });
    } else if (input.proofs.length > 0) {
      throw new ProofValidationError('Reclaimed proofs have no committed output plan');
    }
    const associated = await this.proofs.getProofsByOperationId(current.mintUrl, current.id);
    const releaseCandidates = new Set([
      ...current.inputProofSecrets,
      ...getKeepProofSecrets(current),
    ]);
    const releasedProofSecrets = associated
      .filter(
        (proof) => proof.usedByOperationId === current.id && releaseCandidates.has(proof.secret),
      )
      .map((proof) => proof.secret);
    await this.proofs.releaseOwned(current.mintUrl, current.id, releasedProofSecrets);
    const revision = current.revision ?? 0;
    const rolledBack: RolledBackSendOperation = {
      ...current,
      state: 'rolled_back',
      revision: revision + 1,
      updatedAt: input.updatedAt,
      error: input.reason,
    };
    const transitioned = await this.sends.transition({
      operationId: current.id,
      expectedState: 'rolling_back',
      expectedRevision: revision,
      next: rolledBack,
    });
    if (!transitioned) {
      throw new SendOperationConflictError(
        current.id,
        'Pending Send reclaim completion lost a state or revision conflict',
      );
    }
    return {
      operation: rolledBack,
      savedProofs: input.proofs,
      spentProofSecrets,
      releasedProofSecrets,
    };
  }

  private async getOwnedReadyInputs(
    operation: PreparedSendOperation | ExecutingSendOperation,
  ): Promise<CoreProof[]> {
    return this.proofs.getOwned({
      mintUrl: operation.mintUrl,
      unit: operation.unit,
      operationId: operation.id,
      secrets: operation.inputProofSecrets,
      state: 'ready',
    });
  }
}

/** Completion can resume after an old finalizer released already-spent inputs before crashing. */
function canCompleteWithInput(proof: CoreProof, operationId: string): boolean {
  return (
    proof.usedByOperationId === operationId ||
    (proof.usedByOperationId == null && proof.state === 'spent')
  );
}

function getIdempotentExactResult(
  current: SendOperation | null,
  input: ExecuteExactSendInput,
): ExecuteExactSendResult | undefined {
  if (!current || current.state !== 'pending' || current.needsSwap || !current.token) {
    return undefined;
  }
  if (!isEquivalentExactToken(current, current.token, input)) {
    throw new SendOperationConflictError(
      input.operationId,
      'Exact Send result differs from the already committed operation',
    );
  }
  return {
    operation: current as ExecuteExactSendResult['operation'],
    token: current.token,
    committed: false,
  };
}

function isEquivalentExactToken(
  operation: PendingSendOperation,
  token: Token,
  input: ExecuteExactSendInput,
): boolean {
  return (
    token.mint === operation.mintUrl &&
    normalizeUnit(token.unit) === normalizeUnit(operation.unit) &&
    normalizeMemo(token.memo) === normalizeMemo(input.memo) &&
    token.proofs.length === operation.inputProofSecrets.length &&
    token.proofs.every((proof, index) => proof.secret === operation.inputProofSecrets[index])
  );
}

function assertExactInputs(
  resolved: Proof[],
  operation: PreparedSendOperation | ExecutingSendOperation,
): void {
  if (
    !sumProofs(resolved).equals(operation.amount) ||
    !operation.inputAmount.equals(operation.amount) ||
    !operation.fee.isZero()
  ) {
    throw new ProofValidationError(`Send operation ${operation.id} is not an exact proof match`);
  }
}

function normalizeMemo(memo: string | undefined): string | undefined {
  const trimmed = memo?.trim();
  return trimmed ? trimmed : undefined;
}

function assertSwapResult(
  operation: ExecutingSendOperation | PendingSendOperation,
  input: ApplySwapResultInput,
): void {
  assertOutputProofs({
    ...operation,
    outputData: operation.outputData!,
    createdByOperationId: operation.id,
    proofs: input.keepProofs,
    state: 'ready',
    kind: 'keep',
  });
  assertOutputProofs({
    ...operation,
    outputData: operation.outputData!,
    createdByOperationId: operation.id,
    proofs: input.sendProofs,
    state: 'inflight',
    kind: 'send',
  });

  if (
    input.token.mint !== operation.mintUrl ||
    normalizeUnit(input.token.unit) !== normalizeUnit(operation.unit) ||
    input.token.memo !== operation.executionMemo ||
    !sameProofSet(input.token.proofs, input.sendProofs)
  ) {
    throw new ProofValidationError('Swap token does not match the persisted Send request');
  }
}

function sameToken(left: Token, right: Token): boolean {
  return (
    left.mint === right.mint &&
    normalizeUnit(left.unit) === normalizeUnit(right.unit) &&
    left.memo === right.memo &&
    sameProofSet(left.proofs, right.proofs)
  );
}

function sameCoreProofSet(left: CoreProof[], right: CoreProof[]): boolean {
  return (
    sameProofSet(left, right) &&
    left.every((proof) => {
      const candidate = right.find((item) => item.secret === proof.secret);
      return (
        candidate?.mintUrl === proof.mintUrl &&
        normalizeUnit(candidate.unit) === normalizeUnit(proof.unit) &&
        candidate.createdByOperationId === proof.createdByOperationId
      );
    })
  );
}

function sameProofSet(left: Proof[], right: Proof[]): boolean {
  if (
    left.length !== right.length ||
    new Set(left.map((proof) => proof.secret)).size !== left.length ||
    new Set(right.map((proof) => proof.secret)).size !== right.length
  ) {
    return false;
  }
  const rightBySecret = new Map(right.map((proof) => [proof.secret, proof]));
  return left.every((proof) => {
    const candidate = rightBySecret.get(proof.secret);
    return candidate ? sameProof(proof, candidate) : false;
  });
}

function sameProof(left: Proof, right: Proof): boolean {
  return (
    left.id === right.id &&
    left.secret === right.secret &&
    left.C === right.C &&
    Amount.from(left.amount).equals(Amount.from(right.amount)) &&
    left.witness === right.witness &&
    JSON.stringify(left.dleq) === JSON.stringify(right.dleq)
  );
}
