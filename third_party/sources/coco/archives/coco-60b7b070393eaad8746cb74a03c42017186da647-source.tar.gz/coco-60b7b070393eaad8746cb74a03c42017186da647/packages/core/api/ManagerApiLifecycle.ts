import { AuthApi } from './AuthApi.ts';
import { HistoryApi } from './HistoryApi.ts';
import { KeyRingApi } from './KeyRingApi.ts';
import { MeltOpsApi } from './MeltOpsApi.ts';
import { MintApi } from './MintApi.ts';
import { MintOpsApi } from './MintOpsApi.ts';
import { OpsApi } from './OpsApi.ts';
import { PaymentRequestsApi } from './PaymentRequestsApi.ts';
import { MeltQuoteApi, MintQuoteApi, QuoteApi } from './QuoteApi.ts';
import { ReceiveOpsApi } from './ReceiveOpsApi.ts';
import { SendOpsApi } from './SendOpsApi.ts';
import { WalletApi } from './WalletApi.ts';
import { WalletBalancesApi } from './WalletBalancesApi.ts';
import {
  createLifecycleOperationCalls,
  type CapabilityLifecycleGate,
} from '../plugins/CapabilityLifecycle.ts';

type Callable = (...args: never[]) => unknown;
type TrustedCallable = (this: unknown, ...args: unknown[]) => unknown;
type FacadeEntries = Record<string, Callable | object>;
type TrustedMethodTable = Readonly<Record<string, TrustedCallable>>;

const nativeCreate = Object.create;
const nativeDefineProperty = Object.defineProperty;
const nativeEntries = Object.entries;
const nativeFreeze = Object.freeze;
const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const nativeReflectApply = Reflect.apply;
const nativeSetPrototypeOf = Object.setPrototypeOf;

function applyTrusted<T>(
  callable: TrustedCallable,
  receiver: unknown,
  args: readonly unknown[],
): T {
  return nativeReflectApply(callable, receiver, args) as T;
}

function hardenFunction<T extends Callable>(fn: T): T {
  nativeSetPrototypeOf(fn, null);
  return nativeFreeze(fn);
}

function freezeFacade<T extends FacadeEntries>(entries: T): T {
  const facade = nativeCreate(null) as T;
  const entryList = nativeEntries(entries);
  for (let index = 0; index < entryList.length; index += 1) {
    const pair = entryList[index]!;
    const key = pair[0];
    const value = pair[1];
    nativeDefineProperty(facade, key, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: typeof value === 'function' ? hardenFunction(value as Callable) : value,
    });
  }
  return nativeFreeze(facade);
}

/** Static source-of-truth used by public shape and trusted-callable regressions. */
export const MANAGER_API_METHOD_MANIFEST = nativeFreeze({
  mint: nativeFreeze([
    'addMint',
    'getMintInfo',
    'checkPaymentMethodCapability',
    'listPaymentMethodCapabilities',
    'isTrustedMint',
    'getAllMints',
    'getAllTrustedMints',
    'trustMint',
    'untrustMint',
  ]),
  wallet: nativeFreeze([
    'receive',
    'restore',
    'sweep',
    'decodeToken',
    'encodeToken',
    'encodePaymentRequest',
  ]),
  walletBalances: nativeFreeze(['byMint', 'byMintAndUnit', 'byUnit', 'total', 'totalByUnit']),
  keyring: nativeFreeze([
    'generateKeyPair',
    'generateMintQuoteKeyPair',
    'addKeyPair',
    'removeKeyPair',
    'getKeyPair',
    'getLatestKeyPair',
    'getAllKeyPairs',
  ]),
  history: nativeFreeze([
    'getPaginatedHistory',
    'getHistoryEntryById',
    'getOperationIdForHistoryEntry',
  ]),
  auth: nativeFreeze([
    'startDeviceAuth',
    'login',
    'restore',
    'logout',
    'getSession',
    'hasSession',
    'getAuthProvider',
    'getPoolSize',
  ]),
  send: nativeFreeze([
    'prepare',
    'execute',
    'get',
    'listPrepared',
    'listInFlight',
    'refresh',
    'cancel',
    'reclaim',
    'finalize',
  ]),
  receive: nativeFreeze([
    'prepare',
    'execute',
    'get',
    'listPrepared',
    'listInFlight',
    'refresh',
    'cancel',
  ]),
  mintOps: nativeFreeze([
    'prepare',
    'execute',
    'get',
    'listByQuote',
    'listPending',
    'listInFlight',
    'checkPayment',
    'refresh',
    'finalize',
  ]),
  melt: nativeFreeze([
    'prepare',
    'execute',
    'get',
    'getByQuote',
    'listByQuote',
    'listPrepared',
    'listInFlight',
    'refresh',
    'cancel',
    'reclaim',
    'finalize',
  ]),
  mintQuotes: nativeFreeze(['create', 'get', 'import', 'listPending', 'refresh']),
  meltQuotes: nativeFreeze(['create', 'get', 'listPending', 'refresh']),
  paymentRequests: nativeFreeze(['parse', 'prepare', 'execute']),
  incomingPaymentRequests: nativeFreeze([
    'create',
    'cancel',
    'get',
    'list',
    'claimPayload',
    'ingestPayload',
  ]),
  operationRecovery: nativeFreeze(['run', 'inProgress']),
  paymentRequestRecovery: nativeFreeze(['run']),
  diagnostics: nativeFreeze(['isLocked']),
});

function ownData<T>(target: object, key: PropertyKey, label: string): T {
  const descriptor = nativeGetOwnPropertyDescriptor(target, key);
  if (!descriptor || !('value' in descriptor)) {
    throw new TypeError(`${label} must be an own data property`);
  }
  return descriptor.value as T;
}

function ownCallable(target: object, key: string, label: string): TrustedCallable {
  const value = ownData<unknown>(target, key, label);
  if (typeof value !== 'function') throw new TypeError(`${label} must be callable`);
  return value as TrustedCallable;
}

function capturePrototypeMethods(
  Api: Function,
  methodNames: readonly string[],
  label: string,
): TrustedMethodTable {
  const prototype = ownData<object>(Api, 'prototype', `${label}.prototype`);
  const captured = nativeCreate(null) as Record<string, TrustedCallable>;
  for (let index = 0; index < methodNames.length; index += 1) {
    const methodName = methodNames[index]!;
    nativeDefineProperty(captured, methodName, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: ownCallable(prototype, methodName, `${label}.prototype.${methodName}`),
    });
  }
  return nativeFreeze(captured);
}

// Captured at module evaluation, before initializeCoco can load or execute plugin code. Prototype
// replacement after import can neither redirect dispatch nor receive a private implementation.
const TRUSTED_MANAGER_API_METHODS = nativeFreeze({
  mint: capturePrototypeMethods(MintApi, MANAGER_API_METHOD_MANIFEST.mint, 'MintApi'),
  wallet: capturePrototypeMethods(WalletApi, MANAGER_API_METHOD_MANIFEST.wallet, 'WalletApi'),
  walletBalances: capturePrototypeMethods(
    WalletBalancesApi,
    MANAGER_API_METHOD_MANIFEST.walletBalances,
    'WalletBalancesApi',
  ),
  keyring: capturePrototypeMethods(KeyRingApi, MANAGER_API_METHOD_MANIFEST.keyring, 'KeyRingApi'),
  history: capturePrototypeMethods(HistoryApi, MANAGER_API_METHOD_MANIFEST.history, 'HistoryApi'),
  auth: capturePrototypeMethods(AuthApi, MANAGER_API_METHOD_MANIFEST.auth, 'AuthApi'),
  send: capturePrototypeMethods(SendOpsApi, MANAGER_API_METHOD_MANIFEST.send, 'SendOpsApi'),
  receive: capturePrototypeMethods(
    ReceiveOpsApi,
    MANAGER_API_METHOD_MANIFEST.receive,
    'ReceiveOpsApi',
  ),
  mintOps: capturePrototypeMethods(MintOpsApi, MANAGER_API_METHOD_MANIFEST.mintOps, 'MintOpsApi'),
  melt: capturePrototypeMethods(MeltOpsApi, MANAGER_API_METHOD_MANIFEST.melt, 'MeltOpsApi'),
  mintQuotes: capturePrototypeMethods(
    MintQuoteApi,
    MANAGER_API_METHOD_MANIFEST.mintQuotes,
    'MintQuoteApi',
  ),
  meltQuotes: capturePrototypeMethods(
    MeltQuoteApi,
    MANAGER_API_METHOD_MANIFEST.meltQuotes,
    'MeltQuoteApi',
  ),
  paymentRequests: capturePrototypeMethods(
    PaymentRequestsApi,
    MANAGER_API_METHOD_MANIFEST.paymentRequests,
    'PaymentRequestsApi',
  ),
});

export interface ManagerApiImplementations {
  mint: MintApi;
  wallet: WalletApi;
  keyring: KeyRingApi;
  history: HistoryApi;
  ops: OpsApi;
  quotes: QuoteApi;
  auth: AuthApi;
  paymentRequests: PaymentRequestsApi;
}

type LifecycleCalls = ReturnType<typeof createLifecycleOperationCalls>;

function classification(names: readonly string[]): Readonly<Record<string, true>> {
  const result = nativeCreate(null) as Record<string, true>;
  for (let index = 0; index < names.length; index += 1) {
    nativeDefineProperty(result, names[index]!, {
      configurable: false,
      enumerable: true,
      writable: false,
      value: true,
    });
  }
  return nativeFreeze(result);
}

const SYNC_MANAGER_METHODS = nativeFreeze({
  wallet: classification(['encodeToken', 'encodePaymentRequest']),
  auth: classification(['getAuthProvider', 'getPoolSize']),
});

function createPrototypeFacade<T extends object>(
  implementation: T,
  trustedMethods: TrustedMethodTable,
  lifecycleCalls: LifecycleCalls,
  syncMethods: Readonly<Record<string, true>> = nativeFreeze(nativeCreate(null)),
): T {
  const entries: FacadeEntries = nativeCreate(null);
  const methodEntries = nativeEntries(trustedMethods);
  for (let index = 0; index < methodEntries.length; index += 1) {
    const pair = methodEntries[index]!;
    const name = pair[0];
    const trustedMethod = pair[1];
    nativeDefineProperty(entries, name, {
      configurable: true,
      enumerable: true,
      writable: true,
      value: syncMethods[name]
        ? (...args: unknown[]) =>
            lifecycleCalls.syncCall(() => applyTrusted(trustedMethod, implementation, args))
        : (...args: unknown[]) =>
            lifecycleCalls.asyncCall(() => applyTrusted(trustedMethod, implementation, args)),
    });
  }
  return freezeFacade(entries) as T;
}

function createOperationFacade<T extends object>(
  implementation: T,
  trustedMethods: TrustedMethodTable,
  lifecycleCalls: LifecycleCalls,
  label: string,
): T {
  const base = createPrototypeFacade(implementation, trustedMethods, lifecycleCalls) as Record<
    string,
    Callable | object
  >;
  const entries: FacadeEntries = nativeCreate(null);
  const baseEntries = nativeEntries(base);
  for (let index = 0; index < baseEntries.length; index += 1) {
    const pair = baseEntries[index]!;
    const name = pair[0];
    const value = pair[1];
    nativeDefineProperty(entries, name, {
      configurable: true,
      enumerable: true,
      writable: true,
      value,
    });
  }

  const recovery = ownData<object>(implementation, 'recovery', `${label}.recovery`);
  const recoveryRun = ownCallable(recovery, 'run', `${label}.recovery.run`);
  const recoveryInProgressDescriptor = nativeGetOwnPropertyDescriptor(recovery, 'inProgress');
  const recoveryInProgress = recoveryInProgressDescriptor
    ? ownCallable(recovery, 'inProgress', `${label}.recovery.inProgress`)
    : undefined;
  const diagnostics = ownData<object>(implementation, 'diagnostics', `${label}.diagnostics`);
  const diagnosticsIsLocked = ownCallable(diagnostics, 'isLocked', `${label}.diagnostics.isLocked`);

  nativeDefineProperty(entries, 'recovery', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: freezeFacade({
      run: () => lifecycleCalls.asyncCall(() => applyTrusted(recoveryRun, recovery, [])),
      ...(recoveryInProgress
        ? {
            inProgress: () =>
              lifecycleCalls.syncCall(() => applyTrusted(recoveryInProgress, recovery, [])),
          }
        : {}),
    }),
  });
  nativeDefineProperty(entries, 'diagnostics', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: freezeFacade({
      isLocked: (operationId: string) =>
        lifecycleCalls.syncCall(() =>
          applyTrusted(diagnosticsIsLocked, diagnostics, [operationId]),
        ),
    }),
  });
  return freezeFacade(entries) as T;
}

/** Build the complete lifecycle-fenced public API graph returned by Manager. */
export function createLifecycleManagerApis(
  apis: ManagerApiImplementations,
  lifecycle: CapabilityLifecycleGate,
): ManagerApiImplementations {
  const lifecycleCalls = createLifecycleOperationCalls(lifecycle);

  // Read each private implementation and nested object through captured own descriptors exactly
  // once during Manager construction. No invocation below performs property dispatch on them.
  const rawMint = ownData<MintApi>(apis, 'mint', 'manager APIs.mint');
  const rawWallet = ownData<WalletApi>(apis, 'wallet', 'manager APIs.wallet');
  const rawBalances = ownData<WalletBalancesApi>(rawWallet, 'balances', 'WalletApi.balances');
  const rawKeyring = ownData<KeyRingApi>(apis, 'keyring', 'manager APIs.keyring');
  const rawHistory = ownData<HistoryApi>(apis, 'history', 'manager APIs.history');
  const rawAuth = ownData<AuthApi>(apis, 'auth', 'manager APIs.auth');
  const rawOps = ownData<OpsApi>(apis, 'ops', 'manager APIs.ops');
  const rawSend = ownData<SendOpsApi>(rawOps, 'send', 'OpsApi.send');
  const rawReceive = ownData<ReceiveOpsApi>(rawOps, 'receive', 'OpsApi.receive');
  const rawMintOps = ownData<MintOpsApi>(rawOps, 'mint', 'OpsApi.mint');
  const rawMelt = ownData<MeltOpsApi>(rawOps, 'melt', 'OpsApi.melt');
  const rawQuotes = ownData<QuoteApi>(apis, 'quotes', 'manager APIs.quotes');
  const rawMintQuotes = ownData<MintQuoteApi>(rawQuotes, 'mint', 'QuoteApi.mint');
  const rawMeltQuotes = ownData<MeltQuoteApi>(rawQuotes, 'melt', 'QuoteApi.melt');
  const rawPaymentRequests = ownData<PaymentRequestsApi>(
    apis,
    'paymentRequests',
    'manager APIs.paymentRequests',
  );
  const rawIncoming = ownData<PaymentRequestsApi['incoming']>(
    rawPaymentRequests,
    'incoming',
    'PaymentRequestsApi.incoming',
  );

  const mint = createPrototypeFacade(rawMint, TRUSTED_MANAGER_API_METHODS.mint, lifecycleCalls);
  const balances = createPrototypeFacade(
    rawBalances,
    TRUSTED_MANAGER_API_METHODS.walletBalances,
    lifecycleCalls,
  );
  const walletBase = createPrototypeFacade(
    rawWallet,
    TRUSTED_MANAGER_API_METHODS.wallet,
    lifecycleCalls,
    SYNC_MANAGER_METHODS.wallet,
  ) as unknown as Record<string, Callable | object>;
  const wallet = freezeFacade({ balances, ...walletBase }) as unknown as WalletApi;
  const keyring = createPrototypeFacade(
    rawKeyring,
    TRUSTED_MANAGER_API_METHODS.keyring,
    lifecycleCalls,
  );
  const history = createPrototypeFacade(
    rawHistory,
    TRUSTED_MANAGER_API_METHODS.history,
    lifecycleCalls,
  );
  const auth = createPrototypeFacade(
    rawAuth,
    TRUSTED_MANAGER_API_METHODS.auth,
    lifecycleCalls,
    SYNC_MANAGER_METHODS.auth,
  );

  const send = createOperationFacade(
    rawSend,
    TRUSTED_MANAGER_API_METHODS.send,
    lifecycleCalls,
    'SendOpsApi',
  );
  const receive = createOperationFacade(
    rawReceive,
    TRUSTED_MANAGER_API_METHODS.receive,
    lifecycleCalls,
    'ReceiveOpsApi',
  );
  const mintOps = createOperationFacade(
    rawMintOps,
    TRUSTED_MANAGER_API_METHODS.mintOps,
    lifecycleCalls,
    'MintOpsApi',
  );
  const melt = createOperationFacade(
    rawMelt,
    TRUSTED_MANAGER_API_METHODS.melt,
    lifecycleCalls,
    'MeltOpsApi',
  );
  const ops = freezeFacade({ send, receive, mint: mintOps, melt }) as unknown as OpsApi;

  const mintQuotes = createPrototypeFacade(
    rawMintQuotes,
    TRUSTED_MANAGER_API_METHODS.mintQuotes,
    lifecycleCalls,
  );
  const meltQuotes = createPrototypeFacade(
    rawMeltQuotes,
    TRUSTED_MANAGER_API_METHODS.meltQuotes,
    lifecycleCalls,
  );
  const quotes = freezeFacade({ mint: mintQuotes, melt: meltQuotes }) as unknown as QuoteApi;

  // Incoming payment requests deliberately use own closures rather than a class prototype. Capture
  // each data-property callable once, before plugin lifecycle begins.
  const incomingEntries: FacadeEntries = nativeCreate(null);
  for (
    let index = 0;
    index < MANAGER_API_METHOD_MANIFEST.incomingPaymentRequests.length;
    index += 1
  ) {
    const name = MANAGER_API_METHOD_MANIFEST.incomingPaymentRequests[index]!;
    const trustedMethod = ownCallable(rawIncoming, name, `PaymentRequestsApi.incoming.${name}`);
    nativeDefineProperty(incomingEntries, name, {
      configurable: true,
      enumerable: true,
      writable: true,
      value: (...args: unknown[]) =>
        lifecycleCalls.asyncCall(() => applyTrusted(trustedMethod, rawIncoming, args)),
    });
  }
  const incomingRecovery = ownData<object>(
    rawIncoming,
    'recovery',
    'PaymentRequestsApi.incoming.recovery',
  );
  const incomingRecoveryRun = ownCallable(
    incomingRecovery,
    'run',
    'PaymentRequestsApi.incoming.recovery.run',
  );
  const incomingDiagnostics = ownData<object>(
    rawIncoming,
    'diagnostics',
    'PaymentRequestsApi.incoming.diagnostics',
  );
  const incomingDiagnosticsIsLocked = ownCallable(
    incomingDiagnostics,
    'isLocked',
    'PaymentRequestsApi.incoming.diagnostics.isLocked',
  );
  nativeDefineProperty(incomingEntries, 'recovery', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: freezeFacade({
      run: () =>
        lifecycleCalls.asyncCall(() => applyTrusted(incomingRecoveryRun, incomingRecovery, [])),
    }),
  });
  nativeDefineProperty(incomingEntries, 'diagnostics', {
    configurable: true,
    enumerable: true,
    writable: true,
    value: freezeFacade({
      isLocked: (operationId: string) =>
        lifecycleCalls.syncCall(() =>
          applyTrusted(incomingDiagnosticsIsLocked, incomingDiagnostics, [operationId]),
        ),
    }),
  });
  const incoming = freezeFacade(incomingEntries);
  const paymentRequestsBase = createPrototypeFacade(
    rawPaymentRequests,
    TRUSTED_MANAGER_API_METHODS.paymentRequests,
    lifecycleCalls,
  ) as unknown as Record<string, Callable | object>;
  const paymentRequests = freezeFacade({
    incoming,
    ...paymentRequestsBase,
  }) as unknown as PaymentRequestsApi;

  return { mint, wallet, keyring, history, ops, quotes, auth, paymentRequests };
}
