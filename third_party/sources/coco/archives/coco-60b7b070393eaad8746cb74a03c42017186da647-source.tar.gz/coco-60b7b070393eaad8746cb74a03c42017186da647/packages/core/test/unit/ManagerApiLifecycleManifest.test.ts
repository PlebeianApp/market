import { describe, expect, test } from 'bun:test';
import { AuthApi } from '../../api/AuthApi.ts';
import { HistoryApi } from '../../api/HistoryApi.ts';
import { KeyRingApi } from '../../api/KeyRingApi.ts';
import { MANAGER_API_METHOD_MANIFEST } from '../../api/ManagerApiLifecycle.ts';
import { MeltOpsApi } from '../../api/MeltOpsApi.ts';
import { MintApi } from '../../api/MintApi.ts';
import { MintOpsApi } from '../../api/MintOpsApi.ts';
import { OpsApi } from '../../api/OpsApi.ts';
import { PaymentRequestsApi } from '../../api/PaymentRequestsApi.ts';
import { MeltQuoteApi, MintQuoteApi, QuoteApi } from '../../api/QuoteApi.ts';
import { ReceiveOpsApi } from '../../api/ReceiveOpsApi.ts';
import { SendOpsApi } from '../../api/SendOpsApi.ts';
import { WalletApi } from '../../api/WalletApi.ts';
import { WalletBalancesApi } from '../../api/WalletBalancesApi.ts';

function publicPrototypeMethods(value: { prototype: object }): string[] {
  return Object.getOwnPropertyNames(value.prototype)
    .filter((name) => name !== 'constructor')
    .sort();
}

describe('Manager public API lifecycle manifest', () => {
  test('class prototypes cannot gain a public method without explicit lifecycle classification', () => {
    const checks = [
      [MintApi, MANAGER_API_METHOD_MANIFEST.mint],
      [WalletApi, MANAGER_API_METHOD_MANIFEST.wallet],
      [WalletBalancesApi, MANAGER_API_METHOD_MANIFEST.walletBalances],
      [KeyRingApi, MANAGER_API_METHOD_MANIFEST.keyring],
      [HistoryApi, MANAGER_API_METHOD_MANIFEST.history],
      [AuthApi, MANAGER_API_METHOD_MANIFEST.auth],
      [SendOpsApi, MANAGER_API_METHOD_MANIFEST.send],
      [ReceiveOpsApi, MANAGER_API_METHOD_MANIFEST.receive],
      [MintOpsApi, MANAGER_API_METHOD_MANIFEST.mintOps],
      [MeltOpsApi, MANAGER_API_METHOD_MANIFEST.melt],
      [MintQuoteApi, MANAGER_API_METHOD_MANIFEST.mintQuotes],
      [MeltQuoteApi, MANAGER_API_METHOD_MANIFEST.meltQuotes],
      [PaymentRequestsApi, MANAGER_API_METHOD_MANIFEST.paymentRequests],
    ] as const;
    for (const [Api, expected] of checks) {
      expect(publicPrototypeMethods(Api)).toEqual([...expected].sort());
    }
  });

  test('container APIs have no uncaptured prototype dispatch surface', () => {
    expect(publicPrototypeMethods(OpsApi)).toEqual([]);
    expect(publicPrototypeMethods(QuoteApi)).toEqual([]);
    expect(MANAGER_API_METHOD_MANIFEST.operationRecovery).toEqual(['run', 'inProgress']);
    expect(MANAGER_API_METHOD_MANIFEST.paymentRequestRecovery).toEqual(['run']);
    expect(MANAGER_API_METHOD_MANIFEST.diagnostics).toEqual(['isLocked']);
  });
});
