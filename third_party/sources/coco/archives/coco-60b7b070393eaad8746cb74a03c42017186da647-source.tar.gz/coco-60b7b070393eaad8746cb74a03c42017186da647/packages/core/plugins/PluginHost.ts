import type { Plugin, ServiceKey, ServiceMap } from './types.ts';
import { DuplicatePluginRegistrationError, ExtensionRegistrationError } from './types.ts';
import {
  freezeRecord,
  hardenFunction,
  type PluginCapabilityFactoryMap,
} from './PluginCapabilities.ts';
import type { CapabilityLifecycleGate } from './CapabilityLifecycle.ts';
import { createLifecycleOperationCalls } from './CapabilityLifecycle.ts';
import { resolveSafely, settleWithin, thenSafely } from './SafeAsync.ts';

const nativeDateNow = Date.now;
const nativeDefineProperty = Object.defineProperty;
const nativeHasOwn = Object.hasOwn;
const nativeReflectApply = Reflect.apply;
const nativeSetAdd = Set.prototype.add;
const nativeSetDelete = Set.prototype.delete;
const nativeSetForEach = Set.prototype.forEach;

function setAdd<T>(set: Set<T>, value: T): void {
  nativeReflectApply(nativeSetAdd, set, [value]);
}

function setDelete<T>(set: Set<T>, value: T): void {
  nativeReflectApply(nativeSetDelete, set, [value]);
}

function snapshotSet<T>(set: Set<T>): T[] {
  const values: T[] = [];
  nativeReflectApply(nativeSetForEach, set, [(value: T) => (values[values.length] = value)]);
  return values;
}

export class PluginHost {
  readonly #lifecycle: CapabilityLifecycleGate;
  readonly #lifecycleCalls;
  readonly #plugins: Plugin[] = [];
  readonly #cleanups: Array<() => void | Promise<void>> = [];
  readonly #extensions: Record<string, unknown> = Object.create(null);
  readonly #registeredPlugins = new WeakSet<Plugin>();
  readonly #initializationStartedPlugins = new WeakSet<Plugin>();
  readonly #initializedPlugins = new WeakSet<Plugin>();
  readonly #readyPlugins = new WeakSet<Plugin>();
  readonly #initPromises = new WeakMap<Plugin, Promise<void>>();
  readonly #readyPromises = new WeakMap<Plugin, Promise<void>>();
  readonly #lifecyclePromises = new Set<Promise<void>>();
  #capabilities?: PluginCapabilityFactoryMap;
  #initialized = false;
  #readyPhase = false;
  #disposed = false;
  #disposePromise?: Promise<void>;

  constructor(lifecycle: CapabilityLifecycleGate) {
    this.#lifecycle = lifecycle;
    this.#lifecycleCalls = createLifecycleOperationCalls(lifecycle);
  }

  use(plugin: Plugin): void {
    if (this.#disposePromise || this.#disposed) {
      throw new Error('Cannot register plugin after disposal has started');
    }

    if (this.#registeredPlugins.has(plugin)) {
      throw new DuplicatePluginRegistrationError(plugin.name);
    }

    this.#registeredPlugins.add(plugin);
    this.#plugins.push(plugin);
    if (this.#initialized && this.#capabilities) {
      const capabilities = this.#capabilities;
      void this.#trackLifecycle(this.#initializeRuntimePlugin(plugin, capabilities));
    }
  }

  async init(capabilities: PluginCapabilityFactoryMap): Promise<void> {
    this.#lifecycle.assertActive();
    if (this.#disposePromise || this.#disposed) {
      throw new Error('Cannot initialize plugins after disposal has started');
    }

    this.#capabilities = capabilities;
    this.#initialized = true;
    for (const p of this.#plugins) {
      await this.#ensureInitialized(p, capabilities);
    }
  }

  async ready(): Promise<void> {
    this.#lifecycle.assertActive();
    if (this.#disposePromise || this.#disposed) {
      throw new Error('Cannot mark plugins ready after disposal has started');
    }

    if (!this.#capabilities) return;
    this.#readyPhase = true;
    for (const p of this.#plugins) {
      await this.#ensureReady(p, this.#capabilities);
    }
  }

  async dispose(timeoutMs = 5_000): Promise<void> {
    if (this.#disposePromise) {
      await this.#disposePromise;
      return;
    }
    if (this.#disposed) return;

    this.#disposePromise = this.#runDispose(timeoutMs);
    await this.#disposePromise;
  }

  async #runDispose(timeoutMs: number): Promise<void> {
    const errors: unknown[] = [];
    const deadline = nativeDateNow() + timeoutMs;
    const remaining = () => Math.max(0, deadline - nativeDateNow());
    try {
      await settleWithin(this.#waitForLifecycle(), remaining(), 'plugin lifecycle drain');
    } catch (error) {
      errors.push(error);
    }
    for (const p of this.#plugins) {
      if (!this.#initializationStartedPlugins.has(p)) continue;
      try {
        await settleWithin(p.onDispose?.(), remaining(), `plugin ${p.name} onDispose`);
      } catch (err) {
        // eslint-disable-next-line no-console
        console.error('Plugin dispose error', { plugin: p.name, err });
        errors.push(err);
      }
    }
    while (this.#cleanups.length) {
      const fn = this.#cleanups.pop()!;
      try {
        await settleWithin(fn(), remaining(), 'plugin cleanup');
      } catch (err) {
        errors.push(err);
      }
    }
    if (errors.length > 0) {
      // eslint-disable-next-line no-console
      console.error('One or more plugin dispose/cleanup handlers failed');
    }
    this.#disposed = true;
    if (errors.length > 0) {
      throw new AggregateError(errors, 'One or more plugin dispose/cleanup handlers failed');
    }
  }

  async #initializeRuntimePlugin(
    plugin: Plugin,
    capabilities: PluginCapabilityFactoryMap,
  ): Promise<void> {
    await this.#ensureInitialized(plugin, capabilities);
    if (this.#readyPhase) {
      await this.#ensureReady(plugin, capabilities);
    }
  }

  #trackLifecycle(promise: Promise<void>): Promise<void> {
    const pending = resolveSafely(promise);
    setAdd(this.#lifecyclePromises, pending);
    void thenSafely(
      pending,
      () => {
        setDelete(this.#lifecyclePromises, pending);
      },
      () => {
        setDelete(this.#lifecyclePromises, pending);
      },
    );
    return pending;
  }

  async #waitForLifecycle(): Promise<void> {
    while (this.#lifecyclePromises.size > 0) {
      const snapshot = snapshotSet(this.#lifecyclePromises);
      for (let index = 0; index < snapshot.length; index += 1) {
        try {
          await resolveSafely(snapshot[index]!);
        } catch {
          // Lifecycle failures are handled by the originating init/ready path.
        }
      }
    }
  }

  /**
   * Get all registered plugin extensions
   */
  getExtensions(): Record<string, unknown> {
    return this.#extensions;
  }

  async #ensureInitialized(
    plugin: Plugin,
    capabilities: PluginCapabilityFactoryMap,
  ): Promise<void> {
    if (this.#initializedPlugins.has(plugin)) return;

    const existing = this.#initPromises.get(plugin);
    if (existing) {
      await existing;
      return;
    }

    const promise = this.#trackLifecycle(
      (async () => {
        try {
          await this.#runInit(plugin, capabilities);
          this.#initializedPlugins.add(plugin);
        } finally {
          this.#initPromises.delete(plugin);
        }
      })(),
    );

    this.#initPromises.set(plugin, promise);
    await promise;
  }

  async #ensureReady(plugin: Plugin, capabilities: PluginCapabilityFactoryMap): Promise<void> {
    await this.#ensureInitialized(plugin, capabilities);
    if (this.#readyPlugins.has(plugin)) return;

    const existing = this.#readyPromises.get(plugin);
    if (existing) {
      await existing;
      return;
    }

    const promise = this.#trackLifecycle(
      (async () => {
        try {
          await this.#runReady(plugin, capabilities);
          this.#readyPlugins.add(plugin);
        } finally {
          this.#readyPromises.delete(plugin);
        }
      })(),
    );

    this.#readyPromises.set(plugin, promise);
    await promise;
  }

  async #runInit(plugin: Plugin, capabilities: PluginCapabilityFactoryMap): Promise<void> {
    this.#lifecycle.assertActive();
    const { context, revoke } = this.#createContext(plugin, capabilities);
    // Disposal is permitted only after the hook is actually eligible to run. Registration and
    // rejected context construction are not lifecycle participation and must not grant an
    // onDispose mutation opportunity.
    this.#initializationStartedPlugins.add(plugin);
    try {
      const cleanup = await this.#lifecycleCalls.asyncCall(() => plugin.onInit?.(context as any));
      if (typeof cleanup === 'function') this.#cleanups.push(cleanup);
    } catch (err) {
      if (err instanceof ExtensionRegistrationError) {
        throw err;
      }
      // eslint-disable-next-line no-console
      console.error('Plugin init error', { plugin: plugin.name, err });
    } finally {
      revoke();
    }
  }

  async #runReady(plugin: Plugin, capabilities: PluginCapabilityFactoryMap): Promise<void> {
    this.#lifecycle.assertActive();
    const { context, revoke } = this.#createContext(plugin, capabilities);
    try {
      const cleanup = await this.#lifecycleCalls.asyncCall(() => plugin.onReady?.(context as any));
      if (typeof cleanup === 'function') this.#cleanups.push(cleanup);
    } catch (err) {
      if (err instanceof ExtensionRegistrationError) {
        throw err;
      }
      // eslint-disable-next-line no-console
      console.error('Plugin ready error', { plugin: plugin.name, err });
    } finally {
      revoke();
    }
  }

  #createContext(
    plugin: Plugin,
    capabilities: PluginCapabilityFactoryMap,
  ): {
    context: Readonly<{
      services: Partial<ServiceMap>;
      registerExtension: <K extends string>(key: K, api: unknown) => void;
    }>;
    revoke: () => void;
  } {
    const required = (plugin.required ?? []) as readonly ServiceKey[];
    const selected = Object.create(null) as Partial<ServiceMap>;
    for (const k of required) {
      if (!Object.hasOwn(capabilities, k)) {
        throw new Error(`Plugin "${plugin.name}" requested unavailable service "${String(k)}"`);
      }
      // @ts-expect-error - dynamic key selection
      selected[k] = capabilities[k]();
    }

    let hookActive = true;
    const revoke = () => {
      hookActive = false;
    };
    const registerExtension = hardenFunction(<K extends string>(key: K, api: unknown): void => {
      if (!hookActive) {
        throw new Error(`Plugin "${plugin.name}" extension registrar is no longer active`);
      }
      const complete = this.#lifecycle.beginOperation();
      try {
        if (typeof key !== 'string') {
          throw new TypeError('Plugin extension keys must be primitive strings');
        }
        if (key.length === 0 || key.length > 128) {
          throw new TypeError('Plugin extension keys must contain 1 to 128 UTF-16 code units');
        }
        if (nativeHasOwn(this.#extensions, key)) {
          throw new ExtensionRegistrationError(plugin.name, key);
        }
        nativeDefineProperty(this.#extensions, key, {
          configurable: true,
          enumerable: true,
          writable: true,
          value: api,
        });
      } finally {
        complete();
      }
    });

    return {
      context: freezeRecord({
        services: freezeRecord(selected),
        registerExtension,
      }),
      revoke,
    };
  }
}
