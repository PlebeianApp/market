import type { Keyset } from '../../models/Keyset';
import type { KeysetRepository } from '..';
import {
  createMemoryMap,
  memoryMapDelete,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryKeysetRepository implements KeysetRepository {
  private keysetsByMint: Map<string, Map<string, Keyset>> = createMemoryMap();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryKeysetRepository): void {
    this.keysetsByMint = cloneMemoryRepositoryStateValue(source.keysetsByMint);
  }

  #findMintMap(mintUrl: string): Map<string, Keyset> | undefined {
    return memoryMapGet(this.keysetsByMint, mintUrl);
  }

  #getOrCreateMintMap(mintUrl: string): Map<string, Keyset> {
    const existing = this.#findMintMap(mintUrl);
    if (existing) return existing;
    const created = createMemoryMap<string, Keyset>();
    memoryMapSet(this.keysetsByMint, mintUrl, created);
    return created;
  }

  async getKeysetsByMintUrl(mintUrl: string): Promise<Keyset[]> {
    const mintMap = this.#findMintMap(mintUrl);
    if (!mintMap) return [];
    const keysets = memoryMapValues(mintMap);
    for (let index = 0; index < keysets.length; index += 1) {
      keysets[index] = cloneMemoryValue(keysets[index]!);
    }
    return keysets;
  }

  async getKeysetById(mintUrl: string, id: string): Promise<Keyset | null> {
    const mintMap = this.#findMintMap(mintUrl);
    const keyset = mintMap ? memoryMapGet(mintMap, id) : undefined;
    return keyset ? cloneMemoryValue(keyset) : null;
  }

  async updateKeyset(keyset: Omit<Keyset, 'keypairs' | 'updatedAt'>): Promise<void> {
    const mintMap = this.#getOrCreateMintMap(keyset.mintUrl);
    const existing = memoryMapGet(mintMap, keyset.id);
    if (!existing) {
      // If unknown, create an empty one and then update
      memoryMapSet(
        mintMap,
        keyset.id,
        cloneMemoryValue({
          ...keyset,
          keypairs: {},
          updatedAt: Math.floor(Date.now() / 1000),
        }),
      );
      return;
    }
    memoryMapSet(
      mintMap,
      keyset.id,
      cloneMemoryValue({
        ...existing,
        unit: keyset.unit,
        active: keyset.active,
        feePpk: keyset.feePpk,
        updatedAt: Math.floor(Date.now() / 1000),
      }),
    );
  }

  async addKeyset(keyset: Omit<Keyset, 'updatedAt'>): Promise<void> {
    const mintMap = this.#getOrCreateMintMap(keyset.mintUrl);
    memoryMapSet(
      mintMap,
      keyset.id,
      cloneMemoryValue({
        ...keyset,
        updatedAt: Math.floor(Date.now() / 1000),
      }),
    );
  }

  async deleteKeyset(mintUrl: string, keysetId: string): Promise<void> {
    const mintMap = this.#findMintMap(mintUrl);
    if (mintMap) memoryMapDelete(mintMap, keysetId);
  }
}
