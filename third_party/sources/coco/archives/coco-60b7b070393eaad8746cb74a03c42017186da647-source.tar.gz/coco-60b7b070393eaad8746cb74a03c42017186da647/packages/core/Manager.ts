import { CoreReceiveTransactions } from './transactions/receive/ReceiveTransactions.ts';
import { CashuReceiveRemote } from './infra/handlers/receive/CashuReceiveRemote.ts';
import type { OutputDataCreator } from '@cashu/cashu-ts';
import { CoreMintMetadataTransactions } from './transactions/mints/MintMetadataTransactions.ts';
import { StoredMintQueries } from './mints/MintMetadata.ts';
import { CashuSendRemote } from './infra/handlers/send/CashuSendRemote.ts';
import type {
  Repositories,
  LegacyMintQuoteRepository,
  MintOperationRepository,
  SendOperationRepository,
  MeltOperationRepository,
  ReceiveOperationRepository,
  PaymentRequestReceiveOperationRepository,
  PaymentRequestReceiveAttemptRepository,
} from './repositories';
import { validateWalletAuthorityIdentity } from './repositories';
import {
  CounterService,
  MintService,
  MintOperationWatcherService,
  MintOperationProcessor,
  MeltQuoteWatcherService,
  MeltSettlementProcessor,
  ProofService,
  WalletService,
  SeedService,
  WalletRestoreService,
  ProofStateWatcherService,
  HistoryService,
  KeyRingService,
  PaymentRequestService,
  PaymentRequestReceiveService,
  AuthSessionService,
  AuthService,
  TokenService,
} from './services';
import { SendOperationService } from './operations/send/SendOperationService';
import { MeltOperationService } from './operations/melt/MeltOperationService';
import { MintOperationService } from './operations/mint/MintOperationService';
import { ReceiveOperationService } from './operations/receive/ReceiveOperationService';
import { MintScopedLock } from './operations/MintScopedLock';
import {
  SubscriptionManager,
  type WebSocketFactory,
  PollingTransport,
  MintAdapter,
  MintRequestProvider,
  MeltBolt11Handler,
  MeltBolt12Handler,
  MeltOnchainHandler,
  MeltHandlerProvider,
  SendHandlerProvider,
  DefaultSendHandler,
  P2pkSendHandler,
  MintBolt11Handler,
  MintBolt12Handler,
  MintHandlerProvider,
  MintOnchainHandler,
  PaymentRequestReceiveTransportHandlerProvider,
} from './infra';
import { EventBus, type CoreEvents } from './events';
import { type Logger, NullLogger } from './logging';
import {
  MintApi,
  WalletApi,
  HistoryApi,
  KeyRingApi,
  AuthApi,
  OpsApi,
  SendOpsApi,
  ReceiveOpsApi,
  MeltOpsApi,
  MintOpsApi,
  QuoteApi,
  PaymentRequestsApi,
} from './api';
import { PluginHost } from './plugins/PluginHost.ts';
import {
  createLifecycleSubscriptionFacade,
  createPluginCapabilityFactories,
} from './plugins/PluginCapabilities.ts';
import {
  createCapabilityLifecycleAuthority,
  createLifecycleOperationCalls,
  type CapabilityLifecycleAuthority,
} from './plugins/CapabilityLifecycle.ts';
import { settleWithin, thenSafely } from './plugins/SafeAsync.ts';
import { createLifecycleManagerApis } from './api/ManagerApiLifecycle.ts';
import type { PluginSubscriptionCapability } from './plugins/capabilityTypes.ts';
import type { MintMethodQuoteSnapshot } from './operations/mint';
import type { Plugin, PluginExtensions } from './plugin.ts';
import { QuoteLifecycle } from './quotes/QuoteLifecycle.ts';
import {
  getMintQuoteAmount,
  isStatefulMintQuote,
  mintQuoteToMethodSnapshot,
} from './models/MintQuote.ts';
import { assessMintQuoteClaimability } from './models/MintQuoteClaimability.ts';
import { RepositoryCoreTransactionRunner } from './transactions/CoreTransaction.ts';
import { CoreSendTransactions } from './transactions/send/SendTransactions.ts';
import { CoreKeyRingTransactions } from './transactions/keypairs/KeyRingTransactions.ts';
import { KeypairDerivation } from './keypairs/KeypairDerivation.ts';
import { KeypairP2pkSigner } from './keypairs/P2pkSigner.ts';
import { generateSubId } from './utils.ts';
import { WalletAuthorityLifecycleError } from './models/Error.ts';

/**
 * Configuration options for initializing the Coco Cashu manager
 */
export interface CocoConfig {
  /** Repository implementations for data persistence */
  repo: Repositories;
  /** Function that returns the wallet seed as Uint8Array */
  seedGetter: () => Promise<Uint8Array>;
  /** Optional logger instance (defaults to NullLogger) */
  logger?: Logger;
  /** Optional WebSocket factory for real-time subscriptions */
  webSocketFactory?: WebSocketFactory;
  /** Optional plugins to extend functionality */
  plugins?: Plugin[];
  /**
   * Optional session-wide strategy used only to construct Cashu output material.
   * Defaults to the standard cashu-ts implementation.
   *
   * This does not customize persisted output reconstruction or guarantee custom proof conversion
   * after serialization. Coco persists only the standard `OutputDataLike` fields and may later
   * reconstruct a cashu-ts `OutputData`, whose built-in `toProof()` implementation is then used. A
   * custom result must still satisfy `OutputDataLike`, but its object identity and `toProof()`
   * implementation are not preserved across serialization.
   */
  outputDataCreator?: OutputDataCreator;
  /** Durable identity used to fence concurrent Coco Sessions over the same storage. */
  authority?: {
    /** Stable storage/wallet namespace. Defaults to `default`. */
    namespace?: string;
    /** Unique runtime identity. Defaults to a random value. */
    ownerId?: string;
  };
  /**
   * Watcher configuration (all enabled by default)
   * - Omit to use defaults (enabled)
   * - Set `disabled: true` to disable
   * - Provide options to customize behavior
   */
  watchers?: {
    /** Mint operation watcher (enabled by default) */
    mintOperationWatcher?: {
      disabled?: boolean;
      watchExistingPendingOnStart?: boolean;
      watchExistingPendingQuotesOnStart?: boolean;
    };
    /** Proof state watcher (enabled by default) */
    proofStateWatcher?: {
      disabled?: boolean;
      /** When enabled, scan existing inflight proofs on start (default: true) */
      watchExistingInflightOnStart?: boolean;
    };
    /** Melt quote watcher (enabled by default) */
    meltQuoteWatcher?: {
      disabled?: boolean;
      watchExistingPendingQuotesOnStart?: boolean;
    };
  };
  /**
   * Processor configuration (all enabled by default)
   * - Omit to use defaults (enabled)
   * - Set `disabled: true` to disable
   * - Provide options to customize behavior
   */
  processors?: {
    /** Mint operation processor (enabled by default) */
    mintOperationProcessor?: {
      disabled?: boolean;
      processIntervalMs?: number;
      maxRetries?: number;
      baseRetryDelayMs?: number;
      initialEnqueueDelayMs?: number;
      autoClaimMintQuotes?: boolean;
    };
    /** Melt settlement processor (enabled by default) */
    meltSettlementProcessor?: {
      disabled?: boolean;
      initializeExistingPendingOperationsOnStart?: boolean;
    };
  };
  /**
   * Subscription transport configuration
   * Controls the hybrid WebSocket + polling behavior
   */
  subscriptions?: {
    /**
     * Polling interval (ms) while WebSocket is connected.
     * Only used as backup to catch silent WS failures.
     * Default: 20000 (20 seconds)
     */
    slowPollingIntervalMs?: number;
    /**
     * Polling interval (ms) after WebSocket fails.
     * Used as primary transport when WS is unavailable.
     * Default: 5000 (5 seconds)
     */
    fastPollingIntervalMs?: number;
  };
  /**
   * Session lifecycle limits. Disposal revokes authority synchronously, stops producers, and then
   * gives already-started work this bounded interval to settle before completing cleanup and
   * releasing durable Wallet Authority. Defaults to 5000ms.
   */
  lifecycle?: {
    disposeTimeoutMs?: number;
  };
}

const DEFAULT_DISPOSE_TIMEOUT_MS = 5_000;
const nativeDateNow = Date.now;
const nativeObjectCreate = Object.create;
const nativeObjectFreeze = Object.freeze;
const nativeReflectApply = Reflect.apply;
const nativeMapGet = Map.prototype.get;
const nativeMapSet = Map.prototype.set;
const nativeWeakMapGet = WeakMap.prototype.get;
const nativeWeakMapSet = WeakMap.prototype.set;

function collectionCall<T>(fn: Function, receiver: unknown, args: readonly unknown[]): T {
  return nativeReflectApply(fn, receiver, args) as T;
}

type RepositoryAttachment = Readonly<{
  repositories: Repositories;
  token: unknown;
}>;

function claimRepositoryAttachment(repositories: Repositories): RepositoryAttachment {
  // Attachment authority belongs to the supplied root, not this module evaluation. Duplicate
  // source/dist/package copies therefore coordinate through the exact same root-owned closure.
  const token = repositories.claimSessionAttachment();
  return nativeObjectFreeze({ repositories, token });
}

function releaseRepositoryAttachment(attachment: RepositoryAttachment): void {
  if (!attachment.repositories.releaseSessionAttachment(attachment.token)) {
    throw new WalletAuthorityLifecycleError(
      'Repository root session attachment release did not match the active token',
    );
  }
}

async function releaseAuthorityAndAttachment(attachment: RepositoryAttachment): Promise<void> {
  const released = await attachment.repositories.releaseAuthority();
  if (!released) {
    throw new WalletAuthorityLifecycleError(
      'Repository authority release could not be confirmed for the attached Manager',
    );
  }
  releaseRepositoryAttachment(attachment);
}

export type CocoInitializationCleanupState = 'confirmed' | 'unconfirmed';

/**
 * Reports a failed `initializeCoco()` call and whether its partially initialized Manager was
 * disposed successfully.
 */
export class CocoInitializationError extends Error {
  constructor(
    message: string,
    readonly cleanupState: CocoInitializationCleanupState,
    cause: unknown,
  ) {
    super(message, { cause });
    this.name = 'CocoInitializationError';
  }
}

// These functions are assigned from Manager's static initialization block, the only lexical scope
// outside an instance that can access its ECMAScript private boot state. They are not properties of
// Manager, its prototype, or global symbol registries and therefore cannot be reflected, replaced,
// or invoked by a directly constructed Manager.
let createFactoryManager: (config: CocoConfig, attachment: RepositoryAttachment) => Manager;
let recoverFactoryManager: (manager: Manager) => Promise<void>;
let activateFactoryManager: (manager: Manager) => void;
let disposeFactoryManager: (manager: Manager) => Promise<void>;

/**
 * Initializes and configures a new Coco Cashu manager instance
 * @param config - Configuration options including repositories, seed, and optional features
 * @returns A fully initialized Manager instance
 */
export async function initializeCoco(config: CocoConfig): Promise<Manager> {
  const repositories = config.repo;
  const attachment = claimRepositoryAttachment(repositories);
  let acquiringAuthority = false;
  try {
    await repositories.init();
    const initialAuthorityState = repositories.getAuthorityState();
    if (initialAuthorityState === 'unacquired') {
      acquiringAuthority = true;
      await repositories.acquireAuthority(
        validateWalletAuthorityIdentity({
          namespace: config.authority?.namespace ?? 'default',
          ownerId: config.authority?.ownerId ?? generateSubId(),
        }),
      );
      acquiringAuthority = false;
    } else if (initialAuthorityState !== 'active' || repositories.getAuthority() === null) {
      throw new WalletAuthorityLifecycleError(
        'initializeCoco requires an unacquired or currently active repository root',
      );
    } else if (config.authority) {
      const requestedAuthority = validateWalletAuthorityIdentity({
        namespace: config.authority.namespace ?? 'default',
        ownerId: config.authority.ownerId ?? generateSubId(),
      });
      const currentAuthority = repositories.getAuthority()!;
      if (
        currentAuthority.namespace !== requestedAuthority.namespace ||
        currentAuthority.ownerId !== requestedAuthority.ownerId
      ) {
        throw new WalletAuthorityLifecycleError(
          'Configured authority does not match the active repository capability',
        );
      }
    }
  } catch (error) {
    // A validation failure never adopts or releases someone else's active capability. An
    // acquisition failure that nevertheless became durable is released before attachment rollback.
    let acquisitionBecameActive = false;
    if (acquiringAuthority) {
      try {
        acquisitionBecameActive = repositories.getAuthorityState() === 'active';
      } catch (cleanupError) {
        throw new CocoInitializationError(
          'Coco authority acquisition state could not be confirmed',
          'unconfirmed',
          new AggregateError([error, cleanupError]),
        );
      }
    }
    if (acquisitionBecameActive) {
      try {
        await releaseAuthorityAndAttachment(attachment);
      } catch (cleanupError) {
        throw new CocoInitializationError(
          'Coco authority acquisition failed and cleanup could not be confirmed',
          'unconfirmed',
          new AggregateError([error, cleanupError]),
        );
      }
    } else {
      releaseRepositoryAttachment(attachment);
    }
    throw error;
  }
  let coco: Manager | undefined;

  try {
    coco = createFactoryManager(config, attachment);
    await recoverFactoryManager(coco);
    activateFactoryManager(coco);

    // Plugin hooks receive mutation-capable services only after every durable recovery path has
    // completed. Extensions are still available before autonomous watchers/processors start.
    await coco.initPlugins();

    // Autonomous work starts only after authority acquisition and full recovery.
    const mintOperationWatcherConfig = config.watchers?.mintOperationWatcher;
    if (!mintOperationWatcherConfig?.disabled) {
      await coco.enableMintOperationWatcher(mintOperationWatcherConfig);
    }

    const proofStateWatcherConfig = config.watchers?.proofStateWatcher;
    if (!proofStateWatcherConfig?.disabled) {
      await coco.enableProofStateWatcher(proofStateWatcherConfig);
    }

    const meltQuoteWatcherConfig = config.watchers?.meltQuoteWatcher;
    if (!meltQuoteWatcherConfig?.disabled) {
      await coco.enableMeltQuoteWatcher(meltQuoteWatcherConfig);
    }

    const mintOperationProcessorConfig = config.processors?.mintOperationProcessor;
    if (!mintOperationProcessorConfig?.disabled) {
      await coco.enableMintOperationProcessor(mintOperationProcessorConfig);
    }

    const meltSettlementProcessorConfig = config.processors?.meltSettlementProcessor;
    if (!meltSettlementProcessorConfig?.disabled) {
      await coco.enableMeltSettlementProcessor(meltSettlementProcessorConfig);
    }

    return coco;
  } catch (error) {
    try {
      if (coco) await disposeFactoryManager(coco);
      else {
        await releaseAuthorityAndAttachment(attachment);
      }
    } catch (cleanupError) {
      throw new CocoInitializationError(
        'Coco initialization failed and cleanup could not be confirmed',
        'unconfirmed',
        new AggregateError([error, cleanupError]),
      );
    }
    throw new CocoInitializationError('Coco initialization failed', 'confirmed', error);
  }
}

export class Manager {
  static {
    createFactoryManager = (config, attachment) => {
      const manager = new Manager(
        attachment.repositories,
        config.seedGetter,
        config.logger,
        config.webSocketFactory,
        config.plugins,
        config.watchers,
        config.processors,
        config.subscriptions,
        config.outputDataCreator,
        config.lifecycle,
      );
      manager.#factoryBoot = true;
      manager.#repositoryAttachment = attachment;
      return manager;
    };
    recoverFactoryManager = (manager) => manager.#runQuiescentRecovery();
    activateFactoryManager = (manager) => {
      if (!manager.#factoryBoot) {
        throw new WalletAuthorityLifecycleError('Direct Managers cannot complete recovery');
      }
      manager.#quiescentRecoveryComplete = true;
      manager.#capabilityLifecycle.activate();
    };
    disposeFactoryManager = (manager) => manager.#disposeOwnedResources();
  }

  readonly mint: MintApi;
  readonly wallet: WalletApi;
  readonly keyring: KeyRingApi;
  readonly history: HistoryApi;
  readonly auth: AuthApi;
  readonly ops: OpsApi;
  readonly quotes: QuoteApi;
  readonly paymentRequests: PaymentRequestsApi;
  readonly ext: PluginExtensions;
  #mintService: MintService;
  #walletService: WalletService;
  #proofService: ProofService;
  #walletRestoreService: WalletRestoreService;
  #keyRingService: KeyRingService;
  #eventBus: EventBus<CoreEvents>;
  #logger: Logger;
  /** Lifecycle-fenced subscription API. The mutable transport manager is never exposed. */
  readonly subscriptions: PluginSubscriptionCapability;
  readonly #subscriptions: SubscriptionManager;
  #mintOperationWatcher?: MintOperationWatcherService;
  #mintOperationProcessor?: MintOperationProcessor;
  #meltQuoteWatcher?: MeltQuoteWatcherService;
  #meltSettlementProcessor?: MeltSettlementProcessor;
  #legacyMintQuoteRepository: LegacyMintQuoteRepository;
  #quoteLifecycle: QuoteLifecycle;
  #proofStateWatcher?: ProofStateWatcherService;
  #historyService: HistoryService;
  #counterService: CounterService;
  #tokenService: TokenService;
  #paymentRequestService: PaymentRequestService;
  #paymentRequestReceiveService: PaymentRequestReceiveService;
  #authSessionService: AuthSessionService;
  #authService: AuthService;
  #sendOperationService: SendOperationService;
  #sendOperationRepository: SendOperationRepository;
  #meltOperationService: MeltOperationService;
  #meltOperationRepository: MeltOperationRepository;
  #mintOperationService: MintOperationService;
  #mintOperationRepository: MintOperationRepository;
  #receiveOperationService: ReceiveOperationService;
  #receiveOperationRepository: ReceiveOperationRepository;
  #paymentRequestReceiveOperationRepository: PaymentRequestReceiveOperationRepository;
  #paymentRequestReceiveAttemptRepository: PaymentRequestReceiveAttemptRepository;
  #proofRepository: Repositories['proofRepository'];
  readonly #capabilityLifecycle: CapabilityLifecycleAuthority =
    createCapabilityLifecycleAuthority();
  readonly #lifecycleCalls = createLifecycleOperationCalls(this.#capabilityLifecycle);
  readonly #pluginHost: PluginHost = new PluginHost(this.#capabilityLifecycle);
  #subscriptionsPaused = false;
  #originalWatcherConfig: CocoConfig['watchers'];
  #originalProcessorConfig: CocoConfig['processors'];
  readonly #mintRequestProvider: MintRequestProvider;
  readonly #mintAdapter: MintAdapter;
  #disposed = false;
  #disposePromise?: Promise<void>;
  readonly #outputDataCreator?: OutputDataCreator;
  readonly #disposeTimeoutMs: number;
  readonly #repositories: Repositories;
  readonly #recoveryTasks: Readonly<{
    legacy: () => Promise<unknown>;
    send: () => Promise<void>;
    melt: () => Promise<void>;
    receiveAttempts: () => Promise<void>;
    mint: () => Promise<void>;
  }>;
  #factoryBoot = false;
  #repositoryAttachment?: RepositoryAttachment;
  #quiescentRecoveryComplete = false;
  readonly #publicEventWrappers = new Map<
    keyof CoreEvents,
    WeakMap<object, (payload: unknown) => void>
  >();
  constructor(
    repositories: Repositories,
    seedGetter: () => Promise<Uint8Array>,
    logger?: Logger,
    webSocketFactory?: WebSocketFactory,
    plugins?: Plugin[],
    watchers?: CocoConfig['watchers'],
    processors?: CocoConfig['processors'],
    subscriptions?: CocoConfig['subscriptions'],
    outputDataCreator?: OutputDataCreator,
    lifecycle?: CocoConfig['lifecycle'],
  ) {
    this.#repositories = repositories;
    this.#logger = logger ?? new NullLogger();
    this.#eventBus = this.#createEventBus();
    this.#outputDataCreator = outputDataCreator;
    const disposeTimeoutMs = lifecycle?.disposeTimeoutMs ?? DEFAULT_DISPOSE_TIMEOUT_MS;
    if (!Number.isFinite(disposeTimeoutMs) || disposeTimeoutMs < 0) {
      throw new TypeError('lifecycle.disposeTimeoutMs must be a finite non-negative number');
    }
    this.#disposeTimeoutMs = disposeTimeoutMs;

    // Create shared request provider and mint adapter first
    // These are shared across WalletService and SubscriptionManager (polling)
    this.#mintRequestProvider = new MintRequestProvider({
      capacity: 20,
      refillPerMinute: 20,
      logger: this.#getChildLogger('RequestRateLimiter'),
    });
    this.#mintAdapter = new MintAdapter(this.#mintRequestProvider);

    this.#originalWatcherConfig = watchers;
    this.#originalProcessorConfig = processors;
    if (plugins && plugins.length > 0) {
      for (const p of plugins) this.#pluginHost.use(p);
    }
    const core = this.#buildCoreServices(repositories, seedGetter);
    this.#mintService = core.mintService;
    this.#walletService = core.walletService;
    this.#proofService = core.proofService;
    this.#walletRestoreService = core.walletRestoreService;
    this.#keyRingService = core.keyRingService;
    this.#counterService = core.counterService;
    this.#legacyMintQuoteRepository = core.legacyMintQuoteRepository;
    this.#historyService = core.historyService;
    this.#paymentRequestService = core.paymentRequestService;
    this.#sendOperationService = core.sendOperationService;
    this.#tokenService = core.tokenService;
    this.#sendOperationRepository = core.sendOperationRepository;
    this.#receiveOperationService = core.receiveOperationService;
    this.#receiveOperationRepository = core.receiveOperationRepository;
    this.#paymentRequestReceiveService = core.paymentRequestReceiveService;
    this.#paymentRequestReceiveOperationRepository = core.paymentRequestReceiveOperationRepository;
    this.#paymentRequestReceiveAttemptRepository = core.paymentRequestReceiveAttemptRepository;
    this.#meltOperationService = core.meltOperationService;
    this.#meltOperationRepository = core.meltOperationRepository;
    this.#quoteLifecycle = core.quoteLifecycle;
    this.#authSessionService = core.authSessionService;
    this.#authService = core.authService;
    this.#mintOperationService = core.mintOperationService;
    this.#mintOperationRepository = core.mintOperationRepository;
    this.#proofRepository = repositories.proofRepository;
    this.#recoveryTasks = Object.freeze({
      legacy: () => this.#reconcileLegacyMintQuotes(),
      send: core.recoveryTasks.send,
      melt: core.recoveryTasks.melt,
      receiveAttempts: core.recoveryTasks.receiveAttempts,
      mint: core.recoveryTasks.mint,
    });
    this.#subscriptions = this.#createSubscriptionManager(webSocketFactory, subscriptions);
    this.subscriptions = createLifecycleSubscriptionFacade(
      this.#subscriptions,
      this.#capabilityLifecycle,
      [this.#repositories, this.#eventBus, this.#logger],
    );
    const apis = createLifecycleManagerApis(this.#buildApis(), this.#capabilityLifecycle);
    this.mint = apis.mint;
    this.wallet = apis.wallet;
    this.keyring = apis.keyring;
    this.history = apis.history;
    this.ops = apis.ops;
    this.quotes = apis.quotes;
    this.auth = apis.auth;
    this.paymentRequests = apis.paymentRequests;

    // Point ext to pluginHost's extensions storage
    this.ext = this.#pluginHost.getExtensions() as PluginExtensions;

    // Close subscriptions for untrusted mints
    this.#eventBus.on('mint:untrusted', ({ mintUrl }) => {
      this.#logger.info('Mint untrusted, closing subscriptions', { mintUrl });
      this.#subscriptions.closeMint(mintUrl);
    });

    // Invalidate wallet cache when auth state changes so next getWallet() picks up the new authProvider
    const clearWalletCache = ({ mintUrl }: { mintUrl: string }) => {
      this.#walletService.clearCache(mintUrl);
    };
    this.#eventBus.on('auth-session:updated', clearWalletCache);
    this.#eventBus.on('auth-session:deleted', clearWalletCache);
  }

  on<E extends keyof CoreEvents>(
    event: E,
    handler: (payload: CoreEvents[E]) => void | Promise<void>,
  ): () => void {
    return this.#lifecycleCalls.syncCall(() => {
      const wrapped = this.#wrapPublicEventHandler(event, handler);
      const unsubscribe = this.#eventBus.on(event, wrapped);
      return () => {
        if (!this.#capabilityLifecycle.isActive()) return;
        unsubscribe();
      };
    });
  }

  once<E extends keyof CoreEvents>(
    event: E,
    handler: (payload: CoreEvents[E]) => void | Promise<void>,
  ): () => void {
    return this.#lifecycleCalls.syncCall(() => {
      const wrapped = this.#wrapPublicEventHandler(event, handler);
      const unsubscribe = this.#eventBus.once(event, wrapped);
      return () => {
        if (!this.#capabilityLifecycle.isActive()) return;
        unsubscribe();
      };
    });
  }

  use(plugin: Plugin): void {
    this.#lifecycleCalls.syncCall(() => this.#pluginHost.use(plugin));
  }

  /**
   * Initialize the plugin system.
   * This is called automatically by `initializeCoco()`.
   * A directly constructed Manager remains permanently quiescent and cannot start plugin hooks.
   */
  async initPlugins(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      const capabilities = createPluginCapabilityFactories(
        {
          mintService: this.#mintService,
          proofService: this.#proofService,
          keyRingService: this.#keyRingService,
          walletRestoreService: this.#walletRestoreService,
          paymentRequestService: this.#paymentRequestService,
          counterService: this.#counterService,
          meltOperationService: this.#meltOperationService,
          mintOperationService: this.#mintOperationService,
          quotes: this.quotes,
          historyService: this.#historyService,
          sendOperationService: this.#sendOperationService,
          receiveOperationService: this.#receiveOperationService,
          paymentRequestReceiveService: this.#paymentRequestReceiveService,
          tokenService: this.#tokenService,
          subscriptions: this.#subscriptions,
          eventBus: this.#eventBus,
          logger: this.#logger,
        },
        this.#capabilityLifecycle,
        [
          this.#repositories,
          this.#repositories.mintRepository,
          this.#repositories.keyRingRepository,
          this.#repositories.counterRepository,
          this.#repositories.keysetRepository,
          this.#repositories.proofRepository,
          this.#repositories.meltQuoteRepository,
          this.#repositories.mintQuoteRepository,
          this.#repositories.legacyMintQuoteRepository,
          this.#repositories.historyRepository,
          this.#repositories.sendOperationRepository,
          this.#repositories.meltOperationRepository,
          this.#repositories.authSessionRepository,
          this.#repositories.mintOperationRepository,
          this.#repositories.receiveOperationRepository,
          this.#repositories.paymentRequestReceiveOperationRepository,
          this.#repositories.paymentRequestReceiveAttemptRepository,
        ],
      );
      await this.#pluginHost.init(capabilities);
      await this.#pluginHost.ready();
    });
  }

  async dispose(): Promise<void> {
    if (this.#disposePromise) {
      await this.#disposePromise;
      return;
    }
    if (this.#disposed) return;

    this.#disposePromise = this.#disposeOwnedResources();
    await this.#disposePromise;
  }

  async #disposeOwnedResources(): Promise<void> {
    this.#disposed = true;
    this.#subscriptionsPaused = true;
    const capabilityDrain = this.#capabilityLifecycle.revoke();
    const cleanupErrors: unknown[] = [];
    const deadline = nativeDateNow() + this.#disposeTimeoutMs;
    const remaining = () => Math.max(0, deadline - nativeDateNow());
    const cleanup = async (stage: string, work: () => void | Promise<void>) => {
      try {
        await settleWithin(work(), remaining(), stage);
      } catch (error) {
        cleanupErrors.push(error);
      }
    };

    // Revoke above is synchronous. Close transports and detach every autonomous producer before
    // waiting for plugin work, so a hostile callback cannot keep creating Core-owned work.
    const mintOperationWatcher = this.#mintOperationWatcher;
    const proofStateWatcher = this.#proofStateWatcher;
    const meltSettlementProcessor = this.#meltSettlementProcessor;
    const meltQuoteWatcher = this.#meltQuoteWatcher;
    const mintOperationProcessor = this.#mintOperationProcessor;
    this.#mintOperationWatcher = undefined;
    this.#proofStateWatcher = undefined;
    this.#meltSettlementProcessor = undefined;
    this.#meltQuoteWatcher = undefined;
    this.#mintOperationProcessor = undefined;

    try {
      this.#subscriptions.closeAll();
    } catch (error) {
      cleanupErrors.push(error);
    }
    const producerStops = [
      cleanup('mint operation watcher stop', () => mintOperationWatcher?.stop()),
      cleanup('proof state watcher stop', () => proofStateWatcher?.stop()),
      cleanup('melt settlement processor stop', async () => {
        await meltSettlementProcessor?.setInterestRegistrar(undefined);
        await meltSettlementProcessor?.stop();
      }),
      cleanup('melt quote watcher stop', () => meltQuoteWatcher?.stop()),
      cleanup('mint operation processor stop', () => mintOperationProcessor?.stop()),
    ];

    try {
      for (let index = 0; index < producerStops.length; index += 1) {
        await producerStops[index];
      }
      await cleanup('active lifecycle operation drain', () => capabilityDrain);
      try {
        // A subscription already inside its transport constructor when revocation occurred may
        // finish after the first close. Sweep once more after the bounded drain.
        this.#subscriptions.closeAll();
      } catch (error) {
        cleanupErrors.push(error);
      }
      try {
        // PluginHost enforces the shared remaining deadline internally while still invoking every
        // eligible dispose hook and registered cleanup before it reports aggregate failure.
        await this.#pluginHost.dispose(remaining());
      } catch (error) {
        cleanupErrors.push(error);
      }
    } finally {
      if (this.#factoryBoot) {
        try {
          const authorityReleased = await this.#repositories.releaseAuthority();
          if (!authorityReleased) {
            throw new WalletAuthorityLifecycleError(
              'Repository authority release could not be confirmed for the attached Manager',
            );
          }
          const attachment = this.#repositoryAttachment;
          if (attachment) {
            releaseRepositoryAttachment(attachment);
            this.#repositoryAttachment = undefined;
          }
        } catch (error) {
          cleanupErrors.push(error);
        }
      }
    }

    if (cleanupErrors.length > 0) {
      throw new AggregateError(cleanupErrors, 'Manager cleanup failed');
    }
  }

  async #runQuiescentRecovery(): Promise<void> {
    if (!this.#factoryBoot || this.#quiescentRecoveryComplete) {
      throw new WalletAuthorityLifecycleError('Invalid quiescent recovery lifecycle');
    }

    // These calls deliberately stay behind the private boundary. initializeCoco() must not route
    // required recovery through replaceable Manager.prototype entry points.
    const tasks = this.#recoveryTasks;
    await tasks.legacy();
    await tasks.send();
    await tasks.melt();
    await tasks.receiveAttempts();
    await tasks.mint();
  }

  #assertAutonomousStartAllowed(): void {
    this.#capabilityLifecycle.assertActive();
    if (!this.#quiescentRecoveryComplete) {
      throw new WalletAuthorityLifecycleError(
        'Autonomous wallet work cannot start before quiescent recovery completes',
      );
    }
  }

  off<E extends keyof CoreEvents>(
    event: E,
    handler: (payload: CoreEvents[E]) => void | Promise<void>,
  ): void {
    if (!this.#capabilityLifecycle.isActive()) return;
    const byHandler = collectionCall<WeakMap<object, (payload: unknown) => void> | undefined>(
      nativeMapGet,
      this.#publicEventWrappers,
      [event],
    );
    const wrapped = byHandler
      ? collectionCall<(payload: unknown) => void | undefined>(nativeWeakMapGet, byHandler, [
          handler,
        ])
      : undefined;
    if (wrapped) this.#eventBus.off(event, wrapped as never);
  }

  #wrapPublicEventHandler<E extends keyof CoreEvents>(
    event: E,
    handler: (payload: CoreEvents[E]) => void | Promise<void>,
  ): (payload: CoreEvents[E]) => void {
    let byHandler = collectionCall<WeakMap<object, (payload: unknown) => void> | undefined>(
      nativeMapGet,
      this.#publicEventWrappers,
      [event],
    );
    if (!byHandler) {
      byHandler = new WeakMap();
      collectionCall(nativeMapSet, this.#publicEventWrappers, [event, byHandler]);
    }
    const existing = collectionCall<(payload: CoreEvents[E]) => void | undefined>(
      nativeWeakMapGet,
      byHandler,
      [handler],
    );
    if (existing) return existing;
    const wrapped = (payload: CoreEvents[E]) => {
      if (!this.#capabilityLifecycle.isActive()) return;
      const pending = this.#lifecycleCalls.callback(() => handler(payload));
      void thenSafely(
        pending,
        () => undefined,
        () => undefined,
      );
    };
    collectionCall(nativeWeakMapSet, byHandler, [handler, wrapped]);
    return wrapped;
  }

  /** Read-only lifecycle metadata; never exposes watcher, processor, or service instances. */
  getRuntimeStatus(): Readonly<{
    mintOperationWatcher: boolean;
    proofStateWatcher: boolean;
    meltQuoteWatcher: boolean;
    mintOperationProcessor: boolean;
    meltSettlementProcessor: boolean;
  }> {
    return this.#lifecycleCalls.syncCall(() =>
      Object.freeze({
        mintOperationWatcher: this.#mintOperationWatcher?.isRunning() ?? false,
        proofStateWatcher: this.#proofStateWatcher?.isRunning() ?? false,
        meltQuoteWatcher: this.#meltQuoteWatcher?.isRunning() ?? false,
        mintOperationProcessor: this.#mintOperationProcessor?.isRunning() ?? false,
        meltSettlementProcessor: this.#meltSettlementProcessor?.isRunning() ?? false,
      }),
    );
  }

  async enableMintOperationWatcher(options?: {
    watchExistingPendingOnStart?: boolean;
    watchExistingPendingQuotesOnStart?: boolean;
  }): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      if (this.#mintOperationWatcher?.isRunning()) return;
      const watcherLogger = this.#logger.child
        ? this.#logger.child({ module: 'MintOperationWatcherService' })
        : this.#logger;
      this.#mintOperationWatcher = new MintOperationWatcherService(
        this.#subscriptions,
        this.#mintService,
        this.#mintOperationService,
        this.#quoteLifecycle,
        this.#eventBus,
        watcherLogger,
        {
          watchExistingPendingOnStart: options?.watchExistingPendingOnStart ?? true,
          watchExistingPendingQuotesOnStart: options?.watchExistingPendingQuotesOnStart ?? true,
        },
      );
      await this.#mintOperationWatcher.start();
    });
  }

  async disableMintOperationWatcher(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (!this.#mintOperationWatcher) return;
      await this.#mintOperationWatcher.stop();
      this.#mintOperationWatcher = undefined;
    });
  }

  async enableMintOperationProcessor(options?: {
    processIntervalMs?: number;
    maxRetries?: number;
    baseRetryDelayMs?: number;
    initialEnqueueDelayMs?: number;
    autoClaimMintQuotes?: boolean;
  }): Promise<boolean> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      if (this.#mintOperationProcessor?.isRunning()) return false;
      const processorLogger = this.#logger.child
        ? this.#logger.child({ module: 'MintOperationProcessor' })
        : this.#logger;
      this.#mintOperationProcessor = new MintOperationProcessor(
        this.#mintOperationService,
        this.#quoteLifecycle,
        this.#eventBus,
        processorLogger,
        options,
      );
      await this.#mintOperationProcessor.start();
      return true;
    });
  }

  async disableMintOperationProcessor(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (!this.#mintOperationProcessor) return;
      await this.#mintOperationProcessor.stop();
      this.#mintOperationProcessor = undefined;
    });
  }

  async enableMeltQuoteWatcher(options?: {
    watchExistingPendingQuotesOnStart?: boolean;
  }): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      if (this.#meltQuoteWatcher?.isRunning()) {
        await this.#meltSettlementProcessor?.setInterestRegistrar(this.#meltQuoteWatcher);
        return;
      }
      const watcherLogger = this.#logger.child
        ? this.#logger.child({ module: 'MeltQuoteWatcherService' })
        : this.#logger;
      this.#meltQuoteWatcher = new MeltQuoteWatcherService(
        this.#subscriptions,
        this.#mintService,
        this.#quoteLifecycle,
        this.#eventBus,
        watcherLogger,
        {
          watchExistingPendingQuotesOnStart: options?.watchExistingPendingQuotesOnStart ?? true,
        },
      );
      await this.#meltQuoteWatcher.start();
      await this.#meltSettlementProcessor?.setInterestRegistrar(this.#meltQuoteWatcher);
    });
  }

  async disableMeltQuoteWatcher(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (!this.#meltQuoteWatcher) return;
      await this.#meltSettlementProcessor?.setInterestRegistrar(undefined);
      await this.#meltQuoteWatcher.stop();
      this.#meltQuoteWatcher = undefined;
    });
  }

  async enableMeltSettlementProcessor(options?: {
    initializeExistingPendingOperationsOnStart?: boolean;
  }): Promise<boolean> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      if (this.#meltSettlementProcessor?.isRunning()) return false;
      const processorLogger = this.#logger.child
        ? this.#logger.child({ module: 'MeltSettlementProcessor' })
        : this.#logger;
      this.#meltSettlementProcessor = new MeltSettlementProcessor(
        this.#meltOperationService,
        this.#eventBus,
        processorLogger,
        {
          initializeExistingPendingOperationsOnStart:
            options?.initializeExistingPendingOperationsOnStart ?? true,
          interestRegistrar: this.#meltQuoteWatcher,
        },
      );
      await this.#meltSettlementProcessor.start();
      return true;
    });
  }

  async disableMeltSettlementProcessor(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (!this.#meltSettlementProcessor) return;
      await this.#meltSettlementProcessor.stop();
      this.#meltSettlementProcessor = undefined;
    });
  }

  async waitForMintOperationProcessor(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (!this.#mintOperationProcessor) return;
      await this.#mintOperationProcessor.waitForCompletion();
    });
  }

  async enableProofStateWatcher(options?: {
    watchExistingInflightOnStart?: boolean;
  }): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      if (this.#proofStateWatcher?.isRunning()) return;
      const watcherLogger = this.#logger.child
        ? this.#logger.child({ module: 'ProofStateWatcherService' })
        : this.#logger;
      this.#proofStateWatcher = new ProofStateWatcherService(
        this.#subscriptions,
        this.#mintService,
        this.#proofService,
        this.#proofRepository,
        this.#eventBus,
        watcherLogger,
        { watchExistingInflightOnStart: options?.watchExistingInflightOnStart ?? true },
      );
      this.#proofStateWatcher.setSendOperationService(this.#sendOperationService);
      await this.#proofStateWatcher.start();
    });
  }

  async disableProofStateWatcher(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (!this.#proofStateWatcher) return;
      await this.#proofStateWatcher.stop();
      this.#proofStateWatcher = undefined;
    });
  }

  async recoverPendingMintOperations(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(() =>
      this.#mintOperationService.recoverPendingOperations(),
    );
  }

  async recoverPendingPaymentRequestReceiveAttempts(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(() =>
      this.#paymentRequestReceiveService.recoverPendingAttempts(),
    );
  }

  async reconcileLegacyMintQuotes(
    mintUrl?: string,
  ): Promise<{ reconciled: string[]; skipped: string[] }> {
    return this.#lifecycleCalls.asyncCall(() => this.#reconcileLegacyMintQuotes(mintUrl));
  }

  async #reconcileLegacyMintQuotes(
    mintUrl?: string,
  ): Promise<{ reconciled: string[]; skipped: string[] }> {
    const reconciled: string[] = [];
    const skipped: string[] = [];
    const quotes = await this.#legacyMintQuoteRepository.getPendingLegacyMintQuotes(mintUrl);

    for (const quote of quotes) {
      if (!isStatefulMintQuote(quote)) {
        skipped.push(quote.quote);
        continue;
      }

      if (assessMintQuoteClaimability(quote).status === 'complete') {
        skipped.push(quote.quote);
        continue;
      }

      const trusted = await this.#mintService.isTrustedMint(quote.mintUrl);
      if (!trusted) {
        this.#logger.debug('Skipping legacy mint quote reconciliation for untrusted mint', {
          mintUrl: quote.mintUrl,
          quoteId: quote.quote,
        });
        skipped.push(quote.quote);
        continue;
      }

      const existing = await this.#mintOperationService.getOperationByQuote(
        quote.mintUrl,
        quote.method,
        quote.quoteId,
      );
      if (existing && existing.state !== 'init') {
        skipped.push(quote.quote);
        continue;
      }

      try {
        const imported = await this.#quoteLifecycle.importMintQuote(
          quote.mintUrl,
          'bolt11',
          mintQuoteToMethodSnapshot(quote) as MintMethodQuoteSnapshot<'bolt11'>,
        );
        const amount = getMintQuoteAmount(imported);
        if (!amount) {
          throw new Error(`Legacy mint quote ${imported.quoteId} does not have a fixed amount`);
        }

        const operation = await this.#mintOperationService.prepare(imported, amount);
        reconciled.push(operation.quoteId);
      } catch (err) {
        this.#logger.warn('Failed to reconcile legacy mint quote', {
          mintUrl: quote.mintUrl,
          quoteId: quote.quote,
          err,
        });
        skipped.push(quote.quote);
      }
    }

    this.#logger.info('Legacy mint quote reconciliation completed', {
      mintUrl,
      reconciled: reconciled.length,
      skipped: skipped.length,
    });

    return { reconciled, skipped };
  }

  async pauseSubscriptions(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      if (this.#subscriptionsPaused) {
        this.#logger.debug('Subscriptions already paused');
        return;
      }
      this.#subscriptionsPaused = true;
      this.#logger.info('Pausing subscriptions');
      this.#subscriptions.pause();
      await this.disableMintOperationWatcher();
      await this.disableProofStateWatcher();
      await this.disableMeltSettlementProcessor();
      await this.disableMeltQuoteWatcher();
      await this.disableMintOperationProcessor();
      this.#logger.info('Subscriptions paused');
      await this.#eventBus.emit('subscriptions:paused', undefined);
    });
  }

  async resumeSubscriptions(): Promise<void> {
    return this.#lifecycleCalls.asyncCall(async () => {
      this.#assertAutonomousStartAllowed();
      this.#subscriptionsPaused = false;
      this.#logger.info('Resuming subscriptions');
      await this.#eventBus.emit('subscriptions:resumed', undefined);
      this.#subscriptions.resume();
      const mintOperationWatcherConfig = this.#originalWatcherConfig?.mintOperationWatcher;
      if (!mintOperationWatcherConfig?.disabled) {
        await this.enableMintOperationWatcher(mintOperationWatcherConfig);
      }
      const proofStateWatcherConfig = this.#originalWatcherConfig?.proofStateWatcher;
      if (!proofStateWatcherConfig?.disabled) {
        await this.enableProofStateWatcher(proofStateWatcherConfig);
      }
      const meltQuoteWatcherConfig = this.#originalWatcherConfig?.meltQuoteWatcher;
      if (!meltQuoteWatcherConfig?.disabled) {
        await this.enableMeltQuoteWatcher(meltQuoteWatcherConfig);
      }
      const mintOperationProcessorConfig = this.#originalProcessorConfig?.mintOperationProcessor;
      if (!mintOperationProcessorConfig?.disabled) {
        await this.enableMintOperationProcessor(mintOperationProcessorConfig);
      }
      const meltSettlementProcessorConfig = this.#originalProcessorConfig?.meltSettlementProcessor;
      if (!meltSettlementProcessorConfig?.disabled) {
        await this.enableMeltSettlementProcessor(meltSettlementProcessorConfig);
      }
      await this.recoverPendingMintOperations();
      this.#logger.info('Subscriptions resumed');
    });
  }

  #getChildLogger(moduleName: string): Logger {
    return this.#logger.child ? this.#logger.child({ module: moduleName }) : this.#logger;
  }

  async requeuePaidMintQuotes(mintUrl?: string): Promise<{ requeued: string[] }> {
    return this.#lifecycleCalls.asyncCall(async () => {
      const requeued: string[] = [];
      const pendingOperations = await this.#mintOperationService.getPendingOperations();

      for (const operation of pendingOperations) {
        if (mintUrl && operation.mintUrl !== mintUrl) continue;

        const assessment = await this.#mintOperationService.getMintQuoteClaimability(
          operation.mintUrl,
          operation.method,
          operation.quoteId,
          {
            requestedAmount: operation.amount,
            targetOperationId: operation.id,
          },
        );
        if (
          !assessment ||
          (assessment.status !== 'claimable' && assessment.status !== 'complete')
        ) {
          continue;
        }

        const trusted = await this.#mintService.isTrustedMint(operation.mintUrl);
        if (!trusted) {
          continue;
        }

        await this.#eventBus.emit('mint-op:requeue', {
          mintUrl: operation.mintUrl,
          operationId: operation.id,
          operation,
        });
        requeued.push(operation.quoteId);
      }

      return { requeued };
    });
  }

  #createEventBus(): EventBus<CoreEvents> {
    const eventLogger = this.#getChildLogger('EventBus');
    return new EventBus<CoreEvents>({
      onError: (args) => {
        eventLogger.error('Event handler error', args);
      },
    });
  }

  #createSubscriptionManager(
    webSocketFactory?: WebSocketFactory,
    subscriptionOptions?: CocoConfig['subscriptions'],
  ): SubscriptionManager {
    const wsLogger = this.#getChildLogger('SubscriptionManager');
    // Detect global WebSocket if available, otherwise require injected factory
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const hasGlobalWs = typeof (globalThis as any).WebSocket !== 'undefined';
    const defaultFactory: WebSocketFactory | undefined = hasGlobalWs
      ? // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (url: string) => new (globalThis as any).WebSocket(url)
      : undefined;
    const wsFactoryToUse = webSocketFactory ?? defaultFactory;
    const options = {
      slowPollingIntervalMs: subscriptionOptions?.slowPollingIntervalMs ?? 20000,
      fastPollingIntervalMs: subscriptionOptions?.fastPollingIntervalMs ?? 5000,
    };
    if (!wsFactoryToUse) {
      // Fallback to polling transport when WS is unavailable
      const polling = new PollingTransport(
        this.#mintAdapter,
        { intervalMs: options.fastPollingIntervalMs },
        wsLogger,
        this.#quoteLifecycle,
      );
      return new SubscriptionManager(polling, this.#mintAdapter, wsLogger, options);
    }
    return new SubscriptionManager(
      wsFactoryToUse,
      this.#mintAdapter,
      wsLogger,
      options,
      this.#quoteLifecycle,
    );
  }

  #buildCoreServices(
    repositories: Repositories,
    seedGetter: () => Promise<Uint8Array>,
  ): {
    mintService: MintService;
    walletService: WalletService;
    counterService: CounterService;
    proofService: ProofService;
    tokenService: TokenService;
    walletRestoreService: WalletRestoreService;
    keyRingService: KeyRingService;
    legacyMintQuoteRepository: LegacyMintQuoteRepository;
    quoteLifecycle: QuoteLifecycle;
    historyService: HistoryService;
    paymentRequestService: PaymentRequestService;
    sendOperationService: SendOperationService;
    sendOperationRepository: SendOperationRepository;
    receiveOperationService: ReceiveOperationService;
    receiveOperationRepository: ReceiveOperationRepository;
    paymentRequestReceiveService: PaymentRequestReceiveService;
    paymentRequestReceiveOperationRepository: PaymentRequestReceiveOperationRepository;
    paymentRequestReceiveAttemptRepository: PaymentRequestReceiveAttemptRepository;
    meltOperationService: MeltOperationService;
    meltOperationRepository: MeltOperationRepository;
    authSessionService: AuthSessionService;
    authService: AuthService;
    mintOperationService: MintOperationService;
    mintOperationRepository: MintOperationRepository;
    recoveryTasks: Readonly<{
      send: () => Promise<void>;
      melt: () => Promise<void>;
      receiveAttempts: () => Promise<void>;
      mint: () => Promise<void>;
    }>;
  } {
    const mintLogger = this.#getChildLogger('MintService');
    const walletLogger = this.#getChildLogger('WalletService');
    const counterLogger = this.#getChildLogger('CounterService');
    const proofLogger = this.#getChildLogger('ProofService');
    const walletRestoreLogger = this.#getChildLogger('WalletRestoreService');
    const keyRingLogger = this.#getChildLogger('KeyRingService');
    const historyLogger = this.#getChildLogger('HistoryService');
    const tokenLogger = this.#getChildLogger('TokenService');
    const seedService = new SeedService(seedGetter);
    const coreTransactionRunner = new RepositoryCoreTransactionRunner(
      repositories,
      this.#outputDataCreator,
    );
    const mintQueries = new StoredMintQueries(
      repositories.mintRepository,
      repositories.keysetRepository,
    );
    const mintService = new MintService(
      repositories.mintRepository,
      repositories.keysetRepository,
      this.#mintAdapter,
      {
        queries: mintQueries,
        transactions: new CoreMintMetadataTransactions(coreTransactionRunner),
      },
      mintLogger,
      this.#eventBus,
    );
    const keyRingTransactions = new CoreKeyRingTransactions(coreTransactionRunner);
    const keypairDerivation = new KeypairDerivation(() => seedService.getSeed());
    const p2pkSigner = new KeypairP2pkSigner(repositories.keyRingRepository);
    const keyRingService = new KeyRingService(
      repositories.keyRingRepository,
      keyRingTransactions,
      keypairDerivation,
      p2pkSigner,
      keyRingLogger,
    );
    const walletService = new WalletService(
      mintService,
      seedService,
      this.#mintRequestProvider,
      walletLogger,
      (mintUrl: string) => this.#mintAdapter.getAuthProvider(mintUrl),
      this.#outputDataCreator,
    );
    const counterService = new CounterService(
      repositories.counterRepository,
      counterLogger,
      this.#eventBus,
    );
    const proofService = new ProofService(
      counterService,
      repositories.proofRepository,
      walletService,
      mintService,
      p2pkSigner,
      seedService,
      proofLogger,
      this.#eventBus,
      this.#outputDataCreator,
    );
    const walletRestoreService = new WalletRestoreService(
      proofService,
      counterService,
      walletService,
      this.#mintRequestProvider,
      walletRestoreLogger,
      this.#outputDataCreator,
    );

    // One shared instance across every counter-consuming operation service so that
    // send, receive, melt, and mint serialize their per-mint deterministic-output
    // derivation against each other. Passing separate instances would break that.
    const mintScopedLock = new MintScopedLock();
    let sendRecoveryTask: (() => Promise<void>) | undefined;
    let meltRecoveryTask: (() => Promise<void>) | undefined;
    let receiveAttemptRecoveryTask: (() => Promise<void>) | undefined;
    let mintRecoveryTask: (() => Promise<void>) | undefined;

    const sendOperationLogger = this.#getChildLogger('SendOperationService');
    const sendHandlerProvider = new SendHandlerProvider({
      default: new DefaultSendHandler(),
      p2pk: new P2pkSendHandler(p2pkSigner),
    });
    const sendTransactions = new CoreSendTransactions(coreTransactionRunner);
    const sendOperationService = new SendOperationService({
      operationQueries: repositories.sendOperationRepository,
      proofQueries: repositories.proofRepository,
      transactions: sendTransactions,
      mintQueries: repositories.mintRepository,
      mintMetadataQueries: mintQueries,
      mintMetadataRefresh: mintService,
      remote: new CashuSendRemote(
        this.#mintAdapter,
        this.#mintRequestProvider,
        this.#outputDataCreator,
      ),
      loadSeed: () => seedService.getSeed(),
      eventBus: this.#eventBus,
      handlerProvider: sendHandlerProvider,
      outputDataCreator: this.#outputDataCreator,
      logger: sendOperationLogger,
      mintScopedLock,
      registerRecoveryTask: (task) => {
        sendRecoveryTask = task;
      },
    });
    const sendOperationRepository = repositories.sendOperationRepository;

    const tokenService = new TokenService(mintService, tokenLogger);

    const receiveOperationLogger = this.#getChildLogger('ReceiveOperationService');
    const receiveOperationService = new ReceiveOperationService({
      operations: repositories.receiveOperationRepository,
      operationIdCollisionQueries: [
        { type: 'send', repository: repositories.sendOperationRepository },
        { type: 'melt', repository: repositories.meltOperationRepository },
        { type: 'mint', repository: repositories.mintOperationRepository },
        {
          type: 'payment-request-receive',
          repository: repositories.paymentRequestReceiveOperationRepository,
        },
        {
          type: 'payment-request-receive-attempt',
          repository: repositories.paymentRequestReceiveAttemptRepository,
        },
      ],
      transactions: new CoreReceiveTransactions(coreTransactionRunner),
      mintQueries: repositories.mintRepository,
      mintMetadataRefresh: mintService,
      signer: p2pkSigner,
      loadSeed: () => seedService.getSeed(),
      remote: new CashuReceiveRemote(this.#mintAdapter, this.#mintRequestProvider),
      eventBus: this.#eventBus,
      logger: receiveOperationLogger,
      mintScopedLock,
    });
    const receiveOperationRepository = repositories.receiveOperationRepository;
    const paymentRequestReceiveOperationRepository =
      repositories.paymentRequestReceiveOperationRepository;
    const paymentRequestReceiveAttemptRepository =
      repositories.paymentRequestReceiveAttemptRepository;

    const meltOperationLogger = this.#getChildLogger('MeltOperationService');
    const quoteLifecycleLogger = this.#getChildLogger('QuoteLifecycle');
    const meltHandlerProvider = new MeltHandlerProvider({
      bolt11: new MeltBolt11Handler(),
      bolt12: new MeltBolt12Handler(),
      onchain: new MeltOnchainHandler(),
    });
    const mintHandlerProvider = new MintHandlerProvider({
      bolt11: new MintBolt11Handler(keyRingService),
      onchain: new MintOnchainHandler(keyRingService),
      bolt12: new MintBolt12Handler(keyRingService),
    });
    const quoteLifecycle = new QuoteLifecycle({
      mintHandlerProvider,
      meltHandlerProvider,
      mintQuoteRepository: repositories.mintQuoteRepository,
      meltQuoteRepository: repositories.meltQuoteRepository,
      proofRepository: repositories.proofRepository,
      proofService,
      mintService,
      walletService,
      mintAdapter: this.#mintAdapter,
      eventBus: this.#eventBus,
      logger: quoteLifecycleLogger,
      withMintQuoteTransaction: (fn) =>
        repositories.withTransaction(({ mintQuoteRepository }) => fn(mintQuoteRepository)),
    });
    const meltOperationService = new MeltOperationService(
      meltHandlerProvider,
      repositories.meltOperationRepository,
      quoteLifecycle,
      repositories.proofRepository,
      proofService,
      mintService,
      walletService,
      this.#mintAdapter,
      this.#eventBus,
      meltOperationLogger,
      mintScopedLock,
      (task) => {
        meltRecoveryTask = task;
      },
    );
    const meltOperationRepository = repositories.meltOperationRepository;

    const mintOperationLogger = this.#getChildLogger('MintOperationService');
    const mintOperationService = new MintOperationService(
      mintHandlerProvider,
      repositories.mintOperationRepository,
      quoteLifecycle,
      repositories.proofRepository,
      proofService,
      mintService,
      walletService,
      this.#mintAdapter,
      this.#eventBus,
      mintOperationLogger,
      mintScopedLock,
      (task) => {
        mintRecoveryTask = task;
      },
    );
    const mintOperationRepository = repositories.mintOperationRepository;

    const historyService = new HistoryService(
      repositories.historyRepository,
      this.#eventBus,
      historyLogger,
    );

    const legacyMintQuoteRepository = repositories.legacyMintQuoteRepository;

    const paymentRequestLogger = this.#getChildLogger('PaymentRequestService');
    const paymentRequestService = new PaymentRequestService(
      sendOperationService,
      proofService,
      mintService,
      paymentRequestLogger,
    );
    const paymentRequestReceiveLogger = this.#getChildLogger('PaymentRequestReceiveService');
    const paymentRequestReceiveTransportHandlerProvider =
      new PaymentRequestReceiveTransportHandlerProvider();
    const paymentRequestReceiveService = new PaymentRequestReceiveService(
      paymentRequestReceiveOperationRepository,
      paymentRequestReceiveAttemptRepository,
      receiveOperationService,
      receiveOperationRepository,
      mintService,
      paymentRequestReceiveTransportHandlerProvider,
      paymentRequestReceiveLogger,
      (task) => {
        receiveAttemptRecoveryTask = task;
      },
    );

    if (
      !sendRecoveryTask ||
      !meltRecoveryTask ||
      !receiveAttemptRecoveryTask ||
      !mintRecoveryTask
    ) {
      throw new WalletAuthorityLifecycleError('Mandatory recovery task registration failed');
    }

    const authSessionLogger = this.#getChildLogger('AuthSessionService');
    const authSessionService = new AuthSessionService(
      repositories.authSessionRepository,
      this.#eventBus,
      authSessionLogger,
    );

    const authServiceLogger = this.#getChildLogger('AuthService');
    const authService = new AuthService(authSessionService, this.#mintAdapter, authServiceLogger);

    return {
      mintService,
      walletService,
      counterService,
      proofService,
      tokenService,
      walletRestoreService,
      keyRingService,
      legacyMintQuoteRepository,
      quoteLifecycle,
      historyService,
      paymentRequestService,
      sendOperationService,
      sendOperationRepository,
      receiveOperationService,
      receiveOperationRepository,
      paymentRequestReceiveService,
      paymentRequestReceiveOperationRepository,
      paymentRequestReceiveAttemptRepository,
      meltOperationService,
      meltOperationRepository,
      authSessionService,
      authService,
      mintOperationService,
      mintOperationRepository,
      recoveryTasks: Object.freeze({
        send: sendRecoveryTask,
        melt: meltRecoveryTask,
        receiveAttempts: receiveAttemptRecoveryTask,
        mint: mintRecoveryTask,
      }),
    };
  }

  #buildApis(): {
    mint: MintApi;
    wallet: WalletApi;
    keyring: KeyRingApi;
    history: HistoryApi;
    ops: OpsApi;
    quotes: QuoteApi;
    auth: AuthApi;
    paymentRequests: PaymentRequestsApi;
  } {
    const walletApiLogger = this.#getChildLogger('WalletApi');
    const mint = new MintApi(this.#mintService);
    const wallet = new WalletApi(
      this.#mintService,
      this.#walletService,
      this.#proofService,
      this.#walletRestoreService,
      this.#receiveOperationService,
      this.#tokenService,
      walletApiLogger,
    );
    const keyring = new KeyRingApi(this.#keyRingService);
    const history = new HistoryApi(this.#historyService);
    const send = new SendOpsApi(this.#sendOperationService);
    const receive = new ReceiveOpsApi(this.#receiveOperationService);
    const mintOps = new MintOpsApi(this.#mintOperationService);
    const melt = new MeltOpsApi(this.#meltOperationService);
    const ops = new OpsApi(send, receive, mintOps, melt);
    const quotes = new QuoteApi(this.#quoteLifecycle);
    const auth = new AuthApi(this.#authService);
    const paymentRequests = new PaymentRequestsApi(
      this.#paymentRequestService,
      this.#paymentRequestReceiveService,
    );
    return {
      mint,
      wallet,
      keyring,
      history,
      ops,
      quotes,
      auth,
      paymentRequests,
    };
  }
}
