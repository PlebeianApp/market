import { isMintQuotePending, type MintQuote } from '@core/models/MintQuote';
import type { LegacyMintQuoteRepository } from '..';
import { normalizeMintUrl } from '../../utils';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryLegacyMintQuoteRepository implements LegacyMintQuoteRepository {
  private quotes = createMemoryMap<string, MintQuote>();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryLegacyMintQuoteRepository): void {
    this.quotes = cloneMemoryRepositoryStateValue(source.quotes);
  }

  private makeKey(mintUrl: string, method: string, quoteId: string): string {
    return `${normalizeMintUrl(mintUrl)}::${method}::${quoteId}`;
  }

  async upsertMintQuote(quote: MintQuote): Promise<void> {
    const normalizedMintUrl = normalizeMintUrl(quote.mintUrl);
    const key = this.makeKey(normalizedMintUrl, quote.method, quote.quoteId);
    memoryMapSet(
      this.quotes,
      key,
      cloneMemoryValue({
        ...quote,
        mintUrl: normalizedMintUrl,
        quote: quote.quoteId,
      }),
    );
  }

  async getPendingLegacyMintQuotes(mintUrl?: string): Promise<MintQuote[]> {
    const normalizedMintUrl = mintUrl ? normalizeMintUrl(mintUrl) : undefined;
    const result: MintQuote[] = [];
    const quotes = memoryMapValues(this.quotes);
    for (let index = 0; index < quotes.length; index += 1) {
      const quote = quotes[index]!;
      if (normalizedMintUrl && quote.mintUrl !== normalizedMintUrl) continue;
      if (isMintQuotePending(quote)) memoryArrayPush(result, cloneMemoryValue(quote));
    }
    return result;
  }
}
