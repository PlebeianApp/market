import { describe, expect, test } from 'bun:test';

const CORE_ROOT = new URL('../../', import.meta.url).pathname.replace(/\/$/, '');

type Loaded = {
  initializeCoco: (config: any) => Promise<any>;
  MemoryRepositories: new () => any;
  Manager: new (...args: any[]) => any;
};

const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

function representativeCapabilityCalls(services: any): Array<readonly [string, () => unknown]> {
  return [
    ['mintService', () => services.mintService.getAllMints()],
    ['proofService', () => services.proofService.getBalances()],
    ['keyRingService', () => services.keyRingService.getAllKeyPairs()],
    [
      'walletRestoreService',
      () => services.walletRestoreService.sweepKeyset('mint', 'keyset', new Uint8Array()),
    ],
    ['counterService', () => services.counterService.getCounter('mint', 'keyset')],
    ['tokenService', () => services.tokenService.decodeToken('token', 'mint')],
    ['historyService', () => services.historyService.getPaginatedHistory()],
    ['sendOperationService', () => services.sendOperationService.getOperation('operation')],
    ['receiveOperationService', () => services.receiveOperationService.getOperation('operation')],
    ['meltOperationService', () => services.meltOperationService.getOperation('operation')],
    ['mintOperationService', () => services.mintOperationService.getOperation('operation')],
    [
      'quotes',
      () => services.quotes.mint.get({ mintUrl: 'https://mint.invalid', quoteId: 'quote' }),
    ],
    ['paymentRequestService', () => services.paymentRequestService.parse('request')],
    ['paymentRequestReceiveService', () => services.paymentRequestReceiveService.get('operation')],
    ['subscriptions', () => services.subscriptions.pause()],
    ['eventBus', () => services.eventBus.on('counter:updated', () => {})],
    ['logger', () => services.logger.info('diagnostic')],
  ];
}

async function expectRevoked(call: () => unknown): Promise<void> {
  let rejected = false;
  try {
    await call();
  } catch {
    rejected = true;
  }
  expect(rejected).toBe(true);
}

async function probe(label: string, loaded: Loaded): Promise<void> {
  const sockets: any[] = [];
  let services: any;
  let initRegistrar: ((key: string, value: unknown) => void) | undefined;
  let readyRegistrar: ((key: string, value: unknown) => void) | undefined;
  const manager = await loaded.initializeCoco({
    repo: new loaded.MemoryRepositories(),
    seedGetter: async () => new Uint8Array(64).fill(0x51),
    webSocketFactory: (url: string) => {
      const listeners = new Map<string, Set<(event: unknown) => void>>();
      const socket = {
        url,
        sent: [] as string[],
        closed: false,
        send(data: string) {
          this.sent.push(data);
        },
        close() {
          this.closed = true;
        },
        addEventListener(type: string, listener: (event: unknown) => void) {
          const set = listeners.get(type) ?? new Set();
          set.add(listener);
          listeners.set(type, set);
        },
        removeEventListener(type: string, listener: (event: unknown) => void) {
          listeners.get(type)?.delete(listener);
        },
      };
      sockets.push(socket);
      return socket;
    },
    plugins: [
      {
        name: `round6-capability-lifetime-${label}`,
        required: [
          'mintService',
          'proofService',
          'keyRingService',
          'walletRestoreService',
          'counterService',
          'tokenService',
          'historyService',
          'sendOperationService',
          'receiveOperationService',
          'meltOperationService',
          'mintOperationService',
          'quotes',
          'paymentRequestService',
          'paymentRequestReceiveService',
          'subscriptions',
          'eventBus',
          'logger',
        ],
        onInit(context: any) {
          services = context.services;
          initRegistrar = context.registerExtension;
          context.registerExtension('during-init', Object.freeze({ safe: true }));
        },
        onReady(context: any) {
          readyRegistrar = context.registerExtension;
          context.registerExtension('during-ready', Object.freeze({ safe: true }));
        },
      },
    ],
    ...disabledRuntime,
  });

  // A registrar expires when its own hook settles, not merely when the Manager is disposed.
  expect(Object.hasOwn(manager.ext, 'during-init')).toBe(true);
  expect(Object.hasOwn(manager.ext, 'during-ready')).toBe(true);
  expect(() => initRegistrar!('after-init', { unsafe: true })).toThrow();
  expect(() => readyRegistrar!('after-ready', { unsafe: true })).toThrow();
  expect(Object.hasOwn(manager.ext, 'after-init')).toBe(false);
  expect(Object.hasOwn(manager.ext, 'after-ready')).toBe(false);

  await manager.dispose();
  expect(sockets).toHaveLength(0);

  let subscription: unknown;
  await expectRevoked(async () => {
    subscription = await services.subscriptions.subscribe(
      'https://disposed-capability.invalid',
      'not-a-supported-kind',
      ['quote-id'],
      () => {},
    );
  });
  expect(subscription).toBeUndefined();
  expect(sockets).toHaveLength(0);
  expect(services.subscriptions.getDiagnostics()).toMatchObject({
    subscriptions: [],
    activeMintCount: 0,
    transportCount: 0,
    paused: true,
  });

  for (const [, call] of representativeCapabilityCalls(services)) {
    await expectRevoked(call);
  }

  expect(() => initRegistrar!('after-dispose-init', { unsafe: true })).toThrow();
  expect(() => readyRegistrar!('after-dispose-ready', { unsafe: true })).toThrow();
  expect(Object.hasOwn(manager.ext, 'after-dispose-init')).toBe(false);
  expect(Object.hasOwn(manager.ext, 'after-dispose-ready')).toBe(false);
}

async function probeDisposeRace(loaded: Loaded): Promise<void> {
  const sockets: Array<{ closed: boolean }> = [];
  let subscriptions: any;
  const manager = await loaded.initializeCoco({
    repo: new loaded.MemoryRepositories(),
    seedGetter: async () => new Uint8Array(64).fill(0x53),
    webSocketFactory: () => {
      const socket = {
        closed: false,
        send() {},
        close() {
          this.closed = true;
        },
        addEventListener() {},
        removeEventListener() {},
      };
      sockets.push(socket);
      return socket;
    },
    plugins: [
      {
        name: 'round6-dispose-race',
        required: ['subscriptions'],
        onInit(context: any) {
          subscriptions = context.services.subscriptions;
        },
      },
    ],
    ...disabledRuntime,
  });

  const pending = subscriptions.subscribe('https://dispose-race.invalid', 'bolt11_mint_quote', [
    'quote',
  ]);
  const disposing = manager.dispose();
  await expect(pending).rejects.toThrow();
  await disposing;
  expect(sockets.every((socket) => socket.closed)).toBe(true);
  expect(subscriptions.getDiagnostics()).toMatchObject({
    subscriptions: [],
    activeMintCount: 0,
    transportCount: 0,
  });
}

describe('round-six capability lifecycle revocation', () => {
  for (const [label, modulePath] of [
    ['source', `${CORE_ROOT}/index.ts`],
    ['dist', `${CORE_ROOT}/dist/index.js`],
  ] as const) {
    test(`revokes all 17 retained capabilities and hook registrars (${label})`, async () => {
      await probe(label, (await import(modulePath)) as unknown as Loaded);
    });

    test(`direct Manager subscription access remains quiescent (${label})`, async () => {
      const loaded = (await import(modulePath)) as unknown as Loaded;
      let socketCount = 0;
      const manager = new loaded.Manager(
        new loaded.MemoryRepositories(),
        async () => new Uint8Array(64),
        undefined,
        () => {
          socketCount++;
          return {
            send() {},
            close() {},
            addEventListener() {},
            removeEventListener() {},
          };
        },
      );
      await expect(
        manager.subscriptions.subscribe('https://direct-manager.invalid', 'not-a-supported-kind', [
          'quote-id',
        ]),
      ).rejects.toThrow();
      expect(socketCount).toBe(0);
      await manager.dispose();
    });

    test(`dispose revokes a racing retained capability before teardown (${label})`, async () => {
      await probeDisposeRace((await import(modulePath)) as unknown as Loaded);
    });
  }
});
