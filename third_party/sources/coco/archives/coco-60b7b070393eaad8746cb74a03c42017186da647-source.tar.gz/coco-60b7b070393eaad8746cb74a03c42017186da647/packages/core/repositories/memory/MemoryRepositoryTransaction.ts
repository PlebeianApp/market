import { Amount } from '@cashu/cashu-ts';
import {
  cloneMemoryBytes,
  createMemoryMap,
  createMemorySet,
  isMemoryBytes,
  isMemoryMap,
  isMemorySet,
  memoryMapEntries,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryBytesLength,
  memorySetAdd,
  memorySetDelete,
  memorySetHas,
  memorySetValues,
} from './MemoryCollectionIntrinsics.ts';

/** Internal protocol that lets each memory repository own its transaction-state representation. */
export const COPY_MEMORY_REPOSITORY_STATE = Symbol('copyMemoryRepositoryState');

const NativeArray = Array;
const NativeDate = Date;
const NativeNumber = Number;
const NativeString = String;
const NativeTypeError = TypeError;
const nativeStructuredClone = structuredClone;
const nativeAmountFrom = Amount.from;
const nativeAmountPrototype = Amount.prototype;
const nativeArrayIsArray = Array.isArray;
const nativeArrayPrototype = Array.prototype;
const nativeCreate = Object.create;
const nativeDefineProperty = Object.defineProperty;
const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const nativeGetPrototypeOf = Object.getPrototypeOf;
const nativeObjectPrototype = Object.prototype;
const nativeNumberIsFinite = Number.isFinite;
const nativeNumberIsSafeInteger = Number.isSafeInteger;
const nativeOwnKeys = Reflect.ownKeys;
const nativeReflectApply = Reflect.apply;
const nativeDateGetTime = Date.prototype.getTime;
const nativeDatePrototype = Date.prototype;
const nativeIsProxy = captureNativeIsProxy();

export type MemoryRepositoryStateOwner<TRepository extends object> = {
  [COPY_MEMORY_REPOSITORY_STATE](source: TRepository): void;
};

/**
 * Clone one inert value across the Memory repository persistence boundary.
 *
 * This deliberately accepts a smaller surface than JavaScript's object model. Persisted values
 * may contain plain records, dense arrays, Amount, Date, and byte values. Accessors, functions,
 * symbols, arbitrary prototypes, and collection objects are rejected before they can become part
 * of private repository state.
 */
export function cloneMemoryValue<T>(value: T): T {
  // Browser and Expo runtimes do not expose a direct Proxy identity intrinsic. Their native
  // structured-clone implementation rejects a Proxy graph without consulting its traps, so use
  // that as the graph-wide preflight before any reflective traversal. Bun and Node expose the
  // stronger native isProxy check captured below; clonePersistedValue applies it at every node,
  // preserving the zero-getter behavior of the descriptor validator as well.
  if (!nativeIsProxy) rejectProxyOrUncloneableGraph(value);
  return clonePersistedValue(value, createCloneContext(false)) as T;
}

/** Clone private adapter state, including its backing Map/Set collections. */
export function cloneMemoryRepositoryStateValue<T>(value: T): T {
  return clonePersistedValue(value, createCloneContext(true)) as T;
}

type CloneContext = {
  allowCollections: boolean;
  active: Set<object>;
  seen: Map<object, unknown>;
};

function createCloneContext(allowCollections: boolean): CloneContext {
  return {
    allowCollections,
    active: createMemorySet<object>(),
    seen: createMemoryMap<object, unknown>(),
  };
}

function clonePersistedValue(value: unknown, context: CloneContext): unknown {
  const valueType = typeof value;
  if (
    value === null ||
    valueType === 'string' ||
    valueType === 'boolean' ||
    valueType === 'bigint' ||
    valueType === 'undefined'
  ) {
    return value;
  }
  if (valueType === 'number') {
    if (!nativeNumberIsFinite(value)) throw invalidValue('non-finite numbers are not supported');
    return value;
  }
  if (valueType === 'function') throw invalidValue('functions are not supported');
  if (valueType === 'symbol') throw invalidValue('symbol values are not supported');
  if (valueType !== 'object') throw invalidValue(`unsupported ${valueType} value`);

  const objectValue = value as object;
  if (nativeIsProxy?.(objectValue)) {
    throw invalidValue('Proxy and non-cloneable object graphs are not supported');
  }
  if (memorySetHas(context.active, objectValue)) {
    throw invalidValue('cyclic object graphs are not supported');
  }
  if (memoryMapHas(context.seen, objectValue)) return memoryMapGet(context.seen, objectValue);

  const prototype = nativeGetPrototypeOf(objectValue);

  if (prototype === nativeAmountPrototype) return cloneAmount(objectValue);
  if (prototype === nativeDatePrototype) return cloneDate(objectValue);
  if (isMemoryBytes(objectValue)) return cloneBytes(objectValue);

  if (nativeArrayIsArray(objectValue)) {
    if (prototype !== nativeArrayPrototype)
      throw invalidValue('array subclasses are not supported');
    return cloneArray(objectValue as unknown[], context);
  }

  if (isMemoryMap(objectValue)) {
    if (!context.allowCollections) throw invalidValue('Map values are not supported');
    return cloneInternalMap(objectValue, context);
  }
  if (isMemorySet(objectValue)) {
    if (!context.allowCollections) throw invalidValue('Set values are not supported');
    return cloneInternalSet(objectValue, context);
  }

  if (prototype !== nativeObjectPrototype && prototype !== null) {
    throw invalidValue('objects with custom prototypes are not supported');
  }
  return cloneRecord(objectValue, prototype, context);
}

function cloneAmount(value: object): Amount {
  const keys = nativeOwnKeys(value);
  if (keys.length !== 1 || keys[0] !== 'value') throw invalidValue('invalid Amount shape');
  const descriptor = nativeGetOwnPropertyDescriptor(value, 'value');
  if (!descriptor || !('value' in descriptor) || typeof descriptor.value !== 'bigint') {
    throw invalidValue('invalid Amount value');
  }
  return nativeReflectApply(nativeAmountFrom, Amount, [descriptor.value]) as Amount;
}

function cloneDate(value: object): Date {
  rejectOwnProperties(value, 'Date');
  const timestamp = nativeReflectApply(nativeDateGetTime, value, []) as number;
  if (!nativeNumberIsFinite(timestamp)) throw invalidValue('invalid Date value');
  return new NativeDate(timestamp);
}

function cloneBytes(value: Uint8Array): Uint8Array {
  const keys = nativeOwnKeys(value);
  const length = memoryBytesLength(value);
  for (let index = 0; index < keys.length; index += 1) {
    const key = keys[index]!;
    if (typeof key !== 'string' || !isCanonicalArrayIndex(key, length)) {
      throw invalidValue('byte values may not contain extra properties');
    }
    const descriptor = nativeGetOwnPropertyDescriptor(value, key);
    if (!descriptor || !('value' in descriptor) || typeof descriptor.value !== 'number') {
      throw invalidValue('invalid byte value');
    }
  }
  return cloneMemoryBytes(value);
}

function cloneArray(value: unknown[], context: CloneContext): unknown[] {
  const keys = nativeOwnKeys(value);
  const lengthDescriptor = nativeGetOwnPropertyDescriptor(value, 'length');
  if (!lengthDescriptor || !('value' in lengthDescriptor)) throw invalidValue('invalid array');
  const length = lengthDescriptor.value;
  if (!nativeNumberIsSafeInteger(length) || length < 0) throw invalidValue('invalid array length');
  if (keys.length !== length + 1) throw invalidValue('arrays must be dense and contain no extras');

  const clone = new NativeArray<unknown>(length);
  memoryMapSet(context.seen, value, clone);
  memorySetAdd(context.active, value);
  try {
    for (let index = 0; index < length; index += 1) {
      const key = NativeString(index);
      const descriptor = nativeGetOwnPropertyDescriptor(value, key);
      if (!descriptor || !('value' in descriptor))
        throw invalidValue('array accessors are not supported');
      nativeDefineProperty(clone, key, {
        configurable: true,
        enumerable: true,
        writable: true,
        value: clonePersistedValue(descriptor.value, context),
      });
    }
  } finally {
    memorySetDelete(context.active, value);
  }
  return clone;
}

function cloneRecord(value: object, _prototype: object | null, context: CloneContext): object {
  // A null prototype prevents later Object.prototype poisoning from changing stored semantics.
  const clone = nativeCreate(null) as object;
  memoryMapSet(context.seen, value, clone);
  memorySetAdd(context.active, value);
  try {
    const keys = nativeOwnKeys(value);
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index]!;
      if (typeof key !== 'string') throw invalidValue('symbol-keyed properties are not supported');
      const descriptor = nativeGetOwnPropertyDescriptor(value, key);
      if (!descriptor || !('value' in descriptor)) {
        throw invalidValue('accessor properties are not supported');
      }
      if (!descriptor.enumerable) {
        throw invalidValue('non-enumerable record properties are not supported');
      }
      nativeDefineProperty(clone, key, {
        configurable: true,
        enumerable: true,
        writable: true,
        value: clonePersistedValue(descriptor.value, context),
      });
    }
  } finally {
    memorySetDelete(context.active, value);
  }
  return clone;
}

function cloneInternalMap(
  value: Map<unknown, unknown>,
  context: CloneContext,
): Map<unknown, unknown> {
  const clone = createMemoryMap<unknown, unknown>();
  memoryMapSet(context.seen, value, clone);
  memorySetAdd(context.active, value);
  try {
    const entries = memoryMapEntries(value);
    for (let index = 0; index < entries.length; index += 1) {
      const entry = entries[index]!;
      memoryMapSet(
        clone,
        clonePersistedValue(entry[0], context),
        clonePersistedValue(entry[1], context),
      );
    }
  } finally {
    memorySetDelete(context.active, value);
  }
  return clone;
}

function cloneInternalSet(value: Set<unknown>, context: CloneContext): Set<unknown> {
  const clone = createMemorySet<unknown>();
  memoryMapSet(context.seen, value, clone);
  memorySetAdd(context.active, value);
  try {
    const values = memorySetValues(value);
    for (let index = 0; index < values.length; index += 1) {
      memorySetAdd(clone, clonePersistedValue(values[index], context));
    }
  } finally {
    memorySetDelete(context.active, value);
  }
  return clone;
}

function rejectOwnProperties(value: object, label: string): void {
  if (nativeOwnKeys(value).length !== 0) {
    throw invalidValue(`${label} values may not contain extra properties`);
  }
}

function isCanonicalArrayIndex(key: string, length: number): boolean {
  if (key === '') return false;
  const index = NativeNumber(key);
  return (
    nativeNumberIsSafeInteger(index) && index >= 0 && index < length && NativeString(index) === key
  );
}

function invalidValue(reason: string): TypeError {
  return new NativeTypeError(`Unsafe Memory repository value: ${reason}`);
}

type RuntimeProcess = {
  getBuiltinModule?: (specifier: string) => unknown;
};

type NativeUtilModule = {
  types?: {
    isProxy?: (value: object) => boolean;
  };
};

/** Capture the runtime's native, trap-free Proxy identity predicate when it is available. */
function captureNativeIsProxy(): ((value: object) => boolean) | null {
  const runtimeProcess = (globalThis as typeof globalThis & { process?: RuntimeProcess }).process;
  const getBuiltinModule = runtimeProcess?.getBuiltinModule;
  if (typeof getBuiltinModule !== 'function') return null;
  try {
    const util = nativeReflectApply(getBuiltinModule, runtimeProcess, ['node:util']) as
      | NativeUtilModule
      | undefined;
    const types = util?.types;
    const isProxy = types?.isProxy;
    if (!types || typeof isProxy !== 'function') return null;
    return (value: object): boolean => nativeReflectApply(isProxy, types, [value]) as boolean;
  } catch {
    return null;
  }
}

function rejectProxyOrUncloneableGraph(value: unknown): void {
  if ((typeof value !== 'object' || value === null) && typeof value !== 'function') return;
  try {
    nativeReflectApply(nativeStructuredClone, undefined, [value]);
  } catch {
    throw invalidValue('Proxy and non-cloneable object graphs are not supported');
  }
}
