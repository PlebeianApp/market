import type {
  PaymentRequestReceiveAttemptRepository,
  PaymentRequestReceiveOperationRepository,
} from '..';
import type {
  PaymentRequestReceiveAttempt,
  PaymentRequestReceiveAttemptState,
  PaymentRequestReceiveOperation,
  PaymentRequestReceiveState,
} from '../../operations/paymentRequestReceive/PaymentRequestReceiveOperation';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapDelete,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';
import { MemoryOperationIdOwnership } from '../OperationIdOwnership.ts';

function cloneOperation(operation: PaymentRequestReceiveOperation): PaymentRequestReceiveOperation {
  return cloneMemoryValue(operation);
}

function cloneAttempt(attempt: PaymentRequestReceiveAttempt): PaymentRequestReceiveAttempt {
  return cloneMemoryValue(attempt);
}

export class MemoryPaymentRequestReceiveOperationRepository implements PaymentRequestReceiveOperationRepository {
  private operations = createMemoryMap<string, PaymentRequestReceiveOperation>();

  constructor(private readonly operationIds = new MemoryOperationIdOwnership()) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryPaymentRequestReceiveOperationRepository): void {
    this.operations = cloneMemoryRepositoryStateValue(source.operations);
    this.operationIds.copyFrom(source.operationIds);
  }

  async create(operation: PaymentRequestReceiveOperation): Promise<void> {
    if (memoryMapHas(this.operations, operation.id)) {
      throw new Error(`PaymentRequestReceiveOperation with id ${operation.id} already exists`);
    }
    this.operationIds.claim(operation.id, 'payment-request-receive');
    memoryMapSet(this.operations, operation.id, cloneOperation(operation));
  }

  async update(operation: PaymentRequestReceiveOperation): Promise<void> {
    if (!memoryMapHas(this.operations, operation.id)) {
      throw new Error(`PaymentRequestReceiveOperation with id ${operation.id} not found`);
    }
    memoryMapSet(
      this.operations,
      operation.id,
      cloneOperation({ ...operation, updatedAt: Date.now() }),
    );
  }

  async getById(id: string): Promise<PaymentRequestReceiveOperation | null> {
    const operation = memoryMapGet(this.operations, id);
    return operation ? cloneOperation(operation) : null;
  }

  async getByState(state: PaymentRequestReceiveState): Promise<PaymentRequestReceiveOperation[]> {
    return this.#filterOperations((operation) => operation.state === state);
  }

  async getActiveByRequestId(requestId: string): Promise<PaymentRequestReceiveOperation[]> {
    return this.#filterOperations(
      (operation) => operation.state === 'active' && operation.requestId === requestId,
    );
  }

  async list(filter?: {
    state?: PaymentRequestReceiveState;
  }): Promise<PaymentRequestReceiveOperation[]> {
    return this.#filterOperations(
      (operation) => !filter?.state || operation.state === filter.state,
    );
  }

  #filterOperations(
    predicate: (operation: PaymentRequestReceiveOperation) => boolean,
  ): PaymentRequestReceiveOperation[] {
    const result: PaymentRequestReceiveOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (predicate(operation)) memoryArrayPush(result, cloneOperation(operation));
    }
    return result;
  }
}

export class MemoryPaymentRequestReceiveAttemptRepository implements PaymentRequestReceiveAttemptRepository {
  private attempts = createMemoryMap<string, PaymentRequestReceiveAttempt>();

  constructor(private readonly operationIds = new MemoryOperationIdOwnership()) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryPaymentRequestReceiveAttemptRepository): void {
    this.attempts = cloneMemoryRepositoryStateValue(source.attempts);
    this.operationIds.copyFrom(source.operationIds);
  }

  async create(attempt: PaymentRequestReceiveAttempt): Promise<void> {
    if (memoryMapHas(this.attempts, attempt.id)) {
      throw new Error(`PaymentRequestReceiveAttempt with id ${attempt.id} already exists`);
    }
    this.operationIds.claim(attempt.id, 'payment-request-receive-attempt');
    if (
      attempt.transportMessageId &&
      (await this.getByTransportMessageId(attempt.transportMessageId))
    ) {
      throw new Error(
        `PaymentRequestReceiveAttempt with transport message id ${attempt.transportMessageId} already exists`,
      );
    }
    if (await this.getByPayloadHash(attempt.requestOperationId, attempt.payloadHash)) {
      throw new Error(
        `PaymentRequestReceiveAttempt with payload hash ${attempt.payloadHash} already exists`,
      );
    }
    memoryMapSet(this.attempts, attempt.id, cloneAttempt(attempt));
  }

  async update(attempt: PaymentRequestReceiveAttempt): Promise<void> {
    if (!memoryMapHas(this.attempts, attempt.id)) {
      throw new Error(`PaymentRequestReceiveAttempt with id ${attempt.id} not found`);
    }
    memoryMapSet(this.attempts, attempt.id, cloneAttempt({ ...attempt, updatedAt: Date.now() }));
  }

  async getById(id: string): Promise<PaymentRequestReceiveAttempt | null> {
    const attempt = memoryMapGet(this.attempts, id);
    return attempt ? cloneAttempt(attempt) : null;
  }

  async getByRequestOperationId(
    requestOperationId: string,
  ): Promise<PaymentRequestReceiveAttempt[]> {
    return this.#filterAttempts((attempt) => attempt.requestOperationId === requestOperationId);
  }

  async getByReceiveOperationId(
    receiveOperationId: string,
  ): Promise<PaymentRequestReceiveAttempt | null> {
    const attempt = this.#findAttempt(
      (candidate) => candidate.receiveOperationId === receiveOperationId,
    );
    return attempt ? cloneAttempt(attempt) : null;
  }

  async getByTransportMessageId(
    transportMessageId: string,
  ): Promise<PaymentRequestReceiveAttempt | null> {
    const attempt = this.#findAttempt(
      (candidate) => candidate.transportMessageId === transportMessageId,
    );
    return attempt ? cloneAttempt(attempt) : null;
  }

  async getByPayloadHash(
    requestOperationId: string,
    payloadHash: string,
  ): Promise<PaymentRequestReceiveAttempt | null> {
    const attempt = this.#findAttempt(
      (candidate) =>
        candidate.requestOperationId === requestOperationId &&
        candidate.payloadHash === payloadHash,
    );
    return attempt ? cloneAttempt(attempt) : null;
  }

  async getByRequestIdAndPayloadHash(
    requestId: string,
    payloadHash: string,
  ): Promise<PaymentRequestReceiveAttempt | null> {
    const attempts = this.#filterAttempts(
      (candidate) => candidate.requestId === requestId && candidate.payloadHash === payloadHash,
    );
    let attempt = attempts[0];
    for (let index = 0; index < attempts.length; index += 1) {
      if (attempts[index]!.state === 'finalized') {
        attempt = attempts[index];
        break;
      }
    }
    return attempt ? cloneAttempt(attempt) : null;
  }

  async getByState(
    state: PaymentRequestReceiveAttemptState,
  ): Promise<PaymentRequestReceiveAttempt[]> {
    return this.#filterAttempts((attempt) => attempt.state === state);
  }

  async delete(id: string): Promise<void> {
    memoryMapDelete(this.attempts, id);
  }

  #findAttempt(
    predicate: (attempt: PaymentRequestReceiveAttempt) => boolean,
  ): PaymentRequestReceiveAttempt | undefined {
    const attempts = memoryMapValues(this.attempts);
    for (let index = 0; index < attempts.length; index += 1) {
      const attempt = attempts[index]!;
      if (predicate(attempt)) return attempt;
    }
    return undefined;
  }

  #filterAttempts(
    predicate: (attempt: PaymentRequestReceiveAttempt) => boolean,
  ): PaymentRequestReceiveAttempt[] {
    const result: PaymentRequestReceiveAttempt[] = [];
    const attempts = memoryMapValues(this.attempts);
    for (let index = 0; index < attempts.length; index += 1) {
      const attempt = attempts[index]!;
      if (predicate(attempt)) memoryArrayPush(result, cloneAttempt(attempt));
    }
    return result;
  }
}
