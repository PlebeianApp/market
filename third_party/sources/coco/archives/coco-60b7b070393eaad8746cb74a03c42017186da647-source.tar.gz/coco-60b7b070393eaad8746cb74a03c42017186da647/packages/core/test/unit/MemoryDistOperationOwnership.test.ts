import { describe, expect, it } from 'bun:test';
import { Amount } from '@cashu/cashu-ts';

const owners = [
  'send',
  'receive',
  'mint',
  'melt',
  'payment-request-receive',
  'payment-request-receive-attempt',
] as const;
type Owner = (typeof owners)[number];
type OperationRepository = {
  create(operation: unknown): Promise<void>;
  getById(id: string): Promise<unknown | null>;
  delete?(id: string): Promise<void>;
};
type RuntimeRepositories = {
  init(): Promise<void>;
  acquireAuthority(identity: { namespace: string; ownerId: string }): Promise<unknown>;
  releaseAuthority(): Promise<boolean>;
  sendOperationRepository: OperationRepository;
  receiveOperationRepository: OperationRepository;
  mintOperationRepository: OperationRepository;
  meltOperationRepository: OperationRepository;
  paymentRequestReceiveOperationRepository: OperationRepository;
  paymentRequestReceiveAttemptRepository: OperationRepository;
};

function repositoryFor(repositories: RuntimeRepositories, owner: Owner): OperationRepository {
  switch (owner) {
    case 'send':
      return repositories.sendOperationRepository;
    case 'receive':
      return repositories.receiveOperationRepository;
    case 'mint':
      return repositories.mintOperationRepository;
    case 'melt':
      return repositories.meltOperationRepository;
    case 'payment-request-receive':
      return repositories.paymentRequestReceiveOperationRepository;
    case 'payment-request-receive-attempt':
      return repositories.paymentRequestReceiveAttemptRepository;
  }
}

function operationFor(owner: Owner, id: string): object {
  const common = { id, mintUrl: 'https://mint.test', createdAt: 0, updatedAt: 0 };
  switch (owner) {
    case 'send':
      return {
        ...common,
        state: 'prepared',
        amount: Amount.from(1),
        unit: 'sat',
        method: 'default',
        methodData: {},
        needsSwap: false,
        fee: Amount.zero(),
        inputAmount: Amount.from(1),
        inputProofSecrets: [`proof-${id}`],
      };
    case 'receive':
      return {
        ...common,
        state: 'init',
        unit: 'sat',
        amount: Amount.from(1),
        inputProofs: [{ id: 'keyset', amount: Amount.from(1), secret: `secret-${id}`, C: 'C' }],
      };
    case 'mint':
      return {
        ...common,
        state: 'pending',
        quoteId: `quote-${id}`,
        method: 'bolt11',
        methodData: {},
        amount: Amount.from(1),
        unit: 'sat',
        request: 'lnbc1test',
        outputData: { keep: [], send: [] },
      };
    case 'melt':
      return {
        ...common,
        state: 'init',
        unit: 'sat',
        method: 'bolt11',
        methodData: { invoice: 'lnbc1test', amountSats: Amount.from(1) },
        quoteId: `quote-${id}`,
      };
    case 'payment-request-receive':
      return {
        id,
        requestId: `request-${id}`,
        encodedRequest: 'CREQB1TEST',
        state: 'active',
        transport: 'inband',
        amount: Amount.from(1),
        unit: 'sat',
        mints: ['https://mint.test'],
        singleUse: true,
        createdAt: 0,
        updatedAt: 0,
      };
    case 'payment-request-receive-attempt':
      return {
        ...common,
        requestOperationId: `request-operation-${id}`,
        requestId: `request-${id}`,
        transport: 'inband',
        transportMessageId: `message-${id}`,
        payloadHash: `payload-${id}`,
        unit: 'sat',
        grossAmount: Amount.from(1),
        state: 'received',
      };
  }
}

async function create(repositories: RuntimeRepositories, owner: Owner, id: string): Promise<void> {
  await repositoryFor(repositories, owner).create(operationFor(owner, id));
}

describe('emitted Memory global operation-ID ownership', () => {
  for (let leftIndex = 0; leftIndex < owners.length; leftIndex++) {
    for (let rightIndex = leftIndex + 1; rightIndex < owners.length; rightIndex++) {
      const left = owners[leftIndex]!;
      const right = owners[rightIndex]!;
      it(`atomically resolves emitted ${left} vs ${right}`, async () => {
        const emitted = (await import('../../dist/index.js')) as unknown as {
          MemoryRepositories: new () => RuntimeRepositories;
        };
        const repositories = new emitted.MemoryRepositories();
        await repositories.init();
        await repositories.acquireAuthority({ namespace: 'wallet', ownerId: 'dist-contract' });
        try {
          const id = `dist-${left}-${right}`;
          const outcomes = await Promise.allSettled([
            create(repositories, left, id),
            create(repositories, right, id),
          ]);
          expect(outcomes.filter((outcome) => outcome.status === 'fulfilled')).toHaveLength(1);
          const rejected = outcomes.find((outcome) => outcome.status === 'rejected');
          expect(rejected?.status).toBe('rejected');
          if (rejected?.status === 'rejected') {
            expect((rejected.reason as Error).name).toBe('OperationIdConflictError');
          }
          const rows = await Promise.all([
            repositoryFor(repositories, left).getById(id),
            repositoryFor(repositories, right).getById(id),
          ]);
          expect(rows.filter(Boolean)).toHaveLength(1);
        } finally {
          await repositories.releaseAuthority();
        }
      });
    }
  }

  it('never reuses an emitted ID after its owning row is deleted', async () => {
    const emitted = (await import('../../dist/index.js')) as unknown as {
      MemoryRepositories: new () => RuntimeRepositories;
    };
    const repositories = new emitted.MemoryRepositories();
    await repositories.init();
    await repositories.acquireAuthority({ namespace: 'wallet', ownerId: 'dist-delete-contract' });
    const id = 'dist-never-reused';
    try {
      await create(repositories, 'receive', id);
      await repositories.receiveOperationRepository.delete!(id);
      await expect(create(repositories, 'receive', id)).rejects.toMatchObject({
        name: 'OperationIdConflictError',
      });
      await expect(create(repositories, 'send', id)).rejects.toMatchObject({
        name: 'OperationIdConflictError',
      });
    } finally {
      await repositories.releaseAuthority();
    }
  });
});
