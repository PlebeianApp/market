import { describe, expect, it, mock } from 'bun:test';

describe('emitted Manager quiescence contract', () => {
  it('does not expose seed, repositories, plugin host, or privileged API dependencies', async () => {
    const emitted = (await import('../../dist/index.js')) as any;
    const seed = Uint8Array.from({ length: 64 }, (_, index) => index + 1);
    const manager = await emitted.initializeCoco({
      repo: new emitted.MemoryRepositories(),
      seedGetter: async () => seed,
      watchers: {
        mintOperationWatcher: { disabled: true },
        proofStateWatcher: { disabled: true },
        meltQuoteWatcher: { disabled: true },
      },
      processors: {
        mintOperationProcessor: { disabled: true },
        meltSettlementProcessor: { disabled: true },
      },
    });
    const forbidden = new Set([
      'seedService',
      'repositories',
      'pluginHost',
      'mintService',
      'walletService',
      'proofService',
      'eventBus',
      'mintAdapter',
      'mintRequestProvider',
      'transactionRunner',
      'db',
      'database',
    ]);
    const visited = new Set<object>();
    const inspect = (value: unknown): void => {
      if (value === null || (typeof value !== 'object' && typeof value !== 'function')) return;
      const object = value as object;
      if (visited.has(object)) return;
      visited.add(object);
      for (const key of Reflect.ownKeys(object)) {
        if (typeof key === 'string') expect(forbidden.has(key)).toBe(false);
        const descriptor = Object.getOwnPropertyDescriptor(object, key);
        if (descriptor && 'value' in descriptor && typeof descriptor.value !== 'function') {
          inspect(descriptor.value);
        }
      }
      const prototype = Object.getPrototypeOf(object);
      if (prototype && prototype !== Object.prototype && prototype !== Function.prototype) {
        for (const key of Reflect.ownKeys(prototype)) {
          if (typeof key === 'string') expect(forbidden.has(key)).toBe(false);
        }
      }
    };

    expect(manager.seedService).toBeUndefined();
    expect(manager.repositories).toBeUndefined();
    inspect(manager);
    await manager.dispose();
  });

  it('does not permit direct construction to activate plugins or autonomous work', async () => {
    const preImportGlobalSymbol = Symbol.for('coco-manager-boot-capability');
    const emitted = (await import('../../dist/index.js')) as unknown as {
      Manager: new (
        repositories: unknown,
        seedGetter: () => Promise<Uint8Array>,
        logger?: unknown,
        webSocketFactory?: unknown,
        plugins?: unknown[],
        ...forgedBootArguments: unknown[]
      ) => {
        initPlugins(): Promise<void>;
        enableMintOperationWatcher(): Promise<void>;
        enableProofStateWatcher(): Promise<void>;
        enableMeltQuoteWatcher(): Promise<void>;
        enableMintOperationProcessor(): Promise<boolean>;
        enableMeltSettlementProcessor(): Promise<boolean>;
        resumeSubscriptions(): Promise<void>;
        use(plugin: unknown): void;
        dispose(): Promise<void>;
      };
      MemoryRepositories: new () => unknown;
    };
    const onInit = mock(() => {});
    const onReady = mock(() => {});
    const onDispose = mock(() => {});
    const manager = new emitted.Manager(
      new emitted.MemoryRepositories(),
      async () => new Uint8Array(32),
      undefined,
      undefined,
      [{ name: 'emitted-static', required: [], onInit, onReady, onDispose }],
      undefined,
      undefined,
      undefined,
      undefined,
      preImportGlobalSymbol,
    );

    expect(Object.getOwnPropertyNames(manager)).not.toContain('quiescentRecoveryComplete');
    expect(Object.getOwnPropertyNames(manager)).not.toContain('factoryBoot');
    Reflect.set(manager, 'quiescentRecoveryComplete', true);
    Reflect.set(manager, 'factoryBoot', true);

    const starts = [
      () => manager.initPlugins(),
      () => manager.enableMintOperationWatcher(),
      () => manager.enableProofStateWatcher(),
      () => manager.enableMeltQuoteWatcher(),
      () => manager.enableMintOperationProcessor(),
      () => manager.enableMeltSettlementProcessor(),
      () => manager.resumeSubscriptions(),
    ];
    for (const start of starts) {
      try {
        await start();
        throw new Error('expected emitted Manager to remain quiescent');
      } catch (error) {
        expect((error as Error).name).toBe('WalletAuthorityLifecycleError');
      }
    }
    expect('completeQuiescentRecovery' in manager).toBe(false);
    const runtimeInit = mock(() => {});
    const runtimeDispose = mock(() => {});
    expect(() =>
      manager.use({
        name: 'emitted-runtime',
        required: [],
        onInit: runtimeInit,
        onDispose: runtimeDispose,
      }),
    ).toThrow('Manager capability authority is not active');
    await manager.dispose();
    expect(onInit).not.toHaveBeenCalled();
    expect(onReady).not.toHaveBeenCalled();
    expect(onDispose).not.toHaveBeenCalled();
    expect(runtimeInit).not.toHaveBeenCalled();
    expect(runtimeDispose).not.toHaveBeenCalled();
  });

  it('performs durable recovery before plugins under the emitted intrinsic-patch adversary', async () => {
    const emitted = (await import('../../dist/index.js')) as any;
    const backing = new emitted.MemoryRepositories();
    await backing.init();
    await backing.acquireAuthority({ namespace: 'default', ownerId: 'dist-recovery-seed' });
    const operationId = 'dist-private-recovery-init';
    const now = Date.now();
    await backing.sendOperationRepository.create({
      id: operationId,
      state: 'init',
      mintUrl: 'https://dist-recovery.test',
      amount: emitted.Amount.from(1),
      unit: 'sat',
      method: 'default',
      methodData: {},
      createdAt: now,
      updatedAt: now,
      revision: 0,
    });
    await backing.releaseAuthority();
    const repositories = backing.createPeer();

    const originalReconcile = emitted.Manager.prototype.reconcileLegacyMintQuotes;
    const publicReplacement = mock(async () => {
      throw new Error('public recovery path was invoked');
    });
    emitted.Manager.prototype.reconcileLegacyMintQuotes = publicReplacement;

    const nativeCall = Function.prototype.call;
    const nativeApply = Function.prototype.apply;
    const nativeBind = Function.prototype.bind;
    const nativeReflectApply = Reflect.apply;
    const skippedRecovery: string[] = [];
    const classifyRecovery = (target: Function, receiver: unknown): string | undefined => {
      const functionName = target.name;
      const receiverName = (receiver as any)?.constructor?.name;
      if (
        (functionName === 'recoverPendingOperations' ||
          functionName === 'recoverPendingAttempts') &&
        (receiverName === 'SendOperationService' ||
          receiverName === 'MeltOperationService' ||
          receiverName === 'PaymentRequestReceiveService' ||
          receiverName === 'MintOperationService')
      ) {
        return `${receiverName}.${functionName}`;
      }
      return undefined;
    };
    Function.prototype.call = function redTeamCall(thisArg: unknown, ...args: unknown[]) {
      const classified = classifyRecovery(this, thisArg);
      if (classified) {
        skippedRecovery.push(`call:${classified}`);
        return Promise.resolve();
      }
      return nativeReflectApply(nativeCall, this, [thisArg, ...args]);
    };
    Function.prototype.apply = function redTeamApply(thisArg: unknown, args?: unknown) {
      const classified = classifyRecovery(this, thisArg);
      if (classified) {
        skippedRecovery.push(`apply:${classified}`);
        return Promise.resolve();
      }
      return nativeReflectApply(nativeApply, this, [thisArg, args]);
    };
    Function.prototype.bind = function redTeamBind(thisArg: unknown, ...args: unknown[]) {
      const classified = classifyRecovery(this, thisArg);
      if (classified) {
        skippedRecovery.push(`bind:${classified}`);
        return () => Promise.resolve();
      }
      return nativeReflectApply(nativeBind, this, [thisArg, ...args]);
    };
    Reflect.apply = function redTeamReflectApply(
      target: Function,
      thisArg: unknown,
      args: ArrayLike<unknown>,
    ) {
      const classified = classifyRecovery(target, thisArg);
      if (classified) {
        skippedRecovery.push(`reflect:${classified}`);
        return Promise.resolve();
      }
      return nativeReflectApply(target, thisArg, args);
    } as typeof Reflect.apply;

    let manager: any;
    let pluginObservedCleanup = false;
    let recoveryFactoryReachable = true;
    try {
      manager = await emitted.initializeCoco({
        repo: repositories,
        seedGetter: async () => new Uint8Array(64),
        plugins: [
          {
            name: 'dist-intrinsic-patch-recovery-observer',
            required: ['sendOperationService'],
            async onInit({ services }: any) {
              pluginObservedCleanup =
                (await repositories.sendOperationRepository.getById(operationId)) === null;
              const constructor = services.sendOperationService.constructor as
                | Record<string, unknown>
                | undefined;
              recoveryFactoryReachable = typeof constructor?.createRecoveryTask === 'function';
            },
          },
        ],
        watchers: {
          mintOperationWatcher: { disabled: true },
          proofStateWatcher: { disabled: true },
          meltQuoteWatcher: { disabled: true },
        },
        processors: {
          mintOperationProcessor: { disabled: true },
          meltSettlementProcessor: { disabled: true },
        },
      });
    } finally {
      Reflect.apply = nativeReflectApply;
      Function.prototype.bind = nativeBind;
      Function.prototype.apply = nativeApply;
      Function.prototype.call = nativeCall;
      emitted.Manager.prototype.reconcileLegacyMintQuotes = originalReconcile;
      await manager?.dispose();
    }

    expect(skippedRecovery).toEqual([]);
    expect(publicReplacement).not.toHaveBeenCalled();
    expect(pluginObservedCleanup).toBe(true);
    expect(recoveryFactoryReachable).toBe(false);
    expect(await repositories.sendOperationRepository.getById(operationId)).toBeNull();
  });
});
