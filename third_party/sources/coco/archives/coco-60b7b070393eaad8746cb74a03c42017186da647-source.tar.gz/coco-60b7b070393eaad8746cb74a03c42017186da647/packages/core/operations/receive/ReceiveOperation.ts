/**
 * Durable lifecycle: prepared → executing → finalized (or rolled_back after proven non-effect).
 * Preparation atomically commits signed inputs, outputs, and counter allocation.
 * `init` is an in-memory draft; persisted legacy init rows remain readable for upgrade recovery.
 */
export type ReceiveOperationState = 'init' | 'prepared' | 'executing' | 'finalized' | 'rolled_back';

import { Amount, type Proof } from '@cashu/cashu-ts';
import {
  getSecretsFromSerializedOutputData,
  normalizeMintUrl,
  type SerializedOutputData,
} from '../../utils';
import { normalizeUnit, normalizeUnitAmount, type UnitAmount } from '../../amounts.ts';

export type ReceiveOperationSource =
  | { type: 'manual-token' }
  | {
      type: 'payment-request';
      requestOperationId: string;
      requestId?: string;
      attemptId: string;
      transport: 'inband' | 'nostr' | 'post';
      transportMessageId?: string;
      senderPubkey?: string;
      memo?: string;
    };

// ============================================================================
// Base and Data Interfaces
// ============================================================================

/**
 * Base fields present in all receive operations
 */
interface ReceiveOperationBase {
  /** Unique identifier for this operation */
  id: string;

  /** Monotonic persistence revision; absent on legacy records and interpreted as zero. */
  revision?: number;

  /** The mint URL for this operation */
  mintUrl: string;

  /** Unit declared by the received token */
  unit: string;

  /** The amount received (sum of input proofs) */
  amount: Amount;

  /** Proofs contained in the received token (prepared for receiving) */
  inputProofs: Proof[];

  /** Timestamp when the operation was created */
  createdAt: number;

  /** Timestamp when the operation was last updated */
  updatedAt: number;

  /** Error message if the operation failed */
  error?: string;

  /** Optional origin metadata for receives created by higher-level sagas. */
  source?: ReceiveOperationSource;
}

/**
 * Data set during the prepare phase
 */
interface PreparedData {
  /** Fees charged for the receive operation */
  fee: Amount;

  /** Serialized OutputData for deterministic receive outputs */
  outputData: SerializedOutputData;
}

// ============================================================================
// State-specific Operation Types
// ============================================================================

/**
 * Initial state - operation just created, token decoded
 */
export interface InitReceiveOperation extends ReceiveOperationBase {
  state: 'init';
  /** Transient marker consumed by atomic preparation; never persisted. */
  callerSuppliedId?: boolean;
}

export interface CallerOwnedInitReceiveOperation extends InitReceiveOperation {
  callerSuppliedId: true;
}

/**
 * Prepared state - outputs created, ready to execute
 */
export interface PreparedReceiveOperation extends ReceiveOperationBase, PreparedData {
  state: 'prepared';
}

/**
 * Executing state - receive in progress
 */
export interface ExecutingReceiveOperation extends ReceiveOperationBase, PreparedData {
  state: 'executing';
}

/**
 * Finalized state - proofs saved, operation complete
 */
export interface FinalizedReceiveOperation extends ReceiveOperationBase, PreparedData {
  state: 'finalized';
}

/**
 * Rolled back state - operation failed or aborted
 */
export interface RolledBackReceiveOperation extends ReceiveOperationBase, PreparedData {
  state: 'rolled_back';
}

// ============================================================================
// Union Type
// ============================================================================

/**
 * Discriminated union of all receive operation states.
 */
export type ReceiveOperation =
  | InitReceiveOperation
  | PreparedReceiveOperation
  | ExecutingReceiveOperation
  | FinalizedReceiveOperation
  | RolledBackReceiveOperation;

// ============================================================================
// Utility Types
// ============================================================================

/**
 * Any operation that has been prepared (has PreparedData)
 */
export type PreparedOrLaterOperation =
  | PreparedReceiveOperation
  | ExecutingReceiveOperation
  | FinalizedReceiveOperation
  | RolledBackReceiveOperation;

/**
 * Terminal states - operation is finished
 */
export type TerminalReceiveOperation = FinalizedReceiveOperation | RolledBackReceiveOperation;

// ============================================================================
// Type Guards
// ============================================================================

export function isInitOperation(op: ReceiveOperation): op is InitReceiveOperation {
  return op.state === 'init';
}

export function isPreparedOperation(op: ReceiveOperation): op is PreparedReceiveOperation {
  return op.state === 'prepared';
}

export function isExecutingOperation(op: ReceiveOperation): op is ExecutingReceiveOperation {
  return op.state === 'executing';
}

export function isFinalizedOperation(op: ReceiveOperation): op is FinalizedReceiveOperation {
  return op.state === 'finalized';
}

export function isRolledBackOperation(op: ReceiveOperation): op is RolledBackReceiveOperation {
  return op.state === 'rolled_back';
}

export function hasPreparedData(op: ReceiveOperation): op is PreparedOrLaterOperation {
  return op.state !== 'init';
}

export function isTerminalOperation(op: ReceiveOperation): op is TerminalReceiveOperation {
  return op.state === 'finalized' || op.state === 'rolled_back';
}

// ============================================================================
// Helpers
// ============================================================================

export function getOutputProofSecrets(op: PreparedOrLaterOperation): string[] {
  const { keepSecrets, sendSecrets } = getSecretsFromSerializedOutputData(op.outputData);
  return [...keepSecrets, ...sendSecrets];
}

// ============================================================================
// Factory Function
// ============================================================================

/**
 * Creates a new ReceiveOperation in init state
 */
export function createReceiveOperation(
  id: string,
  mintUrl: string,
  intent: UnitAmount,
  inputProofs: Proof[],
  source?: ReceiveOperationSource,
  callerSuppliedId = false,
): InitReceiveOperation {
  const now = Date.now();
  const amount = normalizeUnitAmount(intent);
  return {
    id,
    state: 'init',
    mintUrl,
    unit: amount.unit,
    amount: amount.amount,
    inputProofs,
    source,
    ...(callerSuppliedId ? { callerSuppliedId: true } : {}),
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Canonical lifecycle intent used before persistence and for every retry/restart comparison.
 * `p2pk_e`, DLEQ material, and a caller-provided witness are transport/preparation fields: Coco
 * verifies them during the first preparation, creates its own durable P2PK witness, and never lets
 * a retry replace that witness. The exact value-bearing proof identity and NUT-11 condition remain
 * bound by id/amount/secret/C, with the condition encoded in `secret`.
 */
export function canonicalReceiveIntent(operation: ReceiveOperation): string {
  const proofs = operation.inputProofs
    .map((proof) => ({
      id: proof.id,
      amount: Amount.from(proof.amount).toString(),
      secret: proof.secret,
      C: proof.C,
    }))
    .sort((left, right) => {
      const secret = left.secret.localeCompare(right.secret);
      return (
        secret ||
        left.id.localeCompare(right.id) ||
        left.C.localeCompare(right.C) ||
        left.amount.localeCompare(right.amount)
      );
    });
  const source =
    operation.source?.type === 'payment-request'
      ? {
          type: operation.source.type,
          requestOperationId: operation.source.requestOperationId,
          requestId: operation.source.requestId ?? null,
          attemptId: operation.source.attemptId,
          transport: operation.source.transport,
          transportMessageId: operation.source.transportMessageId ?? null,
          senderPubkey: operation.source.senderPubkey ?? null,
          memo: operation.source.memo ?? null,
        }
      : operation.source?.type === 'manual-token'
        ? { type: operation.source.type }
        : null;
  return JSON.stringify({
    mintUrl: normalizeMintUrl(operation.mintUrl),
    unit: normalizeUnit(operation.unit),
    amount: operation.amount.toString(),
    proofs,
    source,
  });
}

export function isSameReceiveIntent(
  existing: ReceiveOperation,
  candidate: InitReceiveOperation,
): boolean {
  return canonicalReceiveIntent(existing) === canonicalReceiveIntent(candidate);
}
