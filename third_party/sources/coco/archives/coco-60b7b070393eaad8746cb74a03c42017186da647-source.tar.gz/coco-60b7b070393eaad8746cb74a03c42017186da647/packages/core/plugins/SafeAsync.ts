const NativePromise = Promise;
const nativePromiseResolve = Promise.resolve;
const nativePromiseThen = Promise.prototype.then;
const nativeReflectApply = Reflect.apply;
const nativeSetTimeout = globalThis.setTimeout;
const nativeClearTimeout = globalThis.clearTimeout;

function applyIntrinsic<T>(fn: Function, receiver: unknown, args: readonly unknown[]): T {
  return nativeReflectApply(fn, receiver, args) as T;
}

/** Assimilate native, foreign, and hostile thenables through intrinsics captured before plugins run. */
export function resolveSafely<T>(value: T | PromiseLike<T>): Promise<T> {
  return applyIntrinsic<Promise<T>>(nativePromiseResolve, NativePromise, [value]);
}

export function rejectSafely(reason: unknown): Promise<never> {
  return new NativePromise<never>((_resolve, reject) => reject(reason));
}

export function createSafePromise<T>(
  executor: (
    resolve: (value: T | PromiseLike<T>) => void,
    reject: (reason?: unknown) => void,
  ) => void,
): Promise<T> {
  return new NativePromise<T>(executor);
}

/** Attach handlers without consulting a possibly plugin-modified Promise prototype. */
export function thenSafely<T, TResult1 = T, TResult2 = never>(
  promise: Promise<T>,
  onFulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | null,
  onRejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null,
): Promise<TResult1 | TResult2> {
  return applyIntrinsic<Promise<TResult1 | TResult2>>(nativePromiseThen, promise, [
    onFulfilled,
    onRejected,
  ]);
}

export class LifecycleDeadlineError extends Error {
  constructor(
    readonly stage: string,
    readonly timeoutMs: number,
  ) {
    super(`${stage} exceeded the ${timeoutMs}ms lifecycle deadline`);
    this.name = 'LifecycleDeadlineError';
  }
}

/**
 * Wait for work through captured Promise/timer intrinsics, rejecting at a deterministic bound.
 * The abandoned work retains terminal handlers so a later rejection cannot become unhandled.
 */
export function settleWithin<T>(
  work: T | PromiseLike<T>,
  timeoutMs: number,
  stage: string,
): Promise<T> {
  const pending = resolveSafely(work);
  return new NativePromise<T>((resolve, reject) => {
    let settled = false;
    const timer = nativeSetTimeout(() => {
      if (settled) return;
      settled = true;
      reject(new LifecycleDeadlineError(stage, timeoutMs));
    }, timeoutMs);

    void thenSafely(
      pending,
      (value) => {
        if (settled) return value;
        settled = true;
        nativeClearTimeout(timer);
        resolve(value);
        return value;
      },
      (error) => {
        if (settled) return undefined as never;
        settled = true;
        nativeClearTimeout(timer);
        reject(error);
        return undefined as never;
      },
    );
  });
}

/** Attach an inert terminal rejection handler to work that may outlive its caller. */
export function observeAbandoned(work: unknown): void {
  if (work === null || (typeof work !== 'object' && typeof work !== 'function')) return;
  let pending: Promise<unknown>;
  try {
    pending = resolveSafely(work as PromiseLike<unknown>);
  } catch {
    return;
  }
  void thenSafely(
    pending,
    () => undefined,
    () => undefined,
  );
}
