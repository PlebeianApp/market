import type { AuthSession } from '@core/models/AuthSession';
import type { AuthSessionRepository } from '..';
import {
  createMemoryMap,
  memoryMapDelete,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryAuthSessionRepository implements AuthSessionRepository {
  private sessions = createMemoryMap<string, AuthSession>();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryAuthSessionRepository): void {
    this.sessions = cloneMemoryRepositoryStateValue(source.sessions);
  }

  async getSession(mintUrl: string): Promise<AuthSession | null> {
    const session = memoryMapGet(this.sessions, mintUrl);
    return session ? cloneMemoryValue(session) : null;
  }

  async saveSession(session: AuthSession): Promise<void> {
    memoryMapSet(this.sessions, session.mintUrl, cloneMemoryValue(session));
  }

  async deleteSession(mintUrl: string): Promise<void> {
    memoryMapDelete(this.sessions, mintUrl);
  }

  async getAllSessions(): Promise<AuthSession[]> {
    const sessions = memoryMapValues(this.sessions);
    for (let index = 0; index < sessions.length; index += 1) {
      sessions[index] = cloneMemoryValue(sessions[index]!);
    }
    return sessions;
  }
}
