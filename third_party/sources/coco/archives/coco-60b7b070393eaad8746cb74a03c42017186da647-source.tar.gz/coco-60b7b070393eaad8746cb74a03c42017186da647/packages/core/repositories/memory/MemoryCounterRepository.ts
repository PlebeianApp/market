import type { Counter } from '../../models/Counter';
import type { CounterRepository } from '..';
import { createMemoryMap, memoryMapGet, memoryMapSet } from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

export class MemoryCounterRepository implements CounterRepository {
  private counters: Map<string, Counter> = createMemoryMap();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryCounterRepository): void {
    this.counters = cloneMemoryRepositoryStateValue(source.counters);
  }

  private key(mintUrl: string, keysetId: string): string {
    return `${mintUrl}::${keysetId}`;
  }

  async getCounter(mintUrl: string, keysetId: string): Promise<Counter | null> {
    const counter = memoryMapGet(this.counters, this.key(mintUrl, keysetId));
    return counter ? cloneMemoryValue(counter) : null;
  }

  async setCounter(mintUrl: string, keysetId: string, counter: number): Promise<void> {
    const key = this.key(mintUrl, keysetId);
    memoryMapSet(this.counters, key, { mintUrl, keysetId, counter });
  }
}
