import { describe, expect, test } from 'bun:test';

const CORE_ROOT = '/home/maximoto/dev/coco-market-prod-2026-09-21/packages/core';
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

async function probe(label: string, modulePath: string): Promise<void> {
  const core: any = await import(modulePath);
  const first = Object.freeze({ owner: 'first' });
  let coercions = 0;
  const rejected: string[] = [];
  const coercible = new Proxy(
    {
      toString() {
        coercions += 1;
        return 'owned-extension';
      },
      valueOf() {
        coercions += 1;
        return 'owned-extension';
      },
      [Symbol.toPrimitive]() {
        coercions += 1;
        return 'owned-extension';
      },
    },
    {
      get(target, key, receiver) {
        if (key === 'toString' || key === 'valueOf' || key === Symbol.toPrimitive) coercions += 1;
        return Reflect.get(target, key, receiver);
      },
    },
  );

  const manager = await core.initializeCoco({
    repo: new core.MemoryRepositories(),
    seedGetter: async () => new Uint8Array(64),
    plugins: [
      {
        name: `extension-integrity-${label}`,
        onInit(context: any) {
          context.registerExtension('owned-extension', first);
          context.registerExtension('__proto__', Object.freeze({ key: '__proto__' }));
          context.registerExtension('prototype', Object.freeze({ key: 'prototype' }));
          context.registerExtension('constructor', Object.freeze({ key: 'constructor' }));
          context.registerExtension('雪-🧊', Object.freeze({ key: 'unicode' }));
          for (const [name, key] of [
            ['object', coercible],
            ['symbol', Symbol('hidden')],
            ['boxed', new String('boxed')],
            ['empty', ''],
            ['long', 'x'.repeat(129)],
          ] as const) {
            try {
              context.registerExtension(key as any, Object.freeze({ owner: 'attacker' }));
            } catch {
              rejected.push(name);
            }
          }
          try {
            context.registerExtension('owned-extension', Object.freeze({ owner: 'second' }));
          } catch {
            rejected.push('duplicate');
          }
        },
      },
    ],
    ...disabledRuntime,
  });

  try {
    expect(coercions).toBe(0);
    expect(rejected.sort()).toEqual(['boxed', 'duplicate', 'empty', 'long', 'object', 'symbol']);
    expect(manager.ext['owned-extension']).toBe(first);
    expect(manager.ext['__proto__']).toEqual({ key: '__proto__' });
    expect(manager.ext.prototype).toEqual({ key: 'prototype' });
    expect(manager.ext.constructor).toEqual({ key: 'constructor' });
    expect(manager.ext['雪-🧊']).toEqual({ key: 'unicode' });
    expect(Object.getOwnPropertySymbols(manager.ext)).toEqual([]);
    expect(Object.getPrototypeOf(manager.ext)).toBeNull();
  } finally {
    await manager.dispose();
  }
}

for (const [label, modulePath] of [
  ['source', `${CORE_ROOT}/index.ts`],
  ['dist', `${CORE_ROOT}/dist/index.js`],
] as const) {
  describe(`round-seven extension key integrity (${label})`, () => {
    test('accepts only bounded primitive strings without coercion and preserves first ownership', () =>
      probe(label, modulePath));
  });
}
