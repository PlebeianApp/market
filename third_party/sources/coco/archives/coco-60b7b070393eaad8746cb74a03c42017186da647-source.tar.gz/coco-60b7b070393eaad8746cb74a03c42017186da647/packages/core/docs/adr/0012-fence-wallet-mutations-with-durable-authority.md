---
status: accepted
---

# Fence Wallet mutations with durable authority

Each physical Wallet store has one stable namespace and one durable authority row. A Coco Session
acquires that authority with a runtime owner ID. Acquisition atomically advances a positive,
never-reused generation and marks it active; the returned namespace, owner ID, and generation form
the Session's capability. Reusing an owner ID does not reuse its generation.

Every Wallet mutation performed by Coco passes through the adapter's strong transaction gateway.
The adapter compares the stored active authority with the caller's complete capability inside the
same database transaction as the mutation, both before invoking the callback and before commit.
Root repository mutation methods are routed through that gateway too. Reads remain available to a
stale Session so it can report state, but initialized stale, released, and unacquired repository
roots cannot write, even before the first authority is acquired.

Repository dispatch is deny-by-default. Only methods listed in the reviewed read-only manifest may
execute as reads. Explicit mutators and any unknown callable route through the authority-fenced
transaction gateway. Prototype-to-manifest tests cover the source Memory implementation and emitted
package so adding a public repository method cannot silently create an unfenced write surface.

Authority acquisition participates in the same writer serialization as Wallet transactions.
SQLite uses an immediate transaction and IndexedDB includes the authority object store in each
read-write transaction. In-memory repositories use the same serialized backend used by their
transaction snapshots. A stale release compares the complete capability and cannot clear a newer
owner.

The authority row also binds the physical store to its first namespace. A different namespace is
an environment error, not a second independent lock over the same money.

## Remote effects and startup

The fence cannot retract a request already sent to a mint. Coordinators therefore persist an Exact
Operation Request before remote I/O and apply a response only through a fenced transaction. If
authority transfers while a request is in flight, the stale Session cannot apply the response; the
new owner recovers the same durable request.

`initializeCoco()` opens storage, validates and acquires authority (or verifies the exact active
capability already held by the supplied root), performs legacy reconciliation
and Send, Melt, Receive, Payment Request Receive, and Mint recovery, and marks quiescent recovery
complete. Only then are plugin `onInit` and `onReady` hooks given mutation-capable services;
Background Watchers and processors start after the hooks. Startup failure releases only the exact
capability acquired by that attempt.

Only module-lexical factory functions can create an authority-owning Manager, run required recovery,
and change its ECMAScript-private activation state. There is no public boot capability, constructor
argument, reflected field, or recovery-completion method. Direct `Manager` construction cannot
activate plugins, subscriptions, watchers, or processors. Disposal
calls a plugin hook only if that plugin's initialization actually began, and runs cleanup functions
only when a hook registered them.

A separate Manager-owned, ECMAScript-private lifecycle authority gates every plugin capability, the
public subscription facade, and every method in the complete nested Manager API graph. It is
activated only after private recovery completes and is
irreversibly revoked synchronously before disposal can yield or resource teardown begins. In-flight
calls assimilate foreign thenables through captured promise intrinsics and drain only to a configured
deadline; retained calls and every public API, diagnostics, background, and recovery start reject
after revocation. Cleanup-only unsubscribe/off handles remain idempotent and cannot recreate
authority. Transports and autonomous callback producers stop before the bounded drain, while
deadline expiry cannot prevent later cleanup attempts or final durable authority release. Extension
registration is hook-scoped, accepts only bounded primitive-string keys without coercion, and uses
null-prototype own-key ownership to preserve the first registration.

The Manager API boundary captures a static allowlist of original exported API prototype methods at
trusted module evaluation. Frozen null-prototype facades invoke only those captured functions via a
captured intrinsic; they never resolve a method from the private API receiver at call time. Nested
own recovery/diagnostic functions are captured through own data descriptors during construction.
Post-import prototype poisoning therefore cannot obtain a raw API receiver or redirect dispatch.

Required service recovery is registered as private closures during trusted construction and invoked
directly from native-private Manager state. Public prototype replacement and post-import mutation of
`Function.prototype.call`, `apply`, `bind`, or `Reflect.apply` cannot intercept it. The same-realm
pre-import intrinsic/source attacker is outside the runtime authority boundary; publishable package
exports provide no equivalent recovery task or activation handle.

## Consequences

`Repositories` implementations must implement root-owned synchronous Session attachment, durable
authority acquisition, exact release, local capability inspection, and atomic comparison at
`withTransaction`. This is a breaking contract for custom adapters. A repository root is single-use
after acquiring or releasing authority; create a new root for a later Session.

Adopting an already-active capability is also a single-consumption attachment for the exact supplied
root object. Every repository root implements an immutable synchronous claim/release pair over
root-owned private closure state and returns an opaque identity token. The factory claims the root
before storage initialization, transfers the token to exactly one Manager, rolls the claim back
after confirmed startup cleanup, and removes it only after exact authority release succeeds. An
unconfirmed or stale release preserves the attachment. Because no Core-module registry owns this
state, independently evaluated source, emitted, or packed copies cannot share the same root and
capability. Bound and transparent delegating wrappers reach the same root closure. A separately
constructed peer root still acquires a new durable generation and fences the prior owner through the
adapter authority protocol.

Schema setup and migration run as part of `init()` before repository mutation APIs become usable.
After initialization, all repository mutations require an acquired capability. Direct access to a
concrete adapter's raw database is outside the Coco repository contract and must not be used for
Wallet mutations.

The published IndexedDB adapter does not expose its internally opened database, schema helper, or
concrete repository constructors. SQLite adapters necessarily receive an already-open database from
the embedding application; that caller-owned handle remains outside Coco's authority boundary, and
the adapter leaks no additional internal handle. Manager and public API dependency state uses native
private fields. The plugin service map excludes raw seed and low-level wallet access even for trusted
plugins.

Plugin service-map entries are capability names, not concrete service identities. Static factories
create a new frozen null-prototype facade for each hook from an explicit reviewed method manifest;
they never enumerate or copy an implementation prototype. Contexts and selected-service maps are
also frozen, Core event access is subscribe-only, and returned objects, callback payloads, and errors
are sanitized before delivery. Consequently, concrete services, repositories, runners, publishers,
transports, loggers, and low-level Wallet objects cannot be recovered by reflecting through a
supported plugin key. Adding an internal method does not expand plugin authority.

The plugin value boundary never freezes and returns a Core-owned class instance. Explicit adapters
reconstruct supported domain values and web responses into detached plugin-side values; typed
buffers are copied, arrays and records are recursively detached, and unsupported class instances,
accessors, symbols, mutable collections, functions, or privileged identities fail closed. Adapters
use captured intrinsics plus own data descriptors and indexed copies, never dispatching a Core-owned
value through plugin-modifiable methods, getters, iterators, constructors, or prototypes. Callable
detached values are independently lifecycle-fenced.

Repository surfaces use frozen null-prototype facades, not transparent proxies. Only statically
classified own wrapper functions exist on those facades, implementation access never evaluates a
getter, and transaction wrappers are revoked after callback completion. This makes prototype,
descriptor, accessor, alias, and captured-method reflection incapable of recovering a mutable
repository implementation.

Concrete Memory repositories and their transaction backend use constructors, prototype methods,
iterator steps, and Promise resolution captured during trusted module evaluation for every private
Map, Set, byte buffer, snapshot, and serialization queue operation. Post-import constructor or
prototype replacement cannot observe a backing collection or prematurely resolve transaction
serialization. Stored inputs and returned values are detached, so collection safety does not depend
on callers preserving object identity or prototype integrity. The Memory adapter validates every
repository argument through an inert-value codec before concrete method dispatch. The codec reads
only captured own data descriptors, reconstructs the approved Amount/Date/byte brands, normalizes
records to null prototypes, and rejects accessors, functions, proxies/non-cloneable graphs, symbols,
caller prototypes, nested collections, cycles, sparse arrays, and unexpected branded fields. Backing Map/Set snapshot cloning
is intentionally separate and never accepts public persisted payloads.

Deterministic adapter contracts pause a simulated remote response immediately before its commit,
transfer authority, and assert that the stale callback never runs and that no proof, operation,
key, or counter changes. They also cover new-owner reconciliation, same-owner ABA, namespace
binding, stale release, and two independent roots over each supported physical store.

[Transaction Design](../../../../TRANSACTION_DESIGN.md) remains the authoritative implementation
contract. ADR-0011 defines domain transaction ownership; this decision adds the capability check at
the shared adapter commit boundary beneath those gateways.
