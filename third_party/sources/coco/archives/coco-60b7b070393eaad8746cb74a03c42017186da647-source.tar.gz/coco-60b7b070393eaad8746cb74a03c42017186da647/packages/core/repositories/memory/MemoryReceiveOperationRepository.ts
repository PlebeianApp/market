import type { ReceiveOperationRepository } from '..';
import type {
  ReceiveOperation,
  ReceiveOperationState,
} from '../../operations/receive/ReceiveOperation';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapDelete,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';
import { MemoryOperationIdOwnership } from '../OperationIdOwnership.ts';

export class MemoryReceiveOperationRepository implements ReceiveOperationRepository {
  private operations = createMemoryMap<string, ReceiveOperation>();

  constructor(private readonly operationIds = new MemoryOperationIdOwnership()) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryReceiveOperationRepository): void {
    this.operations = cloneMemoryRepositoryStateValue(source.operations);
    this.operationIds.copyFrom(source.operationIds);
  }

  async create(operation: ReceiveOperation): Promise<void> {
    if (memoryMapHas(this.operations, operation.id)) {
      throw new Error(`ReceiveOperation with id ${operation.id} already exists`);
    }
    this.operationIds.claim(operation.id, 'receive');
    memoryMapSet(
      this.operations,
      operation.id,
      cloneMemoryValue({ ...operation, revision: operation.revision ?? 0 }),
    );
  }

  async update(operation: ReceiveOperation): Promise<void> {
    if (!memoryMapHas(this.operations, operation.id)) {
      throw new Error(`ReceiveOperation with id ${operation.id} not found`);
    }
    memoryMapSet(
      this.operations,
      operation.id,
      cloneMemoryValue({ ...operation, revision: operation.revision ?? 0, updatedAt: Date.now() }),
    );
  }

  async transition(
    input: Parameters<ReceiveOperationRepository['transition']>[0],
  ): Promise<boolean> {
    const current = memoryMapGet(this.operations, input.operationId);
    if (
      !current ||
      current.state !== input.expectedState ||
      (current.revision ?? 0) !== input.expectedRevision
    )
      return false;
    if (input.next.id !== input.operationId)
      throw new Error('Receive operation transition cannot change the operation id');
    memoryMapSet(
      this.operations,
      input.operationId,
      cloneMemoryValue({ ...input.next, revision: input.expectedRevision + 1 }),
    );
    return true;
  }

  async getById(id: string): Promise<ReceiveOperation | null> {
    const op = memoryMapGet(this.operations, id);
    return op ? cloneMemoryValue(op) : null;
  }

  async getByState(state: ReceiveOperationState): Promise<ReceiveOperation[]> {
    const results: ReceiveOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.state === state) {
        memoryArrayPush(results, cloneMemoryValue(op));
      }
    }
    return results;
  }

  async getPending(): Promise<ReceiveOperation[]> {
    const results: ReceiveOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.state === 'executing') {
        memoryArrayPush(results, cloneMemoryValue(op));
      }
    }
    return results;
  }

  async getByMintUrl(mintUrl: string): Promise<ReceiveOperation[]> {
    const results: ReceiveOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.mintUrl === mintUrl) {
        memoryArrayPush(results, cloneMemoryValue(op));
      }
    }
    return results;
  }

  async getByPaymentRequestAttemptId(attemptId: string): Promise<ReceiveOperation | null> {
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.source?.type === 'payment-request' && op.source.attemptId === attemptId) {
        return cloneMemoryValue(op);
      }
    }
    return null;
  }

  async getAll(): Promise<ReceiveOperation[]> {
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      operations[index] = cloneMemoryValue({
        ...operation,
        revision: operation.revision ?? 0,
      });
    }
    return operations;
  }

  async delete(id: string): Promise<void> {
    memoryMapDelete(this.operations, id);
  }
}
