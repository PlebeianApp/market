import type { KeypairPurpose } from './Keypair.ts';

export { HttpResponseError, MintOperationError, NetworkError } from '@cashu/cashu-ts';

export class UnknownMintError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UnknownMintError';
  }
}

export class MintFetchError extends Error {
  readonly mintUrl: string;
  constructor(mintUrl: string, message?: string, cause?: unknown) {
    super(message ?? `Failed to fetch mint ${mintUrl}`);
    this.name = 'MintFetchError';
    this.mintUrl = mintUrl;
    // Assign cause in a backwards compatible way without relying on ErrorOptions
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

export class KeysetSyncError extends Error {
  readonly mintUrl: string;
  readonly keysetId: string;
  constructor(mintUrl: string, keysetId: string, message?: string, cause?: unknown) {
    super(message ?? `Failed to sync keyset ${keysetId} for mint ${mintUrl}`);
    this.name = 'KeysetSyncError';
    this.mintUrl = mintUrl;
    this.keysetId = keysetId;
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

export class ProofValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ProofValidationError';
  }
}

export class MintQuoteValidationError extends Error {
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = 'MintQuoteValidationError';
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

export class MintQuoteKeyError extends Error {
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = 'MintQuoteKeyError';
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

export class DerivationIndexExhaustedError extends Error {
  readonly purpose: KeypairPurpose;

  constructor(purpose: KeypairPurpose) {
    super(`No derivation indexes remain for keypair purpose ${purpose}`);
    this.name = 'DerivationIndexExhaustedError';
    this.purpose = purpose;
  }
}

export class UnitValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UnitValidationError';
  }
}

export class UnitMismatchError extends UnitValidationError {
  constructor(message: string) {
    super(message);
    this.name = 'UnitMismatchError';
  }
}

export class TokenValidationError extends Error {
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = 'TokenValidationError';
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

export class ProofOperationError extends Error {
  readonly mintUrl: string;
  readonly keysetId?: string;
  constructor(mintUrl: string, message?: string, keysetId?: string, cause?: unknown) {
    super(
      message ??
        `Proof operation failed for mint ${mintUrl}${keysetId ? ` keyset ${keysetId}` : ''}`,
    );
    this.name = 'ProofOperationError';
    this.mintUrl = mintUrl;
    this.keysetId = keysetId;
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

/**
 * This error is thrown when a payment request is invalid or cannot be processed.
 */
export class PaymentRequestError extends Error {
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = 'PaymentRequestError';
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

/**
 * This error is thrown when attempting to modify an operation that is already in progress.
 */
export class OperationInProgressError extends Error {
  readonly operationId: string;
  constructor(operationId: string) {
    super(`Operation ${operationId} is already in progress`);
    this.name = 'OperationInProgressError';
    this.operationId = operationId;
  }
}

export class SendOperationConflictError extends Error {
  readonly operationId: string;

  constructor(operationId: string, message?: string) {
    super(message ?? `Send operation ${operationId} changed concurrently`);
    this.name = 'SendOperationConflictError';
    this.operationId = operationId;
  }
}

export class OperationIdValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'OperationIdValidationError';
  }
}

export class OperationIdConflictError extends Error {
  constructor(
    readonly operationId: string,
    readonly existingOperationType: string,
    message?: string,
  ) {
    super(
      message ??
        `Operation ID ${operationId} is already used by a ${existingOperationType} operation`,
    );
    this.name = 'OperationIdConflictError';
  }
}

export class WalletAuthorityValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WalletAuthorityValidationError';
  }
}

export class WalletAuthorityNotAcquiredError extends Error {
  constructor() {
    super('Wallet mutation requires an acquired durable authority');
    this.name = 'WalletAuthorityNotAcquiredError';
  }
}

export class WalletAuthorityConflictError extends Error {
  constructor(
    readonly namespace: string,
    readonly expectedGeneration: number,
    readonly actualGeneration?: number,
  ) {
    super(
      actualGeneration === undefined
        ? `Wallet authority ${namespace} is no longer active`
        : `Wallet authority ${namespace} generation ${expectedGeneration} was fenced by generation ${actualGeneration}`,
    );
    this.name = 'WalletAuthorityConflictError';
  }
}

export class WalletAuthorityLifecycleError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WalletAuthorityLifecycleError';
  }
}

export class WalletAuthorityGenerationExhaustedError extends Error {
  constructor(readonly namespace: string) {
    super(`Wallet authority generation exhausted for namespace ${namespace}`);
    this.name = 'WalletAuthorityGenerationExhaustedError';
  }
}

export class ReceiveOperationConflictError extends Error {
  constructor(
    readonly operationId: string,
    message?: string,
  ) {
    super(message ?? `Receive operation ${operationId} changed concurrently`);
    this.name = 'ReceiveOperationConflictError';
  }
}

/**
 * This error is thrown when a caller-supplied Send operation ID is already bound to a different
 * intent, so the ID cannot be joined as a duplicate of the existing operation.
 */
export class SendOperationIntentConflictError extends SendOperationConflictError {
  constructor(operationId: string, message?: string) {
    super(operationId, message ?? `Send operation ${operationId} has a different intent`);
    this.name = 'SendOperationIntentConflictError';
  }
}

export class AuthSessionError extends Error {
  readonly mintUrl: string;
  constructor(mintUrl: string, message?: string, cause?: unknown) {
    super(message ?? `Auth session error for mint ${mintUrl}`);
    this.name = 'AuthSessionError';
    this.mintUrl = mintUrl;
    (this as unknown as { cause?: unknown }).cause = cause;
  }
}

export class AuthSessionExpiredError extends AuthSessionError {
  constructor(mintUrl: string) {
    super(mintUrl, `Auth session expired for mint ${mintUrl}`);
    this.name = `AuthSessionExpiredError`;
  }
}

export class QuoteIdentityConflictError extends Error {
  readonly kind: 'mint' | 'melt';
  readonly mintUrl: string;
  readonly quoteId: string;
  readonly methods: readonly string[];

  constructor(
    kind: 'mint' | 'melt',
    mintUrl: string,
    quoteId: string,
    methods: readonly string[],
    message?: string,
  ) {
    super(
      message ??
        `${kind} quote identity conflict for quote ${quoteId} at ${mintUrl}: methods ${methods.join(', ')}`,
    );
    this.name = 'QuoteIdentityConflictError';
    this.kind = kind;
    this.mintUrl = mintUrl;
    this.quoteId = quoteId;
    this.methods = [...methods];
  }
}
