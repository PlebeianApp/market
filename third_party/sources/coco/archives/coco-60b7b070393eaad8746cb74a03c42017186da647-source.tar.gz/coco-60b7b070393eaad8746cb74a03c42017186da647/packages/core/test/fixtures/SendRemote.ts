import { mock } from 'bun:test';
import {
  validateProofStateResponse,
  type SendRemote,
  type SendRemoteSession,
} from '../../operations/send/SendRemote.ts';

/** In-memory protocol boundary; persistence stays in the real transaction runner. */
export function createSendRemoteDouble() {
  const checkProofStates = mock<SendRemoteSession['checkProofStates']>(async () => []);
  const session = {
    swap: mock<SendRemoteSession['swap']>(async () => ({ send: [], keep: [] })),
    checkProofStates,
    observeReclaimInputStates: mock<SendRemoteSession['observeReclaimInputStates']>(
      async (proofs) => {
        try {
          return validateProofStateResponse(proofs, await checkProofStates(proofs));
        } catch {
          return { status: 'inconclusive', reason: 'unavailable' };
        }
      },
    ),
    restoreOutputs: mock<SendRemoteSession['restoreOutputs']>(async () => []),
    observeReclaimOutputs: mock<SendRemoteSession['observeReclaimOutputs']>(async () => ({
      status: 'none',
    })),
    reclaim: mock<SendRemoteSession['reclaim']>(async () => []),
  };
  return {
    ...session,
    open: mock<SendRemote['open']>(() => session),
  };
}
