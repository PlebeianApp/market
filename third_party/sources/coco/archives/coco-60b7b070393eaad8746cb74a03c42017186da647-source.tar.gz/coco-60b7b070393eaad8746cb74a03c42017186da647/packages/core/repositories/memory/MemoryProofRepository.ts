import type { ProofRepository, ProofUnitFilter } from '..';
import type { CoreProof, ProofState } from '../../types';
import { normalizeUnit } from '../../amounts.ts';
import {
  createMemoryMap,
  createMemorySet,
  memoryArrayPush,
  memoryMapDelete,
  memoryMapEntries,
  memoryMapGet,
  memoryMapSet,
  memoryMapValues,
  memorySetAdd,
  memorySetHas,
  memorySetValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';

function normalizeProofUnit(proof: CoreProof): string {
  return normalizeUnit((proof as { unit?: string }).unit);
}

function getUnitFilter(filter?: ProofUnitFilter): Set<string> | undefined {
  const units = createMemorySet<string>();
  const listedUnits = filter?.units;
  if (listedUnits) {
    for (let index = 0; index < listedUnits.length; index += 1) {
      memorySetAdd(units, normalizeUnit(listedUnits[index]!));
    }
  }
  if (filter?.unit) memorySetAdd(units, normalizeUnit(filter.unit));
  return memorySetValues(units).length === 0 ? undefined : units;
}

function matchesUnit(proof: CoreProof, unitFilter?: Set<string>): boolean {
  return !unitFilter || memorySetHas(unitFilter, normalizeProofUnit(proof));
}

export class MemoryProofRepository implements ProofRepository {
  private proofsByMint: Map<string, Map<string, CoreProof>> = createMemoryMap();

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryProofRepository): void {
    this.proofsByMint = cloneMemoryRepositoryStateValue(source.proofsByMint);
  }

  #findMintMap(mintUrl: string): Map<string, CoreProof> | undefined {
    return memoryMapGet(this.proofsByMint, mintUrl);
  }

  #getOrCreateMintMap(mintUrl: string): Map<string, CoreProof> {
    const existing = this.#findMintMap(mintUrl);
    if (existing) return existing;
    const created = createMemoryMap<string, CoreProof>();
    memoryMapSet(this.proofsByMint, mintUrl, created);
    return created;
  }

  async saveProofs(mintUrl: string, proofs: CoreProof[]): Promise<void> {
    if (!proofs || proofs.length === 0) return;
    const map = this.#getOrCreateMintMap(mintUrl);
    const normalizedProofs: CoreProof[] = [];
    for (let index = 0; index < proofs.length; index += 1) {
      const proof = proofs[index]!;
      memoryArrayPush(normalizedProofs, {
        ...cloneMemoryValue(proof),
        unit: normalizeProofUnit(proof),
      });
    }
    // Pre-check for any collisions and fail atomically.
    for (let index = 0; index < normalizedProofs.length; index += 1) {
      const proof = normalizedProofs[index]!;
      if (memoryMapGet(map, proof.secret)) {
        throw new Error(`Proof with secret already exists: ${proof.secret}`);
      }
    }
    for (let index = 0; index < normalizedProofs.length; index += 1) {
      const proof = normalizedProofs[index]!;
      memoryMapSet(map, proof.secret, cloneMemoryValue({ ...proof, mintUrl }));
    }
  }

  async getReadyProofs(mintUrl: string, filter?: ProofUnitFilter): Promise<CoreProof[]> {
    const unitFilter = getUnitFilter(filter);
    return this.#collectProofs(this.#findMintMap(mintUrl), (proof) => {
      return proof.state === 'ready' && matchesUnit(proof, unitFilter);
    });
  }

  async getInflightProofs(mintUrls?: string[], filter?: ProofUnitFilter): Promise<CoreProof[]> {
    const unitFilter = getUnitFilter(filter);
    const results: CoreProof[] = [];
    if (!mintUrls || mintUrls.length === 0) {
      const mintMaps = memoryMapValues(this.proofsByMint);
      for (let index = 0; index < mintMaps.length; index += 1) {
        this.#appendMatchingProofs(mintMaps[index]!, results, (proof) => {
          return proof.state === 'inflight' && matchesUnit(proof, unitFilter);
        });
      }
      return results;
    }

    const uniqueMintUrls = createMemorySet<string>();
    for (let index = 0; index < mintUrls.length; index += 1) {
      const mintUrl = mintUrls[index]!.trim();
      if (mintUrl.length > 0) memorySetAdd(uniqueMintUrls, mintUrl);
    }
    const listedMintUrls = memorySetValues(uniqueMintUrls);
    for (let index = 0; index < listedMintUrls.length; index += 1) {
      const map = this.#findMintMap(listedMintUrls[index]!);
      this.#appendMatchingProofs(map, results, (proof) => {
        return proof.state === 'inflight' && matchesUnit(proof, unitFilter);
      });
    }
    return results;
  }

  async getAllReadyProofs(filter?: ProofUnitFilter): Promise<CoreProof[]> {
    const unitFilter = getUnitFilter(filter);
    const results: CoreProof[] = [];
    const mintMaps = memoryMapValues(this.proofsByMint);
    for (let index = 0; index < mintMaps.length; index += 1) {
      this.#appendMatchingProofs(mintMaps[index]!, results, (proof) => {
        return proof.state === 'ready' && matchesUnit(proof, unitFilter);
      });
    }
    return results;
  }

  async getProofsByKeysetId(
    mintUrl: string,
    keysetId: string,
    filter?: ProofUnitFilter,
  ): Promise<CoreProof[]> {
    const unitFilter = getUnitFilter(filter);
    return this.#collectProofs(this.#findMintMap(mintUrl), (proof) => {
      return proof.state === 'ready' && proof.id === keysetId && matchesUnit(proof, unitFilter);
    });
  }

  async setProofState(mintUrl: string, secrets: string[], state: ProofState): Promise<void> {
    const map = this.#findMintMap(mintUrl);
    if (!map) return;
    for (let index = 0; index < secrets.length; index += 1) {
      const secret = secrets[index]!;
      const proof = memoryMapGet(map, secret);
      if (proof) memoryMapSet(map, secret, cloneMemoryValue({ ...proof, state }));
    }
  }

  async deleteProofs(mintUrl: string, secrets: string[]): Promise<void> {
    const map = this.#findMintMap(mintUrl);
    if (!map) return;
    for (let index = 0; index < secrets.length; index += 1) {
      memoryMapDelete(map, secrets[index]!);
    }
  }

  async wipeProofsByKeysetId(mintUrl: string, keysetId: string): Promise<void> {
    const map = this.#findMintMap(mintUrl);
    if (!map) return;
    const entries = memoryMapEntries(map);
    for (let index = 0; index < entries.length; index += 1) {
      const entry = entries[index]!;
      if (entry[1].id === keysetId) memoryMapDelete(map, entry[0]);
    }
  }

  async reserveProofs(mintUrl: string, secrets: string[], operationId: string): Promise<void> {
    const map = this.#findMintMap(mintUrl);
    // Pre-check: all proofs must exist, be ready, and not already reserved.
    for (let index = 0; index < secrets.length; index += 1) {
      const secret = secrets[index]!;
      const proof = map ? memoryMapGet(map, secret) : undefined;
      if (!proof) throw new Error(`Proof with secret not found: ${secret}`);
      if (proof.state !== 'ready') throw new Error(`Proof is not ready, cannot reserve: ${secret}`);
      if (proof.usedByOperationId) {
        throw new Error(
          `Proof already reserved by operation ${proof.usedByOperationId}: ${secret}`,
        );
      }
    }
    if (!map) return;
    for (let index = 0; index < secrets.length; index += 1) {
      const secret = secrets[index]!;
      const proof = memoryMapGet(map, secret)!;
      memoryMapSet(map, secret, cloneMemoryValue({ ...proof, usedByOperationId: operationId }));
    }
  }

  async releaseProofs(mintUrl: string, secrets: string[]): Promise<void> {
    const map = this.#findMintMap(mintUrl);
    if (!map) return;
    for (let index = 0; index < secrets.length; index += 1) {
      const secret = secrets[index]!;
      const proof = memoryMapGet(map, secret);
      if (proof) {
        const { usedByOperationId: _, ...rest } = proof;
        memoryMapSet(map, secret, cloneMemoryValue(rest as CoreProof));
      }
    }
  }

  async setCreatedByOperation(
    mintUrl: string,
    secrets: string[],
    operationId: string,
  ): Promise<void> {
    const map = this.#findMintMap(mintUrl);
    if (!map) return;
    for (let index = 0; index < secrets.length; index += 1) {
      const secret = secrets[index]!;
      const proof = memoryMapGet(map, secret);
      if (proof) {
        memoryMapSet(
          map,
          secret,
          cloneMemoryValue({ ...proof, createdByOperationId: operationId }),
        );
      }
    }
  }

  async getProofBySecret(mintUrl: string, secret: string): Promise<CoreProof | null> {
    const map = this.#findMintMap(mintUrl);
    const proof = map ? memoryMapGet(map, secret) : undefined;
    return proof ? cloneMemoryValue(proof) : null;
  }

  async getProofsBySecrets(mintUrl: string, secrets: string[]): Promise<CoreProof[]> {
    if (!secrets || secrets.length === 0) return [];
    const map = this.#findMintMap(mintUrl);
    if (!map) return [];
    const uniqueSecrets = createMemorySet<string>();
    for (let index = 0; index < secrets.length; index += 1) {
      memorySetAdd(uniqueSecrets, secrets[index]!);
    }
    const listedSecrets = memorySetValues(uniqueSecrets);
    const proofs: CoreProof[] = [];
    for (let index = 0; index < listedSecrets.length; index += 1) {
      const proof = memoryMapGet(map, listedSecrets[index]!);
      if (proof) memoryArrayPush(proofs, cloneMemoryValue(proof));
    }
    return proofs;
  }

  async getProofsByOperationId(mintUrl: string, operationId: string): Promise<CoreProof[]> {
    return this.#collectProofs(this.#findMintMap(mintUrl), (proof) => {
      return proof.usedByOperationId === operationId || proof.createdByOperationId === operationId;
    });
  }

  async getAvailableProofs(mintUrl: string, filter?: ProofUnitFilter): Promise<CoreProof[]> {
    const unitFilter = getUnitFilter(filter);
    return this.#collectProofs(this.#findMintMap(mintUrl), (proof) => {
      return proof.state === 'ready' && !proof.usedByOperationId && matchesUnit(proof, unitFilter);
    });
  }

  async getReservedProofs(): Promise<CoreProof[]> {
    const results: CoreProof[] = [];
    const mintMaps = memoryMapValues(this.proofsByMint);
    for (let index = 0; index < mintMaps.length; index += 1) {
      this.#appendMatchingProofs(mintMaps[index]!, results, (proof) => {
        return proof.state === 'ready' && Boolean(proof.usedByOperationId);
      });
    }
    return results;
  }

  #collectProofs(
    map: Map<string, CoreProof> | undefined,
    predicate: (proof: CoreProof) => boolean,
  ): CoreProof[] {
    const results: CoreProof[] = [];
    this.#appendMatchingProofs(map, results, predicate);
    return results;
  }

  #appendMatchingProofs(
    map: Map<string, CoreProof> | undefined,
    results: CoreProof[],
    predicate: (proof: CoreProof) => boolean,
  ): void {
    if (!map) return;
    const proofs = memoryMapValues(map);
    for (let index = 0; index < proofs.length; index += 1) {
      const proof = proofs[index]!;
      if (predicate(proof)) memoryArrayPush(results, cloneMemoryValue(proof));
    }
  }
}
