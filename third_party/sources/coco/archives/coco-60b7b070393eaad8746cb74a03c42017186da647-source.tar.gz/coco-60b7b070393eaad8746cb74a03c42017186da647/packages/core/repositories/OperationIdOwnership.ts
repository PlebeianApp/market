import { OperationIdConflictError } from '../models/Error.ts';
import {
  copyMemoryMap,
  createMemoryMap,
  memoryMapGet,
  memoryMapSet,
} from './memory/MemoryCollectionIntrinsics.ts';

/** Durable, lifecycle-wide owner classes for globally unique monetary command IDs. */
export type OperationIdOwner =
  | 'send'
  | 'receive'
  | 'mint'
  | 'melt'
  | 'payment-request-receive'
  | 'payment-request-receive-attempt';

/** In-memory equivalent of the adapter ownership table. Claims are never released. */
export class MemoryOperationIdOwnership {
  private owners = createMemoryMap<string, OperationIdOwner>();

  claim(id: string, owner: OperationIdOwner): void {
    const existing = memoryMapGet(this.owners, id);
    if (existing) throw new OperationIdConflictError(id, existing);
    memoryMapSet(this.owners, id, owner);
  }

  copyFrom(source: MemoryOperationIdOwnership): void {
    this.owners = copyMemoryMap(source.owners);
  }
}
