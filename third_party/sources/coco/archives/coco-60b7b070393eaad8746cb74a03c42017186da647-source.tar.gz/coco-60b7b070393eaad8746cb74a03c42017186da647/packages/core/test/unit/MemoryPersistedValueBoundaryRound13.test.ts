import { afterAll, describe, expect, it } from 'bun:test';
import { cp, mkdtemp, rm } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Amount } from '@cashu/cashu-ts';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';

const coreRoot = dirname(dirname(dirname(fileURLToPath(import.meta.url))));
const copiedDirectories = await Promise.all([
  mkdtemp(join(coreRoot, '.round13-packed-a-')),
  mkdtemp(join(coreRoot, '.round13-packed-b-')),
]);
await Promise.all(
  copiedDirectories.map((directory) =>
    cp(join(coreRoot, 'dist'), join(directory, 'dist'), { recursive: true }),
  ),
);

type CoreModule = {
  Amount: typeof Amount;
  MemoryRepositories: new () => any;
};

const dist = (await import(
  `${pathToFileURL(join(coreRoot, 'dist/index.js')).href}?round13-dist`
)) as CoreModule;
const packedA = (await import(
  `${pathToFileURL(join(copiedDirectories[0]!, 'dist/index.js')).href}?round13-pack-a`
)) as CoreModule;
const packedB = (await import(
  `${pathToFileURL(join(copiedDirectories[1]!, 'dist/index.js')).href}?round13-pack-b`
)) as CoreModule;

afterAll(() =>
  Promise.all(
    copiedDirectories.map((directory) => rm(directory, { recursive: true, force: true })),
  ),
);

function unsafeAccessor(onGet: () => void): object {
  const value = Object.create(null);
  Object.defineProperty(value, 'id', {
    enumerable: true,
    get() {
      onGet();
      return 'unsafe';
    },
  });
  return value;
}

function sendOperation(core: CoreModule, id: string, methodData: object = {}) {
  return {
    id,
    state: 'init',
    mintUrl: 'https://round13.invalid',
    amount: core.Amount.from(1),
    unit: 'sat',
    method: 'default',
    methodData,
    createdAt: 1,
    updatedAt: 1,
    revision: 0,
  };
}

function proof(core: CoreModule, secret: string, dleq: object = { e: 'e', s: 's', r: 'r' }) {
  return {
    id: '00round13',
    amount: core.Amount.from(1),
    secret,
    C: '02round13',
    dleq,
    mintUrl: 'https://round13.invalid',
    unit: 'sat',
    state: 'ready',
  };
}

function mintQuote(core: CoreModule, quoteData: object = {}) {
  return {
    mintUrl: 'https://round13.invalid',
    method: 'bolt11',
    quoteId: 'round13-quote',
    quote: 'round13-quote',
    request: 'lnbc1round13',
    amount: core.Amount.from(1),
    unit: 'sat',
    expiry: 1_730_000_000,
    state: 'UNPAID',
    reusable: false,
    amountPaid: core.Amount.zero(),
    amountIssued: core.Amount.zero(),
    remoteUpdatedAt: null,
    quoteData,
    createdAt: 1,
    updatedAt: 1,
  };
}

async function activeRoot(core: CoreModule, suffix: string): Promise<any> {
  const root = new core.MemoryRepositories();
  await root.init();
  await root.acquireAuthority({ namespace: `round13-${suffix}`, ownerId: 'owner-a' });
  return root;
}

function runPersistedValueBoundary(label: string, core: CoreModule): void {
  describe(`${label} strict Memory persisted-value boundary`, () => {
    it('rejects accessors atomically across every repository family without invoking them', async () => {
      const root = await activeRoot(core, `${label}-matrix`);
      let getterCalls = 0;
      const unsafe = unsafeAccessor(() => {
        getterCalls += 1;
      });
      const attempts = [
        () => root.mintRepository.addNewMint(unsafe),
        () => root.keyRingRepository.setPersistedKeyPair(unsafe),
        () => root.counterRepository.setCounter('https://round13.invalid', 'keyset', unsafe),
        () => root.keysetRepository.addKeyset(unsafe),
        () => root.proofRepository.saveProofs('https://round13.invalid', [unsafe]),
        () => root.mintQuoteRepository.upsertMintQuote(unsafe),
        () => root.legacyMintQuoteRepository.upsertMintQuote(unsafe),
        () => root.meltQuoteRepository.upsertMeltQuote(unsafe),
        () => root.historyRepository.addLegacyHistoryEntry(unsafe),
        () => root.sendOperationRepository.create(unsafe),
        () => root.meltOperationRepository.create(unsafe),
        () => root.authSessionRepository.saveSession(unsafe),
        () => root.mintOperationRepository.create(unsafe),
        () => root.receiveOperationRepository.create(unsafe),
        () => root.paymentRequestReceiveOperationRepository.create(unsafe),
        () => root.paymentRequestReceiveAttemptRepository.create(unsafe),
      ];

      for (let index = 0; index < attempts.length; index += 1) {
        await expect(attempts[index]!()).rejects.toThrow('accessor properties are not supported');
      }
      expect(getterCalls).toBe(0);
      expect(await root.mintRepository.getAllMints()).toHaveLength(0);
      expect(await root.keyRingRepository.getAllPersistedKeyPairs()).toHaveLength(0);
      expect(
        await root.counterRepository.getCounter('https://round13.invalid', 'keyset'),
      ).toBeNull();
      expect(
        await root.keysetRepository.getKeysetsByMintUrl('https://round13.invalid'),
      ).toHaveLength(0);
      expect(await root.proofRepository.getAllReadyProofs()).toHaveLength(0);
      expect(await root.mintQuoteRepository.getPendingMintQuotes()).toHaveLength(0);
      expect(await root.legacyMintQuoteRepository.getPendingLegacyMintQuotes()).toHaveLength(0);
      expect(await root.meltQuoteRepository.getPendingMeltQuotes()).toHaveLength(0);
      expect(await root.historyRepository.getPaginatedHistoryEntries(100, 0)).toHaveLength(0);
      expect(await root.sendOperationRepository.getAll()).toHaveLength(0);
      expect(await root.meltOperationRepository.getAll()).toHaveLength(0);
      expect(await root.authSessionRepository.getAllSessions()).toHaveLength(0);
      expect(await root.mintOperationRepository.getAll()).toHaveLength(0);
      expect(await root.receiveOperationRepository.getAll()).toHaveLength(0);
      expect(await root.paymentRequestReceiveOperationRepository.list()).toHaveLength(0);
      expect(await root.paymentRequestReceiveAttemptRepository.getByState('received')).toHaveLength(
        0,
      );
    });

    it('rejects functions, custom prototypes, symbols, collections, sparse arrays, and branded extras', async () => {
      const root = await activeRoot(core, `${label}-shapes`);
      const customPrototype = { inherited: true };
      const custom = Object.create(customPrototype);
      custom.own = true;
      const symbolValue = { [Symbol('hidden')]: true };
      const nonEnumerable = {};
      Object.defineProperty(nonEnumerable, 'hidden', { value: true });
      const sparse = new Array(2);
      sparse[1] = true;
      const bytes = new Uint8Array([1, 2, 3]);
      Object.defineProperty(bytes, 'hidden', { value: true });
      const proxy = new Proxy({ nested: true }, {});
      const amount = Object.create(core.Amount.prototype);
      Object.defineProperties(amount, {
        value: { configurable: false, enumerable: true, writable: false, value: 1n },
        hidden: { value: true },
      });

      const rejected = [
        () => root.sendOperationRepository.create(sendOperation(core, 'function', () => undefined)),
        () => root.sendOperationRepository.create(sendOperation(core, 'prototype', custom)),
        () => root.sendOperationRepository.create(sendOperation(core, 'symbol', symbolValue)),
        () =>
          root.sendOperationRepository.create(sendOperation(core, 'non-enumerable', nonEnumerable)),
        () =>
          root.sendOperationRepository.create(sendOperation(core, 'map', { nested: new Map() })),
        () =>
          root.sendOperationRepository.create(sendOperation(core, 'set', { nested: new Set() })),
        () => root.sendOperationRepository.create(sendOperation(core, 'proxy', { nested: proxy })),
        () =>
          root.sendOperationRepository.create(sendOperation(core, 'sparse', { nested: sparse })),
        () => root.sendOperationRepository.create(sendOperation(core, 'bytes', { nested: bytes })),
        () => root.sendOperationRepository.create({ ...sendOperation(core, 'amount'), amount }),
        () => root.sendOperationRepository.create(sendOperation(core, 'thenable', { then() {} })),
      ];
      for (let index = 0; index < rejected.length; index += 1) {
        await expect(rejected[index]!()).rejects.toThrow('Unsafe Memory repository value');
      }
      expect(await root.sendOperationRepository.getAll()).toHaveLength(0);
    });

    it('rejects Proxy graphs without invoking traps or admitting reentrant writes', async () => {
      const root = await activeRoot(core, `${label}-proxy-preflight`);
      const mintUrl = `https://round14-proxy-${label}.invalid`;
      const proofSecret = `round14-proof-${label}`;
      await root.counterRepository.setCounter(mintUrl, 'keyset', 100);
      await root.proofRepository.saveProofs(mintUrl, [{ ...proof(core, proofSecret), mintUrl }]);

      let trapCalls = 0;
      const reentrantWrites: Promise<unknown>[] = [];
      const onTrap = (): void => {
        trapCalls += 1;
        reentrantWrites.push(root.counterRepository.setCounter(mintUrl, 'keyset', 41));
        queueMicrotask(() => {
          reentrantWrites.push(root.proofRepository.setProofState(mintUrl, [proofSecret], 'spent'));
        });
      };
      const handler: ProxyHandler<object> = {
        getPrototypeOf(target) {
          onTrap();
          return Reflect.getPrototypeOf(target);
        },
        ownKeys(target) {
          onTrap();
          return Reflect.ownKeys(target);
        },
        getOwnPropertyDescriptor(target, key) {
          onTrap();
          return Reflect.getOwnPropertyDescriptor(target, key);
        },
        get(target, key, receiver) {
          onTrap();
          return Reflect.get(target, key, receiver);
        },
        has(target, key) {
          onTrap();
          return Reflect.has(target, key);
        },
      };
      const proxy = <Value extends object>(target: Value): Value =>
        new Proxy(target, handler) as Value;
      const attempts = [
        sendOperation(core, `${label}-proxy-direct`, proxy({ forceSwap: false })),
        sendOperation(core, `${label}-proxy-nested`, {
          nested: { hostile: proxy({ forceSwap: false }) },
        }),
        sendOperation(core, `${label}-proxy-array`, [proxy({ forceSwap: false })]),
        {
          ...sendOperation(core, `${label}-proxy-amount`),
          amount: proxy(core.Amount.from(1)),
        },
        sendOperation(core, `${label}-proxy-bytes`, {
          bytes: proxy(new Uint8Array([1, 2, 3])),
        }),
        proxy(sendOperation(core, `${label}-proxy-operation`)),
      ];

      for (let index = 0; index < attempts.length; index += 1) {
        await expect(root.sendOperationRepository.create(attempts[index])).rejects.toThrow(
          'Proxy and non-cloneable object graphs are not supported',
        );
      }
      await expect(
        root.withTransaction(async (scope: any) => {
          await scope.counterRepository.setCounter(mintUrl, 'keyset', 77);
          await scope.sendOperationRepository.create(
            sendOperation(core, `${label}-proxy-transaction`, proxy({ forceSwap: false })),
          );
        }),
      ).rejects.toThrow('Proxy and non-cloneable object graphs are not supported');

      await Promise.resolve();
      await Promise.resolve();
      await Promise.allSettled(reentrantWrites);
      expect(trapCalls).toBe(0);
      expect(reentrantWrites).toHaveLength(0);
      expect((await root.counterRepository.getCounter(mintUrl, 'keyset'))?.counter).toBe(100);
      expect((await root.proofRepository.getProofBySecret(mintUrl, proofSecret))?.state).toBe(
        'ready',
      );
      for (let index = 0; index < attempts.length; index += 1) {
        expect(await root.sendOperationRepository.getById(attempts[index]!.id)).toBeNull();
      }
      expect(await root.sendOperationRepository.getById(`${label}-proxy-transaction`)).toBeNull();
    });

    it('detaches safe records, Amount values, bytes, and returned query values across takeover', async () => {
      const rootA = await activeRoot(core, `${label}-takeover`);
      const methodData = { forceSwap: false, nested: { policy: 'safe' } };
      const dleq = { e: 'e-before', s: 's-before', r: 'r-before' };
      const quoteData = { amount: core.Amount.from(1), nested: { memo: 'safe' } };
      const secretKey = new Uint8Array([1, 2, 3]);
      const publicKeyHex = `02${'13'.repeat(32)}`;

      await rootA.sendOperationRepository.create(sendOperation(core, 'safe-send', methodData));
      await rootA.proofRepository.saveProofs('https://round13.invalid', [
        proof(core, 'safe-proof', dleq),
      ]);
      await rootA.mintQuoteRepository.upsertMintQuote(mintQuote(core, quoteData));
      await rootA.keyRingRepository.setPersistedKeyPair({
        publicKeyHex,
        secretKey,
        purpose: 'p2pk',
      });

      methodData.forceSwap = true;
      dleq.s = 'caller-mutated';
      quoteData.nested.memo = 'caller-mutated';
      secretKey[0] = 9;

      const returnedOperation = await rootA.sendOperationRepository.getById('safe-send');
      const returnedProof = await rootA.proofRepository.getProofBySecret(
        'https://round13.invalid',
        'safe-proof',
      );
      const returnedQuote = await rootA.mintQuoteRepository.getMintQuote(
        'https://round13.invalid',
        'bolt11',
        'round13-quote',
      );
      const returnedKey = await rootA.keyRingRepository.getPersistedKeyPair(publicKeyHex, 'p2pk');
      returnedOperation.methodData.forceSwap = true;
      returnedProof.dleq.s = 'returned-mutated';
      returnedQuote.quoteData.nested.memo = 'returned-mutated';
      returnedKey.secretKey[1] = 9;

      const rootB = rootA.createPeer();
      await rootB.init();
      const generationTwo = await rootB.acquireAuthority({
        namespace: `round13-${label}-takeover`,
        ownerId: 'owner-b',
      });
      expect(generationTwo.generation).toBe(2);
      await expect(
        rootA.counterRepository.setCounter('https://round13.invalid', 'stale', 1),
      ).rejects.toThrow();

      const durableOperation = await rootB.sendOperationRepository.getById('safe-send');
      const durableProof = await rootB.proofRepository.getProofBySecret(
        'https://round13.invalid',
        'safe-proof',
      );
      const durableQuote = await rootB.mintQuoteRepository.getMintQuote(
        'https://round13.invalid',
        'bolt11',
        'round13-quote',
      );
      const durableKey = await rootB.keyRingRepository.getPersistedKeyPair(publicKeyHex, 'p2pk');
      expect(durableOperation.methodData.forceSwap).toBe(false);
      expect(durableProof.dleq.s).toBe('s-before');
      expect(durableQuote.quoteData.nested.memo).toBe('safe');
      expect(Array.from(durableKey.secretKey)).toEqual([1, 2, 3]);
      expect(Object.getPrototypeOf(durableOperation.methodData)).toBeNull();
      expect(durableOperation.amount).not.toBe(returnedOperation.amount);
    });

    it('rejects an unsafe transaction value without a row or operation-ID residue', async () => {
      const root = await activeRoot(core, `${label}-rollback`);
      let calls = 0;
      const operation = sendOperation(core, 'rollback-send');
      Object.defineProperty(operation, 'state', {
        enumerable: true,
        get() {
          calls += 1;
          return 'init';
        },
      });
      await expect(
        root.withTransaction(async (scope: any) => {
          await scope.sendOperationRepository.create(operation);
        }),
      ).rejects.toThrow('accessor properties are not supported');
      expect(calls).toBe(0);
      expect(await root.sendOperationRepository.getById('rollback-send')).toBeNull();
      await root.mintOperationRepository.create({
        id: 'rollback-send',
        state: 'init',
        mintUrl: 'https://round13.invalid',
        amount: core.Amount.from(1),
        unit: 'sat',
        method: 'bolt11',
        quoteId: 'fresh-owner',
        createdAt: 1,
        updatedAt: 1,
      });
      expect(await root.mintOperationRepository.getById('rollback-send')).not.toBeNull();
    });
  });
}

runPersistedValueBoundary('source', { Amount, MemoryRepositories });
runPersistedValueBoundary('dist', dist);
runPersistedValueBoundary('packed-a', packedA);
runPersistedValueBoundary('packed-b', packedB);
