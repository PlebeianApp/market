import type { CommittedRefundReclaimPlan } from './RefundReclaimPlan.ts';

/** Private synchronous capability used to re-authenticate a durable refund plan in-transaction. */
export type RefundReclaimPlanVerifier = (
  plan: CommittedRefundReclaimPlan,
  expectedCommitment: string,
) => Uint8Array;
