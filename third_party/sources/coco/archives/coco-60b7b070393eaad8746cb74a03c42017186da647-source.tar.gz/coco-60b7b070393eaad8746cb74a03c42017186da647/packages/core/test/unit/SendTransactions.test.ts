import { Amount, type MintKeys, type OutputDataLike } from '@cashu/cashu-ts';
import { describe, expect, it } from 'bun:test';
import { preparedSend, pendingSend } from '../fixtures/SendOperation.ts';
import { testMintInfo } from '../fixtures/MintMetadata.ts';
import { overrideTransactions } from '../overrideTransactions.ts';
import {
  createSendOperation,
  type ExecutingSendOperation,
  type PendingSendOperation,
  type PreparedSendOperation,
} from '../../operations/send';
import { createReceiveOperation } from '../../operations/receive/ReceiveOperation.ts';
import { OperationIdConflictError, SendOperationIntentConflictError } from '../../models/Error.ts';
import type {
  Repositories,
  RepositoryTransactionScope,
  SendOperationRepository,
} from '../../repositories';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import { RepositoryCoreTransactionRunner } from '../../transactions/CoreTransaction.ts';
import { CoreSendTransactions } from '../../transactions/send/SendTransactions.ts';
import type {
  CompletePendingSendInput,
  ExecuteExactSendInput,
  PrepareSendInput,
} from '../../transactions/send/types.ts';
import type { CoreProof } from '../../types.ts';
import { getSecretsFromSerializedOutputData } from '../../utils.ts';
import { makeOutputDataCreator } from '../fixtures/OutputDataCreator.ts';
import { activateTestMemoryRepositories } from '../fixtures/TestMemoryRepositories.ts';

const mintUrl = 'https://mint.test';
const keysetId = 'keyset-1';
const keys = { id: keysetId, unit: 'sat', keys: { 1: 'unused' } } as MintKeys;

function proof(secret: string, amount = 10): CoreProof {
  return {
    id: keysetId,
    secret,
    amount: Amount.from(amount),
    C: `C-${secret}`,
    mintUrl,
    unit: 'sat',
    state: 'ready',
  };
}

function operation(id: string, forceSwap = true) {
  return {
    ...createSendOperation(
      id,
      mintUrl,
      { amount: Amount.from(10), unit: 'sat' },
      {
        method: 'default',
        methodData: forceSwap ? { forceSwap: true } : {},
      },
    ),
    createdAt: 100,
    updatedAt: 200,
  };
}

function output(amount: Amount, counter: number): OutputDataLike {
  return {
    blindedMessage: { amount, id: keysetId, B_: `B-${counter}` },
    blindingFactor: BigInt(counter + 1),
    secret: new Uint8Array([counter + 1]),
    toProof: () => {
      throw new Error('not used');
    },
  };
}

async function setup(repositories: Repositories = new MemoryRepositories()) {
  if (repositories instanceof MemoryRepositories) {
    await activateTestMemoryRepositories(repositories);
  }
  await repositories.mintRepository.addNewMint({
    mintUrl,
    name: 'Test',
    trusted: true,
    mintInfo: testMintInfo,
    createdAt: 1,
    updatedAt: 1,
  });
  await repositories.keysetRepository.addKeyset({
    mintUrl,
    id: keysetId,
    unit: 'sat',
    keypairs: { 1: 'unused' },
    active: true,
    feePpk: 0,
  });
  const outputDataCreator = makeOutputDataCreator({
    createDeterministicData: (amount, _seed, counter) => [output(Amount.from(amount), counter)],
  });
  const runner = new RepositoryCoreTransactionRunner(repositories, outputDataCreator);
  return { repositories, transactions: new CoreSendTransactions(runner) };
}

class RejectingSendTransitionRepositories extends MemoryRepositories {
  override withTransaction<T>(
    fn: (repositories: RepositoryTransactionScope) => Promise<T>,
  ): Promise<T> {
    return super.withTransaction((repositories) =>
      fn({
        ...repositories,
        sendOperationRepository: rejectTransitions(repositories.sendOperationRepository),
      }),
    );
  }
}

function rejectTransitions(repository: SendOperationRepository): SendOperationRepository {
  return {
    ...repository,
    transition: async () => false,
  };
}

function prepareInput(id: string, forceSwap = true): PrepareSendInput {
  return {
    operation: operation(id, forceSwap),
    activeKeys: keys,
    seed: new Uint8Array(32).fill(1),
    forceSwap,
  };
}

function callerPrepareInput(id: string, amount = 10): PrepareSendInput {
  return {
    ...prepareInput(id),
    operation: {
      ...createSendOperation(
        id,
        mintUrl,
        { amount: Amount.from(amount), unit: 'sat' },
        { method: 'default', methodData: { forceSwap: true }, operationId: id },
      ),
      createdAt: 100,
      updatedAt: 200,
    },
  };
}

describe('SendTransactions preparation', () => {
  it('reserves proofs, allocates outputs, advances the counter, and creates prepared atomically', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);

    const result = await transactions.prepare(prepareInput('send-1'));

    expect(result.operation.state).toBe('prepared');
    expect(result.outcome).toBe('created');
    expect(result.operation.revision).toBe(0);
    expect(result.operation.inputProofSecrets).toEqual(['proof-1']);
    expect(result.operation.outputData?.send[0]?.blindedMessage.B_).toBe('B-0');
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.usedByOperationId,
    ).toBe('send-1');
    expect((await repositories.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(1);
    expect((await repositories.sendOperationRepository.getById('send-1'))?.state).toBe('prepared');
    expect(await repositories.sendOperationRepository.getByState('init')).toEqual([]);
  });

  it('joins a matching caller-supplied ID inside the transaction without a second mutation', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1'), proof('proof-2')]);

    const created = await transactions.prepare(callerPrepareInput('caller-send'));
    const joined = await transactions.prepare(callerPrepareInput('caller-send'));

    expect(created.outcome).toBe('created');
    expect(joined.outcome).toBe('joined');
    expect(joined.operation).toEqual(created.operation);
    expect(joined.reservation).toBeUndefined();
    expect(joined.counter).toBeUndefined();
    expect('callerSuppliedId' in joined.operation).toBe(false);
    expect(await repositories.sendOperationRepository.getByState('prepared')).toHaveLength(1);
    expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toHaveLength(1);
  });

  it('fails closed when a caller-supplied ID changes immutable Send intent', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [
      proof('proof-1'),
      proof('proof-2', 20),
    ]);
    await transactions.prepare(callerPrepareInput('caller-conflict'));

    await expect(
      transactions.prepare(callerPrepareInput('caller-conflict', 20)),
    ).rejects.toBeInstanceOf(SendOperationIntentConflictError);
    expect(await repositories.sendOperationRepository.getByState('prepared')).toHaveLength(1);
    expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toHaveLength(1);
  });

  it('rejects a caller-supplied ID already owned by another operation domain', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    await repositories.receiveOperationRepository.create(
      createReceiveOperation('cross-domain-id', mintUrl, { amount: Amount.from(10), unit: 'sat' }, [
        { id: keysetId, amount: Amount.from(10), secret: 'incoming', C: 'C-incoming' },
      ]),
    );

    const error = await transactions
      .prepare(callerPrepareInput('cross-domain-id'))
      .catch((caught: unknown) => caught);

    expect(error).toBeInstanceOf(OperationIdConflictError);
    expect((error as OperationIdConflictError).existingOperationType).toBe('receive');
    expect(await repositories.sendOperationRepository.getById('cross-domain-id')).toBeNull();
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.usedByOperationId,
    ).toBeUndefined();
  });

  it('rolls back proofs, counters, and the operation when persistence fails after allocation', async () => {
    const { repositories } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    await repositories.counterRepository.setCounter(mintUrl, keysetId, 5);
    const failing = overrideTransactions(repositories, (work) =>
      repositories.withTransaction((scope) => {
        const create = scope.sendOperationRepository.create.bind(scope.sendOperationRepository);
        return work({
          ...scope,
          sendOperationRepository: {
            ...scope.sendOperationRepository,
            create: async (operation) => {
              await create(operation);
              // Establish that all three writes happened before testing their rollback.
              expect(
                await scope.proofRepository.getProofBySecret(mintUrl, 'proof-1'),
              ).toMatchObject({
                usedByOperationId: operation.id,
              });
              expect((await scope.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(
                6,
              );
              expect(await scope.sendOperationRepository.getById(operation.id)).toMatchObject({
                state: 'prepared',
              });
              throw new Error('operation persistence failed');
            },
          },
        });
      }),
    );
    const { transactions } = await setup(failing);

    await expect(transactions.prepare(prepareInput('send-failure'))).rejects.toThrow(
      'operation persistence failed',
    );

    expect(await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1')).toEqual(
      proof('proof-1'),
    );
    expect((await repositories.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(5);
    expect(await repositories.sendOperationRepository.getById('send-failure')).toBeNull();
  });

  it('gives one concurrent reservation winner for the same authoritative proof', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('shared-proof')]);

    const results = await Promise.allSettled([
      transactions.prepare(prepareInput('send-a', false)),
      transactions.prepare(prepareInput('send-b', false)),
    ]);

    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(await repositories.sendOperationRepository.getByState('prepared')).toHaveLength(1);
    const storedProof = await repositories.proofRepository.getProofBySecret(
      mintUrl,
      'shared-proof',
    );
    expect(storedProof?.usedByOperationId).toBeDefined();
    expect(['send-a', 'send-b']).toContain(storedProof!.usedByOperationId!);
  });

  it.each(['init', 'prepared'] as const)(
    'rejects an existing %s operation before mutating proofs or counters',
    async (state) => {
      const { repositories, transactions } = await setup();
      const input = proof('legacy-proof');
      await repositories.proofRepository.saveProofs(mintUrl, [input]);
      await repositories.counterRepository.setCounter(mintUrl, keysetId, 5);
      const existing = {
        ...(state === 'init' ? operation('legacy-send') : preparedSend('legacy-send', [input])),
        revision: undefined,
      };
      await repositories.sendOperationRepository.create(existing);

      await expect(transactions.prepare(prepareInput(existing.id))).rejects.toThrow(
        'Send operation legacy-send already exists in state',
      );

      expect(await repositories.proofRepository.getProofBySecret(mintUrl, input.secret)).toEqual(
        input,
      );
      expect((await repositories.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(5);
      expect(await repositories.sendOperationRepository.getById(existing.id)).toEqual({
        ...existing,
        revision: 0,
      });
    },
  );

  it('allocates distinct counter positions across concurrent preparations', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-a'), proof('proof-b')]);

    const results = await Promise.all([
      transactions.prepare(prepareInput('send-a')),
      transactions.prepare(prepareInput('send-b')),
    ]);
    const positions = results.map(
      (result) => result.operation.outputData!.send[0]!.blindedMessage.B_,
    );

    expect(new Set(positions).size).toBe(2);
    expect((await repositories.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(2);
  });

  it('uses the canonical fee-aware selector instead of consuming an uneconomic proof', async () => {
    const { repositories, transactions } = await setup();
    await repositories.keysetRepository.addKeyset({
      mintUrl,
      id: 'expensive-keyset',
      unit: 'sat',
      keypairs: { 1: 'unused' },
      active: true,
      feePpk: 100_000,
    });
    await repositories.keysetRepository.addKeyset({
      mintUrl,
      id: 'free-keyset',
      unit: 'sat',
      keypairs: { 1: 'unused' },
      active: true,
      feePpk: 0,
    });
    await repositories.proofRepository.saveProofs(mintUrl, [
      { ...proof('expensive-proof', 100), id: 'expensive-keyset' },
      { ...proof('free-proof', 10), id: 'free-keyset' },
    ]);

    const result = await transactions.prepare(prepareInput('fee-aware-send'));

    expect(result.operation.inputProofSecrets).toEqual(['free-proof']);
    expect(result.operation.inputAmount.equals(Amount.from(10))).toBe(true);
    expect(result.operation.fee.isZero()).toBe(true);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'expensive-proof'))
        ?.usedByOperationId,
    ).toBeUndefined();
  });

  it('finds a non-greedy exact subset without allocating swap outputs', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [
      proof('proof-8', 8),
      proof('proof-7', 7),
      proof('proof-3', 3),
    ]);

    const result = await transactions.prepare(prepareInput('exact-subset-send', false));

    expect(new Set(result.operation.inputProofSecrets)).toEqual(new Set(['proof-7', 'proof-3']));
    expect(result.operation.needsSwap).toBe(false);
    expect(result.operation.outputData).toBeUndefined();
    expect(await repositories.counterRepository.getCounter(mintUrl, keysetId)).toBeNull();
  });

  it('rejects stale active key material before allocating or reserving anything', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);

    await expect(
      transactions.prepare({
        ...prepareInput('stale-keyset-send'),
        activeKeys: { ...keys, keys: { 1: 'stale-key' } },
      }),
    ).rejects.toThrow('changed after preflight');

    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.usedByOperationId,
    ).toBeUndefined();
    expect(await repositories.counterRepository.getCounter(mintUrl, keysetId)).toBeNull();
    expect(await repositories.sendOperationRepository.getById('stale-keyset-send')).toBeNull();
  });
});

describe('SendTransactions exact-match execution', () => {
  async function prepareExact(
    id: string,
    repositories = new MemoryRepositories(),
  ): Promise<Awaited<ReturnType<typeof setup>>> {
    const environment = await setup(repositories);
    await environment.repositories.proofRepository.saveProofs(mintUrl, [proof('exact-proof')]);
    await environment.transactions.prepare(prepareInput(id, false));
    return environment;
  }

  function executeCommand(
    operationId: string,
    overrides: Partial<ExecuteExactSendInput> = {},
  ): ExecuteExactSendInput {
    return {
      operationId,
      updatedAt: 300,
      ...overrides,
    };
  }

  it('commits proof state, complete token data, and prepared-to-pending together', async () => {
    const { repositories, transactions } = await prepareExact('exact-send');

    const result = await transactions.executeExact(
      executeCommand('exact-send', { memo: '  exact memo  ' }),
    );

    expect(result.committed).toBe(true);
    expect(result.operation.state).toBe('pending');
    expect(result.operation.revision).toBe(1);
    expect(result.token.memo).toBe('exact memo');
    expect(result.token.proofs.map((candidate) => candidate.secret)).toEqual(['exact-proof']);
    const stored = await repositories.sendOperationRepository.getById('exact-send');
    expect(stored?.state).toBe('pending');
    expect(stored?.revision).toBe(1);
    expect((stored as typeof result.operation).token.proofs).toHaveLength(1);
    const storedProof = await repositories.proofRepository.getProofBySecret(mintUrl, 'exact-proof');
    expect(storedProof?.state).toBe('inflight');
    expect(storedProof?.usedByOperationId).toBe('exact-send');
    expect(await repositories.sendOperationRepository.getByState('executing')).toEqual([]);
  });

  it('advances the authoritative revision without accepting one from the caller', async () => {
    const { repositories, transactions } = await prepareExact('revisioned-exact-send');
    const prepared = await repositories.sendOperationRepository.getById('revisioned-exact-send');
    if (!prepared || prepared.state !== 'prepared') throw new Error('prepared operation missing');
    await repositories.sendOperationRepository.update({ ...prepared, revision: 5 });

    const result = await transactions.executeExact(executeCommand(prepared.id));

    expect(result.operation.revision).toBe(6);
  });

  it('rolls back the inflight proof write when the final operation transition loses', async () => {
    const repositories = new RejectingSendTransitionRepositories();
    const environment = await prepareExact('rejected-exact-send', repositories);

    await expect(
      environment.transactions.executeExact(executeCommand('rejected-exact-send')),
    ).rejects.toThrow('state or revision conflict');

    expect((await repositories.sendOperationRepository.getById('rejected-exact-send'))?.state).toBe(
      'prepared',
    );
    const storedProof = await repositories.proofRepository.getProofBySecret(mintUrl, 'exact-proof');
    expect(storedProof?.state).toBe('ready');
    expect(storedProof?.usedByOperationId).toBe('rejected-exact-send');
  });

  it('has one transition winner and returns the identical committed result to a duplicate', async () => {
    const { repositories, transactions } = await prepareExact('concurrent-exact-send');
    const request = executeCommand('concurrent-exact-send', { memo: 'same memo' });

    const results = await Promise.all([
      transactions.executeExact(request),
      transactions.executeExact(request),
    ]);

    expect(results.filter((result) => result.committed)).toHaveLength(1);
    expect(results.filter((result) => !result.committed)).toHaveLength(1);
    expect(results[0]?.token).toEqual(results[1]?.token);
    expect(
      (await repositories.sendOperationRepository.getById('concurrent-exact-send'))?.revision,
    ).toBe(1);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'exact-proof'))?.state,
    ).toBe('inflight');
  });

  it('rejects execution when a prepared input is no longer ready and owned', async () => {
    const { repositories, transactions } = await prepareExact('unowned-exact-send');
    await repositories.proofRepository.releaseProofs(mintUrl, ['exact-proof']);

    await expect(transactions.executeExact(executeCommand('unowned-exact-send'))).rejects.toThrow(
      'not ready and operation-owned',
    );

    expect((await repositories.sendOperationRepository.getById('unowned-exact-send'))?.state).toBe(
      'prepared',
    );
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'exact-proof'))?.state,
    ).toBe('ready');
  });
});

describe('SendTransactions legacy exact recovery', () => {
  async function persistLegacy(repositories: Repositories) {
    const legacy: ExecutingSendOperation = {
      ...operation('legacy-exact', false),
      state: 'executing',
      revision: undefined,
      needsSwap: false,
      fee: Amount.zero(),
      inputAmount: Amount.from(10),
      inputProofSecrets: ['legacy-input'],
    };
    await repositories.sendOperationRepository.create(legacy);
    await repositories.proofRepository.saveProofs(mintUrl, [
      { ...proof('legacy-input'), state: 'inflight', usedByOperationId: legacy.id },
    ]);
    return legacy;
  }

  it('rolls back proof state and reservation changes when the operation transition fails', async () => {
    const { repositories, transactions } = await setup(new RejectingSendTransitionRepositories());
    const legacy = await persistLegacy(repositories);

    await expect(
      transactions.recoverLegacyExact({ operationId: legacy.id, updatedAt: 300 }),
    ).rejects.toThrow('conflicted');

    expect((await repositories.sendOperationRepository.getById(legacy.id))?.state).toBe(
      'executing',
    );
    const stored = await repositories.proofRepository.getProofBySecret(mintUrl, 'legacy-input');
    expect(stored?.state).toBe('inflight');
    expect(stored?.usedByOperationId).toBe(legacy.id);
  });

  it('allows only one recovery of the legacy executing revision', async () => {
    const { repositories, transactions } = await setup();
    const legacy = await persistLegacy(repositories);
    const recover = () =>
      transactions.recoverLegacyExact({ operationId: legacy.id, updatedAt: 300 });

    const results = await Promise.allSettled([recover(), recover()]);

    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((result) => result.status === 'rejected')).toHaveLength(1);
    expect((await repositories.sendOperationRepository.getById(legacy.id))?.revision).toBe(1);
    expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toHaveLength(1);
  });

  it.each(['spent', 'unowned', 'revision', 'swap', 'amount'] as const)(
    'preserves inputs when legacy exact recovery encounters %s data',
    async (invalid) => {
      const { repositories, transactions } = await setup();
      const legacy = await persistLegacy(repositories);
      if (invalid === 'spent') {
        await repositories.proofRepository.setProofState(mintUrl, ['legacy-input'], 'spent');
      } else if (invalid === 'unowned') {
        await repositories.proofRepository.releaseProofs(mintUrl, ['legacy-input']);
      } else {
        await repositories.sendOperationRepository.update({
          ...legacy,
          ...(invalid === 'revision' ? { revision: 1 } : {}),
          ...(invalid === 'swap' ? { needsSwap: true } : {}),
          ...(invalid === 'amount' ? { amount: Amount.from(11) } : {}),
        });
      }
      const before = await repositories.proofRepository.getProofBySecret(mintUrl, 'legacy-input');
      const operationBefore = await repositories.sendOperationRepository.getById(legacy.id);

      await expect(
        transactions.recoverLegacyExact({ operationId: legacy.id, updatedAt: 300 }),
      ).rejects.toThrow();

      expect(await repositories.proofRepository.getProofBySecret(mintUrl, 'legacy-input')).toEqual(
        before,
      );
      expect(await repositories.sendOperationRepository.getById(legacy.id)).toEqual(
        operationBefore,
      );
    },
  );
});

function swapProof(
  operation: ExecutingSendOperation,
  secret: string,
  state: CoreProof['state'],
): CoreProof {
  return {
    id: keysetId,
    secret,
    amount: operation.amount,
    C: `C-${secret}`,
    mintUrl: operation.mintUrl,
    unit: operation.unit,
    state,
    createdByOperationId: operation.id,
  };
}

describe('SendTransactions swap execution', () => {
  it.each(['ready', 'inflight', 'spent'] as const)(
    'reconciles existing %s send outputs while preserving reserved change',
    async (state) => {
      const { repositories, transactions } = await setup();
      await repositories.proofRepository.saveProofs(mintUrl, [proof('legacy-input', 20)]);
      const prepared = (await transactions.prepare(prepareInput('legacy-outputs'))).operation;
      const executing: ExecutingSendOperation = { ...prepared, state: 'executing', revision: 0 };
      await repositories.sendOperationRepository.update(executing);
      const { keepSecrets, sendSecrets } = getSecretsFromSerializedOutputData(
        executing.outputData!,
      );
      const keep = swapProof(executing, keepSecrets[0]!, 'ready');
      const send = swapProof(executing, sendSecrets[0]!, 'inflight');
      const reservedChange = { ...keep, usedByOperationId: 'later-send' };
      await repositories.proofRepository.saveProofs(mintUrl, [reservedChange, { ...send, state }]);
      const input = {
        operationId: executing.id,
        updatedAt: 300,
        keepProofs: [keep],
        sendProofs: [send],
        token: { mint: mintUrl, unit: 'sat', proofs: [send] },
      };

      const result = await transactions.applyResult(input);

      expect(result.operation.state).toBe('pending');
      expect(result.inflightProofSecrets).toEqual(state === 'ready' ? [send.secret] : []);
      expect(result.savedProofs).toEqual([]);
      expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
      expect(await repositories.proofRepository.getProofBySecret(mintUrl, send.secret)).toEqual({
        ...send,
        state: state === 'ready' ? 'inflight' : state,
      });
      expect(await repositories.proofRepository.getProofBySecret(mintUrl, keep.secret)).toEqual(
        reservedChange,
      );
      const replay = await transactions.applyResult(input);
      expect(replay.committed).toBe(false);
      expect(replay.inflightProofSecrets).toEqual([]);
    },
  );

  it('leaves recovery executing when a legacy ready send output is reserved elsewhere', async () => {
    const { repositories, transactions } = await setup();
    const input = { ...proof('legacy-input'), usedByOperationId: 'legacy-reserved-output' };
    const send = {
      ...proof('legacy-send'),
      state: 'inflight' as const,
      createdByOperationId: input.usedByOperationId,
    };
    const executing: ExecutingSendOperation = {
      ...preparedSend(input.usedByOperationId, [input], [send]),
      state: 'executing',
    };
    const reservedSend = { ...send, state: 'ready' as const, usedByOperationId: 'later-send' };
    await repositories.sendOperationRepository.create(executing);
    await repositories.proofRepository.saveProofs(mintUrl, [input, reservedSend]);

    await expect(
      transactions.applyResult({
        operationId: executing.id,
        updatedAt: 300,
        keepProofs: [],
        sendProofs: [send],
        token: { mint: mintUrl, unit: 'sat', proofs: [send] },
      }),
    ).rejects.toThrow('reserved by another operation');

    expect(await repositories.sendOperationRepository.getById(executing.id)).toEqual(executing);
    expect(await repositories.proofRepository.getProofBySecret(mintUrl, input.secret)).toEqual(
      input,
    );
    expect(await repositories.proofRepository.getProofBySecret(mintUrl, send.secret)).toEqual(
      reservedSend,
    );
  });

  it('settles a legacy partial result without resetting existing output state or ownership', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('legacy-swap-input', 20)]);
    const prepared = (await transactions.prepare(prepareInput('legacy-partial-result'))).operation;
    const executing: ExecutingSendOperation = { ...prepared, state: 'executing', revision: 0 };
    await repositories.sendOperationRepository.update(executing);
    const { keepSecrets, sendSecrets } = getSecretsFromSerializedOutputData(executing.outputData!);
    const keep = swapProof(executing, keepSecrets[0]!, 'ready');
    const send = swapProof(executing, sendSecrets[0]!, 'inflight');
    const alreadyUsed = { ...keep, state: 'spent' as const, usedByOperationId: 'later-send' };
    await repositories.proofRepository.saveProofs(mintUrl, [alreadyUsed]);
    await repositories.proofRepository.setProofState(mintUrl, executing.inputProofSecrets, 'spent');

    const claimed = await transactions.claimRecovery({
      operationId: executing.id,
      expectedRevision: 0,
      updatedAt: 300,
    });
    const result = await transactions.applyResult({
      operationId: executing.id,
      updatedAt: 400,
      keepProofs: [keep],
      sendProofs: [send],
      token: { mint: mintUrl, unit: 'sat', proofs: [send] },
    });

    expect(claimed.request.outputData).toEqual(executing.outputData!);
    expect(result.operation.state).toBe('pending');
    expect(result.savedProofs).toEqual([send]);
    expect(await repositories.proofRepository.getProofBySecret(mintUrl, keep.secret)).toEqual(
      alreadyUsed,
    );
    expect(await repositories.proofRepository.getProofBySecret(mintUrl, send.secret)).toEqual(send);
  });

  it('commits the exact executing request and memo before transport starts', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-begin'))).operation;

    const begun = await transactions.beginExecution({
      operationId: prepared.id,
      updatedAt: 300,
      memo: 'durable memo',
    });

    const stored = await repositories.sendOperationRepository.getById(prepared.id);
    expect(stored?.state).toBe('executing');
    expect(stored?.revision).toBe(1);
    expect(stored?.executionMemo).toBe('durable memo');
    expect(begun.request.inputProofs.map((candidate) => candidate.secret)).toEqual(['proof-1']);
    expect(begun.request.outputData).toEqual(prepared.outputData!);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.usedByOperationId,
    ).toBe(prepared.id);
  });

  it('keeps persisted inputs and outputs independent of returned and queried request objects', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('request-input')]);
    const prepared = await transactions.prepare(prepareInput('request-immutability'));
    const begun = await transactions.beginExecution({
      operationId: prepared.operation.id,
      updatedAt: 300,
    });
    const expected = JSON.stringify(begun.request.outputData);
    begun.request.outputData.send[0]!.secret = 'changed';
    const queried = await repositories.sendOperationRepository.getById(prepared.operation.id);
    if (!queried || queried.state !== 'executing') throw new Error('Missing executing operation');
    expect(JSON.stringify(queried.outputData)).toBe(expected);
    queried.inputProofSecrets.push('changed');
    queried.outputData!.send[0]!.secret = 'changed';
    const replay = await transactions.claimRecovery({
      operationId: prepared.operation.id,
      expectedRevision: queried.revision!,
      updatedAt: 400,
    });
    expect(JSON.stringify(replay.request.outputData)).toBe(expected);
    expect(replay.request.inputProofs.map((proof) => proof.secret)).toEqual(['request-input']);
  });

  it('leaves the complete request executing when a response is not applied', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-response-crash'))).operation;
    const begun = await transactions.beginExecution({
      operationId: prepared.id,
      updatedAt: 300,
    });
    const sendSecret = getSecretsFromSerializedOutputData(begun.request.outputData).sendSecrets[0]!;

    // A remote response may now exist, but no local result transaction has run.
    const response = { send: [swapProof(begun.operation, sendSecret, 'inflight')], keep: [] };
    expect(response.send).toHaveLength(1);
    expect((await repositories.sendOperationRepository.getById(prepared.id))?.state).toBe(
      'executing',
    );
    expect(await repositories.proofRepository.getProofBySecret(mintUrl, sendSecret)).toBeNull();
    expect((await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.state).toBe(
      'ready',
    );
  });

  it('gives only one concurrent begin attempt authority to contact the mint', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-concurrent-begin'))).operation;
    const begin = () =>
      transactions.beginExecution({
        operationId: prepared.id,
        updatedAt: 300,
      });

    const results = await Promise.allSettled([begin(), begin()]);

    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((result) => result.status === 'rejected')).toHaveLength(1);
    expect((await repositories.sendOperationRepository.getById(prepared.id))?.revision).toBe(1);
  });

  it('gives only one recovery caller authority to replay an executing revision', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-recovery-claim'))).operation;
    const begun = await transactions.beginExecution({
      operationId: prepared.id,
      updatedAt: 300,
    });
    const claim = () =>
      transactions.claimRecovery({
        operationId: begun.operation.id,
        expectedRevision: begun.operation.revision ?? 0,
        updatedAt: 400,
      });

    const results = await Promise.allSettled([claim(), claim()]);

    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((result) => result.status === 'rejected')).toHaveLength(1);
    expect((await repositories.sendOperationRepository.getById(prepared.id))?.revision).toBe(2);
  });

  it('atomically saves swap proofs, spends inputs, persists the token, and becomes pending', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-apply'))).operation;
    const begun = await transactions.beginExecution({
      operationId: prepared.id,
      updatedAt: 300,
      memo: 'memo',
    });
    const sendSecret = getSecretsFromSerializedOutputData(begun.request.outputData).sendSecrets[0]!;
    const sendProof = swapProof(begun.operation, sendSecret, 'inflight');
    const token = {
      mint: mintUrl,
      proofs: [sendProof],
      unit: 'sat',
      memo: 'memo',
    };

    const applied = await transactions.applyResult({
      operationId: begun.operation.id,
      updatedAt: 400,
      keepProofs: [],
      sendProofs: [sendProof],
      token,
    });

    expect(applied.committed).toBe(true);
    expect(applied.operation.state).toBe('pending');
    expect(applied.operation.revision).toBe(2);
    expect(applied.operation.token).toEqual(token);
    expect((await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.state).toBe(
      'spent',
    );
    expect((await repositories.proofRepository.getProofBySecret(mintUrl, sendSecret))?.state).toBe(
      'inflight',
    );

    const duplicate = await transactions.applyResult({
      operationId: begun.operation.id,
      updatedAt: 500,
      keepProofs: [],
      sendProofs: [sendProof],
      token,
    });
    expect(duplicate.committed).toBe(false);
    expect(duplicate.operation.revision).toBe(2);
  });

  it('rejects swap proofs that do not match the exact persisted output allocation', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-invalid-allocation')))
      .operation;
    const begun = await transactions.beginExecution({ operationId: prepared.id, updatedAt: 300 });
    const sendSecret = getSecretsFromSerializedOutputData(begun.request.outputData).sendSecrets[0]!;
    const allocated = swapProof(begun.operation, sendSecret, 'inflight');
    const token = { mint: mintUrl, proofs: [allocated], unit: 'sat' };
    const invalidProofs = [
      { ...allocated, id: 'wrong-keyset' },
      { ...allocated, amount: allocated.amount.add(Amount.from(1)) },
    ];

    for (const invalid of invalidProofs) {
      await expect(
        transactions.applyResult({
          operationId: begun.operation.id,
          updatedAt: 400,
          keepProofs: [],
          sendProofs: [invalid],
          token: { ...token, proofs: [invalid] },
        }),
      ).rejects.toThrow('do not match allocated outputs');
    }
    await expect(
      transactions.applyResult({
        operationId: begun.operation.id,
        updatedAt: 400,
        keepProofs: [{ ...allocated, state: 'ready' }],
        sendProofs: [],
        token: { ...token, proofs: [] },
      }),
    ).rejects.toThrow('do not match allocated outputs');
    expect((await repositories.sendOperationRepository.getById(prepared.id))?.state).toBe(
      'executing',
    );
  });

  it('rolls back every local result write when output persistence conflicts', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-apply-rollback'))).operation;
    const begun = await transactions.beginExecution({
      operationId: prepared.id,
      updatedAt: 300,
    });
    const sendSecret = getSecretsFromSerializedOutputData(begun.request.outputData).sendSecrets[0]!;
    const sendProof = swapProof(begun.operation, sendSecret, 'inflight');
    await repositories.proofRepository.saveProofs(mintUrl, [proof(sendSecret, 1)]);

    await expect(
      transactions.applyResult({
        operationId: begun.operation.id,
        updatedAt: 400,
        keepProofs: [],
        sendProofs: [sendProof],
        token: { mint: mintUrl, proofs: [sendProof], unit: 'sat' },
      }),
    ).rejects.toThrow('already exists');

    expect((await repositories.sendOperationRepository.getById(prepared.id))?.state).toBe(
      'executing',
    );
    expect((await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.state).toBe(
      'ready',
    );
  });

  it('rejects an initial failure after recovery has claimed its executing revision', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-stale-failure'))).operation;
    const begun = await transactions.beginExecution({ operationId: prepared.id, updatedAt: 300 });
    await transactions.claimRecovery({
      operationId: prepared.id,
      expectedRevision: begun.operation.revision!,
      updatedAt: 400,
    });

    await expect(
      transactions.failExecution({
        operationId: prepared.id,
        expectedRevision: begun.operation.revision!,
        updatedAt: 500,
        error: 'keyset rejected',
      }),
    ).rejects.toThrow('revision conflict');

    expect((await repositories.sendOperationRepository.getById(prepared.id))?.state).toBe(
      'executing',
    );
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.usedByOperationId,
    ).toBe(prepared.id);
  });

  it('atomically releases inputs on a definitive failure without reclaiming counters', async () => {
    const { repositories, transactions } = await setup();
    await repositories.proofRepository.saveProofs(mintUrl, [proof('proof-1')]);
    const prepared = (await transactions.prepare(prepareInput('send-fail'))).operation;
    const allocatedCounter = await repositories.counterRepository.getCounter(mintUrl, keysetId);
    const begun = await transactions.beginExecution({
      operationId: prepared.id,
      updatedAt: 300,
    });

    const failed = await transactions.failExecution({
      operationId: begun.operation.id,
      expectedRevision: begun.operation.revision!,
      updatedAt: 400,
      error: 'Keyset rejected',
    });

    expect(failed.operation.state).toBe('rolled_back');
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'proof-1'))?.usedByOperationId,
    ).toBeUndefined();
    expect(await repositories.counterRepository.getCounter(mintUrl, keysetId)).toEqual(
      allocatedCounter,
    );
  });
});

describe('SendTransactions cancellation and completion', () => {
  async function createPrepared(
    repositories: MemoryRepositories,
    id: string,
  ): Promise<PreparedSendOperation> {
    const input = proof(`${id}-input`);
    await repositories.proofRepository.saveProofs(mintUrl, [input]);
    await repositories.proofRepository.reserveProofs(mintUrl, [input.secret], id);
    const prepared = preparedSend(id, [input]);
    await repositories.sendOperationRepository.create(prepared);
    return prepared;
  }

  it('releases terminal Send reservations while preserving active and unidentified owners', async () => {
    const repositories = new MemoryRepositories();
    const { transactions } = await setup(repositories);
    const active = await createPrepared(repositories, 'active-send');
    const terminal = await createPrepared(repositories, 'terminal-send');
    await repositories.sendOperationRepository.update({
      ...terminal,
      state: 'rolled_back',
      error: 'already terminal',
    });
    const orphan = proof('orphan-input');
    await repositories.proofRepository.saveProofs(mintUrl, [orphan]);
    await repositories.proofRepository.reserveProofs(mintUrl, [orphan.secret], 'missing-send');

    const meltInput = proof('melt-input');
    await repositories.proofRepository.saveProofs(mintUrl, [meltInput]);
    await repositories.meltOperationRepository.create({
      id: 'prepared-melt',
      mintUrl,
      unit: 'sat',
      state: 'prepared',
      method: 'bolt11',
      methodData: { invoice: 'test-invoice' },
      createdAt: 100,
      updatedAt: 100,
      needsSwap: false,
      amount: Amount.from(10),
      fee_reserve: Amount.zero(),
      swap_fee: Amount.zero(),
      quoteId: 'melt-quote',
      inputAmount: Amount.from(10),
      inputProofSecrets: [meltInput.secret],
      changeOutputData: { keep: [], send: [] },
    });
    await repositories.proofRepository.reserveProofs(mintUrl, [meltInput.secret], 'prepared-melt');

    const result = await transactions.cleanupOrphanedReservations();

    expect(result.count).toBe(1);
    expect(result.released).toEqual([
      {
        mintUrl,
        secrets: [terminal.inputProofSecrets[0]!],
      },
    ]);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, active.inputProofSecrets[0]!))
        ?.usedByOperationId,
    ).toBe(active.id);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, terminal.inputProofSecrets[0]!))
        ?.usedByOperationId,
    ).toBeUndefined();
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, orphan.secret))
        ?.usedByOperationId,
    ).toBe('missing-send');
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, meltInput.secret))
        ?.usedByOperationId,
    ).toBe('prepared-melt');
  });

  it('atomically releases a prepared reservation and records cancellation', async () => {
    const repositories = new MemoryRepositories();
    const { transactions } = await setup(repositories);
    const prepared = await createPrepared(repositories, 'cancel-send');

    const cancelled = await transactions.cancelPrepared({
      operationId: prepared.id,
      updatedAt: 300,
      reason: 'Cancelled by user',
    });

    expect(cancelled.operation.state).toBe('rolled_back');
    expect(cancelled.operation.revision).toBe(1);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, prepared.inputProofSecrets[0]!))
        ?.usedByOperationId,
    ).toBeUndefined();
  });

  it('rolls back reservation release when cancellation loses its final transition', async () => {
    const repositories = new RejectingSendTransitionRepositories();
    const { transactions } = await setup(repositories);
    const prepared = await createPrepared(repositories, 'cancel-conflict');

    await expect(
      transactions.cancelPrepared({
        operationId: prepared.id,
        updatedAt: 300,
        reason: 'Cancelled by user',
      }),
    ).rejects.toThrow('prepared-state or revision conflict');

    expect((await repositories.sendOperationRepository.getById(prepared.id))?.state).toBe(
      'prepared',
    );
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, prepared.inputProofSecrets[0]!))
        ?.usedByOperationId,
    ).toBe(prepared.id);
  });

  it('allows only cancellation or swap execution to win from the same prepared revision', async () => {
    const repositories = new MemoryRepositories();
    const { transactions } = await setup(repositories);
    await repositories.proofRepository.saveProofs(mintUrl, [proof('race-input')]);
    const prepared = (await transactions.prepare(prepareInput('race-send'))).operation;

    const results = await Promise.allSettled([
      transactions.cancelPrepared({
        operationId: prepared.id,
        updatedAt: 300,
        reason: 'Cancelled by user',
      }),
      transactions.beginExecution({
        operationId: prepared.id,
        updatedAt: 300,
      }),
    ]);

    expect(results.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    expect(results.filter((result) => result.status === 'rejected')).toHaveLength(1);
    const stored = await repositories.sendOperationRepository.getById(prepared.id);
    expect(stored).not.toBeNull();
    expect(['executing', 'rolled_back']).toContain(stored!.state);
    const input = await repositories.proofRepository.getProofBySecret(mintUrl, 'race-input');
    expect(input?.usedByOperationId).toBe(stored?.state === 'executing' ? prepared.id : undefined);
  });

  it('commits the last spent observation, reservation release, and final state together', async () => {
    const repositories = new MemoryRepositories();
    const { transactions } = await setup(repositories);
    const prepared = await createPrepared(repositories, 'complete-send');
    const pending = await transactions.executeExact({
      operationId: prepared.id,
      updatedAt: 300,
    });

    const completed = await transactions.completePending({
      operationId: pending.operation.id,
      updatedAt: 400,
      spentProofSecrets: pending.operation.inputProofSecrets,
    });

    expect(completed.operation.state).toBe('finalized');
    expect(completed.operation.revision).toBe(2);
    const input = await repositories.proofRepository.getProofBySecret(
      mintUrl,
      pending.operation.inputProofSecrets[0]!,
    );
    expect(input?.state).toBe('spent');
    expect(input?.usedByOperationId).toBeUndefined();

    const duplicate = await transactions.completePending({
      operationId: pending.operation.id,
      updatedAt: 500,
      spentProofSecrets: pending.operation.inputProofSecrets,
    });
    expect(duplicate.committed).toBe(false);
  });

  it('rolls back proof completion when the pending terminal transition loses', async () => {
    const repositories = new RejectingSendTransitionRepositories();
    const { transactions } = await setup(repositories);
    const input = proof('terminal-conflict-input');
    await repositories.proofRepository.saveProofs(mintUrl, [
      { ...input, state: 'inflight', usedByOperationId: 'terminal-conflict' },
    ]);
    const pending: PendingSendOperation = {
      ...operation('terminal-conflict', false),
      state: 'pending',
      revision: 1,
      needsSwap: false,
      fee: Amount.zero(),
      inputAmount: Amount.from(10),
      inputProofSecrets: [input.secret],
      token: { mint: mintUrl, proofs: [input], unit: 'sat' },
    };
    await repositories.sendOperationRepository.create(pending);

    await expect(
      transactions.completePending({
        operationId: pending.id,
        updatedAt: 400,
        spentProofSecrets: [input.secret],
      }),
    ).rejects.toThrow('pending-state or revision conflict');

    expect((await repositories.sendOperationRepository.getById(pending.id))?.state).toBe('pending');
    const storedInput = await repositories.proofRepository.getProofBySecret(mintUrl, input.secret);
    expect(storedInput?.state).toBe('inflight');
    expect(storedInput?.usedByOperationId).toBe(pending.id);
  });
});

describe.each(['exact', 'swap'] as const)(
  'SendTransactions %s completion after reservation release',
  (method) => {
    async function pending(repositories = new MemoryRepositories(), revision = 0) {
      const environment = await setup(repositories);
      const id = 'released-send';
      const needsSwap = method === 'swap';
      const inputs: CoreProof[] = [0, 1].map((index) => ({
        ...proof(`input-${index}`, 5),
        state: needsSwap ? 'spent' : 'inflight',
        usedByOperationId: id,
      }));
      const sendProofs: CoreProof[] = needsSwap
        ? [0, 1].map((index) => ({
            ...proof(`send-${index}`, 5),
            state: 'inflight',
            createdByOperationId: id,
          }))
        : inputs;
      const operation = {
        ...pendingSend(id, inputs, needsSwap ? sendProofs : undefined),
        revision,
      };
      await repositories.sendOperationRepository.create(operation);
      await repositories.proofRepository.saveProofs(
        mintUrl,
        needsSwap ? [...inputs, ...sendProofs] : inputs,
      );
      return { ...environment, operation, inputs, sendProofs };
    }

    it.each([0, 3])('completes spent inputs already released at revision %i', async (revision) => {
      const { repositories, transactions, operation, sendProofs } = await pending(
        undefined,
        revision,
      );
      await repositories.proofRepository.setProofState(
        mintUrl,
        sendProofs.map((proof) => proof.secret),
        'spent',
      );
      // The old finalizer could commit this release and crash before persisting finalized.
      await repositories.proofRepository.releaseProofs(mintUrl, operation.inputProofSecrets);

      const result = await transactions.completePending({
        operationId: operation.id,
        updatedAt: 400,
      });

      expect(result.operation.state).toBe('finalized');
      expect(result.operation.revision).toBe(revision + 1);
      expect(result.releasedInputSecrets).toEqual([]);
      expect(result.spentProofSecrets).toEqual([]);
      expect(
        (await transactions.completePending({ operationId: operation.id, updatedAt: 500 }))
          .committed,
      ).toBe(false);
    });

    it('releases and reports only reservations still owned by the Send', async () => {
      const { repositories, transactions, operation, inputs, sendProofs } = await pending();
      await repositories.proofRepository.setProofState(
        mintUrl,
        sendProofs.map((proof) => proof.secret),
        'spent',
      );
      await repositories.proofRepository.releaseProofs(mintUrl, [inputs[0]!.secret]);

      const result = await transactions.completePending({
        operationId: operation.id,
        updatedAt: 400,
      });

      expect(result.operation.state).toBe('finalized');
      expect(result.releasedInputSecrets).toEqual([inputs[1]!.secret]);
      for (const input of inputs) {
        expect(
          (await repositories.proofRepository.getProofBySecret(mintUrl, input.secret))
            ?.usedByOperationId,
        ).toBeUndefined();
      }
    });

    it('records individual observations without finalizing an unclaimed token', async () => {
      const { repositories, transactions, operation, inputs, sendProofs } = await pending();
      if (method === 'swap') {
        await repositories.proofRepository.releaseProofs(mintUrl, operation.inputProofSecrets);
      }
      const first = await transactions.completePending({
        operationId: operation.id,
        updatedAt: 400,
        spentProofSecrets: [sendProofs[0]!.secret],
      });
      expect(first.operation.state).toBe('pending');
      expect(first.spentProofSecrets).toEqual([sendProofs[0]!.secret]);
      expect(first.releasedInputSecrets).toEqual([]);
      expect(
        (await repositories.proofRepository.getProofBySecret(mintUrl, sendProofs[1]!.secret))
          ?.state,
      ).toBe('inflight');

      if (method === 'exact') {
        await repositories.proofRepository.releaseProofs(mintUrl, [inputs[0]!.secret]);
      }
      const last = await transactions.completePending({
        operationId: operation.id,
        updatedAt: 500,
        spentProofSecrets: [sendProofs[1]!.secret],
      });
      expect(last.operation.state).toBe('finalized');
      expect(last.spentProofSecrets).toEqual([sendProofs[1]!.secret]);
      expect(last.releasedInputSecrets).toEqual(method === 'exact' ? [inputs[1]!.secret] : []);
    });

    it.each(['ready', 'inflight', 'foreign-owner', 'token-mismatch', 'missing-token'] as const)(
      'rejects %s data without changing proofs or operation state',
      async (invalid) => {
        const { repositories, transactions, operation, inputs, sendProofs } = await pending();
        await repositories.proofRepository.setProofState(
          mintUrl,
          sendProofs.map((proof) => proof.secret),
          'spent',
        );
        await repositories.proofRepository.releaseProofs(mintUrl, operation.inputProofSecrets);
        if (invalid === 'ready' || invalid === 'inflight') {
          await repositories.proofRepository.setProofState(mintUrl, [inputs[0]!.secret], invalid);
        } else if (invalid === 'foreign-owner') {
          await repositories.proofRepository.setProofState(mintUrl, [inputs[0]!.secret], 'ready');
          await repositories.proofRepository.reserveProofs(
            mintUrl,
            [inputs[0]!.secret],
            'another-operation',
          );
          await repositories.proofRepository.setProofState(mintUrl, [inputs[0]!.secret], 'spent');
        } else {
          await repositories.sendOperationRepository.update({
            ...operation,
            token:
              invalid === 'missing-token'
                ? undefined
                : {
                    ...operation.token!,
                    proofs: operation.token!.proofs.map((proof) => ({
                      ...proof,
                      C: 'different-signature',
                    })),
                  },
          });
        }
        const before = await repositories.proofRepository.getProofsBySecrets(mintUrl, [
          ...new Set([...operation.inputProofSecrets, ...sendProofs.map((proof) => proof.secret)]),
        ]);
        const operationBefore = await repositories.sendOperationRepository.getById(operation.id);

        await expect(
          transactions.completePending({
            operationId: operation.id,
            updatedAt: 400,
            spentProofSecrets: sendProofs.map((proof) => proof.secret),
          }),
        ).rejects.toThrow();

        expect(await repositories.sendOperationRepository.getById(operation.id)).toEqual(
          operationBefore,
        );
        expect(
          await repositories.proofRepository.getProofsBySecrets(
            mintUrl,
            before.map((proof) => proof.secret),
          ),
        ).toEqual(before);
      },
    );

    if (method === 'swap') {
      it('requires token proofs to retain their creation ownership', async () => {
        const { repositories, transactions, operation, sendProofs } = await pending();
        await repositories.proofRepository.releaseProofs(mintUrl, operation.inputProofSecrets);
        await repositories.proofRepository.setCreatedByOperation(
          mintUrl,
          [sendProofs[0]!.secret],
          'another-operation',
        );

        await expect(
          transactions.completePending({
            operationId: operation.id,
            updatedAt: 400,
            spentProofSecrets: sendProofs.map((proof) => proof.secret),
          }),
        ).rejects.toThrow('not inflight and operation-owned');

        expect((await repositories.sendOperationRepository.getById(operation.id))?.state).toBe(
          'pending',
        );
        expect(
          (await repositories.proofRepository.getProofBySecret(mintUrl, sendProofs[0]!.secret))
            ?.state,
        ).toBe('inflight');
      });
    }

    it('rolls back remaining reservation releases when finalization conflicts', async () => {
      const { repositories, transactions, operation, inputs, sendProofs } = await pending(
        new RejectingSendTransitionRepositories(),
      );
      await repositories.proofRepository.setProofState(
        mintUrl,
        sendProofs.map((proof) => proof.secret),
        'spent',
      );
      await repositories.proofRepository.releaseProofs(mintUrl, [inputs[0]!.secret]);

      await expect(
        transactions.completePending({ operationId: operation.id, updatedAt: 400 }),
      ).rejects.toThrow('pending-state or revision conflict');

      expect((await repositories.sendOperationRepository.getById(operation.id))?.state).toBe(
        'pending',
      );
      expect(
        (await repositories.proofRepository.getProofBySecret(mintUrl, inputs[0]!.secret))
          ?.usedByOperationId,
      ).toBeUndefined();
      expect(
        (await repositories.proofRepository.getProofBySecret(mintUrl, inputs[1]!.secret))
          ?.usedByOperationId,
      ).toBe(operation.id);
    });
  },
);

describe('SendTransactions reclaim', () => {
  async function pending(repositories = new MemoryRepositories()) {
    const environment = await setup(repositories);
    await repositories.proofRepository.saveProofs(mintUrl, [proof('reclaim-input')]);
    const prepared = await environment.transactions.prepare(prepareInput('reclaim-send', false));
    const result = await environment.transactions.executeExact({
      operationId: prepared.operation.id,
      updatedAt: 300,
    });
    return { ...environment, operation: result.operation };
  }

  function reclaimProofs(
    outputData: NonNullable<PendingSendOperation['reclaimData']>['outputData'],
  ): CoreProof[] {
    const secrets = getSecretsFromSerializedOutputData(outputData).keepSecrets;
    return outputData.keep.map((output, index) => ({
      ...proof(secrets[index]!),
      amount: Amount.from(output.blindedMessage.amount),
      id: output.blindedMessage.id,
    }));
  }

  async function pendingP2pk() {
    const environment = await setup();
    const id = 'p2pk-refund-send';
    const original = { ...proof('original-input'), state: 'spent' as const };
    const sent = {
      ...proof('p2pk-send-secret'),
      state: 'inflight' as const,
      createdByOperationId: id,
    };
    const operation = {
      ...pendingSend(id, [original], [sent]),
      method: 'p2pk' as const,
      methodData: { pubkey: 'recipient' },
    };
    await environment.repositories.proofRepository.saveProofs(mintUrl, [sent]);
    await environment.repositories.sendOperationRepository.create(operation);
    return { ...environment, operation };
  }

  it('durably binds exact P2PK refund inputs and condition before returning authority', async () => {
    const { repositories, transactions, operation } = await pendingP2pk();
    const begun = await transactions.beginReclaim({
      operationId: operation.id,
      updatedAt: 400,
      activeKeys: keys,
      seed: new Uint8Array(32),
      spendingPath: 'refund',
      expectedRevision: operation.revision!,
      expectedInputProofSecrets: ['p2pk-send-secret'],
      conditionFingerprint: 'condition-fingerprint',
      refundPublicKeyX: '11'.repeat(32),
    });

    expect(begun.operation.state).toBe('rolling_back');
    expect(begun.operation.reclaimData).toMatchObject({
      spendingPath: 'refund',
      inputProofSecrets: ['p2pk-send-secret'],
      conditionFingerprint: 'condition-fingerprint',
      refundPublicKeyX: '11'.repeat(32),
    });
    expect(await repositories.sendOperationRepository.getById(operation.id)).toEqual(
      begun.operation,
    );
  });

  it('rejects stale revisions and non-exact P2PK refund input bindings without allocation', async () => {
    for (const mismatch of [
      { expectedRevision: 1, expectedInputProofSecrets: ['p2pk-send-secret'] },
      { expectedRevision: 2, expectedInputProofSecrets: ['different'] },
    ]) {
      const { repositories, transactions, operation } = await pendingP2pk();
      await expect(
        transactions.beginReclaim({
          operationId: operation.id,
          updatedAt: 400,
          activeKeys: keys,
          seed: new Uint8Array(32),
          spendingPath: 'refund',
          ...mismatch,
          conditionFingerprint: 'condition-fingerprint',
          refundPublicKeyX: '11'.repeat(32),
        }),
      ).rejects.toThrow();
      expect((await repositories.sendOperationRepository.getById(operation.id))?.state).toBe(
        'pending',
      );
      expect(await repositories.counterRepository.getCounter(mintUrl, keysetId)).toBeNull();
    }
  });

  it('commits reclaim allocation with rolling_back and atomically applies its proofs and releases inputs', async () => {
    const { repositories, transactions, operation } = await pending();
    const begun = await transactions.beginReclaim({
      operationId: operation.id,
      updatedAt: 400,
      activeKeys: keys,
      seed: new Uint8Array(32),
    });
    const stored = await repositories.sendOperationRepository.getById(operation.id);
    expect(stored?.state).toBe('rolling_back');
    expect(stored?.reclaimData).toEqual(begun.operation.reclaimData);
    expect(begun.counter?.counter).toBe(1);
    expect(
      (await repositories.proofRepository.getProofBySecret(mintUrl, 'reclaim-input'))?.state,
    ).toBe('inflight');

    const proofs = reclaimProofs(begun.operation.reclaimData!.outputData);
    const completed = await transactions.completeReclaim({
      operationId: operation.id,
      updatedAt: 500,
      reason: 'reclaimed',
      proofs,
    });
    expect(completed.operation.state).toBe('rolled_back');
    expect(completed.operation.token).toEqual(operation.token);
    expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual(proofs);
    const input = await repositories.proofRepository.getProofBySecret(mintUrl, 'reclaim-input');
    expect(input?.state).toBe('spent');
    expect(input?.usedByOperationId).toBeUndefined();
  });

  it('rolls back reclaim allocation when the pending-state transition conflicts', async () => {
    const { repositories, operation } = await pending();
    const rejecting = new CoreSendTransactions(
      new RepositoryCoreTransactionRunner(
        overrideTransactions(repositories, (fn) =>
          repositories.withTransaction((scope) =>
            fn({
              ...scope,
              sendOperationRepository: rejectTransitions(scope.sendOperationRepository),
            }),
          ),
        ),
      ),
    );
    await expect(
      rejecting.beginReclaim({
        operationId: operation.id,
        updatedAt: 400,
        activeKeys: keys,
        seed: new Uint8Array(32),
      }),
    ).rejects.toThrow('conflict');
    expect((await repositories.sendOperationRepository.getById(operation.id))?.state).toBe(
      'pending',
    );
    expect(await repositories.counterRepository.getCounter(mintUrl, keysetId)).toBeNull();
  });

  it('preserves allocation and every input when applying a reclaim result loses its transition', async () => {
    const { repositories, transactions, operation } = await pending();
    const begun = await transactions.beginReclaim({
      operationId: operation.id,
      updatedAt: 400,
      activeKeys: keys,
      seed: new Uint8Array(32),
    });
    const rejecting = new CoreSendTransactions(
      new RepositoryCoreTransactionRunner(
        overrideTransactions(repositories, (fn) =>
          repositories.withTransaction((scope) =>
            fn({
              ...scope,
              sendOperationRepository: rejectTransitions(scope.sendOperationRepository),
            }),
          ),
        ),
      ),
    );
    await expect(
      rejecting.completeReclaim({
        operationId: operation.id,
        updatedAt: 500,
        reason: 'reclaimed',
        proofs: reclaimProofs(begun.operation.reclaimData!.outputData),
      }),
    ).rejects.toThrow('conflict');
    const stored = await repositories.sendOperationRepository.getById(operation.id);
    expect(stored?.state).toBe('rolling_back');
    expect(stored?.reclaimData).toEqual(begun.operation.reclaimData);
    expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
    const input = await repositories.proofRepository.getProofBySecret(mintUrl, 'reclaim-input');
    expect(input?.state).toBe('inflight');
    expect(input?.usedByOperationId).toBe(operation.id);
    expect((await repositories.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(1);
  });

  it('rejects returned proofs that differ from the committed reclaim plan', async () => {
    const { repositories, transactions, operation } = await pending();
    await transactions.beginReclaim({
      operationId: operation.id,
      updatedAt: 400,
      activeKeys: keys,
      seed: new Uint8Array(32),
    });
    await expect(
      transactions.completeReclaim({
        operationId: operation.id,
        updatedAt: 500,
        reason: 'reclaimed',
        proofs: [proof('unexpected')],
      }),
    ).rejects.toThrow('allocated outputs');
    expect((await repositories.sendOperationRepository.getById(operation.id))?.state).toBe(
      'rolling_back',
    );
    expect(await repositories.proofRepository.getAvailableProofs(mintUrl)).toEqual([]);
  });
});

describe('SendTransactions legacy tokenless P2PK completion', () => {
  async function pending(repositories = new MemoryRepositories()) {
    const environment = await setup(repositories);
    const id = 'legacy-p2pk';
    const input = { ...proof('input'), state: 'spent' as const, usedByOperationId: id };
    const send = { ...proof('send'), state: 'inflight' as const, createdByOperationId: id };
    const operation: PendingSendOperation = {
      ...pendingSend(id, [input], [send]),
      method: 'p2pk',
      methodData: { pubkey: 'pubkey' },
      revision: 0,
      token: undefined,
    };
    await repositories.sendOperationRepository.create(operation);
    await repositories.proofRepository.saveProofs(mintUrl, [input]);
    const completion: CompletePendingSendInput = {
      operationId: id,
      updatedAt: 400,
      spentProofSecrets: [send.secret],
      legacyP2pkOutputObservation: {
        expectedRevision: 0,
        mintUrl,
        unit: 'sat',
        outputData: structuredClone(operation.outputData!),
      },
    };
    return { ...environment, operation, input, send, completion };
  }

  it.each(['reserved', 'released'] as const)(
    'completes missing spent outputs with %s inputs',
    async (ownership) => {
      const { repositories, transactions, operation, input, completion } = await pending();
      if (ownership === 'released')
        await repositories.proofRepository.releaseProofs(mintUrl, [input.secret]);
      const result = await transactions.completePending(completion);
      expect(result.operation).toMatchObject({ state: 'finalized', revision: 1 });
      expect(result.operation.token).toBeUndefined();
      expect(result.spentProofSecrets).toEqual([]);
      expect(result.releasedInputSecrets).toEqual(ownership === 'reserved' ? [input.secret] : []);
      expect(await repositories.proofRepository.getProofBySecret(mintUrl, 'send')).toBeNull();
      expect((await transactions.completePending(completion)).committed).toBe(false);
      expect((await repositories.sendOperationRepository.getById(operation.id))?.state).toBe(
        'finalized',
      );
    },
  );

  it.each([
    'missing',
    'incomplete',
    'duplicate',
    'foreign-secret',
    'revision',
    'mint',
    'unit',
    'allocation',
    'method',
    'current-revision',
    'token',
    'exact',
  ] as const)(
    'rejects %s evidence without changing the operation or releasing inputs',
    async (invalid) => {
      const { repositories, transactions, operation, input, send, completion } = await pending();
      switch (invalid) {
        case 'missing':
          delete completion.legacyP2pkOutputObservation;
          break;
        case 'incomplete':
          completion.spentProofSecrets = [];
          break;
        case 'duplicate':
          completion.spentProofSecrets = [send.secret, send.secret];
          break;
        case 'foreign-secret':
          completion.spentProofSecrets = ['foreign'];
          break;
        case 'revision':
          completion.legacyP2pkOutputObservation!.expectedRevision = 1;
          break;
        case 'mint':
          completion.legacyP2pkOutputObservation!.mintUrl = 'https://other.test';
          break;
        case 'unit':
          completion.legacyP2pkOutputObservation!.unit = 'usd';
          break;
        case 'allocation':
          completion.legacyP2pkOutputObservation!.outputData.send[0]!.blindedMessage.B_ = 'changed';
          break;
        case 'method':
          await repositories.sendOperationRepository.update({
            ...operation,
            method: 'default',
            methodData: {},
          });
          break;
        case 'current-revision':
          await repositories.sendOperationRepository.update({ ...operation, revision: 1 });
          break;
        case 'token':
          await repositories.sendOperationRepository.update({
            ...operation,
            token: { mint: mintUrl, unit: 'sat', proofs: [send] },
          });
          break;
        case 'exact':
          await repositories.sendOperationRepository.update({ ...operation, needsSwap: false });
          break;
      }
      const before = await repositories.sendOperationRepository.getById(operation.id);
      await expect(transactions.completePending(completion)).rejects.toThrow();
      expect(await repositories.sendOperationRepository.getById(operation.id)).toEqual(before);
      expect(
        await repositories.proofRepository.getProofBySecret(mintUrl, input.secret),
      ).toMatchObject(input);
    },
  );

  it.each([
    'input-owner',
    'input-state',
    'output-owner',
    'output-state',
    'output-id',
    'output-amount',
    'transition',
  ] as const)('rolls back all proof writes after %s conflicts', async (conflict) => {
    const { repositories, transactions, operation, input, send, completion } = await pending(
      conflict === 'transition' ? new RejectingSendTransitionRepositories() : undefined,
    );
    const storedInput: CoreProof = { ...input };
    const storedSend: CoreProof = { ...send };
    switch (conflict) {
      case 'input-owner':
        storedInput.usedByOperationId = 'other';
        break;
      case 'input-state':
        storedInput.state = 'ready';
        break;
      case 'output-owner':
        storedSend.createdByOperationId = 'other';
        break;
      case 'output-state':
        storedSend.state = 'ready';
        break;
      case 'output-id':
        storedSend.id = 'other';
        break;
      case 'output-amount':
        storedSend.amount = Amount.from(20);
        break;
    }
    await repositories.proofRepository.deleteProofs(mintUrl, [input.secret]);
    await repositories.proofRepository.saveProofs(mintUrl, [storedInput, storedSend]);
    const before = await repositories.sendOperationRepository.getById(operation.id);
    await expect(transactions.completePending(completion)).rejects.toThrow();
    expect(await repositories.sendOperationRepository.getById(operation.id)).toEqual(before);
    expect(
      await repositories.proofRepository.getProofBySecret(mintUrl, input.secret),
    ).toMatchObject(storedInput);
    expect(await repositories.proofRepository.getProofBySecret(mintUrl, send.secret)).toMatchObject(
      storedSend,
    );
  });
});
