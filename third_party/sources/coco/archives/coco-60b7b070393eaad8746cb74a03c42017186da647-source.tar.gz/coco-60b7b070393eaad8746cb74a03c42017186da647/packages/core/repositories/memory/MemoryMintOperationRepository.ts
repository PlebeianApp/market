import type { MintOperationRepository } from '..';
import type { MintOperation, MintOperationState } from '../../operations/mint/MintOperation';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryArraySort,
  memoryMapDelete,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';
import { MemoryOperationIdOwnership } from '../OperationIdOwnership.ts';

export class MemoryMintOperationRepository implements MintOperationRepository {
  private operations = createMemoryMap<string, MintOperation>();

  constructor(private readonly operationIds = new MemoryOperationIdOwnership()) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemoryMintOperationRepository): void {
    this.operations = cloneMemoryRepositoryStateValue(source.operations);
    this.operationIds.copyFrom(source.operationIds);
  }

  async create(operation: MintOperation): Promise<void> {
    if (memoryMapHas(this.operations, operation.id)) {
      throw new Error(`MintOperation with id ${operation.id} already exists`);
    }
    this.operationIds.claim(operation.id, 'mint');
    memoryMapSet(this.operations, operation.id, cloneMemoryValue(operation));
  }

  async update(operation: MintOperation): Promise<void> {
    if (!memoryMapHas(this.operations, operation.id)) {
      throw new Error(`MintOperation with id ${operation.id} not found`);
    }
    memoryMapSet(
      this.operations,
      operation.id,
      cloneMemoryValue({ ...operation, updatedAt: Date.now() }),
    );
  }

  async getById(id: string): Promise<MintOperation | null> {
    const operation = memoryMapGet(this.operations, id);
    return operation ? cloneMemoryValue(operation) : null;
  }

  async getByState(state: MintOperationState): Promise<MintOperation[]> {
    const results: MintOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (operation.state === state) {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getPending(): Promise<MintOperation[]> {
    const results: MintOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (operation.state === 'pending' || operation.state === 'executing') {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getByMintUrl(mintUrl: string): Promise<MintOperation[]> {
    const results: MintOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (operation.mintUrl === mintUrl) {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return results;
  }

  async getByQuoteId(mintUrl: string, method: string, quoteId: string): Promise<MintOperation[]> {
    const results: MintOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const operation = operations[index]!;
      if (
        operation.mintUrl === mintUrl &&
        operation.method === method &&
        'quoteId' in operation &&
        operation.quoteId === quoteId
      ) {
        memoryArrayPush(results, cloneMemoryValue(operation));
      }
    }
    return memoryArraySort(
      results,
      (a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id),
    );
  }

  async getAll(): Promise<MintOperation[]> {
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      operations[index] = cloneMemoryValue(operations[index]!);
    }
    return operations;
  }

  async delete(id: string): Promise<void> {
    memoryMapDelete(this.operations, id);
  }
}
