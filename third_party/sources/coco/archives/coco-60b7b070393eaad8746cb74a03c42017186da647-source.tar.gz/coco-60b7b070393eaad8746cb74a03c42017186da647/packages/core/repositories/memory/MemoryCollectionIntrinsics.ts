const NativeArray = Array;
const NativeArrayBuffer = ArrayBuffer;
const NativeMap = Map;
const NativePromise = Promise;
const NativeSet = Set;
const NativeUint8Array = Uint8Array;
const maybeNativeBuffer = (
  globalThis as typeof globalThis & { Buffer?: { readonly prototype: object } }
).Buffer;
const nativeArrayBufferIsView = ArrayBuffer.isView;
const nativeGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
const nativeGetPrototypeOf = Object.getPrototypeOf;
const nativeReflectApply = Reflect.apply;
const nativeArraySort = Array.prototype.sort;
const nativeMapClear = Map.prototype.clear;
const nativeMapDelete = Map.prototype.delete;
const nativeMapEntries = Map.prototype.entries;
const nativeMapGet = Map.prototype.get;
const nativeMapHas = Map.prototype.has;
const nativeMapKeys = Map.prototype.keys;
const nativeMapSet = Map.prototype.set;
const nativeMapValues = Map.prototype.values;
const nativePromiseResolve = Promise.resolve;
const nativeMathMax = Math.max;
const nativeMathMin = Math.min;
const nativeSetAdd = Set.prototype.add;
const nativeSetClear = Set.prototype.clear;
const nativeSetDelete = Set.prototype.delete;
const nativeSetHas = Set.prototype.has;
const nativeSetValues = Set.prototype.values;
const nativeMapPrototype = Map.prototype;
const nativeSetPrototype = Set.prototype;
const nativeUint8ArrayPrototype = Uint8Array.prototype;
const nativeTypedArrayPrototype = nativeGetPrototypeOf(nativeUint8ArrayPrototype);
const nativeTypedArrayLengthGetter = nativeGetOwnPropertyDescriptor(
  nativeTypedArrayPrototype,
  'length',
)!.get!;
const nativeBufferPrototype = maybeNativeBuffer?.prototype ?? null;
const nativeMapEntryIteratorNext = nativeGetPrototypeOf(
  nativeReflectApply(nativeMapEntries, new NativeMap(), []),
).next as () => IteratorResult<[unknown, unknown]>;
const nativeMapKeyIteratorNext = nativeGetPrototypeOf(
  nativeReflectApply(nativeMapKeys, new NativeMap(), []),
).next as () => IteratorResult<unknown>;
const nativeMapValueIteratorNext = nativeGetPrototypeOf(
  nativeReflectApply(nativeMapValues, new NativeMap(), []),
).next as () => IteratorResult<unknown>;
const nativeSetValueIteratorNext = nativeGetPrototypeOf(
  nativeReflectApply(nativeSetValues, new NativeSet(), []),
).next as () => IteratorResult<unknown>;

export function createMemoryMap<Key, Value>(): Map<Key, Value> {
  return new NativeMap<Key, Value>();
}

export function memoryMapGet<Key, Value>(map: Map<Key, Value>, key: Key): Value | undefined {
  return nativeReflectApply(nativeMapGet, map, [key]) as Value | undefined;
}

export function memoryMapHas<Key, Value>(map: Map<Key, Value>, key: Key): boolean {
  return nativeReflectApply(nativeMapHas, map, [key]) as boolean;
}

export function memoryMapSet<Key, Value>(map: Map<Key, Value>, key: Key, value: Value): void {
  nativeReflectApply(nativeMapSet, map, [key, value]);
}

export function memoryMapDelete<Key, Value>(map: Map<Key, Value>, key: Key): boolean {
  return nativeReflectApply(nativeMapDelete, map, [key]) as boolean;
}

export function memoryMapClear<Key, Value>(map: Map<Key, Value>): void {
  nativeReflectApply(nativeMapClear, map, []);
}

export function memoryMapEntries<Key, Value>(map: Map<Key, Value>): Array<[Key, Value]> {
  const entries = new NativeArray<[Key, Value]>();
  const iterator = nativeReflectApply(nativeMapEntries, map, []) as MapIterator<[Key, Value]>;
  while (true) {
    const next = nativeReflectApply(nativeMapEntryIteratorNext, iterator, []) as IteratorResult<
      [Key, Value]
    >;
    if (next.done) return entries;
    entries[entries.length] = [next.value[0], next.value[1]];
  }
}

export function memoryMapKeys<Key, Value>(map: Map<Key, Value>): Key[] {
  const keys = new NativeArray<Key>();
  const iterator = nativeReflectApply(nativeMapKeys, map, []) as MapIterator<Key>;
  while (true) {
    const next = nativeReflectApply(nativeMapKeyIteratorNext, iterator, []) as IteratorResult<Key>;
    if (next.done) return keys;
    keys[keys.length] = next.value;
  }
}

export function memoryMapValues<Key, Value>(map: Map<Key, Value>): Value[] {
  const values = new NativeArray<Value>();
  const iterator = nativeReflectApply(nativeMapValues, map, []) as MapIterator<Value>;
  while (true) {
    const next = nativeReflectApply(
      nativeMapValueIteratorNext,
      iterator,
      [],
    ) as IteratorResult<Value>;
    if (next.done) return values;
    values[values.length] = next.value;
  }
}

export function copyMemoryMap<Key, Value>(source: Map<Key, Value>): Map<Key, Value> {
  const copy = createMemoryMap<Key, Value>();
  const entries = memoryMapEntries(source);
  for (let index = 0; index < entries.length; index += 1) {
    const entry = entries[index]!;
    memoryMapSet(copy, entry[0], entry[1]);
  }
  return copy;
}

export function createMemorySet<Value>(values?: readonly Value[]): Set<Value> {
  const set = new NativeSet<Value>();
  if (!values) return set;
  for (let index = 0; index < values.length; index += 1) {
    memorySetAdd(set, values[index]!);
  }
  return set;
}

export function memorySetAdd<Value>(set: Set<Value>, value: Value): void {
  nativeReflectApply(nativeSetAdd, set, [value]);
}

export function memorySetHas<Value>(set: Set<Value>, value: Value): boolean {
  return nativeReflectApply(nativeSetHas, set, [value]) as boolean;
}

export function memorySetDelete<Value>(set: Set<Value>, value: Value): boolean {
  return nativeReflectApply(nativeSetDelete, set, [value]) as boolean;
}

export function memorySetClear<Value>(set: Set<Value>): void {
  nativeReflectApply(nativeSetClear, set, []);
}

export function memorySetValues<Value>(set: Set<Value>): Value[] {
  const values = new NativeArray<Value>();
  const iterator = nativeReflectApply(nativeSetValues, set, []) as SetIterator<Value>;
  while (true) {
    const next = nativeReflectApply(
      nativeSetValueIteratorNext,
      iterator,
      [],
    ) as IteratorResult<Value>;
    if (next.done) return values;
    values[values.length] = next.value;
  }
}

export function memoryArrayPush<Value>(array: Value[], value: Value): void {
  array[array.length] = value;
}

export function memoryArrayRemoveAt<Value>(array: Value[], index: number): void {
  if (index < 0 || index >= array.length) return;
  for (let cursor = index; cursor + 1 < array.length; cursor += 1) {
    array[cursor] = array[cursor + 1]!;
  }
  array.length -= 1;
}

export function memoryArrayIndexOf<Value>(array: readonly Value[], value: Value): number {
  for (let index = 0; index < array.length; index += 1) {
    if (array[index] === value) return index;
  }
  return -1;
}

export function memoryArraySlice<Value>(
  array: readonly Value[],
  start: number,
  end = array.length,
): Value[] {
  const result = new NativeArray<Value>();
  const normalizedStart = nativeMathMax(0, nativeMathMin(array.length, start));
  const normalizedEnd = nativeMathMax(normalizedStart, nativeMathMin(array.length, end));
  for (let index = normalizedStart; index < normalizedEnd; index += 1) {
    result[result.length] = array[index]!;
  }
  return result;
}

export function memoryArrayCopy<Value>(array: readonly Value[]): Value[] {
  return memoryArraySlice(array, 0);
}

export function memoryArraySort<Value>(
  array: Value[],
  compare: (left: Value, right: Value) => number,
): Value[] {
  return nativeReflectApply(nativeArraySort, array, [compare]) as Value[];
}

export function createMemoryPromise<Value>(
  executor: (
    resolve: (value: Value | PromiseLike<Value>) => void,
    reject: (reason?: unknown) => void,
  ) => void,
): Promise<Value> {
  return new NativePromise<Value>(executor);
}

export function resolveMemoryPromise<Value>(value: Value | PromiseLike<Value>): Promise<Value> {
  return nativeReflectApply(nativePromiseResolve, NativePromise, [value]) as Promise<Value>;
}

export function isMemoryMap(value: object): value is Map<unknown, unknown> {
  return hasPrototype(value, nativeMapPrototype);
}

export function isMemorySet(value: object): value is Set<unknown> {
  return hasPrototype(value, nativeSetPrototype);
}

export function isMemoryBytes(value: object): value is Uint8Array {
  if (!nativeReflectApply(nativeArrayBufferIsView, NativeArrayBuffer, [value])) return false;
  const prototype = nativeGetPrototypeOf(value);
  return prototype === nativeUint8ArrayPrototype || prototype === nativeBufferPrototype;
}

export function cloneMemoryBytes(value: Uint8Array): Uint8Array {
  const length = memoryBytesLength(value);
  const copy = new NativeUint8Array(length);
  for (let index = 0; index < length; index += 1) copy[index] = value[index]!;
  return copy;
}

export function memoryBytesLength(value: Uint8Array): number {
  return nativeReflectApply(nativeTypedArrayLengthGetter, value, []) as number;
}

function hasPrototype(value: object, expected: object): boolean {
  let prototype = nativeGetPrototypeOf(value);
  while (prototype !== null) {
    if (prototype === expected) return true;
    prototype = nativeGetPrototypeOf(prototype);
  }
  return false;
}
