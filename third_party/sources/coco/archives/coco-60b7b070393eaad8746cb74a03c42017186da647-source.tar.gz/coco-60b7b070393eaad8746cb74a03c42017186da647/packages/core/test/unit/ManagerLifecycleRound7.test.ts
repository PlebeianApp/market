import { describe, expect, test } from 'bun:test';

const CORE_ROOT = '/home/maximoto/dev/coco-market-prod-2026-09-21/packages/core';
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

type Call = { path: string; call: () => unknown };

function collectApiCalls(root: any, prefix: string, calls: Call[]): void {
  for (const key of Object.keys(root)) {
    if (prefix === 'subscriptions' && (key === 'getDiagnostics' || key === 'unsubscribe')) continue;
    const value = root[key];
    const path = `${prefix}.${key}`;
    if (typeof value === 'function') calls.push({ path, call: () => value() });
    else if (value && typeof value === 'object') collectApiCalls(value, path, calls);
  }
}

async function expectLifecycleRejection(call: Call): Promise<void> {
  let error: any;
  try {
    await call.call();
  } catch (caught) {
    error = caught;
  }
  expect(error?.name, call.path).toBe('WalletAuthorityLifecycleError');
}

async function probeApiGraph(label: string, modulePath: string): Promise<void> {
  const core: any = await import(modulePath);
  let fetchCalls = 0;
  let seedCalls = 0;
  let logCalls = 0;
  let socketCalls = 0;
  const originalFetch = globalThis.fetch;
  globalThis.fetch = (async () => {
    fetchCalls += 1;
    throw new Error('network probe');
  }) as unknown as typeof fetch;
  const logger = {
    error() {
      logCalls += 1;
    },
    warn() {
      logCalls += 1;
    },
    info() {
      logCalls += 1;
    },
    debug() {
      logCalls += 1;
    },
    child() {
      return this;
    },
  };
  const makeManager = () =>
    new core.Manager(
      new core.MemoryRepositories(),
      async () => {
        seedCalls += 1;
        return new Uint8Array(64);
      },
      logger,
      () => {
        socketCalls += 1;
        return { send() {}, close() {}, addEventListener() {}, removeEventListener() {} };
      },
    );

  const exercise = async (manager: any) => {
    const calls: Call[] = [];
    for (const key of [
      'mint',
      'wallet',
      'keyring',
      'history',
      'auth',
      'ops',
      'quotes',
      'paymentRequests',
      'subscriptions',
    ]) {
      collectApiCalls(manager[key], key, calls);
    }
    expect(calls.length).toBeGreaterThan(80);
    for (const call of calls) await expectLifecycleRejection(call);

    const exclusions = new Set(['constructor', 'dispose', 'off']);
    for (const name of Object.getOwnPropertyNames(core.Manager.prototype)) {
      if (exclusions.has(name)) continue;
      const descriptor = Object.getOwnPropertyDescriptor(core.Manager.prototype, name);
      if (typeof descriptor?.value !== 'function') continue;
      await expectLifecycleRejection({
        path: `Manager.${name}`,
        call: () => Reflect.apply(descriptor.value, manager, []),
      });
    }
    expect(manager.subscriptions.getDiagnostics()).toMatchObject({
      activeMintCount: 0,
      transportCount: 0,
      paused: true,
    });
  };

  try {
    const direct = makeManager();
    fetchCalls = seedCalls = logCalls = socketCalls = 0;
    await exercise(direct);
    expect({ fetchCalls, seedCalls, logCalls, socketCalls }).toEqual({
      fetchCalls: 0,
      seedCalls: 0,
      logCalls: 0,
      socketCalls: 0,
    });
    await direct.dispose();

    const active = await core.initializeCoco({
      repo: new core.MemoryRepositories(),
      seedGetter: async () => new Uint8Array(64),
      logger,
      ...disabledRuntime,
    });
    await active.dispose();
    fetchCalls = seedCalls = logCalls = socketCalls = 0;
    await exercise(active);
    expect({ fetchCalls, seedCalls, logCalls, socketCalls }).toEqual({
      fetchCalls: 0,
      seedCalls: 0,
      logCalls: 0,
      socketCalls: 0,
    });
  } finally {
    globalThis.fetch = originalFetch;
  }
}

async function probeBoundedDisposal(label: string, modulePath: string): Promise<void> {
  const core: any = await import(modulePath);
  const repositories = new core.MemoryRepositories();
  const sockets: Array<{ closed: boolean }> = [];
  let retainedServices: any;
  let handlerStarted = false;
  let disposeHookStarted = false;
  let cleanupStarted = false;
  const never = Object.create(null, {
    then: {
      enumerable: true,
      value() {},
    },
  });
  const manager = await core.initializeCoco({
    repo: repositories,
    seedGetter: async () => new Uint8Array(64),
    authority: { namespace: `round7-deadline-${label}`, ownerId: 'old-owner' },
    lifecycle: { disposeTimeoutMs: 40 },
    webSocketFactory() {
      const socket = {
        closed: false,
        send() {},
        close() {
          this.closed = true;
        },
        addEventListener() {},
        removeEventListener() {},
      };
      sockets.push(socket);
      return socket;
    },
    plugins: [
      {
        name: `bounded-disposal-${label}`,
        required: ['eventBus', 'subscriptions', 'counterService'],
        onInit({ services }: any) {
          retainedServices = services;
          services.eventBus.on('subscriptions:paused', () => {
            handlerStarted = true;
            return never;
          });
          return () => {
            cleanupStarted = true;
            return never;
          };
        },
        onDispose() {
          disposeHookStarted = true;
          return never;
        },
      },
    ],
    ...disabledRuntime,
  });
  await retainedServices.subscriptions.subscribe(
    'https://round7-deadline.invalid',
    'bolt11_mint_quote',
    ['quote'],
  );
  await manager.pauseSubscriptions();
  expect(handlerStarted).toBe(true);

  const started = Date.now();
  const first = manager.dispose();
  const second = manager.dispose();
  expect(sockets.length).toBeGreaterThan(0);
  expect(sockets.every((socket) => socket.closed)).toBe(true);
  const outcomes = await Promise.allSettled([first, second]);
  const elapsed = Date.now() - started;
  expect(outcomes.every((outcome) => outcome.status === 'rejected')).toBe(true);
  expect(elapsed).toBeLessThan(500);
  expect(disposeHookStarted).toBe(true);
  expect(cleanupStarted).toBe(true);

  const successorRepositories = repositories.createPeer();
  const successor = await core.initializeCoco({
    repo: successorRepositories,
    seedGetter: async () => new Uint8Array(64),
    authority: { namespace: `round7-deadline-${label}`, ownerId: 'new-owner' },
    ...disabledRuntime,
  });
  try {
    await expect(
      retainedServices.counterService.overwriteCounter(
        'https://round7-deadline.invalid',
        'keyset',
        41,
      ),
    ).rejects.toThrow();
    expect(
      await successorRepositories.counterRepository.getCounter(
        'https://round7-deadline.invalid',
        'keyset',
      ),
    ).toBeNull();
  } finally {
    await successor.dispose();
  }
}

for (const [label, modulePath] of [
  ['source', `${CORE_ROOT}/index.ts`],
  ['dist', `${CORE_ROOT}/dist/index.js`],
] as const) {
  describe(`round-seven Manager lifecycle (${label})`, () => {
    test('fences the complete public and nested API graph with zero observable work', () =>
      probeApiGraph(label, modulePath));
    test('bounds hostile work, closes resources, releases authority, and permits a successor', () =>
      probeBoundedDisposal(label, modulePath));
  });
}
