import {
  Amount,
  OutputData,
  type OutputDataCreator,
  type Proof,
  type Token,
  type ProofState as CashuProofState,
} from '@cashu/cashu-ts';
import type { MintService } from '@core/services/MintService.ts';
import type { ProofQueries } from '@core/proofs/ProofQueries.ts';
import { createKeyChain } from '@core/proofs/KeysetSelection.ts';
import type { MintMetadata, MintQueries } from '@core/mints/MintMetadata.ts';
import type {
  SendOperation,
  InitSendOperation,
  PreparedSendOperation,
  ExecutingSendOperation,
  PendingSendOperation,
  RollingBackSendOperation,
} from './SendOperation';
import {
  createSendOperation,
  isLegacyTokenlessP2pkSend,
  getSendProofSecrets,
  type CreateSendOperationOptions,
} from './SendOperation';
import type { SendMethod, SendMethodData } from './SendMethodHandler';
import { SendHandlerProvider } from '../../infra/handlers/send/SendHandlerProvider';
import type { EventBus } from '../../events/EventBus';
import type { CoreEvents } from '../../events/types';
import type { Logger } from '../../logging/Logger';
import {
  generateSubId,
  getProofStateInputsFromSerializedOutputs,
  getSecretsFromSerializedOutputData,
  mapProofToCoreProof,
  normalizeMintUrl,
  serializeOutputData,
  validateCallerOperationId,
} from '../../utils';
import {
  MintOperationError,
  UnknownMintError,
  ProofValidationError,
  OperationInProgressError,
  SendOperationConflictError,
} from '../../models/Error';
import { MintScopedLock } from '../MintScopedLock';
import { OperationIdLock } from '../OperationIdLock';
import { normalizeUnit, normalizeUnitAmount, type UnitAmount } from '../../amounts.ts';
import type { SendTransactions } from '../../transactions/send/SendTransactions.ts';
import type { PreparedSendResult } from '../../transactions/send/types.ts';
import type {
  AppliedSwapResult,
  BegunReclaim,
  CompletedReclaim,
  CancelledPreparedSend,
  CompletedPendingSend,
  CompletePendingSendInput,
  FailedSwapExecution,
  SwapTransportRequest,
} from '../../transactions/send/types.ts';
import type { SendOperationQueries } from './SendOperationQueries.ts';
import type { ReclaimOutputObservation, SendRemote, SendRemoteSession } from './SendRemote.ts';
import {
  cloneRefundOutputData,
  freezeRefundOutputData,
  serializeCommittedRefundReclaimPlan,
  serializeRefundOperationBinding,
  serializeRefundValue,
  verifyCommittedRefundReclaimPlan,
  type CommittedRefundReclaimPlan,
  type RefundReclaimPlan,
  type RefundReclaimAuthorization,
} from './RefundReclaimPlan.ts';

interface AuthenticatedRefundReclaim {
  inputProofs: Proof[];
  outputData: NonNullable<RollingBackSendOperation['reclaimData']>['outputData'];
  authorization: RefundReclaimAuthorization;
}

const nativeStructuredClone = structuredClone;
const nativeReflectApply = Reflect.apply;
const nativeAmountFrom = Amount.from;
const nativeAmountToBigInt = Amount.prototype.toBigInt;
const NativeUint8Array = Uint8Array;

function zeroOwnedSeed(seed: Uint8Array): void {
  for (let index = 0; index < seed.length; index++) seed[index] = 0;
}

// Explicit request-validation rejections from NUT error_codes.md. Unknown errors
// do not establish non-effect and must retain the request for recovery.
const DEFINITIVE_SWAP_MINT_ERROR_CODES = new Set([
  10001, 11005, 11007, 11008, 11009, 11010, 11014, 11015, 12001, 12002, 12003,
]);

type SwapExecutionOutcome =
  | { status: 'PENDING'; result: AppliedSwapResult }
  | { status: 'FAILED'; result: FailedSwapExecution; error: MintOperationError };

export interface SendOperationServiceDependencies {
  operationQueries: SendOperationQueries;
  proofQueries: ProofQueries;
  transactions: SendTransactions;
  mintQueries: { isTrustedMint(mintUrl: string): Promise<boolean> };
  mintMetadataQueries: Pick<MintQueries, 'getMetadata'>;
  mintMetadataRefresh: Pick<MintService, 'refreshAndCommitIfStale'>;
  remote: SendRemote;
  /** Returns a fresh owned seed buffer; refund workflows zeroize it after use. */
  loadSeed: () => Promise<Uint8Array>;
  eventBus: Pick<EventBus<CoreEvents>, 'emit'>;
  handlerProvider: SendHandlerProvider;
  outputDataCreator?: OutputDataCreator;
  logger?: Logger;
  mintScopedLock?: MintScopedLock;
  /** @internal Captures boot recovery without retaining or publicly exposing the callback. */
  registerRecoveryTask?: (task: () => Promise<void>) => void;
}

/**
 * Options applied when a prepared send operation is executed.
 */
export interface ExecuteSendOptions {
  /** Optional memo to persist on the shareable token. Whitespace-only memos are ignored. */
  memo?: string;
}

/**
 * Service that manages send operations as sagas.
 *
 * This service provides crash recovery and rollback capabilities for send operations
 * by breaking them into discrete steps: init → prepare → execute → finalize/rollback.
 */
export class SendOperationService {
  readonly #operationQueries: SendOperationQueries;
  readonly #proofQueries: ProofQueries;
  readonly #transactions: SendTransactions;
  readonly #mintQueries: SendOperationServiceDependencies['mintQueries'];
  readonly #mintMetadataQueries: Pick<MintQueries, 'getMetadata'>;
  readonly #mintMetadataRefresh: Pick<MintService, 'refreshAndCommitIfStale'>;
  readonly #remote: SendRemote;
  readonly #loadSeed: () => Promise<Uint8Array>;
  readonly #eventBus: Pick<EventBus<CoreEvents>, 'emit'>;
  readonly #handlerProvider: SendHandlerProvider;
  readonly #logger?: Logger;
  readonly #outputDataCreator: OutputDataCreator;

  /** In-memory lock to prevent concurrent operations on the same operation ID */
  readonly #operationIdLock = new OperationIdLock();
  /** Lock for the global recovery process */
  #recoveryLock: Promise<void> | null = null;
  /** In-memory lock to serialize proof selection/reservation per mint */
  readonly #mintScopedLock: MintScopedLock;

  constructor(dependencies: SendOperationServiceDependencies) {
    this.#operationQueries = dependencies.operationQueries;
    this.#proofQueries = dependencies.proofQueries;
    this.#transactions = dependencies.transactions;
    this.#mintQueries = dependencies.mintQueries;
    this.#mintMetadataQueries = dependencies.mintMetadataQueries;
    this.#mintMetadataRefresh = dependencies.mintMetadataRefresh;
    this.#remote = dependencies.remote;
    this.#loadSeed = dependencies.loadSeed;
    this.#eventBus = dependencies.eventBus;
    this.#handlerProvider = dependencies.handlerProvider;
    this.#logger = dependencies.logger;
    this.#outputDataCreator = dependencies.outputDataCreator ?? OutputData;
    this.#mintScopedLock = dependencies.mintScopedLock ?? new MintScopedLock();
    dependencies.registerRecoveryTask?.(() => this.#recoverPendingOperations());
  }

  /**
   * Acquire a lock for an operation.
   * Returns a release function that must be called when the operation completes.
   * Throws if the operation is already locked.
   */
  async #acquireOperationLock(operationId: string): Promise<() => void> {
    return this.#operationIdLock.acquire(operationId);
  }

  /**
   * Check if an operation is currently locked.
   */
  isOperationLocked(operationId: string): boolean {
    return this.#operationIdLock.isLocked(operationId);
  }

  /**
   * Check if recovery is currently in progress.
   */
  isRecoveryInProgress(): boolean {
    return this.#recoveryLock !== null;
  }

  /**
   * Create a new send operation.
   * This is the entry point for the saga.
   */
  async init<M extends SendMethod = 'default'>(
    mintUrl: string,
    amount: UnitAmount,
    options: CreateSendOperationOptions<M> = {
      method: 'default' as M,
      methodData: {} as SendMethodData<M>,
    },
  ): Promise<InitSendOperation> {
    mintUrl = normalizeMintUrl(mintUrl);
    const parsed = normalizeUnitAmount(amount);
    const trusted = await this.#mintQueries.isTrustedMint(mintUrl);
    if (!trusted) {
      throw new UnknownMintError(`Mint ${mintUrl} is not trusted`);
    }

    if (parsed.amount.isZero()) {
      throw new ProofValidationError('Amount must be a positive number');
    }

    const id = this.#resolveOperationId(options.operationId);
    const operation = createSendOperation(id, mintUrl, parsed, options);

    this.#logger?.debug('Send operation initialized in memory', {
      operationId: id,
      mintUrl,
      amount: parsed.amount,
      unit: parsed.unit,
      method: options.method,
    });

    return operation;
  }

  /**
   * Use the caller's operation ID verbatim when one is supplied, so it matches the host's durable
   * command record and stays unique across restarts. Otherwise generate a sub-ID as before.
   */
  #resolveOperationId(operationId?: string): string {
    if (operationId === undefined) {
      return generateSubId();
    }

    // Identity is exact: silently trimming (or accepting a blank key) would make two different host
    // commands collide on the same operation.
    validateCallerOperationId(operationId);

    return operationId;
  }

  /**
   * Prepare the operation by reserving proofs and creating outputs.
   * After this step, the operation can be executed or rolled back.
   *
   * Caller-supplied IDs are resolved atomically by the Send transaction command. Matching intent
   * joins the existing prepared operation; conflicting immutable intent or state fails closed.
   */
  async prepare(operation: InitSendOperation): Promise<PreparedSendOperation> {
    if (operation.callerSuppliedId === true) {
      return this.#prepareLocked(operation, () => {});
    }
    return this.#prepareLocked(operation, await this.#acquireOperationLock(operation.id));
  }

  async #prepareLocked(
    operation: InitSendOperation,
    releaseLock: () => void,
  ): Promise<PreparedSendOperation> {
    let result: PreparedSendResult;
    try {
      const releaseMintLock = await this.#mintScopedLock.acquire(operation.mintUrl);
      try {
        const handler = this.#handlerProvider.get(operation.method);
        if (!(await this.#mintQueries.isTrustedMint(operation.mintUrl))) {
          throw new UnknownMintError(`Mint ${operation.mintUrl} is not trusted`);
        }
        const metadata = await this.#mintMetadataRefresh.refreshAndCommitIfStale(operation.mintUrl);
        const keys = this.#activeKeys(metadata, operation.unit);
        const seed = await this.#loadSeed();
        const plan = handler.prepare({
          operation,
          activeKeys: keys,
          mintInfo: metadata.mint.mintInfo,
          outputDataCreator: this.#outputDataCreator,
        });
        result = await this.#transactions.prepare({
          operation: { ...operation, updatedAt: Date.now() },
          activeKeys: keys,
          seed,
          ...plan,
        });
      } finally {
        releaseMintLock();
      }
    } finally {
      releaseLock();
    }
    await this.#publishPrepared(result);
    return result.operation;
  }

  /**
   * Execute the prepared operation.
   * Performs the swap (if needed) and creates the token.
   * If a memo is provided, trims it and persists it on the token before saving the
   * pending operation. Whitespace-only memos are omitted.
   *
   * Swap execution commits the exact request before contacting the mint and applies a successful
   * response in a second atomic transition. Ambiguous outcomes remain executing for recovery.
   * Throws if the operation is already in progress.
   */
  async execute(
    operation: PreparedSendOperation,
    options?: ExecuteSendOptions,
  ): Promise<{ operation: PendingSendOperation; token: Token }> {
    const current = await this.#operationQueries.getById(operation.id);
    if (!current) {
      throw new SendOperationConflictError(
        operation.id,
        `Send operation ${operation.id} not found`,
      );
    }
    if (current.state !== 'prepared' && !(current.state === 'pending' && !current.needsSwap)) {
      throw new SendOperationConflictError(
        operation.id,
        `Cannot execute Send operation in state ${current.state}`,
      );
    }
    return current.needsSwap
      ? this.#executePreparedSwap(current.id, options)
      : this.#executeExactMatch(current.id, options?.memo);
  }

  async #executePreparedSwap(
    operationId: string,
    options?: ExecuteSendOptions,
  ): Promise<{ operation: PendingSendOperation; token: Token }> {
    const releaseLock = await this.#acquireOperationLock(operationId);
    let outcome: SwapExecutionOutcome | undefined;
    try {
      const current = await this.#operationQueries.getById(operationId);
      if (!current) {
        throw new Error(`Operation ${operationId} not found`);
      }
      if (current.state !== 'prepared') {
        throw new SendOperationConflictError(
          operationId,
          `Cannot execute Send operation in state ${current.state}`,
        );
      }

      outcome = await this.#executeSwap(current, options);
    } finally {
      releaseLock();
    }

    if (!outcome) {
      throw new Error(`Send operation ${operationId} did not produce a pending result`);
    }
    if (outcome.status === 'FAILED') {
      await this.#publishFailedSwap(outcome.result);
      throw outcome.error;
    }
    await this.#publishAppliedSwap(outcome.result);
    return { operation: outcome.result.operation, token: outcome.result.operation.token! };
  }

  async #executeSwap(
    operation: PreparedSendOperation,
    options?: ExecuteSendOptions,
  ): Promise<SwapExecutionOutcome> {
    if (!operation.outputData) {
      throw new Error('Missing output data for swap operation');
    }
    const remote = this.#remote.open(
      await this.#mintMetadataRefresh.refreshAndCommitIfStale(operation.mintUrl),
      operation.unit,
    );
    const begun = await this.#transactions.beginExecution({
      operationId: operation.id,
      updatedAt: Date.now(),
      memo: options?.memo ? this.#normalizeMemo(options.memo) : undefined,
    });
    return this.#submitPersistedSwap(begun.operation, begun.request, remote, 'initial');
  }

  async #submitPersistedSwap(
    operation: ExecutingSendOperation,
    request: SwapTransportRequest,
    remote: SendRemoteSession,
    submission: 'initial' | 'replay',
  ): Promise<SwapExecutionOutcome> {
    let result: Awaited<ReturnType<SendRemoteSession['swap']>>;
    try {
      result = await remote.swap(request);
    } catch (error) {
      // A rejected replay cannot rule out an earlier submission still completing.
      if (submission === 'replay' || !this.#isDefinitiveSwapFailure(error)) {
        throw error;
      }
      const failed = await this.#transactions.failExecution({
        operationId: operation.id,
        expectedRevision: operation.revision ?? 0,
        updatedAt: Date.now(),
        error: error.message,
      });
      return { status: 'FAILED', result: failed, error };
    }
    const keepProofs = mapProofToCoreProof(request.mintUrl, 'ready', result.keep, {
      unit: request.unit,
      createdByOperationId: operation.id,
    });
    const sendProofs = mapProofToCoreProof(request.mintUrl, 'inflight', result.send, {
      unit: request.unit,
      createdByOperationId: operation.id,
    });
    const token: Token = {
      mint: request.mintUrl,
      proofs: result.send,
      unit: request.unit,
      ...(operation.executionMemo ? { memo: operation.executionMemo } : {}),
    };

    const applied = await this.#transactions.applyResult({
      operationId: operation.id,
      updatedAt: Date.now(),
      keepProofs,
      sendProofs,
      token,
    });
    return { status: 'PENDING', result: applied };
  }

  async #executeExactMatch(
    operationId: string,
    memo?: string,
  ): Promise<{ operation: PendingSendOperation; token: Token }> {
    const releaseLock = await this.#acquireOperationLock(operationId);
    let result: Awaited<ReturnType<SendTransactions['executeExact']>>;
    try {
      result = await this.#transactions.executeExact({
        operationId,
        updatedAt: Date.now(),
        memo,
      });
    } finally {
      releaseLock();
    }

    if (result.committed) {
      // Publish pending before proof events can trigger watcher finalization.
      await this.#publishCommittedEvent('send:pending', {
        mintUrl: result.operation.mintUrl,
        operationId: result.operation.id,
        operation: result.operation,
        token: result.token,
      });
      await this.#publishCommittedEvent('proofs:state-changed', {
        mintUrl: result.operation.mintUrl,
        secrets: result.operation.inputProofSecrets,
        state: 'inflight',
      });
    }

    this.#logger?.info('Exact-match Send operation executed', {
      operationId,
      proofCount: result.token.proofs.length,
      committed: result.committed,
    });
    return result;
  }

  /**
   * High-level send method that orchestrates init → prepare → execute.
   * This is the main entry point for consumers.
   */
  async send(mintUrl: string, amount: UnitAmount): Promise<Token> {
    const initOp = await this.init(mintUrl, amount);
    const preparedOp = await this.prepare(initOp);
    const { token } = await this.execute(preparedOp);
    return token;
  }

  /**
   * Finalize a pending operation after its proofs have been spent.
   * This method is idempotent - calling it on an already finalized operation is a no-op.
   * If the operation was rolled back, finalization is skipped (rollback takes precedence).
   * Throws if the operation is already in progress.
   */
  async finalize(operationId: string): Promise<void> {
    const operation = await this.#operationQueries.getById(operationId);
    if (!operation) throw new Error(`Operation ${operationId} not found`);
    return this.#completePersistedSend(operationId);
  }

  async #completePersistedSend(operationId: string): Promise<void> {
    let releaseLock: (() => void) | undefined;
    let result: CompletedPendingSend | undefined;
    try {
      try {
        releaseLock = await this.#acquireOperationLock(operationId);
      } catch (error) {
        if (!(error instanceof OperationInProgressError)) {
          throw error;
        }

        await this.#operationIdLock.waitForUnlock(operationId);

        const latest = await this.#operationQueries.getById(operationId);
        if (!latest) {
          throw new Error(`Operation ${operationId} not found`);
        }

        if (latest.state === 'finalized') {
          this.#logger?.debug('Operation finalized while waiting for lock', { operationId });
          return;
        }

        if (latest.state === 'rolled_back' || latest.state === 'rolling_back') {
          this.#logger?.debug('Operation rolled back while waiting for lock', {
            operationId,
            state: latest.state,
          });
          return;
        }

        releaseLock = await this.#acquireOperationLock(operationId);
      }

      const operation = await this.#operationQueries.getById(operationId);
      if (!operation) {
        throw new Error(`Operation ${operationId} not found`);
      }
      if (operation.state === 'finalized') {
        this.#logger?.debug('Operation already finalized', { operationId });
        return;
      }

      if (operation.state === 'rolled_back' || operation.state === 'rolling_back') {
        this.#logger?.debug('Operation was rolled back or is rolling back, skipping finalization', {
          operationId,
        });
        return;
      }

      if (operation.state !== 'pending') {
        throw new Error(`Cannot finalize operation in state ${operation.state}`);
      }
      if (isLegacyTokenlessP2pkSend(operation)) {
        const observation = await this.#observeLegacyTokenlessP2pk(operation);
        if (!observation) {
          throw new ProofValidationError(`Cannot finalize unspent Send operation ${operationId}`);
        }
        result = await this.#transactions.completePending(observation);
      } else {
        const sendSecrets = getSendProofSecrets(operation);
        const localProofs = await this.#proofQueries.getProofsBySecrets(
          operation.mintUrl,
          sendSecrets,
        );
        const locallySpent =
          localProofs.length === new Set(sendSecrets).size &&
          localProofs.every((proof) => proof.state === 'spent');
        let observedSpentSecrets: string[] | undefined;
        if (!locallySpent) {
          const states = await this.#checkProofStatesWithMint(
            operation.mintUrl,
            sendSecrets,
            operation.unit,
          );
          if (!states.every((state) => state.state === 'SPENT')) {
            throw new ProofValidationError(`Cannot finalize unspent Send operation ${operationId}`);
          }
          observedSpentSecrets = sendSecrets;
        }
        result = await this.#transactions.completePending({
          operationId,
          updatedAt: Date.now(),
          spentProofSecrets: observedSpentSecrets,
        });
      }
    } finally {
      releaseLock?.();
    }
    if (result) await this.#publishCompletedSend(result);
  }

  /**
   * Cancel a prepared operation and release its reservations.
   * Reclaim commits its Output Allocation before mint I/O and applies the result atomically.
   * Throws if the operation is already in progress.
   */
  async rollback(operationId: string, reason = 'Rolled back by user action'): Promise<void> {
    const operation = await this.#operationQueries.getById(operationId);
    if (!operation) throw new Error(`Operation ${operationId} not found`);
    const handler = this.#handlerProvider.get(operation.method);
    if (operation.state !== 'prepared' && !handler.canReclaim) {
      throw new Error(`P2PK Send Operation in ${operation.state} state can not be rolled back.`);
    }
    return this.#rollbackPersistedSend(operationId, reason);
  }

  /**
   * Reclaims the frozen Friday NUT-11 refund subset. A pending call creates one durable plan;
   * a rolling_back call only resumes that exact plan.
   */
  async reclaim(operationId: string, options: { spendingPath: 'refund' }): Promise<SendOperation> {
    if (options.spendingPath !== 'refund') {
      throw new ProofValidationError('Unsupported Send reclaim spending path');
    }

    for (;;) {
      let releaseLock: (() => void) | undefined;
      let completed: CompletedReclaim | undefined;
      let result: SendOperation | undefined;
      try {
        try {
          releaseLock = await this.#acquireOperationLock(operationId);
        } catch (error) {
          if (!(error instanceof OperationInProgressError)) throw error;
          await this.#operationIdLock.waitForUnlock(operationId);
          continue;
        }

        const operation = await this.#operationQueries.getById(operationId);
        if (!operation) throw new Error(`Operation ${operationId} not found`);
        if (operation.state === 'rolled_back' || operation.state === 'finalized') {
          result = operation;
        } else if (operation.state === 'pending') {
          if (operation.method !== 'p2pk') {
            throw new SendOperationConflictError(
              operationId,
              'Refund spending path requires a pending P2PK Send operation',
            );
          }
          const p2pkOperation = operation as PendingSendOperation & { method: 'p2pk' };
          const inputProofs = await this.#loadExactRefundInputs(p2pkOperation);
          const handler = this.#handlerProvider.get('p2pk');
          if (!handler.prepareReclaim) {
            throw new ProofValidationError('P2PK refund reclaim is unavailable');
          }
          const prepared = await handler.prepareReclaim({ operation: p2pkOperation, inputProofs });
          const cached = await this.#mintMetadataQueries.getMetadata(operation.mintUrl);
          if (!cached) throw new UnknownMintError(`Mint ${operation.mintUrl} is not stored`);
          const allocationSeed = await this.#loadSeed();
          let begun: BegunReclaim;
          try {
            begun = await this.#transactions.beginReclaim({
              operationId,
              updatedAt: Date.now(),
              activeKeys: this.#activeKeys(cached, operation.unit),
              seed: allocationSeed,
              spendingPath: 'refund',
              expectedRevision: operation.revision ?? 0,
              expectedInputProofSecrets: inputProofs.map((proof) => proof.secret),
              conditionFingerprint: prepared.conditionFingerprint,
              refundPublicKeyX: prepared.refundPublicKeyX,
            });
          } finally {
            zeroOwnedSeed(allocationSeed);
          }
          if (begun.counter) await this.#publishCommittedEvent('counter:updated', begun.counter);
          const begunRefund = begun.operation as RollingBackSendOperation & { method: 'p2pk' };
          const authenticated = await this.#authenticateRefundPlan(begunRefund);
          if (!authenticated) {
            result = begun.operation;
          } else {
            const remote = this.#remote.open(
              await this.#mintMetadataRefresh.refreshAndCommitIfStale(operation.mintUrl),
              operation.unit,
            );
            const reclaimed = await remote.reclaim(
              cloneRefundInputProofs(authenticated.inputProofs),
              cloneRefundOutputData(authenticated.outputData),
            );
            completed = await this.#completeRefundReclaim(
              begunRefund,
              reclaimed,
              authenticated.authorization,
            );
            result = completed.operation;
          }
        } else if (operation.state === 'rolling_back') {
          if (operation.method !== 'p2pk' || operation.reclaimData?.spendingPath !== 'refund') {
            throw new SendOperationConflictError(
              operationId,
              'Rolling-back Send does not contain a P2PK refund plan',
            );
          }
          const recovered = await this.#recoverRefundReclaim(
            operation as RollingBackSendOperation & { method: 'p2pk' },
          );
          completed = recovered.completed;
          result = recovered.operation;
        } else {
          throw new SendOperationConflictError(
            operationId,
            `Cannot refund Send operation in state ${operation.state}`,
          );
        }
      } finally {
        releaseLock?.();
      }

      if (completed) await this.#publishReclaimedSend(completed);
      if (!result) throw new Error(`Send operation ${operationId} produced no refund result`);
      return result;
    }
  }

  async #recoverRefundReclaim(
    operation: RollingBackSendOperation & { method: 'p2pk' },
  ): Promise<{ operation: SendOperation; completed?: CompletedReclaim }> {
    const reclaimData = operation.reclaimData;
    if (!reclaimData || reclaimData.spendingPath !== 'refund') {
      throw new SendOperationConflictError(operation.id, 'P2PK refund plan is missing');
    }
    const authenticated = await this.#authenticateRefundPlan(operation);
    if (!authenticated) return { operation };
    let remote: SendRemoteSession;
    try {
      remote = this.#remote.open(
        await this.#mintMetadataRefresh.refreshAndCommitIfStale(operation.mintUrl),
        operation.unit,
      );
    } catch {
      return { operation };
    }
    const restored = await this.#observeRefundOutputs(remote, authenticated.outputData);
    const restoredCompletion = await this.#completeObservedRefund(
      operation,
      restored,
      authenticated.authorization,
    );
    if (restoredCompletion) {
      return { operation: restoredCompletion.operation, completed: restoredCompletion };
    }
    if (restored.status !== 'none') return { operation };

    let inputStates;
    try {
      inputStates = await remote.observeReclaimInputStates(
        cloneRefundInputProofs(authenticated.inputProofs),
      );
    } catch {
      return { operation };
    }
    if (
      inputStates.status !== 'complete' ||
      !inputStates.inputs.every(({ state }) => state.state === 'UNSPENT')
    ) {
      return { operation };
    }

    try {
      const proofs = await remote.reclaim(
        cloneRefundInputProofs(authenticated.inputProofs),
        cloneRefundOutputData(authenticated.outputData),
      );
      const completed = await this.#completeRefundReclaim(
        operation,
        proofs,
        authenticated.authorization,
      );
      return { operation: completed.operation, completed };
    } catch {
      const replayObservation = await this.#observeRefundOutputs(remote, authenticated.outputData);
      const completed = await this.#completeObservedRefund(
        operation,
        replayObservation,
        authenticated.authorization,
      );
      return completed ? { operation: completed.operation, completed } : { operation };
    }
  }

  /** Verify every persisted refund field before any mint request can observe the plan. */
  async #authenticateRefundPlan(
    operation: RollingBackSendOperation & { method: 'p2pk' },
  ): Promise<AuthenticatedRefundReclaim | null> {
    try {
      const data = operation.reclaimData;
      if (!data || data.spendingPath !== 'refund' || data.version !== 1) return null;
      const seed = await this.#loadSeed();
      try {
        const plan = verifyCommittedRefundReclaimPlan(data, seed);
        const expectedSecrets = getSendProofSecrets(operation);
        const expectedOwnership = operation.needsSwap ? 'created' : 'used';
        if (
          plan.operationId !== operation.id ||
          plan.mintUrl !== normalizeMintUrl(operation.mintUrl) ||
          plan.unit !== normalizeUnit(operation.unit) ||
          plan.inputOwnership !== expectedOwnership ||
          plan.inputProofSecrets.length !== expectedSecrets.length ||
          plan.inputProofSecrets.some((secret, index) => secret !== expectedSecrets[index]) ||
          !plan.conditionFingerprint ||
          !plan.refundPublicKeyX ||
          !plan.planCommitment ||
          plan.outputData.send.length !== 0 ||
          plan.outputData.keep.length === 0 ||
          plan.allocation.counterEnd - plan.allocation.counterStart !==
            plan.outputData.keep.length ||
          !Number.isSafeInteger(plan.allocation.counterStart) ||
          !Number.isSafeInteger(plan.allocation.counterEnd) ||
          plan.allocation.counterStart < 0 ||
          plan.allocation.counterEnd <= plan.allocation.counterStart ||
          plan.outputData.keep.some(
            (output) => output.blindedMessage.id !== plan.allocation.keysetId,
          )
        ) {
          return null;
        }

        const metadata = await this.#mintMetadataQueries.getMetadata(operation.mintUrl);
        if (!metadata) return null;
        const allocationKeys = createKeyChain(operation.mintUrl, operation.unit, metadata.keysets)
          .getKeyset(plan.allocation.keysetId)
          .toMintKeys();
        if (!allocationKeys) return null;
        const outputAmount = Amount.sum(
          plan.outputData.keep.map((output) => output.blindedMessage.amount),
        );
        const rederived = serializeOutputData({
          keep: this.#outputDataCreator.createDeterministicData(
            outputAmount,
            seed,
            plan.allocation.counterStart,
            allocationKeys,
          ),
          send: [],
        });
        if (serializeRefundValue(rederived) !== serializeRefundValue(plan.outputData)) return null;

        const inputProofs = await this.#loadExactRefundInputs(operation);
        const handler = this.#handlerProvider.get('p2pk');
        if (!handler.prepareReclaim) return null;
        const prepared = await handler.prepareReclaim({ operation, inputProofs });
        if (
          prepared.conditionFingerprint !== plan.conditionFingerprint ||
          prepared.refundPublicKeyX !== plan.refundPublicKeyX
        ) {
          return null;
        }
        return {
          inputProofs: prepared.inputProofs,
          outputData: freezeRefundOutputData(plan.outputData),
          authorization: Object.freeze({
            version: 1,
            operationId: operation.id,
            canonicalPlan: serializeCommittedRefundReclaimPlan(plan),
            operationBinding: this.#serializeRefundOperationBinding(operation),
            planCommitment: plan.planCommitment,
          }),
        };
      } finally {
        zeroOwnedSeed(seed);
      }
    } catch {
      return null;
    }
  }

  async #observeRefundOutputs(
    remote: SendRemoteSession,
    outputData: NonNullable<RollingBackSendOperation['reclaimData']>['outputData'],
  ): Promise<ReclaimOutputObservation> {
    try {
      return await remote.observeReclaimOutputs(cloneRefundOutputData(outputData));
    } catch {
      return { status: 'inconclusive', reason: 'unavailable', outputs: [] };
    }
  }

  async #completeObservedRefund(
    operation: RollingBackSendOperation,
    observation: ReclaimOutputObservation,
    authorization: RefundReclaimAuthorization,
  ): Promise<CompletedReclaim | undefined> {
    if (
      observation.status !== 'complete' ||
      !observation.outputs.every((output) => output.state.state === 'UNSPENT')
    ) {
      return undefined;
    }
    return this.#completeRefundReclaim(
      operation,
      observation.outputs.map((output) => output.proof),
      authorization,
    );
  }

  async #completeRefundReclaim(
    operation: RollingBackSendOperation,
    proofs: Proof[],
    authorization: RefundReclaimAuthorization,
  ): Promise<CompletedReclaim> {
    // Seed loading can cross IndexedDB/WebCrypto boundaries. Finish it before the transaction
    // gateway opens, then pass only a short-lived synchronous verifier capability inward.
    const seed = await this.#loadSeed();
    let active = true;
    try {
      return await this.#transactions.completeReclaim(
        {
          operationId: operation.id,
          updatedAt: Date.now(),
          reason: 'Refunded after P2PK locktime',
          proofs: mapProofToCoreProof(operation.mintUrl, 'ready', proofs, { unit: operation.unit }),
          refundAuthorization: authorization,
        },
        (plan, expectedCommitment) => {
          if (!active) throw new Error('Refund reclaim verifier has expired');
          const verified = verifyCommittedRefundReclaimPlan(plan, seed);
          if (verified.planCommitment !== expectedCommitment) {
            throw new Error('Refund reclaim commitment authority changed');
          }
          return new NativeUint8Array(seed);
        },
      );
    } finally {
      active = false;
      zeroOwnedSeed(seed);
    }
  }

  #serializeRefundOperationBinding(operation: RollingBackSendOperation): string {
    return serializeRefundOperationBinding({
      version: 1,
      operationId: operation.id,
      revision: operation.revision ?? 0,
      state: operation.state,
      mintUrl: normalizeMintUrl(operation.mintUrl),
      unit: normalizeUnit(operation.unit),
      method: operation.method,
      methodData: operation.methodData,
      needsSwap: operation.needsSwap,
      inputProofSecrets: getSendProofSecrets(operation),
      inputOwnership: operation.needsSwap ? 'created' : 'used',
    });
  }

  async #loadExactRefundInputs(
    operation: (PendingSendOperation | RollingBackSendOperation) & { method: 'p2pk' },
  ): Promise<Proof[]> {
    const secrets =
      operation.state === 'rolling_back' && operation.reclaimData?.spendingPath === 'refund'
        ? operation.reclaimData.inputProofSecrets
        : getSendProofSecrets(operation);
    if (secrets.length === 0 || new Set(secrets).size !== secrets.length) {
      throw new ProofValidationError('P2PK refund input binding is empty or duplicated');
    }
    const stored = await this.#proofQueries.getProofsBySecrets(operation.mintUrl, secrets);
    const bySecret = new Map(stored.map((proof) => [proof.secret, proof]));
    if (bySecret.size !== secrets.length) {
      throw new ProofValidationError('P2PK refund input metadata is incomplete');
    }
    const proofs = secrets.map((secret) => bySecret.get(secret)!);
    if (
      proofs.some(
        (proof) =>
          proof.unit !== operation.unit ||
          proof.state !== 'inflight' ||
          (operation.needsSwap
            ? proof.createdByOperationId !== operation.id
            : proof.usedByOperationId !== operation.id),
      )
    ) {
      throw new ProofValidationError('P2PK refund inputs are not exact operation-owned proofs');
    }
    return proofs;
  }

  async #rollbackPersistedSend(operationId: string, reason: string): Promise<void> {
    const releaseLock = await this.#acquireOperationLock(operationId);
    let cancelled: CancelledPreparedSend | undefined;
    let reclaimed: CompletedReclaim | undefined;
    try {
      const operation = await this.#operationQueries.getById(operationId);
      if (!operation) {
        throw new Error(`Operation ${operationId} not found`);
      }
      if (operation.state === 'prepared') {
        cancelled = await this.#transactions.cancelPrepared({
          operationId,
          updatedAt: Date.now(),
          reason,
        });
      } else if (operation.state === 'pending' && operation.method === 'default') {
        const metadata = await this.#mintMetadataRefresh.refreshAndCommitIfStale(operation.mintUrl);
        const remote = this.#remote.open(metadata, operation.unit);
        const begun = await this.#transactions.beginReclaim({
          operationId,
          updatedAt: Date.now(),
          activeKeys: this.#activeKeys(metadata, operation.unit),
          seed: await this.#loadSeed(),
        });
        if (begun.counter) await this.#publishCommittedEvent('counter:updated', begun.counter);
        if (begun.skippedForFees) {
          this.#logger?.warn('Cannot reclaim send proofs because fees consume the amount', {
            operationId,
          });
        }
        const proofs = begun.operation.reclaimData
          ? await remote.reclaim(begun.inputProofs, begun.operation.reclaimData.outputData)
          : [];
        reclaimed = await this.#transactions.completeReclaim({
          operationId,
          updatedAt: Date.now(),
          reason,
          proofs: mapProofToCoreProof(operation.mintUrl, 'ready', proofs, { unit: operation.unit }),
        });
      } else {
        throw new Error(`Cannot rollback operation in state ${operation.state}`);
      }
    } finally {
      releaseLock();
    }
    if (cancelled) await this.#publishCancelledSend(cancelled);
    if (reclaimed) await this.#publishReclaimedSend(reclaimed);
  }

  async #publishReclaimedSend(reclaimed: CompletedReclaim): Promise<void> {
    await this.#publishSavedProofs(reclaimed.operation.mintUrl, reclaimed.savedProofs);
    if (reclaimed.spentProofSecrets.length > 0)
      await this.#publishCommittedEvent('proofs:state-changed', {
        mintUrl: reclaimed.operation.mintUrl,
        secrets: reclaimed.spentProofSecrets,
        state: 'spent',
      });
    if (reclaimed.releasedProofSecrets.length > 0)
      await this.#publishCommittedEvent('proofs:released', {
        mintUrl: reclaimed.operation.mintUrl,
        secrets: reclaimed.releasedProofSecrets,
      });
    await this.#publishCommittedEvent('send:rolled-back', {
      mintUrl: reclaimed.operation.mintUrl,
      operationId: reclaimed.operation.id,
      operation: reclaimed.operation,
    });
  }

  /**
   * Recover pending operations on startup.
   * This should be called during initialization.
   * Throws if recovery is already in progress.
   */
  async recoverPendingOperations(): Promise<void> {
    return this.#recoverPendingOperations();
  }

  async #recoverPendingOperations(): Promise<void> {
    if (this.#recoveryLock) {
      throw new Error('Recovery is already in progress');
    }

    let releaseRecoveryLock: () => void;
    this.#recoveryLock = new Promise<void>((resolve) => {
      releaseRecoveryLock = resolve;
    });

    try {
      let initCount = 0;
      let executingCount = 0;
      let pendingCount = 0;
      let rollingBackCount = 0;
      let orphanCount = 0;

      // 1. Clean up failed init operations
      const initOps = await this.#operationQueries.getByState('init');
      for (const op of initOps) {
        await this.#recoverInitOperation(op as InitSendOperation);
        initCount++;
      }

      // 2. Log warnings for prepared operations (leave for user to decide)
      const preparedOps = await this.#operationQueries.getByState('prepared');
      for (const op of preparedOps) {
        this.#logger?.warn('Found stale prepared operation, user can rollback manually', {
          operationId: op.id,
        });
      }

      // 3. Recover executing operations
      const executingOps = await this.#operationQueries.getByState('executing');
      for (const op of executingOps) {
        try {
          await this.#recoverExecutingOperation(op as ExecutingSendOperation);
          executingCount++;
        } catch (e) {
          this.#logger?.error('Error recovering executing operation', {
            operationId: op.id,
            error: e instanceof Error ? e.message : String(e),
          });
        }
      }

      // 4. Check pending operations
      const pendingOps = await this.#operationQueries.getByState('pending');
      for (const op of pendingOps) {
        try {
          await this.checkPendingOperation(op as PendingSendOperation);
          pendingCount++;
        } catch (e) {
          this.#logger?.error('Error checking pending operation', {
            operationId: op.id,
            error: e instanceof Error ? e.message : String(e),
          });
        }
      }

      // 5. Resume only durable P2PK refund plans. Legacy/default rows keep the manual warning.
      const rollingBackOps = await this.#operationQueries.getByState('rolling_back');
      for (const op of rollingBackOps) {
        if (op.method === 'p2pk' && op.reclaimData?.spendingPath === 'refund') {
          try {
            await this.reclaim(op.id, { spendingPath: 'refund' });
          } catch (error) {
            this.#logger?.error('Error recovering P2PK refund reclaim', {
              operationId: op.id,
              error: error instanceof Error ? error.message : String(error),
            });
          }
        } else {
          this.#logger?.warn(
            'Found operation stuck in rolling_back state. ' +
              'This indicates a crash during rollback. Manual recovery via seed restore may be needed.',
            {
              operationId: op.id,
              mintUrl: op.mintUrl,
              amount: op.amount,
            },
          );
        }
        rollingBackCount++;
      }

      // 6. Clean up orphaned proof reservations
      orphanCount = await this.#cleanupOrphanedReservations();

      this.#logger?.info('Recovery completed', {
        initOperations: initCount,
        executingOperations: executingCount,
        pendingOperations: pendingCount,
        rollingBackOperations: rollingBackCount,
        orphanedReservations: orphanCount,
      });
    } finally {
      this.#recoveryLock = null;
      releaseRecoveryLock!();
    }
  }

  /**
   * Clean up a failed init operation.
   * Releases any orphaned proof reservations and deletes the operation.
   */
  async #recoverInitOperation(op: InitSendOperation): Promise<void> {
    const result = await this.#transactions.cleanupLegacyInit(op.id);
    if (result.releasedProofSecrets.length > 0) {
      await this.#publishCommittedEvent('proofs:released', {
        mintUrl: result.mintUrl,
        secrets: result.releasedProofSecrets,
      });
    }
    this.#logger?.info('Cleaned up failed init operation', { operationId: op.id });
  }

  /**
   * Recover an executing swap using only its persisted inputs, outputs, and memo.
   */
  async #recoverExecutingOperation(op: ExecutingSendOperation): Promise<void> {
    const latest = await this.#operationQueries.getById(op.id);
    if (!latest || latest.state !== 'executing') {
      this.#logger?.debug('Skipping executing Send recovery because state changed', {
        operationId: op.id,
        state: latest?.state,
      });
      return;
    }
    if (!latest.needsSwap) {
      const recovered = await this.#transactions.recoverLegacyExact({
        operationId: latest.id,
        updatedAt: Date.now(),
      });
      if (recovered.readyProofSecrets.length > 0) {
        await this.#publishCommittedEvent('proofs:state-changed', {
          mintUrl: recovered.operation.mintUrl,
          secrets: recovered.readyProofSecrets,
          state: 'ready',
        });
      }
      await this.#publishCancelledSend(recovered);
      return;
    }
    if (!latest.outputData) {
      this.#logger?.warn('Executing Send lacks a persisted swap request; leaving it for recovery', {
        operationId: latest.id,
      });
      return;
    }

    const storedInputs = await this.#proofQueries.getProofsBySecrets(
      latest.mintUrl,
      latest.inputProofSecrets,
    );
    const inputBySecret = new Map(storedInputs.map((proof) => [proof.secret, proof]));
    if (inputBySecret.size !== latest.inputProofSecrets.length) {
      throw new ProofValidationError('Cannot recover Send operation: missing input proof metadata');
    }
    const inputProofs = latest.inputProofSecrets.map(
      (secret) => inputBySecret.get(secret) as Proof,
    );
    const remote = this.#remote.open(
      await this.#mintMetadataRefresh.refreshAndCommitIfStale(latest.mintUrl),
      latest.unit,
    );
    const inputStates = await remote.checkProofStates(inputProofs);
    if (inputStates.length !== inputProofs.length) {
      this.#logger?.warn(
        'Executing Send proof-state response was incomplete; preserving recovery material',
        { operationId: latest.id },
      );
      return;
    }
    const allUnspent = inputStates.every((state) => state.state === 'UNSPENT');
    const allSpent = inputStates.every((state) => state.state === 'SPENT');

    if (allUnspent) {
      const claimed = await this.#transactions.claimRecovery({
        operationId: latest.id,
        expectedRevision: latest.revision ?? 0,
        updatedAt: Date.now(),
      });
      const outcome = await this.#submitPersistedSwap(
        claimed.operation,
        claimed.request,
        remote,
        'replay',
      );
      if (outcome.status === 'FAILED') {
        await this.#publishFailedSwap(outcome.result);
      } else {
        await this.#publishAppliedSwap(outcome.result);
      }
      this.#logger?.info('Replayed executing Send from its persisted request', {
        operationId: latest.id,
        result: outcome.status,
      });
      return;
    }

    if (!allSpent) {
      this.#logger?.warn('Executing Send outcome remains ambiguous; preserving recovery material', {
        operationId: latest.id,
      });
      return;
    }

    const claimed = await this.#transactions.claimRecovery({
      operationId: latest.id,
      expectedRevision: latest.revision ?? 0,
      updatedAt: Date.now(),
    });
    const recoveryOperation = claimed.operation;

    const outputSecrets = getSecretsFromSerializedOutputData(recoveryOperation.outputData!);
    const expectedSecrets = [...outputSecrets.keepSecrets, ...outputSecrets.sendSecrets];
    const storedOutputs = await this.#proofQueries.getProofsBySecrets(
      recoveryOperation.mintUrl,
      expectedSecrets,
    );
    const recoveredBySecret = new Map<string, Proof>(
      storedOutputs
        .filter((proof) => proof.createdByOperationId === recoveryOperation.id)
        .map((proof) => [proof.secret, proof]),
    );
    if (!expectedSecrets.every((secret) => recoveredBySecret.has(secret))) {
      const recovered = await remote.restoreOutputs(recoveryOperation.outputData!);
      for (const proof of recovered) {
        if (!recoveredBySecret.has(proof.secret)) recoveredBySecret.set(proof.secret, proof);
      }
    }
    if (!expectedSecrets.every((secret) => recoveredBySecret.has(secret))) {
      this.#logger?.warn(
        'Executing Send outputs could not be fully reconstructed; preserving recovery material',
        { operationId: recoveryOperation.id },
      );
      return;
    }

    const keepProofs = mapProofToCoreProof(
      recoveryOperation.mintUrl,
      'ready',
      outputSecrets.keepSecrets.map((secret) => recoveredBySecret.get(secret)!),
      { unit: recoveryOperation.unit, createdByOperationId: recoveryOperation.id },
    );
    const sendProofs = mapProofToCoreProof(
      recoveryOperation.mintUrl,
      'inflight',
      outputSecrets.sendSecrets.map((secret) => recoveredBySecret.get(secret)!),
      { unit: recoveryOperation.unit, createdByOperationId: recoveryOperation.id },
    );
    const token: Token = {
      mint: recoveryOperation.mintUrl,
      proofs: outputSecrets.sendSecrets.map((secret) => recoveredBySecret.get(secret)!),
      unit: recoveryOperation.unit,
      ...(recoveryOperation.executionMemo ? { memo: recoveryOperation.executionMemo } : {}),
    };
    const applied = await this.#transactions.applyResult({
      operationId: recoveryOperation.id,
      updatedAt: Date.now(),
      keepProofs,
      sendProofs,
      token,
    });
    await this.#publishAppliedSwap(applied);
    this.#logger?.info('Restored executing Send outputs from its persisted request', {
      operationId: recoveryOperation.id,
    });
  }

  /**
   * Check a pending operation to see if it should be finalized.
   */
  async checkPendingOperation(op: PendingSendOperation): Promise<void> {
    const latest = await this.#operationQueries.getById(op.id);
    if (!latest || latest.state !== 'pending') return;
    return this.#checkPersistedSend(latest);
  }

  async #checkPersistedSend(op: PendingSendOperation): Promise<void> {
    const latest = await this.#operationQueries.getById(op.id);
    if (!latest || latest.state !== 'pending') return;
    const sendSecrets = getSendProofSecrets(latest);
    let completion: CompletePendingSendInput | null;
    try {
      if (isLegacyTokenlessP2pkSend(latest)) {
        completion = await this.#observeLegacyTokenlessP2pk(latest);
      } else {
        const states = await this.#checkProofStatesWithMint(
          latest.mintUrl,
          sendSecrets,
          latest.unit,
        );
        completion = states.every((state) => state.state === 'SPENT')
          ? { operationId: latest.id, updatedAt: Date.now(), spentProofSecrets: sendSecrets }
          : null;
      }
    } catch (_e) {
      this.#logger?.warn('Could not reach mint for recovery, will retry later', {
        operationId: latest.id,
        mintUrl: latest.mintUrl,
      });
      return;
    }

    if (!completion) {
      this.#logger?.debug('Pending operation token not yet claimed, leaving as pending', {
        operationId: latest.id,
      });
      return;
    }

    const result = await this.#transactions.completePending(completion);
    await this.#publishCompletedSend(result);
    this.#logger?.info('Send operation finalized during recovery', { operationId: latest.id });
  }

  /**
   * Persist a mint proof-state notification through the Send transaction boundary. The last send
   * proof observation and the pending-to-finalized transition commit together.
   */
  async recordProofSpent(operationId: string, secret: string): Promise<boolean> {
    const operation = await this.#operationQueries.getById(operationId);
    if (!operation || operation.state !== 'pending') return false;
    if (!getSendProofSecrets(operation).includes(secret)) {
      throw new ProofValidationError(`Proof ${secret} does not belong to Send operation`);
    }
    const completion = isLegacyTokenlessP2pkSend(operation)
      ? await this.#observeLegacyTokenlessP2pk(operation)
      : { operationId, updatedAt: Date.now(), spentProofSecrets: [secret] };
    if (!completion) return true;
    const result = await this.#transactions.completePending(completion);
    await this.#publishCompletedSend(result);
    return true;
  }

  async #observeLegacyTokenlessP2pk(
    operation: PendingSendOperation & {
      outputData: NonNullable<PendingSendOperation['outputData']>;
    },
  ): Promise<CompletePendingSendInput | null> {
    const outputData = structuredClone(operation.outputData);
    const proofInputs = getProofStateInputsFromSerializedOutputs(outputData.send);
    if (
      proofInputs.some((proof) => !proof.id || !proof.secret) ||
      new Set(proofInputs.map((proof) => proof.secret)).size !== proofInputs.length
    ) {
      throw new ProofValidationError('Cannot check legacy P2PK Send: invalid output allocation');
    }
    const remote = this.#remote.open(
      await this.#mintMetadataRefresh.refreshAndCommitIfStale(operation.mintUrl),
      operation.unit,
    );
    const states = await remote.checkProofStates(proofInputs);
    if (states.length !== proofInputs.length) {
      throw new ProofValidationError('Cannot check legacy P2PK Send: incomplete mint response');
    }
    if (!states.every((state) => state.state === 'SPENT')) return null;
    return {
      operationId: operation.id,
      updatedAt: Date.now(),
      spentProofSecrets: proofInputs.map((proof) => proof.secret),
      legacyP2pkOutputObservation: {
        expectedRevision: operation.revision ?? 0,
        mintUrl: operation.mintUrl,
        unit: operation.unit,
        outputData,
      },
    };
  }

  /**
   * Check proof states with the mint.
   */
  async #checkProofStatesWithMint(
    mintUrl: string,
    secrets: string[],
    unit: string,
  ): Promise<CashuProofState[]> {
    const remote = this.#remote.open(
      await this.#mintMetadataRefresh.refreshAndCommitIfStale(mintUrl),
      unit,
    );
    const proofInputs = await this.#proofQueries.getProofsBySecrets(mintUrl, secrets);
    if (proofInputs.length !== secrets.length) {
      throw new ProofValidationError('Cannot check proof states: missing proof metadata');
    }
    const states = await remote.checkProofStates(proofInputs);
    if (states.length !== proofInputs.length) {
      throw new ProofValidationError('Cannot check proof states: incomplete mint response');
    }
    return states;
  }

  /**
   * Clean up orphaned proof reservations.
   * Releases proofs reserved by known terminal Sends; unidentified owners remain reserved.
   */
  async #cleanupOrphanedReservations(): Promise<number> {
    const result = await this.#transactions.cleanupOrphanedReservations();
    for (const group of result.released) {
      await this.#publishCommittedEvent('proofs:released', group);
    }
    if (result.count > 0) {
      this.#logger?.info('Released orphaned proof reservations', { count: result.count });
    }
    return result.count;
  }

  async #publishPrepared(result: PreparedSendResult): Promise<void> {
    if (result.outcome === 'joined') return;
    if (result.counter) {
      await this.#publishCommittedEvent('counter:updated', result.counter);
    }
    const reservation = result.reservation!;
    await this.#publishCommittedEvent('proofs:reserved', {
      mintUrl: reservation.mintUrl,
      operationId: reservation.operationId,
      secrets: reservation.secrets,
      amount: {
        amount: reservation.amount,
        unit: reservation.unit,
      },
    });
    await this.#publishCommittedEvent('send:prepared', {
      mintUrl: result.operation.mintUrl,
      operationId: result.operation.id,
      operation: result.operation,
    });
  }

  async #publishSavedProofs(
    mintUrl: string,
    savedProofs: import('@core/types.ts').CoreProof[],
  ): Promise<void> {
    const groups = new Map<string, typeof savedProofs>();
    for (const proof of savedProofs) groups.set(proof.id, [...(groups.get(proof.id) ?? []), proof]);
    for (const [keysetId, proofs] of groups)
      await this.#publishCommittedEvent('proofs:saved', { mintUrl, keysetId, proofs });
  }

  async #publishAppliedSwap(result: AppliedSwapResult): Promise<void> {
    if (!result.committed) return;

    // Saved inflight proofs can immediately trigger watcher finalization.
    await this.#publishCommittedEvent('send:pending', {
      mintUrl: result.operation.mintUrl,
      operationId: result.operation.id,
      operation: result.operation,
      token: result.operation.token!,
    });
    await this.#publishSavedProofs(result.operation.mintUrl, result.savedProofs);
    if (result.inflightProofSecrets.length > 0) {
      await this.#publishCommittedEvent('proofs:state-changed', {
        mintUrl: result.operation.mintUrl,
        secrets: result.inflightProofSecrets,
        state: 'inflight',
      });
    }
    await this.#publishCommittedEvent('proofs:state-changed', {
      mintUrl: result.operation.mintUrl,
      secrets: result.spentInputSecrets,
      state: 'spent',
    });
  }

  async #publishFailedSwap(result: FailedSwapExecution): Promise<void> {
    if (!result.committed) return;

    await this.#publishCommittedEvent('proofs:released', {
      mintUrl: result.operation.mintUrl,
      secrets: result.releasedInputSecrets,
    });
    await this.#publishCommittedEvent('send:rolled-back', {
      mintUrl: result.operation.mintUrl,
      operationId: result.operation.id,
      operation: result.operation,
    });
  }

  async #publishCancelledSend(result: CancelledPreparedSend): Promise<void> {
    if (!result.committed) return;
    await this.#publishCommittedEvent('proofs:released', {
      mintUrl: result.operation.mintUrl,
      secrets: result.releasedInputSecrets,
    });
    await this.#publishCommittedEvent('send:rolled-back', {
      mintUrl: result.operation.mintUrl,
      operationId: result.operation.id,
      operation: result.operation,
    });
    this.#logger?.info('Prepared Send operation cancelled', { operationId: result.operation.id });
  }

  async #publishCompletedSend(result: CompletedPendingSend): Promise<void> {
    if (!result.committed) return;
    if (result.spentProofSecrets.length > 0) {
      await this.#publishCommittedEvent('proofs:state-changed', {
        mintUrl: result.operation.mintUrl,
        secrets: result.spentProofSecrets,
        state: 'spent',
      });
    }
    if (result.releasedInputSecrets.length > 0) {
      await this.#publishCommittedEvent('proofs:released', {
        mintUrl: result.operation.mintUrl,
        secrets: result.releasedInputSecrets,
      });
    }
    if (result.operation.state === 'finalized') {
      await this.#publishCommittedEvent('send:finalized', {
        mintUrl: result.operation.mintUrl,
        operationId: result.operation.id,
        operation: result.operation,
      });
      this.#logger?.info('Send operation finalized', { operationId: result.operation.id });
    }
  }

  #activeKeys(metadata: MintMetadata, unit: string) {
    const keys = createKeyChain(metadata.mint.mintUrl, unit, metadata.keysets)
      .getCheapestKeyset()
      .toMintKeys();
    if (!keys) throw new ProofValidationError('Active keyset is missing mint keys');
    return keys;
  }

  #isDefinitiveSwapFailure(error: unknown): error is MintOperationError {
    return error instanceof MintOperationError && DEFINITIVE_SWAP_MINT_ERROR_CODES.has(error.code);
  }

  async #publishCommittedEvent<E extends keyof CoreEvents>(
    event: E,
    payload: CoreEvents[E],
  ): Promise<void> {
    try {
      await this.#eventBus.emit(event, payload, { throwOnError: true });
    } catch (error) {
      this.#logger?.error('Failed to publish committed Send event', { event, error });
    }
  }

  #normalizeMemo(memo: string): string | undefined {
    const trimmed = memo.trim();
    return trimmed.length > 0 ? trimmed : undefined;
  }

  /**
   * Get an operation by ID.
   */
  async getOperation(operationId: string): Promise<SendOperation | null> {
    return this.#operationQueries.getById(operationId);
  }

  /**
   * Get all pending operations.
   */
  async getPendingOperations(): Promise<SendOperation[]> {
    return this.#operationQueries.getPending();
  }

  /**
   * Get all prepared operations.
   */
  async getPreparedOperations(): Promise<PreparedSendOperation[]> {
    const ops = await this.#operationQueries.getByState('prepared');
    return ops.filter((op): op is PreparedSendOperation => op.state === 'prepared');
  }
}

/** Detach transport proofs without degrading cashu-ts Amount values into plain objects. */
function cloneRefundInputProofs(proofs: readonly Proof[]): Proof[] {
  const detachedProofs: Proof[] = [];
  for (let index = 0; index < proofs.length; index += 1) {
    const proof = proofs[index]!;
    const detached = nativeStructuredClone(proof) as Proof;
    const amountValue = nativeReflectApply(nativeAmountToBigInt, proof.amount, []) as bigint;
    const amount = nativeReflectApply(nativeAmountFrom, Amount, [amountValue]) as Amount;
    detachedProofs[index] = { ...detached, amount };
  }
  return detachedProofs;
}
