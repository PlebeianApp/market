import { afterAll, describe, expect, it } from 'bun:test';
import { cp, mkdtemp, rm } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { runRepositoryInvocationIntrinsicContract } from '@cashu/coco-adapter-tests';
import type { Repositories } from '../../repositories/index.ts';

const coreRoot = dirname(dirname(dirname(fileURLToPath(import.meta.url))));

type MemoryModule = {
  MemoryRepositories: new () => Repositories;
};

const emitted = (await import(
  `${pathToFileURL(join(coreRoot, 'dist/index.js')).href}?round11-invocation-dist`
)) as MemoryModule;
const copiedDirectory = await mkdtemp(join(coreRoot, '.round11-packed-copy-'));
await cp(join(coreRoot, 'dist'), join(copiedDirectory, 'dist'), { recursive: true });
const copied = (await import(
  `${pathToFileURL(join(copiedDirectory, 'dist/index.js')).href}?round11-invocation-copy`
)) as MemoryModule;

afterAll(() => rm(copiedDirectory, { recursive: true, force: true }));

runRepositoryInvocationIntrinsicContract(
  {
    label: 'memory-dist',
    constructRepositories: () => ({
      repositories: new emitted.MemoryRepositories(),
      dispose: () => undefined,
    }),
  },
  { describe, it, expect },
);

runRepositoryInvocationIntrinsicContract(
  {
    label: 'memory-copied-dist',
    constructRepositories: () => ({
      repositories: new copied.MemoryRepositories(),
      dispose: () => undefined,
    }),
  },
  { describe, it, expect },
);
