import { describe, expect, it } from 'bun:test';
import type { RepositoryTransactionScope } from '../../repositories/index.ts';
import {
  getRepositoryFacadeMethods,
  getRepositoryMethodClassification,
} from '../../repositories/RepositoryMutation.ts';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import { MemoryAuthSessionRepository } from '../../repositories/memory/MemoryAuthSessionRepository.ts';
import { MemoryCounterRepository } from '../../repositories/memory/MemoryCounterRepository.ts';
import { MemoryHistoryRepository } from '../../repositories/memory/MemoryHistoryRepository.ts';
import { MemoryKeyRingRepository } from '../../repositories/memory/MemoryKeyRingRepository.ts';
import { MemoryKeysetRepository } from '../../repositories/memory/MemoryKeysetRepository.ts';
import { MemoryLegacyMintQuoteRepository } from '../../repositories/memory/MemoryLegacyMintQuoteRepository.ts';
import { MemoryMeltOperationRepository } from '../../repositories/memory/MemoryMeltOperationRepository.ts';
import { MemoryMeltQuoteRepository } from '../../repositories/memory/MemoryMeltQuoteRepository.ts';
import { MemoryMintOperationRepository } from '../../repositories/memory/MemoryMintOperationRepository.ts';
import { MemoryMintQuoteRepository } from '../../repositories/memory/MemoryMintQuoteRepository.ts';
import { MemoryMintRepository } from '../../repositories/memory/MemoryMintRepository.ts';
import {
  MemoryPaymentRequestReceiveAttemptRepository,
  MemoryPaymentRequestReceiveOperationRepository,
} from '../../repositories/memory/MemoryPaymentRequestReceiveRepository.ts';
import { MemoryProofRepository } from '../../repositories/memory/MemoryProofRepository.ts';
import { MemoryReceiveOperationRepository } from '../../repositories/memory/MemoryReceiveOperationRepository.ts';
import { MemorySendOperationRepository } from '../../repositories/memory/MemorySendOperationRepository.ts';

const repositoryKeys = [
  'mintRepository',
  'keyRingRepository',
  'counterRepository',
  'keysetRepository',
  'proofRepository',
  'mintQuoteRepository',
  'legacyMintQuoteRepository',
  'meltQuoteRepository',
  'historyRepository',
  'sendOperationRepository',
  'meltOperationRepository',
  'authSessionRepository',
  'mintOperationRepository',
  'receiveOperationRepository',
  'paymentRequestReceiveOperationRepository',
  'paymentRequestReceiveAttemptRepository',
] as const satisfies readonly (keyof RepositoryTransactionScope)[];

type RepositoryKey = (typeof repositoryKeys)[number];
const nonPublicPrototypeMethods: Partial<Record<RepositoryKey, ReadonlySet<string>>> = {
  counterRepository: new Set(['key']),
  keysetRepository: new Set(['getMintMap']),
  proofRepository: new Set(['getMintMap']),
  mintQuoteRepository: new Set(['makeKey']),
  legacyMintQuoteRepository: new Set(['makeKey']),
  meltQuoteRepository: new Set(['makeKey']),
  historyRepository: new Set([
    'getProjectedEntries',
    'getOperationEntries',
    'projectOperationById',
    'projectMintOperation',
    'dedupeLegacyEntries',
    'operationKey',
    'quoteKey',
  ]),
  meltOperationRepository: new Set(['assertNoDuplicateQuoteOperation']),
};
type RuntimeRoot = {
  init(): Promise<void>;
  acquireAuthority(identity: { namespace: string; ownerId: string }): Promise<unknown>;
  releaseAuthority(): Promise<boolean>;
  createPeer(): RuntimeRoot;
} & Record<RepositoryKey, object>;

const implementations: Record<RepositoryKey, { prototype: object }> = {
  mintRepository: MemoryMintRepository,
  keyRingRepository: MemoryKeyRingRepository,
  counterRepository: MemoryCounterRepository,
  keysetRepository: MemoryKeysetRepository,
  proofRepository: MemoryProofRepository,
  mintQuoteRepository: MemoryMintQuoteRepository,
  legacyMintQuoteRepository: MemoryLegacyMintQuoteRepository,
  meltQuoteRepository: MemoryMeltQuoteRepository,
  historyRepository: MemoryHistoryRepository,
  sendOperationRepository: MemorySendOperationRepository,
  meltOperationRepository: MemoryMeltOperationRepository,
  authSessionRepository: MemoryAuthSessionRepository,
  mintOperationRepository: MemoryMintOperationRepository,
  receiveOperationRepository: MemoryReceiveOperationRepository,
  paymentRequestReceiveOperationRepository: MemoryPaymentRequestReceiveOperationRepository,
  paymentRequestReceiveAttemptRepository: MemoryPaymentRequestReceiveAttemptRepository,
};

function prototypeMethods(): Array<{ repository: RepositoryKey; method: string }> {
  return repositoryKeys.flatMap((repository) =>
    Object.getOwnPropertyNames(implementations[repository].prototype)
      .filter((method) => {
        if (method === 'constructor') return false;
        const descriptor = Object.getOwnPropertyDescriptor(
          implementations[repository].prototype,
          method,
        );
        return (
          descriptor !== undefined &&
          'value' in descriptor &&
          typeof descriptor.value === 'function'
        );
      })
      .map((method) => ({ repository, method })),
  );
}

function facadeMethods(root: RuntimeRoot): Array<{ repository: RepositoryKey; method: string }> {
  return repositoryKeys.flatMap((repository) =>
    Object.keys(root[repository]).map((method) => ({ repository, method })),
  );
}

function invoke(root: RuntimeRoot, repository: RepositoryKey, method: string): Promise<unknown> {
  const callable = (root[repository] as Record<string, (...args: unknown[]) => unknown>)[method]!;
  return Promise.resolve(callable());
}

async function expectFenced(work: () => Promise<unknown>): Promise<void> {
  try {
    await work();
    throw new Error('expected mutation to be fenced');
  } catch (error) {
    expect([
      'WalletAuthorityLifecycleError',
      'WalletAuthorityNotAcquiredError',
      'WalletAuthorityConflictError',
    ]).toContain((error as Error).name);
  }
}

async function exerciseEveryMutation(
  Constructor: new () => RuntimeRoot,
  mutations: ReadonlyArray<{ repository: RepositoryKey; method: string }>,
): Promise<void> {
  const neverInitializedRoot = new Constructor();
  const neverInitializedPeer = neverInitializedRoot.createPeer();
  for (const mutation of mutations) {
    await expectFenced(() => invoke(neverInitializedRoot, mutation.repository, mutation.method));
    await expectFenced(() => invoke(neverInitializedPeer, mutation.repository, mutation.method));
  }

  const generationOne = new Constructor();
  await generationOne.init();
  await generationOne.acquireAuthority({ namespace: 'wallet', ownerId: 'generation-one' });
  const captured = mutations.map(({ repository, method }) => ({
    repository,
    method,
    callable: (generationOne[repository] as Record<string, (...args: unknown[]) => unknown>)[
      method
    ]!,
  }));
  const generationTwo = generationOne.createPeer();
  await generationTwo.init();
  await generationTwo.acquireAuthority({ namespace: 'wallet', ownerId: 'generation-two' });
  for (const mutation of mutations) {
    await expectFenced(() => invoke(generationOne, mutation.repository, mutation.method));
  }
  for (const mutation of captured) {
    await expectFenced(() => Promise.resolve(mutation.callable()));
    await expectFenced(() => Promise.resolve().then(() => mutation.callable()));
  }

  const released = new Constructor();
  await released.init();
  await released.acquireAuthority({ namespace: 'wallet', ownerId: 'released-root' });
  expect(await released.releaseAuthority()).toBe(true);
  for (const mutation of mutations) {
    await expectFenced(() => invoke(released, mutation.repository, mutation.method));
  }
}

describe('Memory repository deny-by-default mutation fence', () => {
  it('classifies every source and emitted public prototype method and explicitly manifests mutators', async () => {
    const source = new MemoryRepositories() as RuntimeRoot;
    const allMethods = prototypeMethods();
    const methods = allMethods.filter(
      ({ repository, method }) => !nonPublicPrototypeMethods[repository]?.has(method),
    );
    const sourceClassification = methods.map(({ repository, method }) => ({
      repository,
      method,
      classification: getRepositoryMethodClassification(repository, method),
    }));
    expect(
      sourceClassification.filter(({ classification }) => classification === 'unknown-mutation'),
    ).toEqual([]);
    for (const { repository, method } of allMethods.filter(({ repository, method }) =>
      nonPublicPrototypeMethods[repository]?.has(method),
    )) {
      expect(getRepositoryMethodClassification(repository, method)).toBe('unknown-mutation');
    }
    expect(
      sourceClassification.find(
        ({ repository, method }) =>
          repository === 'legacyMintQuoteRepository' && method === 'upsertMintQuote',
      )?.classification,
    ).toBe('mutation');
    expect(
      sourceClassification.find(
        ({ repository, method }) =>
          repository === 'historyRepository' && method === 'addLegacyHistoryEntry',
      )?.classification,
    ).toBe('mutation');

    const dist = (await import('../../dist/index.js')) as unknown as {
      MemoryRepositories: new () => RuntimeRoot;
    };
    const distAdapter = (await import('../../dist/adapter.js')) as unknown as {
      isRepositoryMutation(repository: RepositoryKey, method: string): boolean;
    };
    const sourceFacadeMethods = facadeMethods(source);
    const emittedRoot = new dist.MemoryRepositories();
    const emittedMethods = facadeMethods(emittedRoot);
    expect(emittedMethods).toEqual(sourceFacadeMethods);
    expect(sourceFacadeMethods).toEqual(
      repositoryKeys.flatMap((repository) =>
        getRepositoryFacadeMethods(repository).map((method) => ({ repository, method })),
      ),
    );
    for (const entry of sourceClassification) {
      expect(distAdapter.isRepositoryMutation(entry.repository, entry.method)).toBe(
        entry.classification === 'mutation',
      );
    }
  });

  it('rejects every discovered mutator through stale, captured, delayed, uninitialized, peer, and released source roots', async () => {
    const mutations = facadeMethods(new MemoryRepositories() as RuntimeRoot).filter(
      ({ repository, method }) =>
        getRepositoryMethodClassification(repository, method) === 'mutation',
    );
    await exerciseEveryMutation(MemoryRepositories as unknown as new () => RuntimeRoot, mutations);
  });

  it('enforces the same attacks against emitted Memory artifacts', async () => {
    const dist = (await import('../../dist/index.js')) as unknown as {
      MemoryRepositories: new () => RuntimeRoot;
    };
    const mutations = facadeMethods(new MemoryRepositories() as RuntimeRoot).filter(
      ({ repository, method }) =>
        getRepositoryMethodClassification(repository, method) === 'mutation',
    );
    await exerciseEveryMutation(dist.MemoryRepositories, mutations);
  });

  it('exposes only frozen null-prototype facades and rejects reflection/accessor escape attempts', async () => {
    const root = new MemoryRepositories() as RuntimeRoot;
    for (const repository of repositoryKeys) {
      const facade = root[repository] as Record<PropertyKey, unknown>;
      expect(Object.getPrototypeOf(facade)).toBeNull();
      expect(Object.isFrozen(facade)).toBe(true);
      expect(Object.getOwnPropertySymbols(facade)).toEqual([]);
      for (const method of Object.keys(facade)) {
        expect(Object.getOwnPropertyDescriptor(facade, method)).toMatchObject({
          configurable: false,
          writable: false,
          enumerable: true,
        });
      }
      expect(() => Object.setPrototypeOf(facade, { injected: () => undefined })).toThrow();
      expect(() => Object.defineProperty(facade, 'injected', { get: () => undefined })).toThrow();
      expect(() => delete facade[Object.keys(facade)[0]!]).toThrow();
    }

    let accessorSideEffects = 0;
    const counter = root.counterRepository as Record<PropertyKey, unknown>;
    const hostile = Object.create(null);
    Object.defineProperty(hostile, 'setCounter', {
      get: () => {
        accessorSideEffects++;
        return () => undefined;
      },
    });
    expect(() => Object.setPrototypeOf(counter, hostile)).toThrow();
    expect(accessorSideEffects).toBe(0);
    expect(
      Object.getOwnPropertyDescriptor(Object.getPrototypeOf(counter) ?? {}, 'setCounter'),
    ).toBe(undefined);
  });

  it('keeps source and emitted root implementation state outside reflection', async () => {
    const dist = (await import('../../dist/index.js')) as unknown as {
      MemoryRepositories: new () => RuntimeRoot;
    };
    const forbidden = [
      'backend',
      'initialized',
      'heldAuthority',
      'authorityState',
      'initializeRepositoryProperties',
      'wrapRootRepository',
      'runRootOperation',
      'runExclusive',
      'requireAuthority',
      'assertAuthority',
    ];
    for (const root of [new MemoryRepositories() as RuntimeRoot, new dist.MemoryRepositories()]) {
      const own = Object.getOwnPropertyNames(root);
      const prototype = Object.getOwnPropertyNames(Object.getPrototypeOf(root));
      for (const key of forbidden) {
        expect(own).not.toContain(key);
        expect(prototype).not.toContain(key);
        expect((root as unknown as Record<string, unknown>)[key]).toBeUndefined();
      }
    }
  });

  it('revokes captured transaction facades after the transaction callback completes', async () => {
    const root = new MemoryRepositories();
    await root.init();
    await root.acquireAuthority({ namespace: 'wallet', ownerId: 'transaction-owner' });
    let captured: RepositoryTransactionScope['counterRepository'] | undefined;
    await root.withTransaction(async (scope) => {
      captured = scope.counterRepository;
      await captured.setCounter('https://mint.test', 'keyset', 1);
      expect(Object.getPrototypeOf(captured)).toBeNull();
      expect(Object.isFrozen(captured)).toBe(true);
    });
    await expect(
      Promise.resolve().then(() => captured!.setCounter('https://mint.test', 'keyset', 2)),
    ).rejects.toThrow('transaction has ended');
    expect((await root.counterRepository.getCounter('https://mint.test', 'keyset'))?.counter).toBe(
      1,
    );
  });
});
