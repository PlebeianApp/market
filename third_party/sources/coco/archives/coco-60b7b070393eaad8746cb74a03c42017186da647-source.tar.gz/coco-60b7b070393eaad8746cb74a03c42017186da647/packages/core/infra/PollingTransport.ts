import type { RealTimeTransport } from './RealTimeTransport.ts';
import type {
  WsRequest,
  WsResponse,
  WsNotification,
  SubscribeParams,
  SubscriptionKind,
} from './SubscriptionProtocol.ts';
import type { Logger } from '../logging/Logger.ts';
import type { MintAdapter } from './MintAdapter.ts';
import { mintQuoteToMethodSnapshot } from '../models/MintQuote.ts';
import type { MintMethod } from '../operations/mint/MintMethodHandler.ts';
import type { MintQuotePollingOperation } from '../quotes/MintQuotePolling.ts';
import { normalizeMintUrl } from '../utils.ts';

type Task = {
  subId?: string; // undefined for proof batch sentinel
  kind: SubscribeParams['kind'];
  filter?: string; // single id per subscription (quotes); not used for proof batch
  batch?: boolean; // true for proof_state batch sentinel
};

type MintScheduler = {
  nextAllowedAt: number;
  timer?: ReturnType<typeof setTimeout>;
  queue: Task[];
  running: boolean;
  hasProofBatchTask: boolean;
};

const SUPPORTED_POLLING_KINDS = new Set<SubscriptionKind>([
  'bolt11_mint_quote',
  'onchain_mint_quote',
  'bolt12_mint_quote',
  'bolt11_melt_quote',
  'bolt12_melt_quote',
  'onchain_melt_quote',
  'proof_state',
]);

const MINT_QUOTE_METHOD_BY_KIND: Partial<Record<SubscriptionKind, MintMethod>> = {
  bolt11_mint_quote: 'bolt11',
  bolt12_mint_quote: 'bolt12',
  onchain_mint_quote: 'onchain',
};

export interface PollingOptions {
  intervalMs?: number; // minimum interval between requests per mint
}

export class PollingTransport implements RealTimeTransport {
  private readonly logger?: Logger;
  private readonly mintAdapter: MintAdapter;
  private readonly mintQuotePolling?: MintQuotePollingOperation;
  private readonly options: Required<PollingOptions>;
  private readonly listenersByMint = new Map<
    string,
    Map<'open' | 'message' | 'error' | 'close', Set<(event: any) => void>>
  >();
  private readonly schedByMint = new Map<string, MintScheduler>();
  private readonly proofQueueByMint = new Map<string, string[]>();
  private readonly proofSetByMint = new Map<string, Set<string>>();
  private readonly yToSubsByMint = new Map<string, Map<string, Set<string>>>();
  private readonly subToYsByMint = new Map<string, Map<string, Set<string>>>();
  private readonly intervalByMint = new Map<string, number>();
  // Track unsubscribed subIds to prevent re-enqueuing tasks that are currently being processed
  private readonly unsubscribedByMint = new Map<string, Set<string>>();
  private paused = false;

  constructor(
    mintAdapter: MintAdapter,
    options?: PollingOptions,
    logger?: Logger,
    mintQuotePolling?: MintQuotePollingOperation,
  ) {
    this.logger = logger;
    this.mintAdapter = mintAdapter;
    this.mintQuotePolling = mintQuotePolling;
    this.options = {
      intervalMs: options?.intervalMs ?? 5000,
    };
  }

  on(
    mintUrl: string,
    event: 'open' | 'message' | 'error' | 'close',
    handler: (evt: any) => void,
  ): void {
    mintUrl = normalizeMintUrl(mintUrl);
    let map = this.listenersByMint.get(mintUrl);
    if (!map) {
      map = new Map();
      this.listenersByMint.set(mintUrl, map);
    }
    let set = map.get(event);
    if (!set) {
      set = new Set();
      map.set(event, set);
    }
    if (!set.has(handler)) set.add(handler);

    // Emit synthetic open exactly once per mint
    if (event === 'open') {
      const already = (map.get('open')?.size ?? 0) > 0;
      if (!already) {
        queueMicrotask(() => {
          try {
            handler({ type: 'open' });
          } catch {}
        });
      }
    }

    // Ensure scheduler exists
    this.ensureScheduler(mintUrl);
  }

  send(mintUrl: string, req: WsRequest): void {
    mintUrl = normalizeMintUrl(mintUrl);
    if (req.method === 'subscribe') {
      const params = req.params as SubscribeParams;
      const subId = params.subId;

      if (!this.isSupportedPollingKind(params.kind)) {
        this.logger?.error('PollingTransport: unsupported subscription kind', {
          mintUrl,
          kind: params.kind,
          req,
        });
        const resp: WsResponse = {
          jsonrpc: '2.0',
          error: {
            code: -32602,
            message: `Unsupported subscription kind: ${String(params.kind)}`,
          },
          id: req.id,
        };
        this.emit(mintUrl, 'message', { data: JSON.stringify(resp) });
        return;
      }

      const scheduler = this.ensureScheduler(mintUrl);

      if (params.kind === 'proof_state') {
        const ys = params.filters || [];
        if (!ys.length) {
          this.logger?.error('PollingTransport: subscribe proof_state with no filters', {
            mintUrl,
            req,
          });
        }
        let yToSubs = this.yToSubsByMint.get(mintUrl);
        if (!yToSubs) {
          yToSubs = new Map();
          this.yToSubsByMint.set(mintUrl, yToSubs);
        }
        let subToYs = this.subToYsByMint.get(mintUrl);
        if (!subToYs) {
          subToYs = new Map();
          this.subToYsByMint.set(mintUrl, subToYs);
        }
        let q = this.proofQueueByMint.get(mintUrl);
        if (!q) {
          q = [];
          this.proofQueueByMint.set(mintUrl, q);
        }
        let set = this.proofSetByMint.get(mintUrl);
        if (!set) {
          set = new Set();
          this.proofSetByMint.set(mintUrl, set);
        }

        // Map subId -> Ys
        let subYs = subToYs.get(subId);
        if (!subYs) {
          subYs = new Set();
          subToYs.set(subId, subYs);
        }

        for (const y of ys) {
          subYs.add(y);
          let subs = yToSubs.get(y);
          if (!subs) {
            subs = new Set();
            yToSubs.set(y, subs);
          }
          subs.add(subId);
          if (!set.has(y)) {
            set.add(y);
            q.push(y);
          }
        }

        if (!scheduler.hasProofBatchTask) {
          scheduler.queue.push({ kind: 'proof_state', batch: true });
          scheduler.hasProofBatchTask = true;
        }
      } else {
        const filters = params.filters ?? [];
        if (filters.length === 0) {
          this.logger?.error('PollingTransport: subscribe with no filter', { mintUrl, req });
          return;
        }
        for (const filter of filters) {
          scheduler.queue.push({ subId, kind: params.kind, filter });
        }
      }

      // Acknowledge subscribe immediately
      const resp: WsResponse = { jsonrpc: '2.0', result: { status: 'OK', subId }, id: req.id };
      this.emit(mintUrl, 'message', { data: JSON.stringify(resp) });

      // Try to run now if allowed
      void this.maybeRun(mintUrl);
      return;
    }

    if (req.method === 'unsubscribe') {
      const subId = (req.params as any).subId as string;
      const scheduler = this.ensureScheduler(mintUrl);
      scheduler.queue = scheduler.queue.filter((t) => t.subId !== subId);

      // Track unsubscribed subId to prevent re-enqueuing if task is currently being processed
      let unsubscribed = this.unsubscribedByMint.get(mintUrl);
      if (!unsubscribed) {
        unsubscribed = new Set();
        this.unsubscribedByMint.set(mintUrl, unsubscribed);
      }
      unsubscribed.add(subId);

      // Clean proof mappings
      const subToYs = this.subToYsByMint.get(mintUrl);
      const yToSubs = this.yToSubsByMint.get(mintUrl);
      const q = this.proofQueueByMint.get(mintUrl);
      const set = this.proofSetByMint.get(mintUrl);
      if (subToYs && yToSubs) {
        const ys = subToYs.get(subId);
        if (ys) {
          for (const y of ys) {
            const subs = yToSubs.get(y);
            if (subs) {
              subs.delete(subId);
              if (subs.size === 0) {
                yToSubs.delete(y);
                if (set) set.delete(y);
                if (q) {
                  const idx = q.indexOf(y);
                  if (idx >= 0) q.splice(idx, 1);
                }
              }
            }
          }
          subToYs.delete(subId);
        }
        // If no Ys remain, remove proof batch task
        if (yToSubs.size === 0 && scheduler.hasProofBatchTask) {
          scheduler.queue = scheduler.queue.filter((t) => !(t.kind === 'proof_state' && t.batch));
          scheduler.hasProofBatchTask = false;
        }
      }
      return;
    }
  }

  closeAll(): void {
    for (const scheduler of this.schedByMint.values()) this.clearTimer(scheduler);
    this.schedByMint.clear();
    this.listenersByMint.clear();
    this.proofQueueByMint.clear();
    this.proofSetByMint.clear();
    this.yToSubsByMint.clear();
    this.subToYsByMint.clear();
    this.intervalByMint.clear();
    this.unsubscribedByMint.clear();
  }

  closeMint(mintUrl: string): void {
    mintUrl = normalizeMintUrl(mintUrl);
    const scheduler = this.schedByMint.get(mintUrl);
    if (scheduler) this.clearTimer(scheduler);
    this.schedByMint.delete(mintUrl);
    this.listenersByMint.delete(mintUrl);
    this.proofQueueByMint.delete(mintUrl);
    this.proofSetByMint.delete(mintUrl);
    this.yToSubsByMint.delete(mintUrl);
    this.subToYsByMint.delete(mintUrl);
    this.intervalByMint.delete(mintUrl);
    this.unsubscribedByMint.delete(mintUrl);
  }

  pause(): void {
    this.paused = true;
    for (const scheduler of this.schedByMint.values()) this.clearTimer(scheduler);
  }

  resume(): void {
    this.paused = false;
    // Trigger maybeRun for all mints with schedulers to restart polling
    for (const mintUrl of this.schedByMint.keys()) {
      void this.maybeRun(mintUrl);
    }
  }

  /**
   * Set a custom polling interval for a specific mint.
   * If not set, the default interval from constructor options is used.
   */
  setIntervalForMint(mintUrl: string, intervalMs: number): void {
    this.intervalByMint.set(normalizeMintUrl(mintUrl), intervalMs);
  }

  /**
   * Get the polling interval for a mint (per-mint or default).
   */
  private getIntervalForMint(mintUrl: string): number {
    return this.intervalByMint.get(mintUrl) ?? this.options.intervalMs;
  }

  private isSupportedPollingKind(kind: unknown): kind is SubscriptionKind {
    return typeof kind === 'string' && SUPPORTED_POLLING_KINDS.has(kind as SubscriptionKind);
  }

  private ensureScheduler(mintUrl: string): MintScheduler {
    let s = this.schedByMint.get(mintUrl);
    if (!s) {
      s = { nextAllowedAt: 0, queue: [], running: false, hasProofBatchTask: false };
      this.schedByMint.set(mintUrl, s);
      // Initialize maps for proof batching
      if (!this.proofQueueByMint.get(mintUrl)) this.proofQueueByMint.set(mintUrl, []);
      if (!this.proofSetByMint.get(mintUrl)) this.proofSetByMint.set(mintUrl, new Set());
      if (!this.yToSubsByMint.get(mintUrl)) this.yToSubsByMint.set(mintUrl, new Map());
      if (!this.subToYsByMint.get(mintUrl)) this.subToYsByMint.set(mintUrl, new Map());
    }
    return s;
  }

  private clearTimer(scheduler: MintScheduler): void {
    if (scheduler.timer === undefined) return;
    clearTimeout(scheduler.timer);
    scheduler.timer = undefined;
  }

  private scheduleNext(mintUrl: string, scheduler: MintScheduler): void {
    this.clearTimer(scheduler);
    if (
      this.paused ||
      this.schedByMint.get(mintUrl) !== scheduler ||
      scheduler.running ||
      scheduler.queue.length === 0
    ) {
      return;
    }
    const timer = setTimeout(
      () => {
        if (this.schedByMint.get(mintUrl) !== scheduler || scheduler.timer !== timer) return;
        scheduler.timer = undefined;
        void this.maybeRun(mintUrl);
      },
      Math.max(0, scheduler.nextAllowedAt - Date.now()),
    );
    scheduler.timer = timer;
  }

  private async maybeRun(mintUrl: string): Promise<void> {
    if (this.paused) return;
    const s = this.schedByMint.get(mintUrl);
    if (!s || s.running) return;
    this.clearTimer(s);
    if (s.queue.length === 0) return;
    if (Date.now() < s.nextAllowedAt) {
      // A timer can wake before the wall-clock deadline; keep the queued work scheduled.
      this.scheduleNext(mintUrl, s);
      return;
    }

    s.running = true;
    const task = s.queue.shift()!;
    let opportunity = [task];

    try {
      opportunity = await this.selectOpportunity(mintUrl, task, s);
      await this.performOpportunity(mintUrl, opportunity);
      this.requeueOpportunity(mintUrl, s, opportunity);
    } catch (err) {
      this.logger?.error('Polling task error', { mintUrl, err });
      if (this.getMintQuoteMethod(task.kind) && this.mintQuotePolling) {
        this.requeueOpportunity(mintUrl, s, opportunity);
      }
    } finally {
      s.nextAllowedAt = Date.now() + this.getIntervalForMint(mintUrl);
      s.running = false;
      this.scheduleNext(mintUrl, s);
    }
  }

  private async selectOpportunity(
    mintUrl: string,
    first: Task,
    scheduler: MintScheduler,
  ): Promise<Task[]> {
    const method = this.getMintQuoteMethod(first.kind);
    if (!method || !this.mintQuotePolling || !first.filter) return [first];

    const advertisedLimit = await this.mintQuotePolling.getMintQuotePollingLimit(mintUrl, method);
    const limit = Math.max(1, Math.min(100, Math.floor(advertisedLimit)));
    if (limit === 1) return [first];

    const selected = [first];
    const selectedQuoteIds = new Set([first.filter]);
    const remaining: Task[] = [];
    for (const candidate of scheduler.queue) {
      const isCompatible = candidate.kind === first.kind && candidate.filter !== undefined;
      const isSelectedDuplicate = isCompatible && selectedQuoteIds.has(candidate.filter as string);
      if (isSelectedDuplicate || (isCompatible && selectedQuoteIds.size < limit)) {
        selected.push(candidate);
        selectedQuoteIds.add(candidate.filter!);
      } else {
        remaining.push(candidate);
      }
    }
    scheduler.queue = remaining;
    return selected;
  }

  private requeueOpportunity(mintUrl: string, scheduler: MintScheduler, opportunity: Task[]): void {
    const unsubscribed = this.unsubscribedByMint.get(mintUrl);
    const removedSubIds = new Set<string>();
    for (const task of opportunity) {
      if (task.subId && unsubscribed?.has(task.subId)) {
        removedSubIds.add(task.subId);
      } else {
        scheduler.queue.push(task);
      }
    }
    for (const subId of removedSubIds) unsubscribed?.delete(subId);
  }

  private getMintQuoteMethod(kind: Task['kind']): MintMethod | undefined {
    return MINT_QUOTE_METHOD_BY_KIND[kind];
  }

  private async performOpportunity(mintUrl: string, opportunity: Task[]): Promise<void> {
    const first = opportunity[0]!;
    const method = this.getMintQuoteMethod(first.kind);
    if (!method || !this.mintQuotePolling) {
      await this.performTask(mintUrl, first);
      return;
    }

    const quoteIds = Array.from(
      new Set(opportunity.map(({ filter }) => filter).filter((filter) => filter !== undefined)),
    );
    const result = await this.mintQuotePolling.checkMintQuotesForPolling(
      method,
      quoteIds.map((quoteId) => ({ mintUrl, quoteId })),
    );
    const outcomesByQuoteId = new Map(
      result.outcomes.map((outcome) => [outcome.identity.quoteId, outcome]),
    );
    const unsubscribed = this.unsubscribedByMint.get(mintUrl);
    for (const task of opportunity) {
      if (!task.subId || !task.filter || unsubscribed?.has(task.subId)) continue;
      const outcome = outcomesByQuoteId.get(task.filter);
      if (outcome?.status !== 'updated' || outcome.quote.method !== method) continue;
      const payload = mintQuoteToMethodSnapshot(outcome.quote);
      this.emitNormalizedNotification(mintUrl, task.subId, payload);
    }
  }

  private async performTask(mintUrl: string, task: Task): Promise<void> {
    if (task.kind === 'proof_state' && task.batch) {
      const yToSubs = this.yToSubsByMint.get(mintUrl) ?? new Map<string, Set<string>>();
      const queue = this.proofQueueByMint.get(mintUrl) ?? [];
      if (queue.length === 0 || yToSubs.size === 0) return;

      const selected: string[] = [];
      const selectedSet = new Set<string>();
      let remaining = queue.length;
      // Pull up to 100 unique Ys in round robin.
      while (selected.length < 100 && remaining > 0 && queue.length > 0) {
        remaining--;
        const y = queue.shift()!;
        const subs = yToSubs.get(y);
        if (subs && subs.size > 0 && !selectedSet.has(y)) {
          selected.push(y);
          selectedSet.add(y);
          queue.push(y); // rotate for fairness
        } else if (subs && subs.size > 0) {
          // Drop duplicate queue entries while keeping the rotated selected entry.
          continue;
        } else {
          // drop stale y (no subscribers)
          const set = this.proofSetByMint.get(mintUrl);
          if (set) set.delete(y);
          // do not re-enqueue
        }
      }
      if (selected.length === 0) return;

      const results = await this.mintAdapter.checkProofStates(mintUrl, selected);
      for (let i = 0; i < results.length; i++) {
        const payload = results[i] as any;
        const yFromPayload =
          payload && typeof payload.Y === 'string' ? (payload.Y as string) : undefined;
        const y = yFromPayload ?? selected[i] ?? '';
        if (!y) continue;
        const subs = yToSubs.get(y);
        if (!subs) continue;
        for (const subId of subs.values()) {
          this.emitNormalizedNotification(mintUrl, subId, payload);
        }
      }
      return;
    }

    // Non-proof tasks
    let payload: unknown;
    switch (task.kind) {
      case 'bolt11_mint_quote':
        payload = await this.mintAdapter.checkMintQuote(mintUrl, 'bolt11', task.filter!);
        break;
      case 'onchain_mint_quote':
        payload = await this.mintAdapter.checkMintQuote(mintUrl, 'onchain', task.filter!);
        break;
      case 'bolt12_mint_quote':
        payload = await this.mintAdapter.checkMintQuote(mintUrl, 'bolt12', task.filter!);
        break;
      case 'bolt11_melt_quote':
        payload = await this.mintAdapter.checkMeltQuoteState(mintUrl, task.filter!);
        break;
      case 'bolt12_melt_quote':
        payload = await this.mintAdapter.checkMeltQuoteBolt12State(mintUrl, task.filter!);
        break;
      case 'onchain_melt_quote':
        payload = await this.mintAdapter.checkMeltQuoteOnchain(mintUrl, task.filter!);
        break;
      default:
        throw new Error(`Unsupported polling task kind: ${String(task.kind)}`);
    }
    this.emitNormalizedNotification(mintUrl, task.subId!, payload);
  }

  private emitNormalizedNotification(mintUrl: string, subId: string, payload: unknown): void {
    const notification: WsNotification<unknown> = {
      jsonrpc: '2.0',
      method: 'subscribe',
      params: { subId, payload },
    };
    this.emit(mintUrl, 'message', {
      data: JSON.stringify(notification),
      normalizedPayload: payload,
    });
  }

  private emit(mintUrl: string, event: 'open' | 'message' | 'error' | 'close', evt: any): void {
    const map = this.listenersByMint.get(mintUrl);
    const set = map?.get(event);
    if (!set) return;
    for (const handler of set.values()) {
      try {
        handler(evt);
      } catch {}
    }
  }
}
