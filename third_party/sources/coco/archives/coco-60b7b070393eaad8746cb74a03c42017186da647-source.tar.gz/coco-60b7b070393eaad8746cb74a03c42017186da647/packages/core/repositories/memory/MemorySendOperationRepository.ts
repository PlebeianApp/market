import type { SendOperationRepository } from '..';
import type { SendOperation, SendOperationState } from '../../operations/send/SendOperation';
import {
  createMemoryMap,
  memoryArrayPush,
  memoryMapDelete,
  memoryMapGet,
  memoryMapHas,
  memoryMapSet,
  memoryMapValues,
} from './MemoryCollectionIntrinsics.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
  COPY_MEMORY_REPOSITORY_STATE,
} from './MemoryRepositoryTransaction.ts';
import { MemoryOperationIdOwnership } from '../OperationIdOwnership.ts';

export class MemorySendOperationRepository implements SendOperationRepository {
  private operations = createMemoryMap<string, SendOperation>();

  constructor(private readonly operationIds = new MemoryOperationIdOwnership()) {}

  [COPY_MEMORY_REPOSITORY_STATE](source: MemorySendOperationRepository): void {
    this.operations = cloneMemoryRepositoryStateValue(source.operations);
    this.operationIds.copyFrom(source.operationIds);
  }

  async create(operation: SendOperation): Promise<void> {
    if (memoryMapHas(this.operations, operation.id)) {
      throw new Error(`SendOperation with id ${operation.id} already exists`);
    }
    this.operationIds.claim(operation.id, 'send');
    memoryMapSet(
      this.operations,
      operation.id,
      cloneMemoryValue({ ...operation, revision: operation.revision ?? 0 }),
    );
  }

  async update(operation: SendOperation): Promise<void> {
    if (!memoryMapHas(this.operations, operation.id)) {
      throw new Error(`SendOperation with id ${operation.id} not found`);
    }
    memoryMapSet(
      this.operations,
      operation.id,
      cloneMemoryValue({
        ...operation,
        revision: operation.revision ?? 0,
        updatedAt: Date.now(),
      }),
    );
  }

  async transition(input: {
    operationId: string;
    expectedState: SendOperationState;
    expectedRevision: number;
    next: SendOperation;
  }): Promise<boolean> {
    const current = memoryMapGet(this.operations, input.operationId);
    if (
      !current ||
      current.state !== input.expectedState ||
      (current.revision ?? 0) !== input.expectedRevision
    ) {
      return false;
    }
    if (input.next.id !== input.operationId) {
      throw new Error('Send operation transition cannot change the operation id');
    }
    memoryMapSet(
      this.operations,
      input.operationId,
      cloneMemoryValue({
        ...input.next,
        revision: input.expectedRevision + 1,
      }),
    );
    return true;
  }

  async getById(id: string): Promise<SendOperation | null> {
    const op = memoryMapGet(this.operations, id);
    return op ? cloneMemoryValue({ ...op, revision: op.revision ?? 0 }) : null;
  }

  async getByState(state: SendOperationState): Promise<SendOperation[]> {
    const results: SendOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.state === state) {
        memoryArrayPush(results, cloneMemoryValue(op));
      }
    }
    return results;
  }

  async getPending(): Promise<SendOperation[]> {
    const results: SendOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.state === 'executing' || op.state === 'pending' || op.state === 'rolling_back') {
        memoryArrayPush(results, cloneMemoryValue(op));
      }
    }
    return results;
  }

  async getByMintUrl(mintUrl: string): Promise<SendOperation[]> {
    const results: SendOperation[] = [];
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      const op = operations[index]!;
      if (op.mintUrl === mintUrl) {
        memoryArrayPush(results, cloneMemoryValue(op));
      }
    }
    return results;
  }

  async getAll(): Promise<SendOperation[]> {
    const operations = memoryMapValues(this.operations);
    for (let index = 0; index < operations.length; index += 1) {
      operations[index] = cloneMemoryValue(operations[index]!);
    }
    return operations;
  }

  async delete(id: string): Promise<void> {
    memoryMapDelete(this.operations, id);
  }
}
