import { hashToCurve, type Proof, type ProofState } from '@cashu/cashu-ts';
import type { MintMetadata } from '@core/mints/MintMetadata.ts';
import type { ProofStateInput, SerializedOutputData } from '@core/utils.ts';
import type { SwapTransportRequest } from '@core/transactions/send/types.ts';

/** A mint-and-unit-scoped protocol client. It has no Wallet persistence authority. */
export interface SendRemoteSession {
  swap(request: SwapTransportRequest): Promise<{ keep: Proof[]; send: Proof[] }>;
  checkProofStates(proofs: ProofStateInput[]): Promise<ProofState[]>;
  observeReclaimInputStates(proofs: ProofStateInput[]): Promise<ReclaimInputStateObservation>;
  restoreOutputs(outputData: SerializedOutputData): Promise<Proof[]>;
  observeReclaimOutputs(outputData: SerializedOutputData): Promise<ReclaimOutputObservation>;
  reclaim(proofs: Proof[], outputData: SerializedOutputData): Promise<Proof[]>;
}

export type ReclaimInputStateObservation =
  | {
      status: 'complete';
      inputs: Array<{ secret: string; state: ProofState }>;
    }
  | {
      status: 'inconclusive';
      reason: 'unavailable' | 'malformed' | 'unmatched' | 'duplicate' | 'incomplete';
    };

const VALID_PROOF_STATES = new Set(['UNSPENT', 'PENDING', 'SPENT']);

/** Derive the exact NUT-07 identities for a set of proof secrets. */
export function getProofStateYs(
  expectedProofs: readonly Pick<ProofStateInput, 'secret'>[],
): string[] {
  const encoder = new TextEncoder();
  return expectedProofs.map((proof) => hashToCurve(encoder.encode(proof.secret)).toHex(true));
}

/** Validate untrusted NUT-07 evidence against the exact expected proof identities. */
export function validateProofStateResponse(
  expectedProofs: readonly Pick<ProofStateInput, 'secret'>[],
  response: unknown,
): ReclaimInputStateObservation {
  const expectedYs = getProofStateYs(expectedProofs);
  const expected = expectedProofs.map((proof, index) => ({
    secret: proof.secret,
    Y: expectedYs[index]!,
  }));
  const expectedByY = new Map(expected.map((input) => [input.Y, input] as const));
  if (expectedByY.size !== expected.length) {
    return { status: 'inconclusive', reason: 'duplicate' };
  }
  if (!Array.isArray(response)) {
    return { status: 'inconclusive', reason: 'malformed' };
  }
  if (response.length !== expected.length) {
    return { status: 'inconclusive', reason: 'incomplete' };
  }

  const stateByY = new Map<string, ProofState>();
  for (const candidate of response) {
    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) {
      return { status: 'inconclusive', reason: 'malformed' };
    }
    const stateRecord = candidate as Record<string, unknown>;
    const { Y, state, witness } = stateRecord;
    if (
      typeof Y !== 'string' ||
      typeof state !== 'string' ||
      !VALID_PROOF_STATES.has(state) ||
      !Object.prototype.hasOwnProperty.call(stateRecord, 'witness') ||
      (witness !== null && typeof witness !== 'string')
    ) {
      return { status: 'inconclusive', reason: 'malformed' };
    }
    if (!expectedByY.has(Y)) {
      return { status: 'inconclusive', reason: 'unmatched' };
    }
    if (stateByY.has(Y)) {
      return { status: 'inconclusive', reason: 'duplicate' };
    }
    stateByY.set(Y, {
      Y,
      state: state as ProofState['state'],
      witness,
    });
  }
  if (stateByY.size !== expected.length) {
    return { status: 'inconclusive', reason: 'incomplete' };
  }
  return {
    status: 'complete',
    inputs: expected.map(({ secret, Y }) => ({ secret, state: stateByY.get(Y)! })),
  };
}

export type ReclaimOutputProofObservation = { proof: Proof; state: ProofState };

export type ReclaimOutputObservation =
  | { status: 'none' }
  | { status: 'complete'; outputs: ReclaimOutputProofObservation[] }
  | { status: 'partial'; outputs: ReclaimOutputProofObservation[]; missingOutputs: number }
  | {
      status: 'inconclusive';
      reason: 'unavailable' | 'malformed' | 'unmatched';
      outputs: ReclaimOutputProofObservation[];
    };

export interface SendRemote {
  open(metadata: MintMetadata, unit: string): SendRemoteSession;
}
