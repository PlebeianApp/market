import { Amount } from '@cashu/cashu-ts';
import { describe, it, expect, mock, beforeEach } from 'bun:test';
import { SubscriptionManager } from '../../infra/SubscriptionManager';
import { PollingTransport } from '../../infra/PollingTransport';
import type { RealTimeTransport } from '../../infra/RealTimeTransport';
import type { MintAdapter } from '../../infra/MintAdapter';
import type { WsRequest } from '../../infra/SubscriptionProtocol';
import { NullLogger } from '../../logging';
import type { Logger } from '../../logging';

// Mock MintAdapter for testing
const createMockMintAdapter = (): MintAdapter =>
  ({
    checkMintQuote: mock(() => Promise.resolve({})),
    checkMeltQuoteState: mock(() => Promise.resolve({})),
    checkProofStates: mock(() => Promise.resolve([])),
  }) as unknown as MintAdapter;

class MockTransport implements RealTimeTransport {
  public paused = false;
  public resumed = false;
  public sentMessages: WsRequest[] = [];
  public rejectSubscribes = false;
  private listeners: Map<string, Map<string, Set<(evt: any) => void>>> = new Map();

  on(
    mintUrl: string,
    event: 'open' | 'message' | 'error' | 'close',
    handler: (evt: any) => void,
  ): void {
    if (!this.listeners.has(mintUrl)) {
      this.listeners.set(mintUrl, new Map());
    }
    const mintListeners = this.listeners.get(mintUrl)!;
    if (!mintListeners.has(event)) {
      mintListeners.set(event, new Set());
    }
    mintListeners.get(event)!.add(handler);

    // Simulate open event
    if (event === 'open') {
      queueMicrotask(() => handler({ type: 'open' }));
    }
  }

  send(mintUrl: string, req: WsRequest): void {
    this.sentMessages.push(req);
    // Simulate successful subscription response
    const messageListeners = this.listeners.get(mintUrl)?.get('message');
    if (messageListeners && req.method === 'subscribe') {
      const response = {
        data: JSON.stringify({
          jsonrpc: '2.0',
          ...(this.rejectSubscribes
            ? { error: { code: -32602, message: 'unsupported kind' } }
            : { result: { status: 'OK', subId: (req.params as any).subId } }),
          id: req.id,
        }),
      };
      queueMicrotask(() => {
        for (const listener of messageListeners) {
          listener(response);
        }
      });
    }
  }

  closeAll(): void {
    this.listeners.clear();
  }

  closeMint(mintUrl: string): void {
    this.listeners.delete(mintUrl);
  }

  pause(): void {
    this.paused = true;
  }

  resume(): void {
    this.resumed = true;
    this.paused = false;
    // Simulate socket reconnection by triggering 'open' events for all mints with listeners
    for (const [mintUrl, eventMap] of this.listeners.entries()) {
      const openListeners = eventMap.get('open');
      if (openListeners && openListeners.size > 0) {
        queueMicrotask(() => {
          for (const listener of openListeners) {
            listener({ type: 'open' });
          }
        });
      }
    }
  }

  triggerMessage(mintUrl: string, notification: any): void {
    const messageListeners = this.listeners.get(mintUrl)?.get('message');
    if (messageListeners) {
      for (const listener of messageListeners) {
        listener({ data: JSON.stringify(notification) });
      }
    }
  }
}

describe('SubscriptionManager pause/resume', () => {
  let mockTransport: MockTransport;
  let subManager: SubscriptionManager;

  beforeEach(() => {
    mockTransport = new MockTransport();
    subManager = new SubscriptionManager(mockTransport, createMockMintAdapter(), new NullLogger());
  });

  it('should call pause on all transports when paused', () => {
    subManager.pause();
    expect(mockTransport.paused).toBe(true);
  });

  it('should call resume on all transports when resumed', () => {
    subManager.pause();
    subManager.resume();
    expect(mockTransport.resumed).toBe(true);
  });

  it('should allow subscriptions while paused but not send until resume', async () => {
    const mintUrl = 'https://mint.example.com';

    const messageCountBeforePause = mockTransport.sentMessages.length;
    subManager.pause();

    // Subscribe while paused
    const { subId } = await subManager.subscribe(mintUrl, 'bolt11_mint_quote', ['quote1']);

    // Subscription should be created
    expect(subId).toBeDefined();

    // But no subscribe message should be sent yet (still at same count)
    expect(mockTransport.sentMessages.length).toBe(messageCountBeforePause);

    // Now resume
    subManager.resume();

    // Wait for async re-subscription
    await new Promise((resolve) => setTimeout(resolve, 50));

    // Now the subscribe message should have been sent
    expect(mockTransport.sentMessages.length).toBeGreaterThan(messageCountBeforePause);

    const subscribeMessages = mockTransport.sentMessages.filter(
      (msg) => msg.method === 'subscribe' && (msg.params as any).subId === subId,
    );
    expect(subscribeMessages.length).toBeGreaterThan(0);

    await subManager.unsubscribe(mintUrl, subId);
  });

  it('should re-subscribe all active subscriptions on resume', async () => {
    const mintUrl = 'https://mint.example.com';

    // Create a subscription
    const { subId } = await subManager.subscribe(mintUrl, 'bolt11_mint_quote', [
      'quote1',
      'quote2',
    ]);

    const messageCountBeforePause = mockTransport.sentMessages.length;

    // Pause and resume
    subManager.pause();
    subManager.resume();

    // Wait for async re-subscription
    await new Promise((resolve) => setTimeout(resolve, 50));

    // Should have sent subscribe messages again
    expect(mockTransport.sentMessages.length).toBeGreaterThan(messageCountBeforePause);

    // Check that a re-subscribe message was sent
    const resubscribeMessages = mockTransport.sentMessages.filter(
      (msg) => msg.method === 'subscribe' && (msg.params as any).subId === subId,
    );
    expect(resubscribeMessages.length).toBeGreaterThan(1);

    await subManager.unsubscribe(mintUrl, subId);
  });

  it('should allow new subscriptions after resume', async () => {
    const mintUrl = 'https://mint.example.com';

    subManager.pause();
    subManager.resume();

    // Should be able to subscribe again
    const { subId } = await subManager.subscribe(mintUrl, 'bolt11_mint_quote', ['quote1']);

    expect(subId).toBeDefined();
    await subManager.unsubscribe(mintUrl, subId);
  });

  it('should handle pause with multiple active subscriptions', async () => {
    const mintUrl1 = 'https://mint1.example.com';
    const mintUrl2 = 'https://mint2.example.com';

    const { subId: subId1 } = await subManager.subscribe(mintUrl1, 'bolt11_mint_quote', ['quote1']);
    const { subId: subId2 } = await subManager.subscribe(mintUrl2, 'bolt11_melt_quote', ['quote2']);

    const messageCountBeforePause = mockTransport.sentMessages.length;

    subManager.pause();
    subManager.resume();

    // Wait for async re-subscription
    await new Promise((resolve) => setTimeout(resolve, 50));

    // Should have re-subscribed both
    expect(mockTransport.sentMessages.length).toBeGreaterThan(messageCountBeforePause);

    await subManager.unsubscribe(mintUrl1, subId1);
    await subManager.unsubscribe(mintUrl2, subId2);
  });

  it('should handle multiple pause/resume cycles', async () => {
    const mintUrl = 'https://mint.example.com';

    const { subId } = await subManager.subscribe(mintUrl, 'bolt11_mint_quote', ['quote1']);

    subManager.pause();
    subManager.resume();

    await new Promise((resolve) => setTimeout(resolve, 50));

    subManager.pause();
    subManager.resume();

    await new Promise((resolve) => setTimeout(resolve, 50));

    // Should still work
    expect(mockTransport.resumed).toBe(true);

    await subManager.unsubscribe(mintUrl, subId);
  });

  it('should not re-subscribe after pause if subscription was unsubscribed', async () => {
    const mintUrl = 'https://mint.example.com';

    const { subId } = await subManager.subscribe(mintUrl, 'bolt11_mint_quote', ['quote1']);

    // Unsubscribe before pause
    await subManager.unsubscribe(mintUrl, subId);

    const messageCountAfterUnsub = mockTransport.sentMessages.length;

    subManager.pause();
    subManager.resume();

    await new Promise((resolve) => setTimeout(resolve, 50));

    // Should not have sent additional subscribe messages for the unsubscribed sub
    const newSubscribes = mockTransport.sentMessages
      .slice(messageCountAfterUnsub)
      .filter((msg) => msg.method === 'subscribe' && (msg.params as any).subId === subId);
    expect(newSubscribes.length).toBe(0);
  });

  it('keeps logical subscriptions active when a subscribe request is rejected', async () => {
    const mintUrl = 'https://mint.example.com';
    mockTransport.rejectSubscribes = true;

    const { subId } = await subManager.subscribe(mintUrl, 'onchain_mint_quote', ['quote1']);
    await new Promise((resolve) => setTimeout(resolve, 10));

    mockTransport.triggerMessage(mintUrl, {
      jsonrpc: '2.0',
      method: 'subscribe',
      params: {
        subId,
        payload: {
          quote: 'quote1',
          request: 'bc1ptest',
          unit: 'sat',
          expiry: null,
          pubkey: 'pubkey-1',
          amount_paid: 10,
          amount_issued: 0,
        },
      },
    });

    expect(subManager.getDiagnostics().subscriptions).toEqual(
      expect.arrayContaining([expect.objectContaining({ subId, mintUrl })]),
    );

    await subManager.unsubscribe(mintUrl, subId);
  });

  it('normalizes raw BOLT11 quote notifications through cashu-ts before delivery', async () => {
    const mintUrl = 'https://mint.example.com';
    const normalized = {
      method: 'bolt11' as const,
      quote: 'quote1',
      request: 'lnbc1test',
      amount: Amount.from(10),
      unit: 'sat',
      expiry: null,
      state: 'PAID' as const,
      amount_paid: Amount.from(10),
      amount_issued: Amount.zero(),
      updated_at: null,
    };
    const checkMintQuote = mock(async () => normalized);
    subManager = new SubscriptionManager(
      mockTransport,
      { checkMintQuote } as unknown as MintAdapter,
      new NullLogger(),
    );
    let receivePayload: (payload: typeof normalized) => void = () => {};
    const receivedPayload = new Promise<typeof normalized>((resolve) => {
      receivePayload = resolve;
    });

    const { subId } = await subManager.subscribe<typeof normalized>(
      mintUrl,
      'bolt11_mint_quote',
      ['quote1'],
      receivePayload,
    );
    mockTransport.triggerMessage(mintUrl, {
      jsonrpc: '2.0',
      method: 'subscribe',
      params: {
        subId,
        payload: {
          quote: 'quote1',
          request: 'lnbc1test',
          amount: 10,
          unit: 'sat',
          amount_paid: 10,
          amount_issued: 0,
        },
      },
    });

    await expect(receivedPayload).resolves.toBe(normalized);
    expect(checkMintQuote).toHaveBeenCalledWith(mintUrl, 'bolt11', 'quote1');

    await subManager.unsubscribe(mintUrl, subId);
  });

  it('delivers normalized polling BOLT11 notifications without refetching them', async () => {
    const mintUrl = 'https://mint.example.com';
    const normalized = {
      method: 'bolt11' as const,
      quote: 'quote1',
      request: 'lnbc1test',
      amount: Amount.from(10),
      unit: 'sat',
      expiry: null,
      state: 'PAID' as const,
      amount_paid: Amount.from(10),
      amount_issued: Amount.zero(),
      updated_at: null,
    };
    const checkMintQuote = mock(async () => normalized);
    const mintAdapter = { checkMintQuote } as unknown as MintAdapter;
    const pollingTransport = new PollingTransport(
      mintAdapter,
      { intervalMs: 5_000 },
      new NullLogger(),
    );
    subManager = new SubscriptionManager(pollingTransport, mintAdapter, new NullLogger());
    let receivePayload: (payload: typeof normalized) => void = () => {};
    const receivedPayload = new Promise<typeof normalized>((resolve) => {
      receivePayload = resolve;
    });

    const { unsubscribe } = await subManager.subscribe<typeof normalized>(
      mintUrl,
      'bolt11_mint_quote',
      ['quote1'],
      receivePayload,
    );

    await expect(receivedPayload).resolves.toBe(normalized);
    expect(checkMintQuote).toHaveBeenCalledTimes(1);

    await unsubscribe();
    pollingTransport.closeAll();
  });

  it('drops a raw BOLT11 quote notification when normalization finishes after unsubscribe', async () => {
    const mintUrl = 'https://mint.example.com';
    const normalized = {
      method: 'bolt11' as const,
      quote: 'quote1',
      request: 'lnbc1test',
      amount: Amount.from(10),
      unit: 'sat',
      expiry: null,
      state: 'PAID' as const,
      amount_paid: Amount.from(10),
      amount_issued: Amount.zero(),
      updated_at: null,
    };
    let resolveNormalization!: (quote: typeof normalized) => void;
    const pendingNormalization = new Promise<typeof normalized>((resolve) => {
      resolveNormalization = resolve;
    });
    const checkMintQuote = mock(() => pendingNormalization);
    const callback = mock(() => {});
    subManager = new SubscriptionManager(
      mockTransport,
      { checkMintQuote } as unknown as MintAdapter,
      new NullLogger(),
    );

    const { subId, unsubscribe } = await subManager.subscribe(
      mintUrl,
      'bolt11_mint_quote',
      ['quote1'],
      callback,
    );
    mockTransport.triggerMessage(mintUrl, {
      jsonrpc: '2.0',
      method: 'subscribe',
      params: { subId, payload: { quote: 'quote1' } },
    });
    expect(checkMintQuote).toHaveBeenCalledTimes(1);

    await unsubscribe();
    resolveNormalization(normalized);
    await pendingNormalization;
    await Promise.resolve();

    expect(callback).not.toHaveBeenCalled();
  });

  it('logs a synchronous callback failure and delivers to sibling subscribers', async () => {
    const mintUrl = 'https://mint.example.com';
    const callbackError = new Error('callback failed');
    const error = mock(() => {});
    const logger = {
      error,
      warn: mock(() => {}),
      info: mock(() => {}),
      debug: mock(() => {}),
    } satisfies Logger;
    subManager = new SubscriptionManager(mockTransport, createMockMintAdapter(), logger);
    const failingCallback = mock(() => {
      throw callbackError;
    });
    const healthyCallback = mock(() => {});

    const first = await subManager.subscribe(
      mintUrl,
      'onchain_mint_quote',
      ['quote1'],
      failingCallback,
    );
    const second = await subManager.subscribe(
      mintUrl,
      'onchain_mint_quote',
      ['quote1'],
      healthyCallback,
    );
    mockTransport.triggerMessage(mintUrl, {
      jsonrpc: '2.0',
      method: 'subscribe',
      params: { subId: first.subId, payload: { quote: 'quote1' } },
    });
    await Promise.resolve();

    expect(healthyCallback).toHaveBeenCalledTimes(1);
    expect(error).toHaveBeenCalledWith('Subscription callback error', {
      mintUrl,
      subId: first.subId,
      err: callbackError,
    });

    await first.unsubscribe();
    await second.unsubscribe();
  });

  it('should handle pause with no active subscriptions', () => {
    subManager.pause();
    subManager.resume();

    // Should not error
    expect(mockTransport.resumed).toBe(true);
  });

  it('preserves an injected transport after closeAll', async () => {
    const mintUrl = 'https://mint.example.com';

    await subManager.subscribe(mintUrl, 'bolt11_mint_quote', ['quote1']);
    expect(mockTransport.sentMessages.some((message) => message.method === 'subscribe')).toBe(true);

    subManager.closeAll();
    const messageCountAfterClose = mockTransport.sentMessages.length;

    await subManager.subscribe(mintUrl, 'bolt11_mint_quote', ['quote2']);

    const messagesAfterClose = mockTransport.sentMessages.slice(messageCountAfterClose);
    expect(messagesAfterClose.some((message) => message.method === 'subscribe')).toBe(true);
  });
});
