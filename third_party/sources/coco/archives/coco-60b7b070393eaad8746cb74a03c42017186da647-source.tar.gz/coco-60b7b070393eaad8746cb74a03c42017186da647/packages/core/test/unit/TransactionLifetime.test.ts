import { describe, expect, it } from 'bun:test';
import type { RepositoryTransactionScope } from '../../repositories/index.ts';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import { createTestMemoryRepositories } from '../fixtures/TestMemoryRepositories.ts';
import { TransactionLifetime } from '../../transactions/scoped/TransactionLifetime.ts';
import { RepositoryKeypairCommands } from '../../transactions/scoped/keypairs/ScopedKeypairCommands.ts';

function gate() {
  let release!: () => void;
  const promise = new Promise<void>((resolve) => {
    release = resolve;
  });
  return { promise, release };
}

function importedKey(publicKeyHex: string) {
  return { publicKeyHex, secretKey: new Uint8Array(32), purpose: 'p2pk' as const };
}

describe('TransactionLifetime', () => {
  it('dispatches through module-captured construction, collection, promise, and call intrinsics', async () => {
    const native = {
      Map,
      Promise,
      Proxy,
      Set,
      WeakMap,
      functionApply: Function.prototype.apply,
      functionBind: Function.prototype.bind,
      functionCall: Function.prototype.call,
      mapGet: Map.prototype.get,
      mapHas: Map.prototype.has,
      mapSet: Map.prototype.set,
      objectCreate: Object.create,
      objectDefineProperty: Object.defineProperty,
      objectGetOwnPropertyDescriptor: Object.getOwnPropertyDescriptor,
      objectGetPrototypeOf: Object.getPrototypeOf,
      promiseAll: Promise.all,
      promiseReject: Promise.reject,
      promiseResolve: Promise.resolve,
      promiseThen: Promise.prototype.then,
      reflectApply: Reflect.apply,
      reflectGet: Reflect.get,
      setAdd: Set.prototype.add,
      setDelete: Set.prototype.delete,
      setSize: Object.getOwnPropertyDescriptor(Set.prototype, 'size')!,
      setValues: Set.prototype.values,
      weakMapGet: WeakMap.prototype.get,
      weakMapHas: WeakMap.prototype.has,
      weakMapSet: WeakMap.prototype.set,
    };
    const fail = () => {
      throw new Error('post-import transaction intrinsic was consulted');
    };
    const module = {
      read: () => 42 as unknown as Promise<number>,
    };
    const modules = { module };
    let result: number | undefined;

    try {
      Function.prototype.apply = fail as typeof Function.prototype.apply;
      Function.prototype.bind = fail as typeof Function.prototype.bind;
      Function.prototype.call = fail as typeof Function.prototype.call;
      native.Map.prototype.get = fail as typeof Map.prototype.get;
      native.Map.prototype.has = fail as typeof Map.prototype.has;
      native.Map.prototype.set = fail as typeof Map.prototype.set;
      Object.create = fail as typeof Object.create;
      Object.getOwnPropertyDescriptor = fail as typeof Object.getOwnPropertyDescriptor;
      Object.getPrototypeOf = fail as typeof Object.getPrototypeOf;
      native.Promise.all = fail as typeof Promise.all;
      native.Promise.reject = fail as typeof Promise.reject;
      native.Promise.resolve = fail as typeof Promise.resolve;
      native.Promise.prototype.then = fail as typeof Promise.prototype.then;
      Reflect.apply = fail as typeof Reflect.apply;
      Reflect.get = fail as typeof Reflect.get;
      native.Set.prototype.add = fail as typeof Set.prototype.add;
      native.Set.prototype.delete = fail as typeof Set.prototype.delete;
      native.objectDefineProperty(native.Set.prototype, 'size', {
        configurable: true,
        get: fail,
      });
      native.Set.prototype.values = fail as typeof Set.prototype.values;
      native.WeakMap.prototype.get = fail as typeof WeakMap.prototype.get;
      native.WeakMap.prototype.has = fail as typeof WeakMap.prototype.has;
      native.WeakMap.prototype.set = fail as typeof WeakMap.prototype.set;
      Object.defineProperty = fail as typeof Object.defineProperty;
      globalThis.Map = fail as unknown as MapConstructor;
      globalThis.Promise = fail as unknown as PromiseConstructor;
      globalThis.Proxy = fail as unknown as ProxyConstructor;
      globalThis.Set = fail as unknown as SetConstructor;
      globalThis.WeakMap = fail as unknown as WeakMapConstructor;

      const lifetime = new TransactionLifetime();
      const bound = lifetime.bind(modules);
      result = await lifetime.run(() => bound.module.read());
    } finally {
      globalThis.WeakMap = native.WeakMap;
      globalThis.Set = native.Set;
      globalThis.Proxy = native.Proxy;
      globalThis.Promise = native.Promise;
      globalThis.Map = native.Map;
      Object.defineProperty = native.objectDefineProperty;
      native.WeakMap.prototype.set = native.weakMapSet;
      native.WeakMap.prototype.has = native.weakMapHas;
      native.WeakMap.prototype.get = native.weakMapGet;
      native.Set.prototype.values = native.setValues;
      native.objectDefineProperty(native.Set.prototype, 'size', native.setSize);
      native.Set.prototype.delete = native.setDelete;
      native.Set.prototype.add = native.setAdd;
      Reflect.get = native.reflectGet;
      Reflect.apply = native.reflectApply;
      native.Promise.prototype.then = native.promiseThen;
      native.Promise.resolve = native.promiseResolve;
      native.Promise.reject = native.promiseReject;
      native.Promise.all = native.promiseAll;
      Object.getPrototypeOf = native.objectGetPrototypeOf;
      Object.getOwnPropertyDescriptor = native.objectGetOwnPropertyDescriptor;
      Object.create = native.objectCreate;
      native.Map.prototype.set = native.mapSet;
      native.Map.prototype.has = native.mapHas;
      native.Map.prototype.get = native.mapGet;
      Function.prototype.call = native.functionCall;
      Function.prototype.bind = native.functionBind;
      Function.prototype.apply = native.functionApply;
    }

    expect(result).toBe(42);
  });

  it('binds frozen commands and inherited repository getters without changing their receiver', async () => {
    const repositories = await createTestMemoryRepositories();
    const lifetime = new TransactionLifetime();
    await repositories.withTransaction((scope) => {
      const keyRingRepository = Object.freeze(
        Object.assign({}, scope.keyRingRepository, {
          setPersistedKeyPair: scope.keyRingRepository.setPersistedKeyPair,
        }),
      );
      class GetterScope {
        #repository = keyRingRepository;

        get keyRingRepository() {
          return this.#repository;
        }
      }
      const bound = lifetime.bind(new GetterScope());
      expect(bound.keyRingRepository).toBe(bound.keyRingRepository);
      const commands = lifetime.bind(
        Object.freeze({ keypairs: new RepositoryKeypairCommands(bound.keyRingRepository) }),
      );
      return lifetime.run(() => commands.keypairs.importP2pk(importedKey('frozen')));
    });
    expect(await repositories.keyRingRepository.getAllPersistedKeyPairs('p2pk')).toEqual([
      importedKey('frozen'),
    ]);
  });

  it('drains repository calls inside a failed command and rejects further calls before rollback', async () => {
    const repositories = await createTestMemoryRepositories();
    const blocked = gate();
    const failed = gate();
    const failure = new Error('sibling failed');
    let bound!: RepositoryTransactionScope;
    let ended = false;
    let writesFinished = 0;
    const result = repositories
      .withTransaction((scope) => {
        const save = scope.keyRingRepository.setPersistedKeyPair.bind(scope.keyRingRepository);
        const lifetime = new TransactionLifetime();
        bound = lifetime.bind({
          ...scope,
          keyRingRepository: {
            ...scope.keyRingRepository,
            setPersistedKeyPair: async (keypair) => {
              await blocked.promise;
              await save(keypair);
              writesFinished++;
            },
          },
          counterRepository: {
            ...scope.counterRepository,
            setCounter: async () => {
              failed.release();
              throw failure;
            },
          },
        });
        // Tracking only the command promise would miss the write still running after rejection.
        const commands = lifetime.bind({
          keypairs: {
            async importP2pk() {
              await Promise.all([
                bound.keyRingRepository.setPersistedKeyPair(importedKey('slow')),
                bound.counterRepository.setCounter('https://mint.test', 'keyset', 7),
              ]);
            },
          },
        });
        return lifetime.run(() => commands.keypairs.importP2pk());
      })
      .then(
        () => ({ ok: true as const }),
        (error: unknown) => ({ ok: false as const, error }),
      )
      .finally(() => {
        ended = true;
      });

    try {
      await failed.promise;
      await new Promise((resolve) => setTimeout(resolve, 0));
      expect(ended).toBe(false);
      expect(writesFinished).toBe(0);
      await expect(bound.keyRingRepository.deletePersistedKeyPair('slow', 'p2pk')).rejects.toBe(
        failure,
      );
    } finally {
      blocked.release();
    }
    expect(await result).toEqual({ ok: false, error: failure });
    expect(writesFinished).toBe(1);
    expect(await repositories.keyRingRepository.getAllPersistedKeyPairs('p2pk')).toEqual([]);
    expect(
      await repositories.counterRepository.getCounter('https://mint.test', 'keyset'),
    ).toBeNull();
  });

  it.each(['commit', 'rollback'] as const)('revokes repositories after %s', async (outcome) => {
    const repositories = await createTestMemoryRepositories();
    let bound!: RepositoryTransactionScope;
    let persistKey!: RepositoryTransactionScope['keyRingRepository']['setPersistedKeyPair'];
    const result = repositories.withTransaction((scope) => {
      const lifetime = new TransactionLifetime();
      bound = lifetime.bind(scope);
      persistKey = bound.keyRingRepository.setPersistedKeyPair;
      return lifetime.run(async () => {
        if (outcome === 'rollback') throw new Error('abort');
      });
    });
    if (outcome === 'rollback') await expect(result).rejects.toThrow('abort');
    else await result;

    await expect(bound.keyRingRepository.setPersistedKeyPair(importedKey('late'))).rejects.toThrow(
      'Wallet transaction scope is closed',
    );
    await expect(persistKey(importedKey('late'))).rejects.toThrow(
      'Wallet transaction scope is closed',
    );
    expect(await repositories.keyRingRepository.getAllPersistedKeyPairs('p2pk')).toEqual([]);
  });
});
