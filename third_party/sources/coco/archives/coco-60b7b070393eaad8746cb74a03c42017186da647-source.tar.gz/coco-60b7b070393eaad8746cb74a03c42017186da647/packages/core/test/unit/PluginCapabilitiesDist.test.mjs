import { deriveKeysetId } from '@cashu/cashu-ts';
import { describe, expect, it } from 'bun:test';

import { initializeCoco, MemoryRepositories } from '../../dist/index.js';

const capabilityMethods = Object.freeze({
  mintService: [
    'addMintByUrl',
    'updateMintData',
    'isTrustedMint',
    'refreshAndCommitIfStale',
    'ensureUpdatedMint',
    'deleteMint',
    'getMintInfo',
    'supportsNut',
    'supportsNut29MintQuoteCheck',
    'getNut29MintQuoteCheckLimit',
    'assertNutSupported',
    'checkPaymentMethodCapability',
    'getMintMethodUnitCapability',
    'listPaymentMethodCapabilities',
    'assertMethodUnitSupported',
    'getAllMints',
    'getAllTrustedMints',
    'trustMint',
    'untrustMint',
  ],
  proofService: [
    'calculateSendAmountWithFees',
    'createOutputsAndIncrementCounters',
    'saveProofs',
    'getReadyProofs',
    'getAllReadyProofs',
    'getBalance',
    'getSpendableBalance',
    'getBalanceBreakdown',
    'getBalances',
    'getSpendableBalances',
    'getBalancesByMint',
    'getBalancesByMintAndUnit',
    'getBalanceTotal',
    'getBalancesByUnit',
    'getBalanceTotalByUnit',
    'getBalancesBreakdown',
    'getTrustedBalances',
    'getTrustedSpendableBalances',
    'getTrustedBalancesBreakdown',
    'setProofState',
    'reserveProofs',
    'releaseProofs',
    'restoreProofsToReady',
    'deleteProofs',
    'wipeProofsByKeysetId',
    'selectProofsToSend',
    'getProofsByKeysetId',
    'hasProofsForKeyset',
    'prepareProofsForReceiving',
    'createBlankOutputs',
  ],
  keyRingService: [
    'generateNewKeyPair',
    'generateMintQuoteKeyPair',
    'addKeyPair',
    'removeKeyPair',
    'getKeyPair',
    'getMintQuoteKeyPair',
    'getLatestKeyPair',
    'getAllKeyPairs',
    'signProof',
  ],
  walletRestoreService: ['sweepKeyset', 'restoreKeyset'],
  counterService: ['getCounter', 'incrementCounter', 'overwriteCounter'],
  tokenService: ['decodeToken'],
  historyService: ['getPaginatedHistory', 'getHistoryEntryById', 'getOperationIdFromHistoryEntry'],
  sendOperationService: [
    'init',
    'prepare',
    'execute',
    'send',
    'finalize',
    'rollback',
    'reclaim',
    'getOperation',
    'getPendingOperations',
    'getPreparedOperations',
  ],
  receiveOperationService: [
    'prepareCallerOwned',
    'init',
    'prepare',
    'receive',
    'execute',
    'finalize',
    'rollback',
    'getOperation',
    'getPendingOperations',
    'getPreparedOperations',
  ],
  meltOperationService: [
    'init',
    'prepareExistingQuote',
    'prepare',
    'execute',
    'finalize',
    'rollback',
    'getOperation',
    'getOperationByQuote',
    'getOperationByQuoteIdentity',
    'listOperationsByQuote',
    'getPendingOperations',
    'getPreparedOperations',
  ],
  mintOperationService: [
    'prepare',
    'execute',
    'finalize',
    'getOperation',
    'getOperationByQuote',
    'getOperationsForQuote',
    'listOperationsByQuote',
    'claimMintQuote',
    'claimPendingMintQuotes',
    'getMintQuoteClaimability',
    'getInFlightOperations',
    'getPendingOperations',
    'observePendingOperation',
    'checkPendingOperation',
  ],
  quotes: ['mint', 'melt'],
  paymentRequestService: ['parse', 'prepare', 'execute'],
  paymentRequestReceiveService: [
    'registerTransportHandler',
    'create',
    'cancel',
    'get',
    'list',
    'claimPayload',
    'ingestPayload',
  ],
  subscriptions: ['subscribe', 'unsubscribe', 'pause', 'resume', 'getDiagnostics'],
  eventBus: ['on', 'once', 'off'],
  logger: ['error', 'warn', 'info', 'debug'],
});

const quoteMethods = Object.freeze({
  mint: ['create', 'get', 'import', 'listPending', 'refresh'],
  melt: ['create', 'get', 'listPending', 'refresh'],
});
const keys = Object.keys(capabilityMethods);
const mintUrl = 'https://offline-dist-capability.invalid';
const keypairs = {
  1: '0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798',
};
const keysetId = deriveKeysetId(keypairs, { unit: 'sat' });
const seed = new Uint8Array(64).fill(0x42);

async function setup() {
  const seedRoot = new MemoryRepositories();
  await seedRoot.init();
  await seedRoot.acquireAuthority({ namespace: 'dist-capability-test', ownerId: 'seed' });
  const now = Math.floor(Date.now() / 1000);
  await seedRoot.mintRepository.addNewMint({
    mintUrl,
    name: 'Offline Dist Mint',
    mintInfo: { name: 'Offline Dist Mint', nuts: {} },
    trusted: true,
    createdAt: now,
    updatedAt: now,
  });
  await seedRoot.keysetRepository.addKeyset({
    mintUrl,
    id: keysetId,
    unit: 'sat',
    keypairs,
    active: true,
    feePpk: 0,
  });
  await seedRoot.counterRepository.setCounter(mintUrl, keysetId, 7);
  await seedRoot.releaseAuthority();
  const repository = seedRoot.createPeer();
  const privileged = new Set([
    repository,
    repository.mintRepository,
    repository.keyRingRepository,
    repository.counterRepository,
    repository.keysetRepository,
    repository.proofRepository,
    repository.mintQuoteRepository,
    repository.legacyMintQuoteRepository,
    repository.meltQuoteRepository,
    repository.historyRepository,
    repository.sendOperationRepository,
    repository.meltOperationRepository,
    repository.authSessionRepository,
    repository.mintOperationRepository,
    repository.receiveOperationRepository,
    repository.paymentRequestReceiveOperationRepository,
    repository.paymentRequestReceiveAttemptRepository,
  ]);
  let initContext;
  let readyContext;
  const manager = await initializeCoco({
    repo: repository,
    seedGetter: async () => seed,
    authority: { namespace: 'dist-capability-test', ownerId: 'runtime' },
    plugins: [
      {
        name: 'dist-capability-audit',
        required: keys,
        onInit(context) {
          initContext = context;
        },
        onReady(context) {
          readyContext = context;
        },
      },
    ],
    watchers: {
      mintOperationWatcher: { disabled: true },
      proofStateWatcher: { disabled: true },
      meltQuoteWatcher: { disabled: true },
    },
    processors: {
      mintOperationProcessor: { disabled: true },
      meltSettlementProcessor: { disabled: true },
    },
  });
  return { manager, repository, privileged, initContext, readyContext };
}

function assertUnreachable(root, privileged) {
  const pending = [root];
  const seen = new Set();
  while (pending.length > 0) {
    const value = pending.pop();
    if ((typeof value !== 'object' && typeof value !== 'function') || value === null) continue;
    if (seen.has(value)) continue;
    seen.add(value);
    expect(privileged.has(value)).toBe(false);
    for (const key of Reflect.ownKeys(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor && 'value' in descriptor) pending.push(descriptor.value);
    }
  }
}

describe('emitted plugin capability boundary', () => {
  it('has no supported-service path to repository authority or configured seed', async () => {
    const { manager, privileged, initContext } = await setup();
    try {
      const services = initContext.services;
      const root = services.keyRingService.transactions?.runner?.repositories;
      const walletService = services.walletRestoreService.walletService;
      const wallet = await walletService?.getWallet?.(mintUrl, 'sat');
      const leakedSeed = wallet?._seed;
      expect(root).toBeUndefined();
      expect(walletService).toBeUndefined();
      expect(services.mintService.mintRepo).toBeUndefined();
      expect(services.counterService.counterRepo).toBeUndefined();
      expect(leakedSeed).toBeUndefined();
      expect(
        leakedSeed instanceof Uint8Array && leakedSeed.every((value, i) => value === seed[i]),
      ).toBe(false);
      assertUnreachable(initContext, privileged);
    } finally {
      await manager.dispose();
    }
  });

  it('emits the exact immutable allowlist for all capabilities and fences captured wrappers', async () => {
    const { manager, repository, privileged, initContext, readyContext } = await setup();
    const services = initContext.services;
    let observedPayload;
    try {
      expect(Object.getPrototypeOf(initContext)).toBeNull();
      expect(Object.isFrozen(initContext)).toBe(true);
      expect(Object.getPrototypeOf(services)).toBeNull();
      expect(Object.isFrozen(services)).toBe(true);
      for (const key of keys) {
        const capability = services[key];
        expect(Object.getPrototypeOf(capability)).toBeNull();
        expect(Object.isFrozen(capability)).toBe(true);
        expect(Object.keys(capability)).toEqual(capabilityMethods[key]);
        expect(capability).not.toBe(readyContext.services[key]);
        for (const name of Object.keys(capability)) {
          const value = capability[name];
          if (key === 'quotes') {
            expect(Object.getPrototypeOf(value)).toBeNull();
            expect(Object.keys(value)).toEqual(quoteMethods[name]);
            for (const method of Object.values(value)) {
              expect(Object.getPrototypeOf(method)).toBeNull();
              expect(Object.isFrozen(method)).toBe(true);
            }
          } else {
            expect(typeof value).toBe('function');
            expect(Object.getPrototypeOf(value)).toBeNull();
            expect(Object.isFrozen(value)).toBe(true);
            expect(value.constructor).toBeUndefined();
          }
        }
        assertUnreachable(capability, privileged);
      }
      const trusted = services.mintService.isTrustedMint;
      expect(trusted.call).toBeUndefined();
      expect(trusted.apply).toBeUndefined();
      expect(trusted.bind).toBeUndefined();
      expect(trusted.constructor).toBeUndefined();
      expect(await trusted(mintUrl)).toBe(true);
      expect(await Function.prototype.call.call(trusted, null, mintUrl)).toBe(true);
      expect(await Reflect.apply(new Proxy(trusted, {}), null, [mintUrl])).toBe(true);
      expect(() => new trusted()).toThrow();
      expect(await services.counterService.getCounter(mintUrl, keysetId)).toMatchObject({
        counter: 7,
      });
      expect(await services.keyRingService.getAllKeyPairs()).toEqual([]);
      services.eventBus.on('counter:updated', (payload) => {
        observedPayload = payload;
      });
      const counter = await services.counterService.overwriteCounter(mintUrl, keysetId, 8);
      expect(Object.getPrototypeOf(counter)).toBeNull();
      expect(Object.isFrozen(counter)).toBe(true);
      expect(observedPayload).toMatchObject({ counter: 8 });
      expect(Object.getPrototypeOf(observedPayload)).toBeNull();
      expect(Object.isFrozen(observedPayload)).toBe(true);

      const results = await Promise.all([
        services.mintService.getAllMints(),
        services.proofService.getBalances(),
        services.keyRingService.getAllKeyPairs(),
        services.historyService.getPaginatedHistory(),
        services.sendOperationService.getOperation('missing-send'),
        services.receiveOperationService.getOperation('missing-receive'),
        services.meltOperationService.getOperation('missing-melt'),
        services.mintOperationService.getOperation('missing-mint'),
        services.quotes.mint.get({ mintUrl, quoteId: 'missing-mint-quote' }),
        services.quotes.melt.get({ mintUrl, quoteId: 'missing-melt-quote' }),
        services.paymentRequestReceiveService.get('missing-payment-request'),
      ]);
      for (const result of results) assertUnreachable(result, privileged);
      const diagnostics = services.subscriptions.getDiagnostics();
      assertUnreachable(diagnostics, privileged);
      expect(Object.isFrozen(diagnostics)).toBe(true);

      let sanitizedError;
      try {
        await services.paymentRequestService.parse('not-a-payment-request');
      } catch (error) {
        sanitizedError = error;
      }
      expect(sanitizedError).toBeInstanceOf(Error);
      expect(sanitizedError.cause).toBeUndefined();
      expect(Object.isFrozen(sanitizedError)).toBe(true);
    } finally {
      await manager.dispose();
    }

    const captured = services.counterService.overwriteCounter;
    await expect(captured(mintUrl, keysetId, 41)).rejects.toThrow(/authority|released/i);
    expect((await repository.counterRepository.getCounter(mintUrl, keysetId))?.counter).toBe(8);
  });
});
