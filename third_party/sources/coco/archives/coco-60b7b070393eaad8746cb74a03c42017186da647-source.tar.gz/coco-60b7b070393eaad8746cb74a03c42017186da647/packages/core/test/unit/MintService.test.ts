import { Amount } from '@cashu/cashu-ts';
import { describe, it, beforeEach, expect, mock } from 'bun:test';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import { MintRequestProvider } from '../../infra/MintRequestProvider.ts';
import { createMintMetadataRefreshDependencies } from '../fixtures/MintMetadataRefresh.ts';
import { MintService } from '../../services/MintService';
import { ProofValidationError } from '../../models/Error';
import type { MemoryMintRepository } from '../../repositories/memory/MemoryMintRepository';
import type { MemoryKeysetRepository } from '../../repositories/memory/MemoryKeysetRepository';
import { EventBus } from '../../events/EventBus';
import type { CoreEvents } from '../../events/types';
import type { Mint } from '../../models/Mint';
import type { MintInfo } from '../../types';
import { MintAdapter } from '../../infra/MintAdapter';
import { createTestMemoryRepositories } from '../fixtures/TestMemoryRepositories.ts';

describe('MintService', () => {
  const testMintUrl = 'https://mint.test';
  const testMintUrl2 = 'https://mint2.test';

  let mintRepo: MemoryMintRepository;
  let keysetRepo: MemoryKeysetRepository;
  let eventBus: EventBus<CoreEvents>;
  let service: MintService;
  let mockAdapter: MintAdapter;

  const mockMintInfo: MintInfo = {
    name: 'Test Mint',
    version: '1.0.0',
    pubkey: 'test-pubkey',
    description: 'Test mint description',
    description_long: 'Long description',
    contact: [],
    nuts: {
      '4': { methods: [], disabled: false },
      '5': { methods: [], disabled: false },
    },
    motd: 'Message of the day',
  } as MintInfo;

  const mockKeysets = [
    {
      id: 'keyset-1',
      unit: 'sat',
      active: true,
      input_fee_ppk: 0,
    },
  ];

  const mockKeys = {
    '1': 'key-1',
    '2': 'key-2',
    '4': 'key-4',
    '8': 'key-8',
  };

  beforeEach(async () => {
    const repositories = await createTestMemoryRepositories();
    mintRepo = repositories.mintRepository as MemoryMintRepository;
    keysetRepo = repositories.keysetRepository as MemoryKeysetRepository;
    eventBus = new EventBus<CoreEvents>();

    // Create mock MintAdapter
    mockAdapter = Object.assign(new MintAdapter(new MintRequestProvider()), {
      fetchMintInfo: mock(() => Promise.resolve(mockMintInfo)),
      fetchKeysets: mock(() => Promise.resolve({ keysets: mockKeysets })),
      fetchKeysForId: mock(() => Promise.resolve(mockKeys)),
      checkMintQuote: mock(() => Promise.resolve({})),
      checkMeltQuoteState: mock(() => Promise.resolve({})),
      checkProofStates: mock(() => Promise.resolve([])),
    });

    service = new MintService(
      mintRepo,
      keysetRepo,
      mockAdapter,
      createMintMetadataRefreshDependencies(repositories),
      undefined,
      eventBus,
    );
  });

  describe('trust management', () => {
    it('should add new mints as untrusted by default', async () => {
      const result = await service.addMintByUrl(testMintUrl);

      expect(result.mint.trusted).toBe(false);
      expect(result.mint.mintUrl).toBe(testMintUrl);
      expect(result.keysets.length).toBeGreaterThan(0);
    });

    it('should add new mints as untrusted when explicitly specified', async () => {
      const result = await service.addMintByUrl(testMintUrl, { trusted: false });

      expect(result.mint.trusted).toBe(false);
      expect(result.mint.mintUrl).toBe(testMintUrl);
    });

    it('should add new mints as trusted when option is set', async () => {
      const result = await service.addMintByUrl(testMintUrl, { trusted: true });

      expect(result.mint.trusted).toBe(true);
      expect(result.mint.mintUrl).toBe(testMintUrl);
      expect(result.keysets.length).toBeGreaterThan(0);
    });

    it('should check if mint is trusted', async () => {
      await service.addMintByUrl(testMintUrl);

      const isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(false);
    });

    it('should trust a mint', async () => {
      await service.addMintByUrl(testMintUrl);

      await service.trustMint(testMintUrl);

      const isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(true);
    });

    it('should untrust a mint', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.trustMint(testMintUrl);

      await service.untrustMint(testMintUrl);

      const isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(false);
    });

    it('should emit mint:updated event when trusting mint', async () => {
      await service.addMintByUrl(testMintUrl);

      const events: any[] = [];
      eventBus.on('mint:updated', (payload) => {
        events.push(payload);
      });

      await service.trustMint(testMintUrl);

      expect(events.length).toBe(1);
      expect(events[0]?.mint.trusted).toBe(true);
    });

    it('should emit mint:updated event when untrusting mint', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.trustMint(testMintUrl);

      const events: any[] = [];
      eventBus.on('mint:updated', (payload) => {
        events.push(payload);
      });

      await service.untrustMint(testMintUrl);

      expect(events.length).toBe(1);
      expect(events[0]?.mint.trusted).toBe(false);
    });
  });

  describe('getAllMints', () => {
    it('should return all mints regardless of trust status', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.addMintByUrl(testMintUrl2);
      await service.trustMint(testMintUrl);

      const allMints = await service.getAllMints();

      expect(allMints.length).toBe(2);
      expect(allMints.some((m) => m.trusted)).toBe(true);
      expect(allMints.some((m) => !m.trusted)).toBe(true);
    });

    it('should return empty array when no mints exist', async () => {
      const allMints = await service.getAllMints();
      expect(allMints.length).toBe(0);
    });
  });

  describe('getAllTrustedMints', () => {
    it('should return only trusted mints', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.addMintByUrl(testMintUrl2);
      await service.trustMint(testMintUrl);

      const trustedMints = await service.getAllTrustedMints();

      expect(trustedMints.length).toBe(1);
      expect(trustedMints[0]?.mintUrl).toBe(testMintUrl);
      expect(trustedMints[0]?.trusted).toBe(true);
    });

    it('should return empty array when no trusted mints exist', async () => {
      await service.addMintByUrl(testMintUrl);

      const trustedMints = await service.getAllTrustedMints();
      expect(trustedMints.length).toBe(0);
    });

    it('should return empty array when no mints exist', async () => {
      const trustedMints = await service.getAllTrustedMints();
      expect(trustedMints.length).toBe(0);
    });
  });

  describe('ensureUpdatedMint', () => {
    it('should create mint if it does not exist', async () => {
      const result = await service.ensureUpdatedMint(testMintUrl);

      expect(result.mint.mintUrl).toBe(testMintUrl);
      expect(result.mint.trusted).toBe(false);
      expect(result.keysets.length).toBeGreaterThan(0);
    });

    it('should update existing mint if data is stale', async () => {
      // Add mint
      await service.addMintByUrl(testMintUrl);

      // Manually set updatedAt to a very old timestamp
      const mint = await mintRepo.getMintByUrl(testMintUrl);
      const oldTimestamp = Math.floor(Date.now() / 1000) - 600; // 10 minutes ago
      mint.updatedAt = oldTimestamp;
      await mintRepo.updateMint(mint);

      const result = await service.ensureUpdatedMint(testMintUrl);

      expect(result.mint.updatedAt).toBeGreaterThan(oldTimestamp);
    });

    it('should return cached data if mint is fresh', async () => {
      const added = await service.addMintByUrl(testMintUrl);

      // Clear mock calls
      (mockAdapter.fetchMintInfo as unknown as { mockClear(): void }).mockClear();

      const result = await service.ensureUpdatedMint(testMintUrl);

      // Should not have fetched again
      expect(mockAdapter.fetchMintInfo).not.toHaveBeenCalled();
      expect(result.mint.mintUrl).toBe(testMintUrl);
    });

    it('excludes previously persisted v3 keysets from cached mint data', async () => {
      await service.addMintByUrl(testMintUrl);
      await keysetRepo.addKeyset({
        mintUrl: testMintUrl,
        id: '0200000000000000',
        unit: 'sat',
        keypairs: mockKeys,
        active: true,
        feePpk: 0,
      });

      const result = await service.ensureUpdatedMint(testMintUrl);

      expect(result.keysets.map((keyset) => keyset.id)).toEqual(['keyset-1']);
    });

    it('excludes previously persisted v3 keysets after refreshing mint data', async () => {
      await service.addMintByUrl(testMintUrl);
      await keysetRepo.addKeyset({
        mintUrl: testMintUrl,
        id: '0200000000000000',
        unit: 'sat',
        keypairs: mockKeys,
        active: true,
        feePpk: 0,
      });
      const mint = await mintRepo.getMintByUrl(testMintUrl);
      mint.updatedAt = 0;
      await mintRepo.updateMint(mint);

      const result = await service.ensureUpdatedMint(testMintUrl);

      expect(result.keysets.map((keyset) => keyset.id)).toEqual(['keyset-1']);
    });

    it('should preserve trust status when updating', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.trustMint(testMintUrl);

      // Make mint stale
      const mint = await mintRepo.getMintByUrl(testMintUrl);
      mint.updatedAt = 0;
      await mintRepo.updateMint(mint);

      const result = await service.ensureUpdatedMint(testMintUrl);

      expect(result.mint.trusted).toBe(true);
    });
  });

  describe('getMintInfo', () => {
    it('should get info for untrusted mint', async () => {
      await service.addMintByUrl(testMintUrl);

      const info = await service.getMintInfo(testMintUrl);

      expect(info).toBeDefined();
      expect(info.name).toBe(mockMintInfo.name);
    });

    it('should get info for trusted mint', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.trustMint(testMintUrl);

      const info = await service.getMintInfo(testMintUrl);

      expect(info).toBeDefined();
      expect(info.name).toBe(mockMintInfo.name);
    });

    it('should fetch and cache info for unknown mint', async () => {
      const info = await service.getMintInfo(testMintUrl);

      expect(info).toBeDefined();
      expect(info.name).toBe(mockMintInfo.name);

      // Verify mint was cached
      const mint = await mintRepo.getMintByUrl(testMintUrl);
      expect(mint).toBeDefined();
      expect(mint.trusted).toBe(false);
    });
  });

  describe('nut support capabilities', () => {
    const useMintInfo = (mintInfo: MintInfo) => {
      mockAdapter.fetchMintInfo = mock(() => Promise.resolve(mintInfo));
    };

    it('returns true when NUT-11 support is advertised', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '11': { supported: true },
        },
      } as MintInfo);

      await expect(service.supportsNut(testMintUrl, 11)).resolves.toBe(true);
      await expect(
        service.assertNutSupported(testMintUrl, 11, 'P2PK send'),
      ).resolves.toBeUndefined();
    });

    it('checks NUT-20 support through the typed API', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '20': { supported: true },
        },
      } as MintInfo);

      await expect(service.assertNutSupported(testMintUrl, 20)).resolves.toBeUndefined();
    });

    it('returns false and rejects when NUT-11 metadata is missing', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '4': { methods: [], disabled: false },
          '5': { methods: [], disabled: false },
        },
      } as MintInfo);

      await expect(service.supportsNut(testMintUrl, 11)).resolves.toBe(false);
      await expect(
        service.assertNutSupported(testMintUrl, 11, 'payment request P2PK'),
      ).rejects.toThrow(ProofValidationError);
    });

    it('returns false when NUT-11 support is explicitly false', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '11': { supported: false },
        },
      } as MintInfo);

      await expect(service.supportsNut(testMintUrl, 11)).resolves.toBe(false);
    });

    it('returns false when NUT-11 metadata is malformed', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '11': true,
        },
      } as unknown as MintInfo);

      await expect(service.supportsNut(testMintUrl, 11)).resolves.toBe(false);
    });

    it('returns false when NUT-11 supported is not the boolean true', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '11': { supported: 'true' },
        },
      } as unknown as MintInfo);

      await expect(service.supportsNut(testMintUrl, 11)).resolves.toBe(false);
    });

    it('keeps existing NUT-04 and NUT-05 method-unit capability checks unchanged', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '4': { methods: [{ method: 'bolt11', unit: 'sat' }], disabled: false },
          '5': { methods: [{ method: 'bolt11', unit: 'sat' }], disabled: false },
          '11': { supported: true },
        },
      } as unknown as MintInfo);

      const mintCapability = await service.getMintMethodUnitCapability(
        testMintUrl,
        4,
        'bolt11',
        'sat',
      );
      const meltCapability = await service.getMintMethodUnitCapability(
        testMintUrl,
        5,
        'bolt11',
        'sat',
      );

      expect(mintCapability.supported).toBe(true);
      expect(meltCapability.supported).toBe(true);
    });

    it('reports NUT-29 mint quote checks for explicitly advertised methods', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '29': { methods: ['bolt11', 'onchain'] },
        },
      } as unknown as MintInfo);

      await expect(service.supportsNut29MintQuoteCheck(testMintUrl, 'bolt11')).resolves.toBe(true);
      await expect(service.supportsNut29MintQuoteCheck(testMintUrl, 'bolt12')).resolves.toBe(false);
    });

    it('uses enabled NUT-04 methods when NUT-29 omits its method list', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '4': { methods: [{ method: 'bolt12', unit: 'sat' }], disabled: false },
          '5': { methods: [], disabled: false },
          '29': {},
        },
      } as unknown as MintInfo);

      await expect(service.supportsNut29MintQuoteCheck(testMintUrl, 'bolt12')).resolves.toBe(true);
      await expect(service.supportsNut29MintQuoteCheck(testMintUrl, 'bolt11')).resolves.toBe(false);
    });

    it('rejects malformed NUT-29 metadata and disabled NUT-04 fallback', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '4': { methods: [{ method: 'bolt11', unit: 'sat' }], disabled: true },
          '5': { methods: [], disabled: false },
          '29': true,
        },
      } as unknown as MintInfo);

      await expect(service.supportsNut29MintQuoteCheck(testMintUrl, 'bolt11')).resolves.toBe(false);
    });

    it('bounds the advertised NUT-29 mint quote check limit at 100', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '29': { methods: ['bolt11'], max_batch_size: 250 },
        },
      } as unknown as MintInfo);

      await expect(service.getNut29MintQuoteCheckLimit(testMintUrl, 'bolt11')).resolves.toBe(100);
    });

    it('uses 100 when NUT-29 omits its mint quote check limit', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '29': { methods: ['bolt11'] },
        },
      } as unknown as MintInfo);

      await expect(service.getNut29MintQuoteCheckLimit(testMintUrl, 'bolt11')).resolves.toBe(100);
    });

    it('uses one quote when NUT-29 is unsupported or advertises an invalid limit', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          ...mockMintInfo.nuts,
          '29': { methods: ['bolt11'], max_batch_size: 0 },
        },
      } as unknown as MintInfo);

      await expect(service.getNut29MintQuoteCheckLimit(testMintUrl, 'bolt11')).resolves.toBe(1);
      await expect(service.getNut29MintQuoteCheckLimit(testMintUrl, 'bolt12')).resolves.toBe(1);
    });
  });

  describe('method-unit capabilities', () => {
    const mintInfoWithMethods = (
      methods4: Array<{
        method: string;
        unit: string;
        min_amount?: number;
        max_amount?: number;
      }> = [],
      methods5 = methods4,
      disabled4 = false,
      disabled5 = false,
    ): MintInfo =>
      ({
        ...mockMintInfo,
        nuts: {
          '4': { methods: methods4, disabled: disabled4 },
          '5': { methods: methods5, disabled: disabled5 },
        },
      }) as MintInfo;

    const useMintInfo = (mintInfo: MintInfo) => {
      mockAdapter.fetchMintInfo = mock(() => Promise.resolve(mintInfo));
    };

    it('rejects NUT-04 when method metadata is missing', async () => {
      useMintInfo({ ...mockMintInfo, nuts: {} } as MintInfo);

      const capability = await service.getMintMethodUnitCapability(testMintUrl, 4, 'bolt11', 'sat');

      expect(capability.supported).toBe(false);
      expect(capability.legacySatAllowed).toBeUndefined();
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'sat',
        }),
      ).rejects.toThrow(ProofValidationError);
    });

    it('rejects non-sat when NUT-04 metadata is missing', async () => {
      useMintInfo({ ...mockMintInfo, nuts: {} } as MintInfo);

      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'usd',
        }),
      ).rejects.toThrow(ProofValidationError);
    });

    it('rejects NUT-05 when method metadata is missing', async () => {
      useMintInfo({ ...mockMintInfo, nuts: {} } as MintInfo);

      const capability = await service.getMintMethodUnitCapability(testMintUrl, 5, 'bolt11', 'sat');

      expect(capability.supported).toBe(false);
      expect(capability.legacySatAllowed).toBeUndefined();
    });

    it('requires explicit NUT-04 onchain method metadata for onchain quotes', async () => {
      useMintInfo({ ...mockMintInfo, nuts: {} } as MintInfo);

      const capability = await service.getMintMethodUnitCapability(
        testMintUrl,
        4,
        'onchain',
        'sat',
      );

      expect(capability.supported).toBe(false);
      expect(capability.legacySatAllowed).toBeUndefined();
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'onchain', 'sat'),
      ).rejects.toThrow(ProofValidationError);
    });

    it('does not treat top-level NUT-30 metadata as onchain support', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '30': { methods: [{ method: 'onchain', unit: 'sat', min_amount: 10 }] },
        },
      } as unknown as MintInfo);

      const capability = await service.getMintMethodUnitCapability(
        testMintUrl,
        4,
        'onchain',
        'sat',
      );

      expect(capability.supported).toBe(false);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'onchain', 'sat'),
      ).rejects.toThrow(ProofValidationError);

      const meltCapability = await service.getMintMethodUnitCapability(
        testMintUrl,
        5,
        'onchain',
        'sat',
      );

      expect(meltCapability.supported).toBe(false);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 5, 'onchain', 'sat'),
      ).rejects.toThrow(ProofValidationError);
    });

    it('rejects NUT-30 as a direct method-unit capability check', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '30': { methods: [{ method: 'onchain', unit: 'sat' }] },
        },
      } as unknown as MintInfo);
      const getCapability = service.getMintMethodUnitCapability.bind(service) as (
        mintUrl: string,
        nut: number,
        method: string,
        unit: string,
      ) => ReturnType<MintService['getMintMethodUnitCapability']>;
      const assertSupported = service.assertMethodUnitSupported.bind(service) as (
        mintUrl: string,
        nut: number,
        method: string,
        scope: string,
      ) => ReturnType<MintService['assertMethodUnitSupported']>;

      await expect(getCapability(testMintUrl, 30, 'onchain', 'sat')).rejects.toThrow(
        ProofValidationError,
      );
      await expect(assertSupported(testMintUrl, 30, 'onchain', 'sat')).rejects.toThrow(
        ProofValidationError,
      );
    });

    it('accepts advertised NUT-04 onchain method metadata', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '4': { methods: [{ method: 'onchain', unit: 'sat', min_amount: 10 }] },
        },
      } as unknown as MintInfo);

      const capability = await service.getMintMethodUnitCapability(
        testMintUrl,
        4,
        'onchain',
        'sat',
      );

      expect(capability.supported).toBe(true);
      expect(capability.minAmount?.equals(Amount.from(10))).toBe(true);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'onchain', 'sat'),
      ).resolves.toBeUndefined();
    });

    it('accepts advertised NUT-05 onchain method metadata', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '5': { methods: [{ method: 'onchain', unit: 'sat', min_amount: 10 }] },
        },
      } as unknown as MintInfo);

      const capability = await service.getMintMethodUnitCapability(
        testMintUrl,
        5,
        'onchain',
        'sat',
      );

      expect(capability.supported).toBe(true);
      expect(capability.minAmount?.equals(Amount.from(10))).toBe(true);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 5, 'onchain', 'sat'),
      ).resolves.toBeUndefined();
    });

    it('rejects disabled NUT settings', async () => {
      useMintInfo(mintInfoWithMethods([{ method: 'bolt11', unit: 'sat' }], undefined, true));

      const capability = await service.getMintMethodUnitCapability(testMintUrl, 4, 'bolt11', 'sat');

      expect(capability.supported).toBe(false);
      expect(capability.disabled).toBe(true);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'sat',
        }),
      ).rejects.toThrow(ProofValidationError);
    });

    it('rejects disabled NUT settings even when method metadata is omitted', async () => {
      useMintInfo({
        ...mockMintInfo,
        nuts: {
          '4': { disabled: true },
        },
      } as MintInfo);

      const capability = await service.getMintMethodUnitCapability(testMintUrl, 4, 'bolt11', 'sat');

      expect(capability.supported).toBe(false);
      expect(capability.disabled).toBe(true);
      expect(capability.legacySatAllowed).toBeUndefined();
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'sat',
        }),
      ).rejects.toThrow(ProofValidationError);
    });

    it('requires a matching method and unit pair', async () => {
      useMintInfo(mintInfoWithMethods([{ method: 'bolt11', unit: 'usd' }]));

      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'USD',
        }),
      ).resolves.toBeUndefined();
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'sat',
        }),
      ).rejects.toThrow(ProofValidationError);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt12', {
          amount: Amount.from(100),
          unit: 'usd',
        }),
      ).rejects.toThrow(ProofValidationError);
    });

    it('enforces advertised min and max amounts', async () => {
      useMintInfo(
        mintInfoWithMethods([{ method: 'bolt11', unit: 'sat', min_amount: 10, max_amount: 100 }]),
      );

      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(9),
          unit: 'sat',
        }),
      ).rejects.toThrow(ProofValidationError);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(101),
          unit: 'sat',
        }),
      ).rejects.toThrow(ProofValidationError);
      await expect(
        service.assertMethodUnitSupported(testMintUrl, 4, 'bolt11', {
          amount: Amount.from(100),
          unit: 'sat',
        }),
      ).resolves.toBeUndefined();
    });
  });

  describe('updateMintData', () => {
    it('should update existing mint data', async () => {
      await service.addMintByUrl(testMintUrl);

      const result = await service.updateMintData(testMintUrl);

      expect(result.mint.mintUrl).toBe(testMintUrl);
      expect(result.keysets.length).toBeGreaterThan(0);
    });

    it('should create and update mint if it does not exist', async () => {
      const result = await service.updateMintData(testMintUrl);

      expect(result.mint.mintUrl).toBe(testMintUrl);
      expect(result.mint.trusted).toBe(false);
      expect(result.keysets.length).toBeGreaterThan(0);
    });
  });

  describe('deleteMint', () => {
    it('should delete mint and its keysets', async () => {
      await service.addMintByUrl(testMintUrl);

      await service.deleteMint(testMintUrl);

      // Mint should no longer exist
      const exists = await mintRepo.isTrustedMint(testMintUrl);
      expect(exists).toBe(false);

      // Keysets should be deleted
      const keysets = await keysetRepo.getKeysetsByMintUrl(testMintUrl);
      expect(keysets.length).toBe(0);
    });

    it('should handle deleting non-existent mint gracefully', async () => {
      await service.deleteMint(testMintUrl);
      // Should not throw
    });
  });

  describe('addMintByUrl', () => {
    it('should emit mint:added event', async () => {
      const events: any[] = [];
      eventBus.on('mint:added', (payload) => {
        events.push(payload);
      });

      await service.addMintByUrl(testMintUrl);

      expect(events.length).toBe(1);
      expect(events[0]?.mint.mintUrl).toBe(testMintUrl);
      expect(events[0]?.mint.trusted).toBe(false);
    });

    it('should return existing mint if already added', async () => {
      const first = await service.addMintByUrl(testMintUrl);
      const second = await service.addMintByUrl(testMintUrl);

      expect(first.mint.mintUrl).toBe(second.mint.mintUrl);
    });

    it('should fetch and store mint info', async () => {
      const result = await service.addMintByUrl(testMintUrl);

      expect(result.mint.mintInfo.name).toBe(mockMintInfo.name);
    });

    it('should fetch and store keysets', async () => {
      const result = await service.addMintByUrl(testMintUrl);

      expect(result.keysets.length).toBeGreaterThan(0);
      expect(result.keysets[0]?.id).toBe('keyset-1');
    });

    it('excludes v3 keysets from the supported mint keysets', async () => {
      mockAdapter.fetchKeysets = mock(() =>
        Promise.resolve({
          keysets: [
            ...mockKeysets,
            {
              id: '0200000000000000',
              unit: 'sat',
              active: true,
              input_fee_ppk: 0,
            },
          ],
        }),
      );

      const result = await service.addMintByUrl(testMintUrl);

      expect(result.keysets.map((keyset) => keyset.id)).toEqual(['keyset-1']);
    });

    it('exposes no supported keysets for a v3-only mint', async () => {
      mockAdapter.fetchKeysets = mock(() =>
        Promise.resolve({
          keysets: [
            {
              id: '0200000000000000',
              unit: 'sat',
              active: true,
              input_fee_ppk: 0,
            },
          ],
        }),
      );

      const result = await service.addMintByUrl(testMintUrl);

      expect(result.keysets).toEqual([]);
    });

    it('should preserve large denomination keys as strings', async () => {
      const largeDenominations = [
        '9007199254740992',
        '9007199254740993',
        '18446744073709551615',
        '340282366920938463463374607431768211455',
      ];
      mockAdapter.fetchKeysForId = mock(() =>
        Promise.resolve({
          ...Object.fromEntries(
            largeDenominations.map((denomination, index) => [denomination, `large-key-${index}`]),
          ),
          '1': 'small-key',
        }),
      );

      await service.addMintByUrl(testMintUrl);

      const stored = await keysetRepo.getKeysetById(testMintUrl, 'keyset-1');
      for (const [index, largeDenomination] of largeDenominations.entries()) {
        expect(stored?.keypairs[largeDenomination]).toBe(`large-key-${index}`);
        expect(Object.keys(stored?.keypairs ?? {})).toContain(largeDenomination);
      }
    });

    it('should update trust status when re-adding with trusted=true', async () => {
      // Add as untrusted
      await service.addMintByUrl(testMintUrl, { trusted: false });
      let isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(false);

      // Re-add with trusted=true
      await service.addMintByUrl(testMintUrl, { trusted: true });
      isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(true);
    });

    it('should update trust status when re-adding with trusted=false', async () => {
      // Add as trusted
      await service.addMintByUrl(testMintUrl, { trusted: true });
      let isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(true);

      // Re-add with trusted=false
      await service.addMintByUrl(testMintUrl, { trusted: false });
      isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(false);
    });

    it('should not change trust status when re-adding without options', async () => {
      // Add as trusted
      await service.addMintByUrl(testMintUrl, { trusted: true });
      let isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(true);

      // Re-add without options
      await service.addMintByUrl(testMintUrl);
      isTrusted = await service.isTrustedMint(testMintUrl);
      expect(isTrusted).toBe(true); // Should remain trusted
    });

    it('should emit mint:updated and mint:trusted events when re-adding with trusted=true', async () => {
      // Add as untrusted
      await service.addMintByUrl(testMintUrl, { trusted: false });

      const trustedEvents: any[] = [];
      const updatedEvents: any[] = [];
      eventBus.on('mint:trusted', (payload) => {
        trustedEvents.push(payload);
      });
      eventBus.on('mint:updated', (payload) => {
        updatedEvents.push(payload);
      });

      // Re-add with trusted=true
      await service.addMintByUrl(testMintUrl, { trusted: true });

      expect(trustedEvents.length).toBe(1);
      expect(trustedEvents[0]?.mintUrl).toBe(testMintUrl);
      expect(updatedEvents.length).toBe(1);
      expect(updatedEvents[0]?.mint.trusted).toBe(true);
    });

    it('should emit mint:updated and mint:untrusted events when re-adding with trusted=false', async () => {
      // Add as trusted
      await service.addMintByUrl(testMintUrl, { trusted: true });

      const untrustedEvents: any[] = [];
      const updatedEvents: any[] = [];
      eventBus.on('mint:untrusted', (payload) => {
        untrustedEvents.push(payload);
      });
      eventBus.on('mint:updated', (payload) => {
        updatedEvents.push(payload);
      });

      // Re-add with trusted=false
      await service.addMintByUrl(testMintUrl, { trusted: false });

      expect(untrustedEvents.length).toBe(1);
      expect(untrustedEvents[0]?.mintUrl).toBe(testMintUrl);
      expect(updatedEvents.length).toBe(1);
      expect(updatedEvents[0]?.mint.trusted).toBe(false);
    });

    it('should not emit trust events when re-adding without trust change', async () => {
      // Add as trusted
      await service.addMintByUrl(testMintUrl, { trusted: true });

      const trustedEvents: any[] = [];
      const untrustedEvents: any[] = [];
      const updatedEvents: any[] = [];
      eventBus.on('mint:trusted', (payload) => {
        trustedEvents.push(payload);
      });
      eventBus.on('mint:untrusted', (payload) => {
        untrustedEvents.push(payload);
      });
      eventBus.on('mint:updated', (payload) => {
        updatedEvents.push(payload);
      });

      // Re-add without changing trust
      await service.addMintByUrl(testMintUrl);

      expect(trustedEvents.length).toBe(0);
      expect(untrustedEvents.length).toBe(0);
      // mint:updated might be emitted if mint is stale, but no trust events
    });
  });

  describe('error handling', () => {
    it('should throw MintFetchError when fetchMintInfo fails', async () => {
      mockAdapter.fetchMintInfo = mock(() => Promise.reject(new Error('Network error')));

      await expect(service.addMintByUrl(testMintUrl)).rejects.toThrow();
    });

    it('should throw MintFetchError when fetchKeysets fails', async () => {
      mockAdapter.fetchKeysets = mock(() => Promise.reject(new Error('Network error')));

      await expect(service.addMintByUrl(testMintUrl)).rejects.toThrow();
    });

    it('should throw KeysetSyncError when fetchKeysForId fails', async () => {
      mockAdapter.fetchKeysForId = mock(() => Promise.reject(new Error('Network error')));

      await expect(service.addMintByUrl(testMintUrl)).rejects.toThrow();
    });
  });

  describe('integration with repository', () => {
    it('should persist trusted state correctly', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.trustMint(testMintUrl);

      const mint = await mintRepo.getMintByUrl(testMintUrl);
      expect(mint.trusted).toBe(true);
    });

    it('should update trusted state correctly', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.trustMint(testMintUrl);
      await service.untrustMint(testMintUrl);

      const mint = await mintRepo.getMintByUrl(testMintUrl);
      expect(mint.trusted).toBe(false);
    });

    it('should handle multiple mints with different trust states', async () => {
      await service.addMintByUrl(testMintUrl);
      await service.addMintByUrl(testMintUrl2);
      await service.trustMint(testMintUrl);

      const mint1 = await mintRepo.getMintByUrl(testMintUrl);
      const mint2 = await mintRepo.getMintByUrl(testMintUrl2);

      expect(mint1.trusted).toBe(true);
      expect(mint2.trusted).toBe(false);
    });
  });
});
