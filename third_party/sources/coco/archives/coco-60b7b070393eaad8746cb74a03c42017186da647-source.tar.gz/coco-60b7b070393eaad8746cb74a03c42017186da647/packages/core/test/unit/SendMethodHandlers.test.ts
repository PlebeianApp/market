import { testMintInfo } from '../fixtures/MintMetadata.ts';
import { Amount, schnorrVerifyMessage, type OutputDataLike, type Proof } from '@cashu/cashu-ts';
import { secp256k1 } from '@noble/curves/secp256k1.js';
import { bytesToHex } from '@noble/curves/utils.js';
import { describe, expect, it, mock } from 'bun:test';
import { DefaultSendHandler } from '../../infra/handlers/send/DefaultSendHandler.ts';
import { P2pkSendHandler } from '../../infra/handlers/send/P2pkSendHandler.ts';
import type { PrepareContext } from '../../operations/send/SendMethodHandler.ts';
import { makeOutputDataCreator } from '../fixtures/OutputDataCreator.ts';
import type { RefundReclaimContext } from '../../operations/send/SendMethodHandler.ts';
import { KeypairP2pkSigner } from '../../keypairs/P2pkSigner.ts';

const mintUrl = 'https://mint.test';
const pubkey = '02f9308a019258c31049344f85f89d5229b531c845836f99b08601f113bce036f9';
const common = {
  id: 'send',
  state: 'init' as const,
  mintUrl,
  amount: Amount.from(10),
  unit: 'sat',
  createdAt: 100,
  updatedAt: 100,
};
const keys = { id: 'keyset', unit: 'sat', keys: {} };

describe('Send method policies', () => {
  it('allows default reclaim and selects exact or forced swap preparation', () => {
    const handler = new DefaultSendHandler();
    const ctx = {
      operation: { ...common, method: 'default', methodData: {} },
      activeKeys: keys,
      mintInfo: { ...testMintInfo, nuts: { ...testMintInfo.nuts, '11': undefined } },
      outputDataCreator: makeOutputDataCreator(),
    } satisfies PrepareContext<'default'>;
    expect(handler.canReclaim).toBe(true);
    expect(handler.prepare(ctx)).toEqual({ forceSwap: false });
    expect(
      handler.prepare({ ...ctx, operation: { ...ctx.operation, methodData: { forceSwap: true } } }),
    ).toEqual({ forceSwap: true });
  });

  it('fixes P2PK outputs synchronously from advertised capabilities and rejects reclaim', () => {
    const output = {
      blindedMessage: { id: 'keyset', amount: Amount.from(10), B_: 'B' },
      blindingFactor: 1n,
      secret: new Uint8Array([1]),
      toProof: () => {
        throw new Error('not used');
      },
    } satisfies OutputDataLike;
    const createP2PKData = mock(() => [output]);
    const handler = new P2pkSendHandler();
    const ctx = {
      operation: { ...common, method: 'p2pk', methodData: { pubkey } },
      activeKeys: keys,
      mintInfo: testMintInfo,
      outputDataCreator: makeOutputDataCreator({ createP2PKData }),
    } satisfies PrepareContext<'p2pk'>;
    expect(handler.prepare(ctx)).toEqual({ forceSwap: true, fixedSendOutputs: [output] });
    expect(createP2PKData).toHaveBeenCalledWith(
      { kind: 'P2PK', data: pubkey },
      Amount.from(10),
      keys,
    );
    expect(handler.canReclaim).toBe(true);
  });

  it('rejects unsupported P2PK and HTLC data before deriving outputs', () => {
    const handler = new P2pkSendHandler();
    const createP2PKData = mock(() => []);
    const ctx = {
      operation: { ...common, method: 'p2pk', methodData: { pubkey } },
      activeKeys: keys,
      mintInfo: { ...testMintInfo, nuts: { ...testMintInfo.nuts, '11': undefined } },
      outputDataCreator: makeOutputDataCreator({ createP2PKData }),
    } satisfies PrepareContext<'p2pk'>;
    expect(() => handler.prepare(ctx)).toThrow('NUT-11 support is required');
    expect(() =>
      handler.prepare({
        ...ctx,
        operation: {
          ...ctx.operation,
          methodData: { options: { pubkey, hashlock: 'hash' } as never },
        },
      }),
    ).toThrow('P2PK send does not support hashlock/HTLC options');
    expect(createP2PKData).not.toHaveBeenCalled();
  });

  describe('P2PK refund subset', () => {
    const recipientSecret = new Uint8Array(32).fill(1);
    const refundSecret = new Uint8Array(32).fill(2);
    const recipient = bytesToHex(secp256k1.getPublicKey(recipientSecret, true));
    const refund = bytesToHex(secp256k1.getPublicKey(refundSecret, true));

    function proof(
      nonce: string,
      locktime: number,
      overrides: { data?: string; tags?: string[][]; p2pk_e?: string } = {},
    ): Proof {
      const tags = overrides.tags ?? [
        ['locktime', String(locktime)],
        ['refund', refund],
      ];
      return {
        id: 'keyset',
        amount: Amount.from(1),
        C: 'C',
        secret: JSON.stringify(['P2PK', { nonce, data: overrides.data ?? recipient, tags }]),
        ...(overrides.p2pk_e ? { p2pk_e: overrides.p2pk_e } : {}),
      };
    }

    function handler(now: number, storedPublicKey = refund) {
      return new P2pkSendHandler(
        new KeypairP2pkSigner({
          async getAllPersistedKeyPairs() {
            return [{ purpose: 'p2pk', publicKeyHex: storedPublicKey, secretKey: refundSecret }];
          },
        }),
        () => now,
      );
    }

    function context(proofs: Proof[]): RefundReclaimContext {
      return {
        operation: {
          ...common,
          state: 'pending',
          method: 'p2pk',
          methodData: { pubkey: recipient },
          needsSwap: true,
          fee: Amount.zero(),
          inputAmount: Amount.from(proofs.length),
          inputProofSecrets: proofs.map((item) => item.secret),
        },
        inputProofs: proofs,
      };
    }

    it('enforces strict locktime at one second before, equality, and one second after', async () => {
      await expect(handler(100).prepareReclaim(context([proof('a', 99)]))).resolves.toBeDefined();
      await expect(handler(100).prepareReclaim(context([proof('a', 100)]))).rejects.toThrow(
        'strictly expired',
      );
      await expect(handler(100).prepareReclaim(context([proof('a', 101)]))).rejects.toThrow(
        'strictly expired',
      );
    });

    it('rejects malformed and unsupported P2PK conditions before signing', async () => {
      const cases = [
        proof('a', 99, { tags: [['locktime', '99']] }),
        proof('a', 99, {
          tags: [
            ['locktime', '99'],
            ['locktime', '99'],
            ['refund', refund],
          ],
        }),
        proof('a', 99, {
          tags: [
            ['locktime', '99'],
            ['refund', refund],
            ['unknown', 'x'],
          ],
        }),
        proof('a', 99, {
          tags: [
            ['locktime', '99'],
            ['refund', refund],
            ['pubkeys', recipient],
          ],
        }),
        proof('a', 99, {
          tags: [
            ['locktime', '99'],
            ['refund', refund],
            ['sigflag', 'SIG_ALL'],
          ],
        }),
        proof('a', 99, {
          tags: [
            ['locktime', '99'],
            ['refund', refund],
            ['n_sigs', '2'],
          ],
        }),
        proof('a', 99, {
          tags: [
            ['locktime', '99'],
            ['refund', refund, recipient],
          ],
        }),
        proof('a', 99, { p2pk_e: 'ephemeral' }),
      ];
      for (const candidate of cases) {
        await expect(handler(100).prepareReclaim(context([candidate]))).rejects.toBeDefined();
      }
    });

    it('canonicalizes key parity and case while binding one normalized batch condition', async () => {
      const alternateRecipient = `${recipient.startsWith('02') ? '03' : '02'}${recipient.slice(2)}`;
      const alternateRefund = `${refund.startsWith('02') ? '03' : '02'}${refund.slice(2)}`;
      const result = await handler(100, alternateRefund.toUpperCase()).prepareReclaim(
        context([
          proof('nonce-a', 99),
          proof('nonce-b', 99, {
            data: alternateRecipient.toUpperCase(),
            tags: [
              ['refund', alternateRefund.toUpperCase()],
              ['locktime', '99'],
            ],
          }),
        ]),
      );
      expect(result.inputProofs).toHaveLength(2);
      expect(result.refundPublicKeyX).toBe(refund.slice(2).toLowerCase());
      expect(result.conditionFingerprint).toHaveLength(64);
      expect(result.inputProofs.every((item) => item.witness !== undefined)).toBe(true);
    });

    it.each([
      ['x-only recipient', { data: recipient.slice(2) }],
      [
        'x-only refund',
        {
          tags: [
            ['locktime', '99'],
            ['refund', refund.slice(2)],
          ],
        },
      ],
      ['invalid prefix', { data: `04${recipient.slice(2)}` }],
      ['invalid compressed point', { data: `02${'00'.repeat(32)}` }],
    ] as const)(
      'rejects %s condition keys at the NUT-11 wire boundary',
      async (_name, override) => {
        await expect(
          handler(100).prepareReclaim(
            context([proof('invalid-key', 99, override as { data?: string; tags?: string[][] })]),
          ),
        ).rejects.toBeDefined();
      },
    );

    it('accepts valid 02 and 03 compressed condition keys', async () => {
      expect(refund.startsWith('02')).toBe(true);
      expect(recipient.startsWith('03')).toBe(true);
      const accepted = await handler(100).prepareReclaim(
        context([
          proof('valid-compressed-keys', 99, {
            data: recipient,
            tags: [
              ['locktime', '99'],
              ['refund', refund],
            ],
          }),
        ]),
      );
      expect(accepted.refundPublicKeyX).toBe(refund.slice(2).toLowerCase());
    });

    it('rejects equal recipient/refund identities and heterogeneous batches', async () => {
      await expect(
        handler(100).prepareReclaim(
          context([
            proof('same', 99, {
              tags: [
                ['locktime', '99'],
                ['refund', recipient],
              ],
            }),
          ]),
        ),
      ).rejects.toThrow('must differ');
      await expect(
        handler(100).prepareReclaim(context([proof('a', 98), proof('b', 99)])),
      ).rejects.toThrow('heterogeneous');
    });

    it('returns only signed proof clones and public binding data', async () => {
      const original = proof('private-data-check', 99);
      const result = await handler(100).prepareReclaim(context([original]));
      expect(original.witness).toBeUndefined();
      expect(JSON.stringify(result)).not.toContain(bytesToHex(refundSecret));
      const witness = JSON.parse(result.inputProofs[0]!.witness as string) as {
        signatures: string[];
      };
      expect(schnorrVerifyMessage(witness.signatures[0]!, original.secret, refund)).toBe(true);
    });
  });
});
