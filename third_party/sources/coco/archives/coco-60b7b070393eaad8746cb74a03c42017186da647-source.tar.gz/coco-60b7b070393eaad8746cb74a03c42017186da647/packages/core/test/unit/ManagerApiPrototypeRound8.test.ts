import { describe, expect, test } from 'bun:test';

const CORE_ROOT = '/home/maximoto/dev/coco-market-prod-2026-09-21/packages/core';
const disabledRuntime = {
  watchers: {
    mintOperationWatcher: { disabled: true },
    proofStateWatcher: { disabled: true },
    meltQuoteWatcher: { disabled: true },
  },
  processors: {
    mintOperationProcessor: { disabled: true },
    meltSettlementProcessor: { disabled: true },
  },
};

const API_CLASSES = {
  mint: {
    className: 'MintApi',
    methods: [
      'addMint',
      'getMintInfo',
      'checkPaymentMethodCapability',
      'listPaymentMethodCapabilities',
      'isTrustedMint',
      'getAllMints',
      'getAllTrustedMints',
      'trustMint',
      'untrustMint',
    ],
  },
  wallet: {
    className: 'WalletApi',
    methods: ['receive', 'restore', 'sweep', 'decodeToken', 'encodeToken', 'encodePaymentRequest'],
  },
  walletBalances: {
    className: 'WalletBalancesApi',
    methods: ['byMint', 'byMintAndUnit', 'byUnit', 'total', 'totalByUnit'],
  },
  keyring: {
    className: 'KeyRingApi',
    methods: [
      'generateKeyPair',
      'generateMintQuoteKeyPair',
      'addKeyPair',
      'removeKeyPair',
      'getKeyPair',
      'getLatestKeyPair',
      'getAllKeyPairs',
    ],
  },
  history: {
    className: 'HistoryApi',
    methods: ['getPaginatedHistory', 'getHistoryEntryById', 'getOperationIdForHistoryEntry'],
  },
  auth: {
    className: 'AuthApi',
    methods: [
      'startDeviceAuth',
      'login',
      'restore',
      'logout',
      'getSession',
      'hasSession',
      'getAuthProvider',
      'getPoolSize',
    ],
  },
  send: {
    className: 'SendOpsApi',
    methods: [
      'prepare',
      'execute',
      'get',
      'listPrepared',
      'listInFlight',
      'refresh',
      'cancel',
      'reclaim',
      'finalize',
    ],
  },
  receive: {
    className: 'ReceiveOpsApi',
    methods: ['prepare', 'execute', 'get', 'listPrepared', 'listInFlight', 'refresh', 'cancel'],
  },
  mintOps: {
    className: 'MintOpsApi',
    methods: [
      'prepare',
      'execute',
      'get',
      'listByQuote',
      'listPending',
      'listInFlight',
      'checkPayment',
      'refresh',
      'finalize',
    ],
  },
  melt: {
    className: 'MeltOpsApi',
    methods: [
      'prepare',
      'execute',
      'get',
      'getByQuote',
      'listByQuote',
      'listPrepared',
      'listInFlight',
      'refresh',
      'cancel',
      'reclaim',
      'finalize',
    ],
  },
  mintQuotes: {
    className: 'MintQuoteApi',
    methods: ['create', 'get', 'import', 'listPending', 'refresh'],
  },
  meltQuotes: {
    className: 'MeltQuoteApi',
    methods: ['create', 'get', 'listPending', 'refresh'],
  },
  paymentRequests: {
    className: 'PaymentRequestsApi',
    methods: ['parse', 'prepare', 'execute'],
  },
} as const;

type Phase = 'before-initialize' | 'on-init' | 'on-ready' | 'after-initialize';

function publicGroups(manager: any): Record<keyof typeof API_CLASSES, any> {
  return {
    mint: manager.mint,
    wallet: manager.wallet,
    walletBalances: manager.wallet.balances,
    keyring: manager.keyring,
    history: manager.history,
    auth: manager.auth,
    send: manager.ops.send,
    receive: manager.ops.receive,
    mintOps: manager.ops.mint,
    melt: manager.ops.melt,
    mintQuotes: manager.quotes.mint,
    meltQuotes: manager.quotes.melt,
    paymentRequests: manager.paymentRequests,
  };
}

function poisonApiPrototypes(core: any, observations: unknown[]) {
  const restores: Array<() => void> = [];
  for (const definition of Object.values(API_CLASSES)) {
    const Api = core[definition.className];
    const actualMethods = Object.getOwnPropertyNames(Api.prototype)
      .filter((name) => name !== 'constructor')
      .sort();
    expect(actualMethods, `${definition.className} emitted shape`).toEqual(
      [...definition.methods].sort(),
    );
    for (const name of definition.methods) {
      const original = Object.getOwnPropertyDescriptor(Api.prototype, name);
      expect(typeof original?.value, `${definition.className}.${name}`).toBe('function');
      Object.defineProperty(Api.prototype, name, {
        ...original,
        value: function (...args: unknown[]) {
          observations.push({ receiver: this, args, className: definition.className, name });
          throw new Error(`poisoned ${definition.className}.${name}`);
        },
      });
      restores.push(() => Object.defineProperty(Api.prototype, name, original!));
    }
  }
  for (const name of ['run', 'inProgress', 'isLocked']) {
    const original = Object.getOwnPropertyDescriptor(Object.prototype, name);
    Object.defineProperty(Object.prototype, name, {
      configurable: true,
      enumerable: false,
      writable: true,
      value: function (...args: unknown[]) {
        observations.push({ receiver: this, args, className: 'Object', name });
        throw new Error(`poisoned nested ${name}`);
      },
    });
    restores.push(() => {
      if (original) Object.defineProperty(Object.prototype, name, original);
      else delete (Object.prototype as Record<string, unknown>)[name];
    });
  }
  return () => {
    for (let index = restores.length - 1; index >= 0; index -= 1) restores[index]!();
  };
}

async function settleCall(call: () => unknown): Promise<void> {
  try {
    await call();
  } catch {
    // Invalid fixtures intentionally force trusted originals to stop before remote value movement.
  }
}

async function exerciseCompleteFacade(manager: any): Promise<number> {
  const groups = publicGroups(manager);
  let calls = 0;
  for (const [groupName, definition] of Object.entries(API_CLASSES)) {
    const group = groups[groupName as keyof typeof API_CLASSES];
    for (const name of definition.methods) {
      calls += 1;
      await settleCall(() => group[name]());
    }
  }

  for (const operation of [
    manager.ops.send,
    manager.ops.receive,
    manager.ops.mint,
    manager.ops.melt,
  ]) {
    calls += 3;
    await settleCall(() => operation.recovery.run());
    await settleCall(() => operation.recovery.inProgress());
    await settleCall(() => operation.diagnostics.isLocked('round8-invalid-operation'));
  }
  calls += 2;
  await settleCall(() => manager.paymentRequests.incoming.recovery.run());
  await settleCall(() =>
    manager.paymentRequests.incoming.diagnostics.isLocked('round8-invalid-operation'),
  );
  return calls;
}

async function probePrototypePhase(label: string, core: any, phase: Phase): Promise<void> {
  const observations: unknown[] = [];
  let restore = () => {};
  let installed = false;
  const install = () => {
    if (installed) return;
    installed = true;
    restore = poisonApiPrototypes(core, observations);
  };
  if (phase === 'before-initialize') install();

  const plugin = {
    name: `round8-prototype-${label}-${phase}`,
    version: '1.0.0',
    onInit() {
      if (phase === 'on-init') install();
    },
    onReady() {
      if (phase === 'on-ready') install();
    },
  };
  let manager: any;
  const originalFetch = globalThis.fetch;
  globalThis.fetch = (async () => {
    throw new Error('round8 offline fetch guard');
  }) as unknown as typeof fetch;
  try {
    manager = await core.initializeCoco({
      repo: new core.MemoryRepositories(),
      seedGetter: async () => new Uint8Array(64),
      plugins: [plugin],
      ...disabledRuntime,
    });
    if (phase === 'after-initialize') install();
    expect(await exerciseCompleteFacade(manager)).toBeGreaterThan(90);
    expect(observations, `${label}/${phase}`).toEqual([]);
  } finally {
    restore();
    await manager?.dispose();
    globalThis.fetch = originalFetch;
  }
}

async function probeExactMintExploit(label: string, core: any): Promise<void> {
  const original = core.MintApi.prototype.addMint;
  let capturedRawApi: unknown;
  core.MintApi.prototype.addMint = function () {
    capturedRawApi = this;
    return Promise.resolve({ mint: null, keysets: [] });
  };
  let activeFetchCalls = 0;
  const originalFetch = globalThis.fetch;
  globalThis.fetch = (async () => {
    activeFetchCalls += 1;
    throw new Error('round8 active offline fetch guard');
  }) as unknown as typeof fetch;
  let manager: any;
  try {
    manager = await core.initializeCoco({
      repo: new core.MemoryRepositories(),
      seedGetter: async () => new Uint8Array(64),
      ...disabledRuntime,
    });
    await settleCall(() => manager.mint.addMint('https://capture.invalid'));
  } finally {
    core.MintApi.prototype.addMint = original;
    globalThis.fetch = originalFetch;
  }
  expect(capturedRawApi, label).toBeUndefined();
  expect(activeFetchCalls).toBe(1);

  await manager.dispose();
  let postDisposeFetchCalls = 0;
  globalThis.fetch = (async () => {
    postDisposeFetchCalls += 1;
    throw new Error('post-dispose fetch probe');
  }) as unknown as typeof fetch;
  try {
    await expect(manager.mint.addMint('https://post-dispose.invalid')).rejects.toThrow();
    const publicReceiver = manager.mint;
    const receiverAttempts = [
      () => original.call(publicReceiver, 'https://post-dispose.invalid'),
      () => original.apply(publicReceiver, ['https://post-dispose.invalid']),
      () => original.bind(publicReceiver)('https://post-dispose.invalid'),
      () => Reflect.apply(original, publicReceiver, ['https://post-dispose.invalid']),
      () =>
        Reflect.apply(original, new Proxy(publicReceiver, {}), ['https://post-dispose.invalid']),
    ];
    for (const attempt of receiverAttempts) {
      let error: unknown;
      try {
        await attempt();
      } catch (caught) {
        error = caught;
      }
      expect(error).toBeInstanceOf(Error);
    }
  } finally {
    globalThis.fetch = originalFetch;
  }
  expect(postDisposeFetchCalls).toBe(0);
}

async function probeExactRootAttachment(label: string, core: any): Promise<void> {
  const root = new core.MemoryRepositories();
  await root.init();
  const authority = await root.acquireAuthority({
    namespace: `round8-${label}`,
    ownerId: 'single-manager',
  });
  const manager = await core.initializeCoco({
    repo: root,
    seedGetter: async () => new Uint8Array(64),
    ...disabledRuntime,
  });
  let disposePromise: Promise<void> | undefined;
  try {
    await expect(
      core.initializeCoco({
        repo: root,
        seedGetter: async () => new Uint8Array(64),
        ...disabledRuntime,
      }),
    ).rejects.toThrow('already attached to an active Manager');
    await expect(
      core.initializeCoco({
        repo: root,
        seedGetter: async () => new Uint8Array(64),
        authority,
        ...disabledRuntime,
      }),
    ).rejects.toThrow('already attached to an active Manager');
    expect(root.getAuthority()).toEqual(authority);
    disposePromise = manager.dispose();
    await expect(
      core.initializeCoco({
        repo: root,
        seedGetter: async () => new Uint8Array(64),
        ...disabledRuntime,
      }),
    ).rejects.toThrow('already attached to an active Manager');
    await disposePromise;
  } finally {
    await manager.dispose();
  }

  const concurrentRoot = new core.MemoryRepositories();
  const outcomes = await Promise.allSettled([
    core.initializeCoco({
      repo: concurrentRoot,
      seedGetter: async () => new Uint8Array(64),
      ...disabledRuntime,
    }),
    core.initializeCoco({
      repo: concurrentRoot,
      seedGetter: async () => new Uint8Array(64),
      ...disabledRuntime,
    }),
  ]);
  const fulfilled = outcomes.filter((outcome) => outcome.status === 'fulfilled');
  const rejected = outcomes.filter((outcome) => outcome.status === 'rejected');
  expect(fulfilled).toHaveLength(1);
  expect(rejected).toHaveLength(1);
  expect((rejected[0] as PromiseRejectedResult).reason.message).toContain('already attached');
  await (fulfilled[0] as PromiseFulfilledResult<any>).value.dispose();

  const failedRoot = new core.MemoryRepositories();
  let startupError: any;
  try {
    await core.initializeCoco({
      repo: failedRoot,
      seedGetter: async () => new Uint8Array(64),
      plugins: [
        {
          name: `round8-attachment-failure-${label}`,
          version: '1.0.0',
          onInit({ registerExtension }: any) {
            registerExtension('round8-conflict', Object.freeze({ first: true }));
            registerExtension('round8-conflict', Object.freeze({ second: true }));
          },
        },
      ],
      ...disabledRuntime,
    });
  } catch (error) {
    startupError = error;
  }
  expect(startupError?.cleanupState).toBe('confirmed');
  expect(failedRoot.getAuthorityState()).toBe('released');
  let retryError: any;
  try {
    await core.initializeCoco({
      repo: failedRoot,
      seedGetter: async () => new Uint8Array(64),
      ...disabledRuntime,
    });
  } catch (error) {
    retryError = error;
  }
  expect(retryError?.message).not.toContain('already attached');
}

for (const [label, modulePath] of [
  ['source', `${CORE_ROOT}/index.ts`],
  ['dist', `${CORE_ROOT}/dist/index.js`],
] as const) {
  describe(`round-eight Manager API dispatch (${label})`, () => {
    for (const phase of ['before-initialize', 'on-init', 'on-ready', 'after-initialize'] as const) {
      test(`ignores complete API prototype poisoning ${phase}`, async () => {
        const core: any = await import(modulePath);
        await probePrototypePhase(label, core, phase);
      });
    }

    test('does not leak the MintApi receiver and performs zero post-dispose work', async () => {
      const core: any = await import(modulePath);
      await probeExactMintExploit(label, core);
    });

    test('single-consumes an exact repository-root attachment', async () => {
      const core: any = await import(modulePath);
      await probeExactRootAttachment(label, core);
    });
  });
}
