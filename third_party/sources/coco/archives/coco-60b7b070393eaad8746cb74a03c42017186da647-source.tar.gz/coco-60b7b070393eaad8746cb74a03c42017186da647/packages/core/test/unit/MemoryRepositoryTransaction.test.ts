import { describe, expect, it } from 'bun:test';
import {
  runRepositoryTransactionContract,
  runCallerOwnedReceiveOperationIdContract,
  runOperationIdOwnershipContract,
  runWalletAuthorityContract,
  runRepositoryConstructionIntrinsicContract,
  runRepositoryInvocationIntrinsicContract,
} from '@cashu/coco-adapter-tests';
import { MemoryRepositories } from '../../repositories/memory/MemoryRepositories.ts';
import { Manager } from '../../Manager.ts';
import {
  WalletAuthorityConflictError,
  WalletAuthorityLifecycleError,
  WalletAuthorityNotAcquiredError,
} from '../../models/Error.ts';
import { activateTestMemoryRepositories } from '../fixtures/TestMemoryRepositories.ts';
import {
  cloneMemoryRepositoryStateValue,
  cloneMemoryValue,
} from '../../repositories/memory/MemoryRepositoryTransaction.ts';

async function createRepositories() {
  const repositories = new MemoryRepositories();
  await repositories.init();
  await repositories.acquireAuthority({ namespace: 'wallet', ownerId: 'contract-root' });
  return {
    repositories,
    dispose: async () => {},
  };
}

async function createSharedRepositories() {
  const first = new MemoryRepositories();
  await first.init();
  await first.acquireAuthority({ namespace: 'wallet', ownerId: 'contract-root' });
  return {
    first,
    second: first,
    dispose: async () => {},
  };
}

async function createIndependentRepositories() {
  const first = new MemoryRepositories();
  const second = first.createPeer();
  await first.init();
  await second.init();
  return {
    first,
    second,
    dispose: async () => {},
  };
}

runRepositoryTransactionContract(
  {
    createRepositories,
    createSharedRepositories,
    testConcurrentRootOperationIsolation: true,
    testWriterOwnershipAtEntry: true,
  },
  { describe, it, expect },
);

runWalletAuthorityContract(
  { createSharedRepositories: createIndependentRepositories },
  {
    describe,
    it,
    expect,
  },
);

runRepositoryConstructionIntrinsicContract(
  {
    constructRepositories: () => ({
      repositories: new MemoryRepositories(),
      dispose: () => undefined,
    }),
  },
  { describe, it, expect },
);

runRepositoryInvocationIntrinsicContract(
  {
    label: 'memory-source',
    constructRepositories: () => ({
      repositories: new MemoryRepositories(),
      dispose: () => undefined,
    }),
  },
  { describe, it, expect },
);

runCallerOwnedReceiveOperationIdContract(
  { createRepositories, createIndependentRepositories },
  { describe, it, expect },
);
runOperationIdOwnershipContract({ createRepositories }, { describe, it, expect });

describe('MemoryRepositories transaction byte isolation', () => {
  it('clones through module-captured descriptor, prototype, iterator, and call intrinsics', () => {
    const source = {
      array: [{ value: 1 }],
      bytes: new Uint8Array([1, 2, 3]),
      date: new Date(1234),
      map: new Map([['entry', { nested: true }]]),
      set: new Set([{ item: true }]),
    };
    const native = {
      arrayIsArray: Array.isArray,
      functionApply: Function.prototype.apply,
      functionBind: Function.prototype.bind,
      functionCall: Function.prototype.call,
      dateGetTime: Date.prototype.getTime,
      mapEntries: Map.prototype.entries,
      mapGet: Map.prototype.get,
      mapHas: Map.prototype.has,
      mapSet: Map.prototype.set,
      objectCreate: Object.create,
      objectGetOwnPropertyDescriptor: Object.getOwnPropertyDescriptor,
      objectGetPrototypeOf: Object.getPrototypeOf,
      reflectApply: Reflect.apply,
      reflectOwnKeys: Reflect.ownKeys,
      setAdd: Set.prototype.add,
      setValues: Set.prototype.values,
      uint8ArraySlice: Uint8Array.prototype.slice,
    };
    const fail = () => {
      throw new Error('post-import intrinsic was consulted');
    };

    let clone: typeof source | undefined;
    try {
      Array.isArray = fail as unknown as typeof Array.isArray;
      Function.prototype.apply = fail as typeof Function.prototype.apply;
      Function.prototype.bind = fail as typeof Function.prototype.bind;
      Function.prototype.call = fail as typeof Function.prototype.call;
      Date.prototype.getTime = fail as typeof Date.prototype.getTime;
      Map.prototype.entries = fail as typeof Map.prototype.entries;
      Map.prototype.get = fail as typeof Map.prototype.get;
      Map.prototype.has = fail as typeof Map.prototype.has;
      Map.prototype.set = fail as typeof Map.prototype.set;
      Object.create = fail as typeof Object.create;
      Object.getOwnPropertyDescriptor = fail as typeof Object.getOwnPropertyDescriptor;
      Object.getPrototypeOf = fail as typeof Object.getPrototypeOf;
      Reflect.apply = fail as typeof Reflect.apply;
      Reflect.ownKeys = fail as typeof Reflect.ownKeys;
      Set.prototype.add = fail as typeof Set.prototype.add;
      Set.prototype.values = fail as typeof Set.prototype.values;
      Uint8Array.prototype.slice = fail as typeof Uint8Array.prototype.slice;
      clone = cloneMemoryRepositoryStateValue(source);
    } finally {
      Uint8Array.prototype.slice = native.uint8ArraySlice;
      Set.prototype.values = native.setValues;
      Set.prototype.add = native.setAdd;
      Reflect.ownKeys = native.reflectOwnKeys;
      Reflect.apply = native.reflectApply;
      Object.getPrototypeOf = native.objectGetPrototypeOf;
      Object.getOwnPropertyDescriptor = native.objectGetOwnPropertyDescriptor;
      Object.create = native.objectCreate;
      Map.prototype.set = native.mapSet;
      Map.prototype.has = native.mapHas;
      Map.prototype.get = native.mapGet;
      Map.prototype.entries = native.mapEntries;
      Date.prototype.getTime = native.dateGetTime;
      Function.prototype.call = native.functionCall;
      Function.prototype.bind = native.functionBind;
      Function.prototype.apply = native.functionApply;
      Array.isArray = native.arrayIsArray;
    }

    expect(clone).toEqual(source);
    expect(clone).not.toBe(source);
    expect(clone!.array).not.toBe(source.array);
    expect(clone!.array[0]).not.toBe(source.array[0]);
    expect(clone!.bytes).not.toBe(source.bytes);
    expect(clone!.map).not.toBe(source.map);
    expect(clone!.set).not.toBe(source.set);
  });

  it('rejects executable or prototype-bearing persisted values without invoking them', () => {
    let getterCalls = 0;
    const accessor = Object.create(null);
    Object.defineProperty(accessor, 'value', {
      enumerable: true,
      get() {
        getterCalls += 1;
        return 1;
      },
    });

    expect(() => cloneMemoryValue(accessor)).toThrow('accessor properties are not supported');
    expect(getterCalls).toBe(0);
    expect(() => cloneMemoryValue({ nested: () => 1 })).toThrow('functions are not supported');
    expect(() => cloneMemoryValue(Object.create({ inherited: true }))).toThrow(
      'custom prototypes are not supported',
    );
    expect(() => cloneMemoryValue({ [Symbol('hidden')]: true })).toThrow(
      'symbol-keyed properties are not supported',
    );
    expect(() => cloneMemoryValue(new Map([['hidden', true]]))).toThrow(
      'Map values are not supported',
    );
  });

  it('rolls back mutations to Buffer-backed key material', async () => {
    const repositories = await activateTestMemoryRepositories(new MemoryRepositories());
    const publicKeyHex = `02${'01'.repeat(32)}`;
    await repositories.keyRingRepository.setPersistedKeyPair({
      publicKeyHex,
      secretKey: Buffer.from([1, 2, 3]),
      purpose: 'p2pk',
    });

    await expect(
      repositories.withTransaction(async ({ keyRingRepository }) => {
        const keyPair = await keyRingRepository.getPersistedKeyPair(publicKeyHex, 'p2pk');
        expect(keyPair).not.toBeNull();
        keyPair!.secretKey[0] = 9;
        throw new Error('abort Wallet transaction');
      }),
    ).rejects.toThrow('abort Wallet transaction');

    const stored = await repositories.keyRingRepository.getPersistedKeyPair(publicKeyHex, 'p2pk');
    expect(Array.from(stored!.secretKey)).toEqual([1, 2, 3]);
  });

  it('rejects root and transaction mutations before initialization', async () => {
    const repositories = new MemoryRepositories();

    await expect(
      repositories.counterRepository.setCounter('https://mint.test', 'keyset', 1),
    ).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);
    await expect(
      repositories.withTransaction(async ({ counterRepository }) => {
        await counterRepository.setCounter('https://mint.test', 'keyset', 1);
      }),
    ).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);

    await repositories.init();
    await expect(
      repositories.counterRepository.setCounter('https://mint.test', 'keyset', 1),
    ).rejects.toBeInstanceOf(WalletAuthorityNotAcquiredError);
    expect(
      await repositories.counterRepository.getCounter('https://mint.test', 'keyset'),
    ).toBeNull();
  });

  it('rejects a stale generation through a newly-created peer and public Manager surfaces', async () => {
    const generationOne = new MemoryRepositories();
    await generationOne.init();
    await generationOne.acquireAuthority({ namespace: 'wallet', ownerId: 'generation-one' });

    const generationTwo = generationOne.createPeer();
    await generationTwo.init();
    await generationTwo.acquireAuthority({ namespace: 'wallet', ownerId: 'generation-two' });

    const stalePeer = generationOne.createPeer();
    const staleManager = new Manager(stalePeer, async () => new Uint8Array(64).fill(1));

    await expect(
      stalePeer.counterRepository.setCounter('https://mint.test', 'keyset', 1),
    ).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);
    await expect(
      stalePeer.withTransaction(async ({ counterRepository }) => {
        await counterRepository.setCounter('https://mint.test', 'keyset', 1);
      }),
    ).rejects.toBeInstanceOf(WalletAuthorityLifecycleError);
    await expect(staleManager.keyring.generateKeyPair(true)).rejects.toBeInstanceOf(
      WalletAuthorityLifecycleError,
    );

    await stalePeer.init();
    await expect(
      stalePeer.counterRepository.setCounter('https://mint.test', 'keyset', 1),
    ).rejects.toBeInstanceOf(WalletAuthorityNotAcquiredError);
    await expect(
      generationOne.counterRepository.setCounter('https://mint.test', 'keyset', 1),
    ).rejects.toBeInstanceOf(WalletAuthorityConflictError);
    expect(
      await generationTwo.counterRepository.getCounter('https://mint.test', 'keyset'),
    ).toBeNull();
  });
});
