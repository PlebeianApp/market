# coco-cashu-react

## 1.1.2-rc.50

### Patch Changes

- Updated dependencies [defce3d]
- Updated dependencies [41d6640]
  - coco-cashu-core@1.1.2-rc.50

## 1.1.2-rc.49

### Patch Changes

- Updated dependencies [5447e2c]
- Updated dependencies [8a2d720]
  - coco-cashu-core@1.1.2-rc.49

## 1.1.2-rc.48

### Patch Changes

- Updated dependencies [db8f3c5]
- Updated dependencies [3b29203]
- Updated dependencies [befcdcf]
- Updated dependencies [16f3de1]
- Updated dependencies [c9e378c]
- Updated dependencies [6b2ac82]
  - coco-cashu-core@1.1.2-rc.48

## 1.1.2-rc.47

### Patch Changes

- Updated dependencies [980cff1]
  - coco-cashu-core@1.1.2-rc.47

## 1.1.2-rc.46

### Patch Changes

- coco-cashu-core@1.1.2-rc.46

## 1.1.2-rc.45

### Patch Changes

- 30aa519: Fix: sqlite-bun package was missing from release pipeline. It's included now
- Updated dependencies [30aa519]
  - coco-cashu-core@1.1.2-rc.45

## 1.1.2-rc.44

### Patch Changes

- Updated dependencies [8bb6f67]
  - coco-cashu-core@1.1.2-rc.44

## 1.1.2-rc.43

### Patch Changes

- Updated dependencies [6f0ed09]
- Updated dependencies [ad87919]
- Updated dependencies [2057978]
- Updated dependencies [db2baec]
  - coco-cashu-core@1.1.2-rc.43

## 1.1.2-rc.42

### Patch Changes

- 7f02bb8: Bumped Cashu-TS to major version 3, added typechecks and fixed them
- Updated dependencies [7f02bb8]
  - coco-cashu-core@1.1.2-rc.42

## 1.1.2-rc.41

### Patch Changes

- Upgraded build dependencies to resolve issue with type declaration files
- Updated dependencies
  - coco-cashu-core@1.1.2-rc.41

## 1.1.2-rc.40

### Patch Changes

- Updated dependencies [7394e3d]
- Updated dependencies [ce556d0]
  - coco-cashu-core@1.1.2-rc.40

## 1.1.2-rc.39

### Patch Changes

- Updated dependencies [9d9e798]
  - coco-cashu-core@1.1.2-rc.39

## 1.1.2-rc.38

### Patch Changes

- Updated dependencies [aa97572]
  - coco-cashu-core@1.1.2-rc.38

## 1.1.2-rc.37

### Patch Changes

- Updated dependencies [f32a8a7]
  - coco-cashu-core@1.1.2-rc.37

## 1.1.2-rc.36

### Patch Changes

- Updated dependencies [027449f]
  - coco-cashu-core@1.1.2-rc.36

## 1.1.2-rc.35

### Patch Changes

- Updated dependencies [406c470]
- Updated dependencies [59693b5]
  - coco-cashu-core@1.1.2-rc.35

## 1.1.2-rc.34

### Patch Changes

- coco-cashu-core@1.1.2-rc.34

## 1.1.2-rc.33

### Patch Changes

- Updated dependencies [c444053]
- Updated dependencies [0c191e6]
- Updated dependencies [d985f02]
- Updated dependencies [05ce81d]
  - coco-cashu-core@1.1.2-rc.33

## 1.1.2-rc.32

### Patch Changes

- 914a862: Implemented the new Send API in useSend
- Updated dependencies [b8d70c5]
  - coco-cashu-core@1.1.2-rc.32

## 1.1.2-rc.31

### Patch Changes

- Updated dependencies [3d270d4]
  - coco-cashu-core@1.1.2-rc.31

## 1.1.2-rc.30

### Patch Changes

- Updated dependencies
  - coco-cashu-core@1.1.2-rc.30

## 1.1.2-rc.29

### Patch Changes

- fixed build issue
- Updated dependencies
  - coco-cashu-core@1.1.2-rc.29

## 1.1.2-rc.28

### Patch Changes

- Updated dependencies [d300ecd]
  - coco-cashu-core@1.1.2-rc.28

## 1.1.2-rc.27

### Patch Changes

- Fixed a build issue
- Updated dependencies
  - coco-cashu-core@1.1.2-rc.27

## 1.1.2-rc.26

### Patch Changes

- 8116b37: Added trusted mint utils to hooks
- Updated dependencies [b0a4428]
- Updated dependencies [0fb58a0]
- Updated dependencies [e2e3374]
  - coco-cashu-core@1.1.2-rc.26
