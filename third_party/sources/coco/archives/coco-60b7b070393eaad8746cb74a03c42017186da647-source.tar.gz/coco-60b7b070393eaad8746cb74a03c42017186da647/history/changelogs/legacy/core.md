# coco-cashu-core

## 1.1.2-rc.50

### Patch Changes

- defce3d: fix(core): handle expired quote (20007) in melt executing recovery to prevent permanent proof locking
- 41d6640: Add binary encoding option for token and PaymentRequest

## 1.1.2-rc.49

### Patch Changes

- 5447e2c: Persist bolt11 melt `payment_preimage` data on finalized operations via method-specific
  `finalizedData`, store it across all melt operation repositories, and update adapter tests to
  require preimage propagation only when the mint actually returns one.
- 8a2d720: Finish the mint quote removal migration and make mint operations the runtime source of truth.
  - Replace legacy `mint-quote:*` runtime events with operation-based mint events.
  - Rename watcher and processor config and manager methods to the operation-based surface:
    `mintOperationWatcher`, `mintOperationProcessor`, `enableMintOperationWatcher()`,
    `enableMintOperationProcessor()`, and related disable/wait helpers.
  - Remove the legacy `MintQuoteService` runtime path and keep `MintQuoteRepository` only for
    cold-start reconciliation of old persisted quote rows.
  - Move mint watcher, processor, history, and recovery flows onto `manager.ops.mint`.

  This is a breaking change for consumers using the old mint watcher/processor config keys,
  manager methods, or `mint-quote:*` events.

## 1.1.2-rc.48

### Patch Changes

- db8f3c5: Add NUT-21/22 auth support (CAT/BAT lifecycle)
- 3b29203: fix: Made sure processPaymentRequest will return the decoded PR even if no mints have enough balance
- befcdcf: Fix keyset denomination handling so mint key maps are preserved with string keys instead of being
  coerced to `Number` before persistence. This avoids precision loss for large denomination keys, keeps
  split logic limited to safe integer values, and adds storage migrations that clear cached keysets so
  they are re-fetched in the corrected format.
- 16f3de1: Add changeAmount and effectiveFee to finalized melt operations for accurate settlement reporting, with adapter persistence and legacy compatibility for older melt records.
- c9e378c: Add `manager.ops` as the standard operation API for send, receive, and melt flows, including the follow-up docs and typing updates for the default `bolt11` melt path.
- 6b2ac82: Fix: added mint-level operation locking on proof selection to avoid race conditions in near-parallel execution

  > [!WARNING]
  > The lock is memory level and does not prevent race conditions in multi-process environments

## 1.1.2-rc.47

### Patch Changes

- 980cff1: feat: Added missing util method to QuotesApi (rollback, getPending/getPrepared)

## 1.1.2-rc.46

## 1.1.2-rc.45

### Patch Changes

- 30aa519: Fix: sqlite-bun package was missing from release pipeline. It's included now

## 1.1.2-rc.44

### Patch Changes

- 8bb6f67: Fix: Migrate from deprecated sqlite3 package to better-sqlite3

  Fix: Made sure bootstrap inflight check finalizes send operations when proofs are returned spent.

  WARNING: This is a breaking change for bun environments, as bun currently does not support the better-sqlite3 binding! Bun consumers should use the sqlite-bun adapter instead!!

## 1.1.2-rc.43

### Patch Changes

- 6f0ed09: feat: adds new methods to the WalletAPI:
  - `WalletApi.encode`: This method encodes a Token into a V4 cashuB token
  - `WalletApi.decode`: This method decodes a string token into its decoded Token form. It will use the internal keyset information to resolve short keyset IDs automatically

- ad87919: Feat: Add checkInflightProofs method and wired it up inside proofStateWatcher, so that inflight proofs are state-checked on startup and subscribed to if still inflight
- 2057978: Fix: Added missing startup recovery for MeltOperations
- db2baec: Feat: Add optional token field to ReceiveHistoryEntries

## 1.1.2-rc.42

### Patch Changes

- 7f02bb8: Bumped Cashu-TS to major version 3, added typechecks and fixed them

## 1.1.2-rc.41

### Patch Changes

- Upgraded build dependencies to resolve issue with type declaration files

## 1.1.2-rc.40

### Patch Changes

- 7394e3d: Added Melt Saga for safer melt operations through MeltOperationService. This Service is hooked up through the new prepare and execure methods of the quotes API. It supports generic handlers for future Bolt12 support
- ce556d0: Added pause and resume events to the lifecycle methods of manager, mostly so that plugins can react to those events and manage their own lifecycle accordingly

## 1.1.2-rc.39

### Patch Changes

- 9d9e798: Bumped the main Cashu dependency Cashu-ts

## 1.1.2-rc.38

### Patch Changes

- aa97572: fixed an issue where paymentRequestService was still missing from the ServiceKeys list and made that list a keyof ServiceMap

## 1.1.2-rc.37

### Patch Changes

- f32a8a7: Added paymentRequestService to servicemap for plugins

## 1.1.2-rc.36

### Patch Changes

- 027449f: Added PluginExtension system for coco-plugins to register their own API on the manager instance

## 1.1.2-rc.35

### Patch Changes

- 406c470: patch: make sure parsing secret does not throw on missing tags key
- 59693b5: Make sure missing transport keys on PRs are treated as inband

## 1.1.2-rc.34

## 1.1.2-rc.33

### Patch Changes

- c444053: Fixed an issue where rolling back a SendOperation would not emit proofs:saved events
- 0c191e6: Moved from Ws-focussed transport to HybridTransport
- d985f02: Added checkPendingOperaiton to SendAPI
- 05ce81d: Adjusted the PaymentRequest API for ergonomics. Also change SendAPI state naming (BREAKING)

## 1.1.2-rc.32

### Patch Changes

- b8d70c5: Added auto-recovery on throws inside SendOperationService

## 1.1.2-rc.31

### Patch Changes

- 3d270d4: Refactored Send to use saga/statemachine for state management and consistency

## 1.1.2-rc.30

### Patch Changes

- Fixed the mintservice not emitting events when re-trusting an already added mint

## 1.1.2-rc.29

### Patch Changes

- fixed build issue

## 1.1.2-rc.28

### Patch Changes

- d300ecd: Make sure that untrusted mints don't have active subscriptions

## 1.1.2-rc.27

### Patch Changes

- Fixed a build issue

## 1.1.2-rc.26

### Patch Changes

- b0a4428: Added URL normalization and respective migration
- 0fb58a0: Added PaymentRequestServices and API layer to read and handle payment requests
- e2e3374: Fix a bug in Indexeddb adapter for getLatestDerivationIndex

## 1.0.0-rc.25

### Patch Changes

- c803f3e: Added keyring / p2pk support

## 1.0.0-rc.24

### Patch Changes

- 67c25bb: Made sure WalletApi.receive has all necessary data to work on keyset v2

## 1.0.0-rc.23

### Patch Changes

- 63ea8d6: bumped cashu-ts

## 1.0.0-rc.22

## 1.0.0-rc.21

### Patch Changes

- 3904f75: Upgraded cashu-ts to fix a bug with base64 keyset ids

## 1.0.0-rc.20

### Patch Changes

- 8daa9bd: Added WalletApi.sweep method and tests

## 1.0.0-rc.19

### Patch Changes

- be6737f: Made sure that WalletApi.send does an offline send (no swap) if the coin selection satisfies the exact amount
- 0729533: Fix: made sure websocket does not subscribe twice on resume

## 1.0.0-rc.18

### Patch Changes

- d40ba84: Fixes output creation for melt flow with proper fee handling

## 1.0.0-rc.17

### Patch Changes

- make sure to respect fees on receive

## 1.0.0-rc.16

### Patch Changes

- Made sure proof pre-selection takes fees into account

## 1.0.0-rc.15

### Patch Changes

- fixed build bug

## 1.0.0-rc.14

### Patch Changes

- Added unit to keyset and filtered for sats

## 1.0.0-rc.13

### Patch Changes

- Fixed an issue with async transaction in both sqlite adapters

## 1.0.0-rc.12

### Patch Changes

- changeset init
