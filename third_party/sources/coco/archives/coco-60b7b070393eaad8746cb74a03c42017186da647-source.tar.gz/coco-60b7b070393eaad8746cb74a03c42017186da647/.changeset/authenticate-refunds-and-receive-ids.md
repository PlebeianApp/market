---
'@cashu/coco-core': minor
'@cashu/coco-react': minor
'@cashu/coco-adapter-tests': minor
---

Authenticate deterministic P2PK refund plans and add lifecycle-wide caller-supplied Receive
operation IDs.

Refund recovery now verifies the operation, mint, unit, ordered inputs, spending path, condition,
refund authority, counter allocation, and rederived output data before any reclaim dispatch. It
captures immutable canonical authority before remote I/O, gives transports only detached request
copies, and rechecks the complete durable plan, seed commitment, operation binding, and deterministic
keyset/counter derivation in the completion transaction. This prevents proof credit after mutable
alias, commitment, ABA, or nested-plan TOCTOU mutation.

Persisted refund plans now pass an exact recursive schema before commitment verification. The
seed-keyed commitment covers the whole accepted plan shape, while unknown, missing, undefined,
accessor-backed, symbol, non-plain, sparse, or extended-array data fails before any mint call. Seed
material is supplied only by a private verifier and no longer appears in completion authorization
DTOs.

`ReceiveOpsApi.prepare()` now accepts an optional `operationId`. Repeating the same canonical
Receive intent returns the exact durable operation in any lifecycle state, while conflicting
Receive intents and cross-operation-class ID reuse fail before mutation or mint I/O. Canonical
comparison ignores transient NUT-28 `p2pk_e` while retaining value-bearing proof identity, and a
matching legacy `init` row is atomically promoted to `prepared`.
