---
'@cashu/coco-core': major
'@cashu/coco-adapter-tests': minor
'@cashu/coco-sql-storage': minor
'@cashu/coco-indexeddb': minor
'@cashu/coco-sqlite': minor
'@cashu/coco-sqlite-bun': minor
'@cashu/coco-expo-sqlite': minor
---

Fence Wallet mutations with a durable namespace, owner, and never-reused generation capability.
Authority comparison now occurs inside the same adapter transaction as proof, operation, counter,
and key mutations. Root mutation methods use the same gate, stale releases cannot clear a newer
owner, and one physical store cannot be reopened under a different namespace. Repository dispatch
is deny-by-default: only explicitly reviewed read methods bypass the transaction gate, and source
plus emitted-package tests enumerate every public Memory repository method.

`initializeCoco()` now acquires authority and completes Send, Receive, Mint, Melt, and payment
request recovery before starting any watcher or processor. Custom repository adapters must
implement the new authority lifecycle contract and compare the held capability atomically in
`withTransaction`.

Only `initializeCoco()` can complete the private quiescent boot barrier. Direct Managers cannot
activate plugins or autonomous work, and uninitialized plugin disposal hooks cannot run during
failed recovery. A permanent transactional operation-ID ownership registry covers Send, Receive,
Mint, Melt, Payment Request Receive, and Attempts; migrations backfill deterministically and fail
closed on historical collisions.

Repository roots and transaction scopes now expose frozen null-prototype facades instead of
transparent proxies. Only classified own wrapper functions exist, raw implementations are not
reflectable, and captured transaction functions expire when their callback ends. Manager boot and
activation use ECMAScript-private state and module-lexical factory recovery with no public token or
completion method.

Manager and public API dependency graphs now use native-private state. Required boot recovery is
captured in non-extractable private closures and cannot be skipped by post-import prototype or
Function/Reflect intrinsic changes. Plugins no longer receive `seedService` or `walletService`, and
unavailable service requests fail before hook execution. The IndexedDB package no longer exports a
live database/schema API or concrete unfenced repository constructors; adapter aggregates do not
reflect internal database handles.
