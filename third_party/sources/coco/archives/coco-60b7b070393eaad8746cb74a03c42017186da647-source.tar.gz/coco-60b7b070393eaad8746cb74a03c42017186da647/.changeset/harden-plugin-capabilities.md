---
'@cashu/coco-core': major
---

Replace concrete plugin services with explicit immutable capability facades, sanitize values crossing
the plugin boundary, and make Core event access subscribe-only. Plugins can no longer depend on
concrete service identity, reflective implementation fields, method replacement, or event
publication.
