---
'@cashu/coco-core': major
---

Fence the complete Manager API graph, reject extension-key coercion, safely account foreign
thenables, detach plugin values through captured intrinsics, and bound disposal while guaranteeing
resource cleanup and Wallet Authority release. Factory boot may adopt the exact capability already
active on its repository root, and concurrent caller-owned Receive retries serialize before remote
preflight so identical intents converge without weakening conflict checks.

Manager API dispatch now uses trusted methods captured before plugin execution, so post-import
prototype replacement cannot capture private API receivers or start work after disposal. Adoption
of an already-active exact repository root is single-consumption and cannot attach two Managers to
one capability, including across independently evaluated source, emitted, and packed Core modules.
Repository adapters now own that synchronous attachment claim and opaque release token on the exact
root instance; uncertain durable-authority cleanup preserves the claim and fails closed.
Repository construction also uses descriptor intrinsics captured at trusted module evaluation, so
post-import intrinsic replacement cannot make attachment slots, repository facades, root properties,
transaction scopes, or cloned descriptors writable or configurable.
Repository classification, method lookup/invocation, root and scope enumeration, and Memory value
cloning now use the same captured intrinsic boundary, preventing post-import descriptor, prototype,
Reflect, or Function helper replacement from observing a raw repository implementation. Scoped
transaction command dispatch and lifetime accounting use captured collection, Promise, Proxy, and
call intrinsics as well.
Concrete Memory repositories now apply that boundary to every backing Map/Set, iterator, byte copy,
snapshot, and transaction-serialization Promise. Post-import constructor or collection-prototype
replacement cannot capture mutable durable state, forge proofs or operations, or allow overlapping
Memory transactions.
Memory persistence now uses a strict inert-value codec before repository dispatch: accessor,
function, proxy, symbol, custom-prototype, collection, cyclic, sparse, and extended branded inputs reject
without partial writes, while Amount, Date, and byte values are explicitly reconstructed. Reads
return independently detached records normalized away from caller-controlled prototypes.
Proxy graphs are identified through a captured native preflight before reflective traversal or
transaction scheduling, preventing validation traps from issuing reentrant repository writes.
P2PK refund transport inputs now remain detached while reconstructing fresh valid cashu-ts `Amount`
values, allowing initial reclaim and recovery replay to converge without weakening plan authority.
