---
'@cashu/coco-core': major
---

Revoke every plugin capability and public subscription entry point when Manager disposal begins,
scope extension registration to its active lifecycle hook, and detach supported class and Response
return values instead of freezing Core-owned instances. Directly constructed Managers can no longer
create subscription transports, and unsupported plugin return classes now fail closed.
