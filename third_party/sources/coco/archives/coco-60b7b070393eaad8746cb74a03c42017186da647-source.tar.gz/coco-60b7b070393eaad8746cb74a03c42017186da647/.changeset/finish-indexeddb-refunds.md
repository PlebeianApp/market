---
'@cashu/coco-core': patch
---

Prepare P2PK refund-plan verification before opening the Wallet persistence transaction so browser
IndexedDB completion can atomically credit the already-issued proofs and finalize the original Send.
Keep the completion DTO seed-free and retain synchronous in-transaction plan authentication and
deterministic output re-derivation for initial, Restore, and ambiguous-response recovery paths.
Treat each refund-only seed buffer as an owned ephemeral value and zeroize allocation,
authentication, completion-retry, and per-attempt verification copies on every exit path.
