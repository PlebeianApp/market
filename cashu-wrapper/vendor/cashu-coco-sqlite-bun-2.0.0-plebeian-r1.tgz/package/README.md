# Coco Bun SQLite adapter — POC pin R1

This is the bundled `packages/sqlite-bun` adapter from Coco commit
`60b7b070393eaad8746cb74a03c42017186da647`, the exact source commit from
which the POC's vendored `@cashu/coco-core` 2.0.0 archive was packed.

Source inspected read-only at
`/home/maximoto/dev/coco-market-mint-request-fetch-r1-2026-10-14`.
`packages/sqlite-bun` and `packages/sql-storage` were clean relative to that
commit. The JavaScript bundle was produced with Bun while keeping
`@cashu/coco-core`, its adapter entry point, and `@cashu/cashu-ts` external.

The public npm `@cashu/coco-sqlite-bun@2.0.0` was tested first and rejected:
although its peer versions matched, it lacked the pinned core's repository
authority methods and `findMintByUrl` storage contract. No registry package or
patched `node_modules` file is retained by this pin.
