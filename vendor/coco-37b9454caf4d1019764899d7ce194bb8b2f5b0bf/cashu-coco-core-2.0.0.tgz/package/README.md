# @cashu/coco-core

Modular, storage-agnostic core for working with Cashu mints and wallets.

- **Storage-agnostic**: Repositories are interfaces; bring your own persistence.
- **Typed Event Bus**: Subscribe to mint, proof, quote, and counter events with strong types.
- **High-level APIs**: `MintApi`, `WalletApi`, `AuthApi`, `PaymentRequestsApi`,
  `QuoteApi`, `HistoryApi`, `KeyRingApi`, and `manager.ops.*` for common flows.
- **Background watchers**: Optional services to track quote/payment and proof states.

## Install

```bash
npm install @cashu/coco-core
```

For a real application you will usually install a storage adapter alongside the
core package, for example `@cashu/coco-sqlite`, `@cashu/coco-indexeddb`, or
`@cashu/coco-expo-sqlite`. Bun applications can use `@cashu/coco-sqlite-bun`.

## Entry points

`@cashu/coco-core` publishes three stable import surfaces. Pick the narrowest
one that matches what you are building:

```ts
// App and React usage
import { initializeCoco, Amount, type Manager } from '@cashu/coco-core';

// Storage adapter implementations and adapter contract tests
import { type Repositories, serializeAmount } from '@cashu/coco-core/adapter';

// Plugin authors
import type { Plugin, PluginExtensions } from '@cashu/coco-core/plugin';
```

- Use the package root for app-facing wallet setup, manager APIs, public models,
  errors, amount helpers, events, logging, and config boundary types.
- Use `@cashu/coco-core/adapter` when you are writing persistence adapters or
  adapter contract tests. Repository contracts, persisted operation/domain
  shapes, and serialization helpers live there.
- Use `@cashu/coco-core/plugin` when you are writing extensions. Plugin
  lifecycle types, extension augmentation types, plugin service keys, and plugin
  errors live there.

Concrete services, operation service classes, handler providers, transport
internals, `PluginHost`, and individual memory repository classes are
implementation details. They are not app-facing root API.

## Protocol Support

- [x] NUT-00
- [x] NUT-01
- [x] NUT-02
- [x] NUT-03
- [x] NUT-04
- [x] NUT-05
- [x] NUT-06
- [x] NUT-07
- [x] NUT-08
- [x] NUT-09
- [x] NUT-10
- [x] NUT-11
- [x] NUT-12
- [x] NUT-13
- [ ] NUT-14
- [ ] NUT-15
- [ ] NUT-16
- [x] NUT-17
- [x] NUT-18
- [ ] NUT-19
- [ ] NUT-20
- [x] NUT-21
- [x] NUT-22
- [x] NUT-23
- [ ] NUT-24
- [ ] NUT-25

## Quick start

```ts
import { initializeCoco, MemoryRepositories, ConsoleLogger } from '@cashu/coco-core';

// Provide a deterministic 64-byte seed for wallet key derivation
const seedGetter = async () => seed;

const repos = new MemoryRepositories();
const logger = new ConsoleLogger('example', { level: 'info' });

const manager = await initializeCoco({
  repo: repos,
  seedGetter,
  logger,
});

// Subscribe to events (typed)
const unsubscribe = manager.on('counter:updated', (c) => {
  console.log('counter updated', c);
});

// Register a mint
await manager.mint.addMint('https://nofees.testnut.cashu.space');

// Create a mint quote, prepare an operation, pay externally, then redeem
const quote = await manager.quotes.mint.create({
  mintUrl: 'https://nofees.testnut.cashu.space',
  amount: 100,
  method: 'bolt11',
});

const pendingMint = await manager.ops.mint.prepare({
  quote,
  amount: 100,
});

const completed = new Promise<void>((resolve, reject) => {
  let offFinalized = () => {};
  let offFailed = () => {};
  const cleanup = () => {
    offFinalized();
    offFailed();
  };

  offFinalized = manager.on('mint-op:finalized', ({ operationId }) => {
    if (operationId !== pendingMint.id) return;
    cleanup();
    resolve();
  });
  offFailed = manager.on('mint-op:failed', ({ operationId, operation }) => {
    if (operationId !== pendingMint.id) return;
    cleanup();
    reject(new Error(operation.terminalFailure?.reason ?? operation.error ?? 'Mint failed'));
  });
});

// pay pendingMint.request externally; default processors finalize after payment
await completed;

// Check balances
const balances = await manager.wallet.balances.byMint();
const total = await manager.wallet.balances.total();
console.log('balances', balances);
console.log('wallet total', total.total);

// Inspect spendable vs reserved funds explicitly when needed
console.log('spendable balance', balances['https://nofees.testnut.cashu.space']?.spendable ?? 0);
console.log('reserved balance', balances['https://nofees.testnut.cashu.space']?.reserved ?? 0);
```

### Watchers & processors (optional)

Start background watchers or processors to automatically react to changes:

```ts
// Watch mint operation quote updates on startup and while running (default true)
await manager.enableMintOperationWatcher({ watchExistingPendingOnStart: true });

// Process queued mint operations from live events (auto-enabled by initializeCoco)
await manager.enableMintOperationProcessor({ processIntervalMs: 3000 });

// Watch canonical melt quote updates and settle pending melt operations
await manager.enableMeltQuoteWatcher();
await manager.enableMeltSettlementProcessor();

// Watch proof state updates (e.g., to move inflight proofs to spent)
await manager.enableProofStateWatcher();

// Later, you can stop them
await manager.disableMintOperationWatcher();
await manager.disableMintOperationProcessor();
await manager.disableMeltQuoteWatcher();
await manager.disableMeltSettlementProcessor();
await manager.disableProofStateWatcher();
```

### initializeCoco options

`initializeCoco` sets up repositories, plugins, watchers, and processors for you. You can configure it via `CocoConfig`:

- `repo`: `Repositories` implementation (required)
- `seedGetter`: async seed provider (required)
- `logger`: optional logger (defaults to `NullLogger`)
- `webSocketFactory`: optional WebSocket factory
- `plugins`: optional plugin list
- `watchers`: enable/disable watcher services (`mintOperationWatcher`, `meltQuoteWatcher`,
  `proofStateWatcher`)
- `processors`: enable/disable processors (`mintOperationProcessor`, `meltSettlementProcessor`)
  and tune intervals
- `subscriptions`: polling intervals for hybrid WebSocket + polling (`slowPollingIntervalMs`, `fastPollingIntervalMs`)
- `lifecycle.disposeTimeoutMs`: bounded disposal/drain interval in milliseconds (default: `5000`)

`initializeCoco()` is the only public boot path that can complete the recovery barrier and activate
plugins, subscriptions, watchers, or processors. A directly constructed `Manager` remains
permanently quiescent: `initPlugins()`, `resumeSubscriptions()`, and every autonomous start method
reject. Its public `subscriptions` value is a lifecycle-fenced facade, so direct construction cannot
create a transport. The same private gate wraps every method under `mint`, `wallet` and balances,
`keyring`, `history`, `auth`, `ops`, `quotes`, and `paymentRequests`; inactive or disposed calls fail
before logging, seed access, storage access, callback registration, cache access, or network I/O.
Those facades invoke an explicit allowlist of original API methods captured when the trusted Core
module is evaluated. Later replacement of an exported API prototype is never consulted and never
receives a private API implementation as its receiver. Nested operation recovery and diagnostics
functions are captured once from own data properties during trusted Manager construction.
Direct construction is retained for narrow manual service composition and tests, not as an
alternative Wallet boot sequence. Activation is ECMAScript-private; there is no constructor token,
global symbol, reflected field, or public recovery-completion method that a host can forge.
Required recovery runs through Manager-owned native-private closures registered during trusted
construction. Post-import changes to public service/Manager prototypes, `Function.prototype`
intrinsics, or `Reflect.apply` cannot skip those tasks. A same-realm attacker that changes language
intrinsics before the package module graph is evaluated is outside this boundary; applications
must load trusted code before untrusted same-realm code.

The factory normally acquires a fresh repository capability. It may also adopt a capability already
active on the exact supplied repository root; when `authority` is provided, its namespace and owner
must match that active capability. Adoption transfers release ownership to the returned Manager and
is single-consumption for that exact root object: concurrent, re-entrant, or later factory calls with
the same attached root reject before repository startup. Confirmed startup cleanup rolls back the
attachment claim; disposal releases it only after the authority release attempt completes. Peer
roots remain independent and may acquire a newer generation, fencing the old session. Released,
stale, and otherwise invalid roots are rejected.

## Architecture

- `Manager` is the app-facing facade. It exposes `mint`, `wallet`, `auth`,
  `quotes`, `paymentRequests`, `ops`, `history`, and `keyring` APIs plus watcher
  and processor helpers.
- `initializeCoco` wires the manager from a `CocoConfig`, including
  repositories, seed access, logging, subscriptions, plugins, watchers, and
  processors.
- `manager.ops.*` is the supported surface for recoverable send, receive, mint,
  and melt lifecycles.
- `manager.quotes.mint` and `manager.quotes.melt` expose canonical quote lookup,
  creation, and refresh workflows.
- `manager.on(...)` exposes typed `CoreEvents`, including subscription,
  operation, proof, quote, history, mint, and auth-session events.

### Storage

Initialize Coco with the built-in storage adapter for your runtime. The package root also exports
`MemoryRepositories` for in-memory tests and examples. See [Storage Adapters](../docs/pages/storage-adapters.md)
for setup and storage-security guidance.

## Public API surface

### Manager

- `mint`, `wallet`, `auth`, `quotes`, `paymentRequests`, `ops`, `history`, and
  `keyring`
- `ext: PluginExtensions` from `@cashu/coco-core/plugin`
- `on/once/off` for `CoreEvents`
- `enableMintOperationWatcher()`, `disableMintOperationWatcher()`
- `enableMintOperationProcessor()`, `disableMintOperationProcessor()`,
  `waitForMintOperationProcessor()`
- `enableMeltQuoteWatcher()`, `disableMeltQuoteWatcher()`
- `enableMeltSettlementProcessor()`, `disableMeltSettlementProcessor()`
- `enableProofStateWatcher()`, `disableProofStateWatcher()`
- `pauseSubscriptions()`, `resumeSubscriptions()`
- `subscriptions`, a lifecycle-fenced subscribe/pause/resume/diagnostics facade (not the backing
  transport manager)
- `use(plugin: Plugin): void` with `Plugin` from `@cashu/coco-core/plugin`
- `initPlugins(): Promise<void>`
- `dispose(): Promise<void>`

### OpsApi

- `send`: `prepare`, `execute`, `get`, `listPrepared`, `listInFlight`,
  `refresh`, `cancel`, `reclaim`, plus `recovery` and `diagnostics`
- `receive`: `prepare`, `execute`, `get`, `listPrepared`, `listInFlight`,
  `refresh`, `cancel`, plus `recovery` and `diagnostics`
- `mint`: `prepare`, `execute`, `get`, `listByQuote`,
  `listPending`, `listInFlight`, `checkPayment`, `refresh`, `finalize`, plus
  `recovery` and `diagnostics`. Built-in methods: `bolt11`, `onchain`,
  `bolt12`.
- `melt`: `prepare`, `execute`, `get`, `getByQuote`, `listByQuote`,
  `listPrepared`, `listInFlight`, `refresh`, `cancel`, `reclaim`, `finalize`,
  plus `recovery` and `diagnostics`. Built-in methods: `bolt11`, `bolt12`,
  `onchain`.

Receive callers that need to bind a durable host command before money moves should supply an exact
operation ID:

```ts
const receive = await manager.ops.receive.prepare({
  token,
  operationId: sellerWinnerClaimId,
});
```

The ID is used verbatim and must be non-empty with no surrounding whitespace. The first call
atomically creates the Receive operation, allocates deterministic outputs/counters, and binds the
exact input proof set. A retry with the same ID and canonical token intent returns the exact durable
operation in any lifecycle state, including `finalized` or `rolled_back`; it does not allocate or
contact the mint again. A changed mint, unit, amount, proof set, or an ID already owned by another
operation class fails before mutation or mint I/O. Hosts can therefore reconcile a terminal retry
directly instead of guessing whether the command should be issued again.

The canonical Receive intent normalizes mint URL, unit, amount, source, and the value-bearing proof
identity (`id`, amount, secret, and `C`) independently of proof order. Transient NUT-28 `p2pk_e`,
DLEQ material, and caller witness data are not persisted intent; the signed condition remains bound
by the proof secret. A matching legacy `init` row is atomically promoted to `prepared` on retry.

Operation IDs are globally owned across Send, Receive, Mint, Melt, Payment Request Receive, and
Payment Request Receive Attempt rows. Creation claims ownership in the same transaction as the row;
losers allocate no counters, reserve no proofs, and perform no mint I/O. Claims survive terminal
state and row deletion, so an ID is never silently recycled. Adapter migrations backfill existing
rows and fail closed if historical classes already collide.

Mint and melt quote lookups use `QuoteIdentity`, the methodless object shape
`{ mintUrl, quoteId }`:

```ts
const mintIdentity = { mintUrl: mintQuote.mintUrl, quoteId: mintQuote.quoteId };

await manager.quotes.mint.get(mintIdentity);
await manager.quotes.mint.refresh(mintIdentity);
await manager.ops.mint.listByQuote(mintIdentity);

const meltIdentity = { mintUrl: meltQuote.mintUrl, quoteId: meltQuote.quoteId };

await manager.quotes.melt.get(meltIdentity);
await manager.quotes.melt.refresh(meltIdentity);
await manager.ops.melt.getByQuote(meltIdentity);
await manager.ops.melt.listByQuote(meltIdentity);
```

Operation preparation accepts structural quote refs. `MintQuoteRef` and
`MeltQuoteRef` are `{ mintUrl, quoteId, method }`, and full canonical quote
objects already satisfy those types. Mint prepare uses
`prepare({ quote, amount })`; BOLT melt prepare uses `prepare({ quote })`; and
onchain melt prepare uses `prepare({ quote, feeIndex })`. Public operation
prepare inputs do not accept sibling `unit`, `method`, or `methodData` fields;
those details are derived from canonical quote storage.

### MintApi

- `addMint(mintUrl: string, options?: { trusted?: boolean }): Promise<{ mint: Mint; keysets: Keyset[] }>`
- `getMintInfo(mintUrl: string): Promise<MintInfo>`
- `isTrustedMint(mintUrl: string): Promise<boolean>`
- `getAllMints(): Promise<Mint[]>`
- `getAllTrustedMints(): Promise<Mint[]>`
- `trustMint(mintUrl: string): Promise<void>`
- `untrustMint(mintUrl: string): Promise<void>`

### WalletApi

- `receive(token: Token | string): Promise<void>`
- `balances.byMint(scope?: { mintUrls?: string[]; units?: string[]; trustedOnly?: boolean }): Promise<BalancesByMint>`
- `balances.byMintAndUnit(scope?: { mintUrls?: string[]; units?: string[]; trustedOnly?: boolean }): Promise<BalancesByMintAndUnit>`
- `balances.byUnit(scope?: { mintUrls?: string[]; units?: string[]; trustedOnly?: boolean }): Promise<BalancesByUnit>`
- `balances.total(scope?: { mintUrls?: string[]; units?: string[]; trustedOnly?: boolean }): Promise<BalanceSnapshot>`
- `balances.totalByUnit(scope?: { mintUrls?: string[]; units?: string[]; trustedOnly?: boolean }): Promise<BalancesByUnit>`
- `restore(mintUrl: string, options?: { units?: string[] }): Promise<void>`
- `sweep(mintUrl: string, bip39seed: Uint8Array, options?: { units?: string[] }): Promise<void>`
- `decodeToken(tokenString: string, mintUrl?: string): Promise<Token>`
- `encodeToken(token: Token, opts?: { removeDleq?: boolean }): string`
- `encodePaymentRequest(paymentRequest: PaymentRequest, version?: 'creqA' | 'creqB'): string`

### AuthApi

- `startDeviceAuth(mintUrl: string)`
- `login(mintUrl, tokens): Promise<AuthSession>`
- `restore(mintUrl): Promise<boolean>`
- `logout(mintUrl): Promise<void>`
- `getSession(mintUrl): Promise<AuthSession>`
- `hasSession(mintUrl): Promise<boolean>`
- `getAuthProvider(mintUrl): AuthProvider | undefined`
- `getPoolSize(mintUrl): number`

### PaymentRequestsApi

- `parse(paymentRequest: string): Promise<ResolvedPaymentRequest>`
- `prepare(request: ResolvedPaymentRequest, options: { mintUrl: string; amount?: AmountLike }): Promise<PreparedPaymentRequest>`
- `execute(transaction: PreparedPaymentRequest): Promise<PaymentRequestExecutionResult>`
- `incoming.create(input: CreateIncomingPaymentRequestInput): Promise<PaymentRequestReceiveOperation>`

### QuoteApi

- `mint.create(...)`, `mint.import(...)`, `mint.get({ mintUrl, quoteId })`
- `mint.listPending({ method? })`, `mint.refresh({ mintUrl, quoteId })`
- `melt.create(...)`, `melt.get({ mintUrl, quoteId })`
- `melt.listPending({ method? })`, `melt.refresh({ mintUrl, quoteId })`

Quote refreshes persist canonical quote snapshots before emitting
`mint-quote:updated` or `melt-quote:updated`. Use `manager.on(...)` for live
application flows and operation APIs when a mint or melt should be finalized.

### HistoryApi

- `getPaginatedHistory(offset?: number, limit?: number): Promise<HistoryEntry[]>`
- `getHistoryEntryById(id: string): Promise<HistoryEntry | null>`
- `getOperationIdForHistoryEntry(id: string): Promise<string | null>`

### KeyRingApi

- `generateKeyPair(dumpSecretKey?: boolean): Promise<{ publicKeyHex: string } | Keypair>`
- `addKeyPair(secretKey: Uint8Array): Promise<Keypair>`
- `removeKeyPair(publicKey: string): Promise<void>`
- `getKeyPair(publicKey: string): Promise<Keypair | null>`
- `getLatestKeyPair(): Promise<Keypair | null>`
- `getAllKeyPairs(): Promise<Keypair[]>`

### Subscriptions in Node vs browser

`Manager` will auto-detect a global `WebSocket` if available (e.g., browsers).
In non-browser environments, provide a `webSocketFactory` through
`initializeCoco` or `Manager` construction. App code should not need transport
internals.

## Core events

See the `CoreEvents` type for the full, current event map. Common events
include:

- `mint:added` → `{ mint, keysets }`
- `mint:updated` → `{ mint, keysets }`
- `mint:trusted` → `{ mintUrl }`
- `mint:untrusted` → `{ mintUrl }`
- `counter:updated` → `Counter`
- `proofs:saved` → `{ mintUrl, keysetId, proofs }`
- `proofs:state-changed` → `{ mintUrl, secrets, state }`
- `proofs:deleted` → `{ mintUrl, secrets }`
- `proofs:wiped` → `{ mintUrl, keysetId }`
- `proofs:reserved` → `{ mintUrl, operationId, secrets, amount }`
- `proofs:released` → `{ mintUrl, secrets }`
- `mint-quote:updated` → `{ mintUrl, method, quoteId, quote }`
- `melt-quote:updated` → `{ mintUrl, method, quoteId, quote }`
- `mint-op:pending` → `{ mintUrl, operationId, operation }`
- `mint-op:requeue` → `{ mintUrl, operationId, operation }`
- `mint-op:executing` → `{ mintUrl, operationId, operation }`
- `mint-op:finalized` → `{ mintUrl, operationId, operation }`
- `mint-op:failed` → `{ mintUrl, operationId, operation }`
- `send:prepared` → `{ mintUrl, operationId, operation }`
- `send:pending` → `{ mintUrl, operationId, operation, token }`
- `send:finalized` → `{ mintUrl, operationId, operation }`
- `send:rolled-back` → `{ mintUrl, operationId, operation }`
- `receive-op:prepared` → `{ mintUrl, operationId, operation }`
- `receive-op:finalized` → `{ mintUrl, operationId, operation }`
- `receive-op:rolled-back` → `{ mintUrl, operationId, operation }`
- `history:updated` → `{ mintUrl, entry }`
- `melt-op:prepared` → `{ mintUrl, operationId, operation }`
- `melt-op:pending` → `{ mintUrl, operationId, operation }`
- `melt-op:finalized` → `{ mintUrl, operationId, operation }`
- `melt-op:rolled-back` → `{ mintUrl, operationId, operation }`
- `subscriptions:paused` / `subscriptions:resumed`
- `auth-session:updated` / `auth-session:deleted` / `auth-session:expired`

## Plugins

### Overview

- **Purpose**: Extend the core by hooking into lifecycle events with access only to the services you declare.
- **Lifecycle hooks**: `onInit` (after services are created), `onReady` (after APIs are built), `onDispose` (on shutdown).
- **Cleanup**: Hooks must return a cleanup function (sync or async), similar to React’s `useEffect`.

### Types

```ts
import type { Plugin, ServiceKey } from '@cashu/coco-core/plugin';

// Service keys are derived from the exported plugin ServiceMap type.
// Use ServiceKey when you want the current full set without duplicating it here.

const myPlugin: Plugin<['eventBus', 'logger']> = {
  name: 'my-plugin',
  required: ['eventBus', 'logger'] as const,
  onInit: ({ services: { eventBus, logger } }) => {
    const off = eventBus.on('mint:added', (p) => logger.info('mint added', p));
    return off;
  },
  onReady: async () => {
    // optional
  },
  onDispose: () => {
    // optional
  },
};
```

Plugins that ingest externally created mint quotes can request the canonical
quote API:

```ts
const quotePlugin: Plugin<['quotes']> = {
  name: 'quote-plugin',
  required: ['quotes'] as const,
  onReady: async ({ services }) => {
    await services.quotes.mint.import({
      mintUrl,
      method: 'bolt11',
      quote,
    });
  },
};
```

### Using plugins

```ts
// Pass plugins through the recovery-owning factory.
const manager = await initializeCoco({
  repo: repos,
  seedGetter,
  logger,
  plugins: [myPlugin],
});

// Or register later after factory boot.
manager.use(myPlugin);

// Dispose (runs onDispose and registered cleanups)
await manager.dispose();
```

When using `initializeCoco()`, plugin `onInit` and `onReady` hooks run only after legacy
reconciliation and all Send, Melt, Receive, Payment Request Receive, and Mint recovery has completed
and quiescence has been marked. Watchers and processors start after plugin readiness.

Plugins registered before initialization failure receive no lifecycle or disposal hook. A plugin's
`onDispose` becomes eligible only once its `onInit` has actually begun, and returned cleanup
functions run only if they were registered. This prevents a pre-recovery cleanup hook from obtaining
a mutation opportunity while Wallet authority is live.

Disposal revokes lifecycle authority synchronously and immediately stops transports and autonomous
callback producers. Native promises and foreign/custom thenables remain accounted until settlement,
but only through the configured bounded drain. A stuck operation, `onDispose`, or cleanup cannot
block durable Wallet Authority release; cleanup continues best-effort and `dispose()` reports an
aggregate deadline failure only after release.

Plugins never receive concrete internal services. Every `ServiceMap` key resolves to a separate,
frozen, null-prototype capability facade with an explicit method allowlist. Plugin contexts and
selected service maps are frozen, callback payloads and return values are sanitized, and errors do
not carry internal cause graphs. Internal method additions therefore fail closed until the matching
plugin capability is deliberately extended. Reflective service identity, method replacement,
repository/transaction access, and Core event publication are not supported plugin APIs.

All plugin capabilities share Manager-owned lifecycle authority. It is inactive during recovery,
activated only after the private recovery barrier, and irreversibly revoked before disposal yields
or tears down resources. Calls retained by a plugin therefore reject after disposal; cleanup-only
unsubscribe/off handles become harmless no-ops. `registerExtension` is valid only while the
particular `onInit` or `onReady` hook that received it is executing and expires as soon as that hook
settles. Keys must be primitive strings containing 1–128 UTF-16 code units. Objects, proxies, boxed
strings, symbols, and empty/oversized keys are rejected without coercion. `__proto__`, `prototype`,
and `constructor` remain safe ordinary keys in the null-prototype extension namespace.

Objects crossing the plugin boundary are detached rather than frozen in place. Supported value
types have explicit adapters (`PaymentRequest`, `Response`, `Amount`, `OutputData`, dates, buffers,
arrays, and plain records); unsupported class instances fail closed. Adapters use captured native
operations, own data descriptors, and indexed copies rather than source methods, getters, iterators,
or constructors. A plugin can mutate only its detached copy and cannot change a Core-owned, logged,
or persisted value. Detached callable values such as `OutputData.toProof` remain lifecycle-revocable.

Plugins never receive the raw Wallet Seed or a low-level wallet object that contains it, including
trusted first-party plugins. `seedService` and `walletService` are not part of `ServiceMap`; requests
for unavailable service keys are rejected before the plugin hook begins. `walletRestoreService`
accepts caller-supplied restore material but never returns the configured Wallet. Explicit P2PK and
proof capabilities may return their documented derived key material or proof secrets; those are
intentional sensitive domain outputs and are distinct from the master Wallet Seed.

### Error handling

- Errors thrown in `onInit`, `onReady`, and `onDispose` are caught. Hook errors are logged with the plugin name; a failure during plugin boot is also logged by the injected `Logger`.

## Exports

From the package root (`@cashu/coco-core`), for app and React usage:

- `Manager`, `initializeCoco`, `CocoConfig`
- `MemoryRepositories`
- Public APIs including `MintApi`, `WalletApi`, `AuthApi`, `PaymentRequestsApi`,
  `QuoteApi`, and the operation-oriented APIs
- Public models, errors, API inputs/results, and operation result types
- Events: `CoreEvents`, `EventHandler`
- Types: `CoreProof`, `ProofState`, `BalanceQuery`, `BalanceSnapshot`,
  `BalancesByMint`, `BalanceBreakdown`, `BalancesBreakdownByMint`
- Logging: `ConsoleLogger`, `Logger`
- Helpers: `getEncodedToken`, `getDecodedToken`, `normalizeMintUrl`
- Amount/unit helpers and intentional `@cashu/cashu-ts` re-exports such as `Amount`
- Config boundary types: `WebSocketLike`, `WebSocketFactory`

From the adapter subpath (`@cashu/coco-core/adapter`), for storage adapter
implementations and adapter contract tests:

- Repository contracts, transaction scope types, persisted operation/domain types, and
  adapter serialization helpers for storage implementations

From the plugin subpath (`@cashu/coco-core/plugin`), for extension authors:

- Plugin author types: `Plugin`, `PluginContext`, `PluginExtensions`, `PluginEventBus`,
  `ServiceKey`, `ServiceMap`, the `Plugin*Capability` interfaces, `Cleanup`, `CleanupFn`
- Plugin errors: `DuplicatePluginRegistrationError`, `ExtensionRegistrationError`

The package root (`@cashu/coco-core`) is the supported public import path unless
`package.json` explicitly lists a subpath export. Documented public symbols must be
reachable from the root or from a listed subpath. Internal barrels such as source
folder indexes are private unless the export map and docs explicitly make them public.
